#include "Strategy.h"
#include "Formation.h"
#include "InfoState.h"
#include "PositionInfo.h"
#include "InterceptInfo.h"
#include "PossibilityModel.h"
#include "MotionModel.h"
#include "Tackler.h"
#include "Dasher.h"

//==============================================================================
Strategy::Strategy(Agent & agent):
	DecisionData(agent)
{
    mFocusScoreTmTime = Time(-3, 0);
    mFocusScoreOppTime = Time(-3, 0);

    memset(mTeammateAimAngle, 0, sizeof(mTeammateAimAngle));
    memset(mOpponentAimAngle, 0, sizeof(mOpponentAimAngle));

    mDefenseCycle = 0;
    mControllerBlockedCycle = 0.0;
    mSituation = ST_Defense;

    mPenaltyAttackCycle = 0;
    mIsAttackInAdvantage = false;

    mLastController = 0;

    mIsPenaltyFirstStep = false;
    mPenaltyTaker = 0;
    mPenaltySetupTime = 0;

    mIsBallActuralKickable = false;
    mIsBallFree = false;
    mController = 0;
    mChallenger = 0;

    memset(mActiveBehavior, 0, sizeof(mActiveBehavior));
    memset(mLastActiveBehavior, 0, sizeof(mLastActiveBehavior));

    mAttackPhase = AP_None;
}


//==============================================================================
Strategy::~Strategy()
{

	ResetSavedActiveBehavior();

	for (int type = BT_None + 1; type < BT_Max; ++type) {
		delete mLastActiveBehavior[type];
	}
}

/**
 * �ж����Ƿ����
 * judge whether I can control the ball
 * @return true when the ball is control by myself
 */
bool Strategy::IsMyControl() const
{
	return mController == mAgent.GetSelfUnum();
}

/**
 * �ж����Ƿ����ϴο������
 * judge whether the ball is controled by me at last time
 * @return true when the ball is controled by me at last time
 */

bool Strategy::IsLastMyControl() const
{
    return mLastController == mAgent.GetSelfUnum();
}

/**
 * �ж����Ƿ��Ǳ����ѿ���
 * judge whether the ball is kickable by a teammate
 * @return true when the ball is kickable by a teammate
 */
bool Strategy::IsTmKickable() const
{
	return (mInfoState.GetPositionInfo().GetTeammateWithBall() > 0);
}

/**
 * �жϵ�ǰ�Ƿ�����ߵ���
 * judge whether I commit the penalty
 * @return true when I commit the penalty
 */
bool Strategy::IsMyPenaltyTaken() const
{
	return (mWorldState.GetPlayMode() == PM_Our_Penalty_Taken) &&
	       (mAgent.GetSelfUnum() == mPenaltyTaker);
}

//==============================================================================
void Strategy::UpdateRoutine()
{
	ResetSavedActiveBehavior();
	if ( !PlayerParam::instance().isCoach() ) DashGetBallFix();
	StrategyAnalyze();
	PenaltyAnalyze();
}

void Strategy::DashGetBallFix()
{
	PlayerInterceptInfo * const pInfo = mInfoState.GetInterceptInfo().GetPlayerInterceptInfo(mSelfState.GetUnum());

	Assert(pInfo);
	if (!pInfo) return;

	for(int n = 1; n <= 10; ++n){ //���� -- 1 �� 10 ����
        if( Dasher::instance().CalcDashGetBallInfo(mAgent, n)){
			if( n <= pInfo->mInterCycle[0] ){
				pInfo->mInterCycle[0] = n;
				if (pInfo->mIntervals > 1){
					pInfo->mInterCycle[1] = Max(pInfo->mInterCycle[0], pInfo->mInterCycle[1]);
					pInfo->mInterCycle[2] = Max(pInfo->mInterCycle[1], pInfo->mInterCycle[2]);
				}

				pInfo->mMinCycle = pInfo->mInterCycle[0];
				if (pInfo->mMinCycle == 0) pInfo->mIntervals = 0; //��ʾ����

				pInfo->mInterPos = mBallState.GetPredictedPos(pInfo->mMinCycle);

                if(Dasher::instance().GetDashGetBallInfo(n).mChangeCycle <= 1){
                    pInfo->mDashPowerToUse = (Dasher::instance().GetDashGetBallInfo(n).mDashPower[0] + Dasher::instance().GetDashGetBallInfo(n).mDashPower[3]) /2.0;
				}
                else {
                	pInfo->mDashPowerToUse = 100.0;
                }

				if (!ServerParam::instance().pitchRectanglar().IsWithin(pInfo->mInterPos, 4.0)){
					pInfo->mRes = IR_Failure;
				}
				else {
					pInfo->mRes = IR_Success;
				}
			}
			break;
		}
	}
}

void Strategy::StrategyAnalyze()
{
    mIsLastBallFree = mIsBallFree;
    if (mIsBallFree == false)//��¼�ϴβ�freeʱ��״̬���ο�WE2008
    {
        mLastController = mController;
		mLastChallenger = mChallenger;
    }




	mIsBallActuralKickable = false;
	mIsBallFree = true;
	mController = 0;

	mMyInterCycle = 150;
	mMinTmInterCycle = 150;
	mMinOppInterCycle = 150;
	mMinIntercCycle = 150;
	mSureTmInterCycle = 150;
	mSureOppInterCycle = 150;
	mSureInterCycle = 150;
	mFastestTm = 0;
	mFastestOpp = 0;
	mSureTm = 0;
	mSureOpp = 0;

	mBallInterPos = mWorldState.GetBall().GetPos();
	mBallFreeCycleLeft = 0;
	mBallOutCycle = 1000;

	mController = 0;
	mChallenger = 0;

	BallPossessionAnalyse();
	SituationAnalyse();

	//������ģ���������
	if (mSelfState.GetTackleProb() < FLOAT_EPS) {
		PlayerInterceptInfo* pInfo = & mMyTackleInfo;

		VirtualSelf virtual_self(mSelfState);

		virtual_self.UpdateIsGoalie(false); //������ÿ��˷�Χ����ɲ���Χ�������

		pInfo->mRes = IR_None;
		pInfo->mpPlayer = & virtual_self;
		pInfo->mIdleCycle = 0;

		if ( mIsBallFree) {
			InterceptInfo::CalcInterception(mBallState.GetPos(), mBallState.GetVel(), pInfo, false);
			if (pInfo->mMinCycle >= mSureInterCycle || (mController > 0 && mController != mSelfState.GetUnum())) {
				pInfo->mRes = IR_Failure;
			}
		}
	}
	else {
		mMyTackleInfo.mRes = IR_Success;
		mMyTackleInfo.mMinCycle = 0;
	}
}

/**
 * ����tm_unum�Ŷ��ѵ�Ŀ�귽��
 * get the aim angle of the teammate whose number is tm_unum
 * @param tm_unum
 * @return the aim angle
 */
AngleDeg Strategy::CalcAimAngleForTeammate(const Unum &tm_unum)
{
    Assert(tm_unum >= 1 && tm_unum <= TEAMSIZE);

    const PlayerState &player = mWorldState.GetTeammate(tm_unum);

	const double Interval = 6.6;
    RoleType role = mAgent.GetFormation().GetTeammateRoleType(tm_unum);
    Vector target = Vector(48.0, 0.0);
    target.SetY((role.mIndexY - (mAgent.GetFormation().GetTeammateLineArrange(role.mIndexX) + 1) * 0.5 ) * Interval);

	if (mSituation == ST_Penalty_Attack)
    {
        if (player.GetPos().Dist(target) < 2.6)
        {
			target = Vector(48.0, 0.0);
		}
	}
    else if(mSituation == ST_Forward_Attack && role.mLineType == LT_Forward)
    {
        const std::vector<Unum> &opp_vector = mInfoState.GetPositionInfo().GetCloseOpponentToTeammate(player.GetUnum());
        if (opp_vector.size() > 0)
        {
		    // ��ϸ΢����
		    Unum opp_unum = opp_vector[0];
            const PlayerState &opp = mWorldState.GetOpponent(opp_unum);
            if (opp.IsAlive() == true && opp.GetPosConf() > FLOAT_EPS)
            {
                Vector pos = opp.GetPredictedPos(1) - player.GetPredictedPos(1);
		        if (pos.Mod() < 5.0)
                {
                    if (fabs(pos.Y()) < 1.0)
                    {
                        if (mBallInterPos.Y() > player.GetPredictedPos(1).Y())
                        {
                            target.SetY(target.Y() + 2.6);
				        }
                        else
                        {
                            target.SetY(target.Y() - 2.6);
				        }
			        }
                    else
                    {
                        target.SetY(target.Y() - 1.6 * Sign(pos.Y()));
			        }
		        }
	        }
        }
	}

    if (mWorldState.GetPlayMode() == PM_Our_Penalty_Taken)
    {
        if (fabs(player.GetPos().Y()) > 10.6)
        {
            return -90.0 * Sign(player.GetPos().Y());
		}
	}

    return (target - player.GetPos()).Dir();
}

/**
 * �ж��ҵ������Ƿ��㹻ȫ����distanceԶ������ʣ��һ��������
 * judge whether I can dash a "distance" with max power with a certain stamina left
 * @param distance
 * @return true I can dash a "distance" with max power with a certain stamina left
 */
bool Strategy::IsMyStaminaEnough(double distance)
{
    int stamina_min = 3200; // Ҫ���µ�����ֵ
    double scost;
	double tspeed = 0.0;
    double taps = mSelfState.GetDashPowerRate() * mSelfState.GetEffort();
    const double & decay = mSelfState.GetPlayerDecay();
    while (distance > FLOAT_EPS)
    {
        scost = ServerParam::instance().maxPower();
        if (tspeed + scost * taps > mSelfState.GetEffectiveSpeedMax())
        {
            scost = (mSelfState.GetEffectiveSpeedMax() - tspeed) / taps;
            scost = Max(0.0, scost);
		}
        tspeed += scost * taps;
        distance -= tspeed;
        tspeed *= decay;
        stamina_min = (int)(stamina_min + scost);
        if (stamina_min > mSelfState.GetStamina())
        {
            return false;
        }
    }
    return true;
}


/**
 * ��Ȩ����
 * the anvlyse of ball possession
 */
void Strategy::BallPossessionAnalyse()
{
	const std::vector<Unum> & p2b = mInfoState.GetPositionInfo().GetClosePlayerToBall();
	const PlayerState & self = mAgent.GetSelf();
	BallState & ball = mAgent.World().Ball();

	if(mWorldState.GetHearPassInfo().mRecvTime == mWorldState.CurrentTime() && !mWorldState.GetHearPassInfo().mIsMultiPass){
		mLastBallFreeTime = mWorldState.GetHearPassInfo().mRecvTime;
	}

	//����ball_free�����ؼ���
	mIsBallFree = true;
	if (ServerParam::instance().pitchRectanglar().IsWithin(ball.GetPos())){
		Ray ballcourse(ball.GetPos(), ball.GetVel().Dir());
		Vector outpos;
		if (ServerParam::instance().pitchRectanglar().Intersection(ballcourse, outpos)){
			double distance = outpos.Dist(ball.GetPos());
			mBallOutCycle = (int)ServerParam::instance().GetBallCycle(ball.GetVel().Mod(), distance);
		}
        else
        {
            mBallOutCycle = 0; // ����û�н��㣬����ballλ�õ�x��������Ϊ52.5
        }
	}
	else {
		mBallOutCycle = 0;
	}
	mController = self.GetUnum();

	//����˭����
	//����Գ�������������Ա��������ʱ��������cyc_delay,�õ���������������С��������,
	//��Ϊ�Լ���ȥ����������,���Ķ��ֲ����Լ���̫��,���Ķ������Լ�(��ʱ������buf)
	const std::list<OrderedIT> & OIT = mInfoState.GetInterceptInfo().GetOIT();
	std::list<OrderedIT>::const_iterator it, itr_NULL = OIT.end(), pMyInfo = itr_NULL, pTmInfo = itr_NULL, pOppInfo = itr_NULL;
	mBallFreeCycleLeft = 150;

	for (it = OIT.begin(); it != OIT.end(); ++it){
		if (it->mUnum < 0){
			if (it->mUnum == -mWorldState.GetOpponentGoalieUnum()) continue; //������Ϊ�Է�����Ա����ȥ���򣬷����������Ͳ�ȥ�������������
			if (it->mpInterceptInfo->mMinCycle < mMinOppInterCycle){
				if (it->mCycleDelay < 16){
					mMinOppInterCycle = it->mpInterceptInfo->mMinCycle;
					mBallFreeCycleLeft = Min(mBallFreeCycleLeft, int(mMinOppInterCycle + it->mCycleDelay * 0.5)); //mOppMinInterCycle + it->cd * 0.5�ǶԽ������ڵ�һ��Ȩ��Ĺ���
					mFastestOpp = -it->mUnum;
				}
			}
			if(it->mpInterceptInfo->mMinCycle + it->mCycleDelay < mSureOppInterCycle){
				mSureOppInterCycle = int(it->mpInterceptInfo->mMinCycle + it->mCycleDelay);
				mSureOpp = -it->mUnum;
				pOppInfo = it;
				if (!mWorldState.GetOpponent(mSureOpp).IsBodyDirValid() && mWorldState.GetOpponent(mSureOpp).GetVel().Mod() < 0.26){ //�޷��������巽��
					mSureOppInterCycle += 1;
				}
			}
		}
		else {
			if (it->mUnum == self.GetUnum()){
				mMyInterCycle = it->mpInterceptInfo->mMinCycle;
				mBallFreeCycleLeft = Min(mBallFreeCycleLeft, mMyInterCycle);
				pMyInfo = it;
			}
			else {
				if (it->mpInterceptInfo->mMinCycle < mMinTmInterCycle){
					mMinTmInterCycle = it->mpInterceptInfo->mMinCycle;
					mBallFreeCycleLeft = Min(mBallFreeCycleLeft, int(mMinTmInterCycle + it->mCycleDelay * 0.5));
					mFastestTm = it->mUnum;
				}
				if(it->mpInterceptInfo->mMinCycle + it->mCycleDelay < mSureTmInterCycle){
					mSureTmInterCycle = int(it->mpInterceptInfo->mMinCycle + it->mCycleDelay);
					mSureTm = it->mUnum;
					pTmInfo = it;
					if (!mWorldState.GetTeammate(mSureTm).IsBodyDirValid() && mWorldState.GetTeammate(mSureTm).GetVel().Mod() < 0.26){ //�޷��������巽��
						mSureTmInterCycle += 1;
					}
				}
			}
		}
	}

	mSureInterCycle = Min(mSureOppInterCycle, mSureTmInterCycle);
	mSureInterCycle = Min(mSureInterCycle, mMyInterCycle);

	mMinIntercCycle = Min(mMinOppInterCycle, mMinTmInterCycle);
	mMinIntercCycle = Min(mMyInterCycle, mMinIntercCycle);

	if (mSureTm == 0) {
		mSureTm = mSelfState.GetUnum();
		mSureTmInterCycle = mMyInterCycle;
		mMinTmInterCycle = mMyInterCycle;
		mFastestTm = mSureTm;
	}

	if( /*mMyInterCycle < mBallOutCycle + 2 &&*/ (mMyInterCycle <= mSureInterCycle ||
			(mWorldState.GetHearPassInfo().mRecvTime >= mLastBallFreeTime && mMyInterCycle <= mSureOppInterCycle + 2 && mWorldState.GetHearPassInfo().mPlayerUnum == mSelfState.GetUnum() && !mWorldState.GetHearPassInfo().mIsMultiPass)
	)){ //�Լ������ص������
		mController = self.GetUnum();
		if(pTmInfo != itr_NULL && pTmInfo->mCycleDelay < 3){//2004_10
			if(mSureTmInterCycle - mMyInterCycle < 5 && mSureOppInterCycle - mSureTmInterCycle > 3){//����Ҳ�п����õ���,�ұȽϰ�ȫ�����Լ���ȥ��ȥ����
				bool bSeted = false;
				if(mLastController == mSureTm){//���ǲ��Ƕ����ڴ���...
					if (mWorldState.GetHearPassInfo().mRecvTime < mLastBallFreeTime) {
						bSeted = true;
						mController = mLastController;
					}
					else if (mWorldState.GetHearPassInfo().mPlayerUnum != mSelfState.GetUnum()) {
						bSeted = true;
						mController = mLastController;
					}
				}
				if(!bSeted){
					if (mWorldState.GetHearPassInfo().mRecvTime >= mLastBallFreeTime && !mWorldState.GetHearPassInfo().mIsMultiPass){
						bSeted = true;
						if (mWorldState.GetHearPassInfo().mPlayerUnum != mSelfState.GetUnum()) {
							mController = mSureTm;
						}
					}
				}
			}
			if (IsMyControl()) {
				if (mSureTmInterCycle <= mMyInterCycle && mMyInterCycle <= mSureOppInterCycle) {
					if (mWorldState.GetTeammate(mSureTm).GetVelDelay() == 0 || (mWorldState.GetTeammate(mSureTm).GetPosDelay() == 0 && mInfoState.GetPositionInfo().GetPlayerDistToPlayer(mSureTm, mSelfState.GetUnum()) < ServerParam::instance().visibleDistance() - 0.5)) {
						Vector ball_int_pos = mBallState.GetPredictedPos(mSureTmInterCycle);
						Vector pos = mWorldState.GetTeammate(mSureTm).GetPos();
						if (pos.Dist(ball_int_pos) < mWorldState.GetTeammate(mSureTm).GetKickableArea() - Dasher::GETBALL_BUFFER) {
							mController = mSureTm;
						}
						else {
							Vector vel = mWorldState.GetTeammate(mSureTm).GetVel();
							double speed = vel.Mod() * Cos(vel.Dir() - (ball_int_pos - pos).Dir());
							if (speed > mWorldState.GetTeammate(mSureTm).GetEffectiveSpeedMax() * mWorldState.GetTeammate(mSureTm).GetDecay() * 0.9) { //�������ڽ���
								mController = mSureTm;
							}
						}
					}
				}
				else if (mSureTmInterCycle < mMyInterCycle && mMyInterCycle <= mMinOppInterCycle) {
					mController = mSureTm;
				}
			}
		}

		if (mController == mSelfState.GetUnum()) {
			if (pMyInfo != itr_NULL){
				mBallInterPos = ball.GetPredictedPos(mMyInterCycle);
			}
            else if (mWorldState.CurrentTime().T() > 0) {
				PRINT_ERROR("bug here?");
			}
		}
		else {
			mBallInterPos = ball.GetPredictedPos(mSureTmInterCycle);
			mController = mSureTm;
		}
	}
	else {//�Լ��ò�������,�����������
		if(pTmInfo != itr_NULL && mSureTmInterCycle <= mSureInterCycle){//�п����õ�
			mBallInterPos = ball.GetPredictedPos(mSureTmInterCycle);
			mController = mSureTm;
		}
		else {
			if(pOppInfo != itr_NULL){
				mBallInterPos = ball.GetPredictedPos(mSureOppInterCycle);
				mController = -mSureOpp;
			}
			else {
				if (mMinIntercCycle > mBallOutCycle + 5) { //because ball will be out of field
					mBallInterPos = ball.GetPredictedPos(mBallOutCycle);
					mController = 0;
				}
				else {
					mController = mSelfState.GetUnum();
					mBallInterPos = ball.GetPredictedPos(mMyInterCycle);
				}
			}
		}
	}

	int kickable_player = mInfoState.GetPositionInfo().GetTeammateWithBall(); //����û�п���buffer
	if (kickable_player == 0){
		kickable_player = -mInfoState.GetPositionInfo().GetOpponentWithBall(); //����û�п���buffer
	}

	if (kickable_player != 0) {
		mController = kickable_player;
		mIsBallFree = false;
		mBallOutCycle = 1000;
	}

	//�����жϿ������
	//���ж����ߵ���Ķ�Ա
	//����:�����ߵ�����Լ����м���,����һ�������������˭��,�õ��Ƿ��Լ���������,��Ϊ_pMem->ball_kickable
	//����:����˭����սλ��˭��
    if (self.IsKickable()){
		mController = self.GetUnum();
		mIsBallFree = false;
		mSureInterCycle = 0;
		mMinIntercCycle = 0;
		mMyInterCycle = 0;
		mMinTmInterCycle = 0;
		mSureTmInterCycle = 0;
		mBallInterPos = ball.GetPos();
		mBallFreeCycleLeft = 0;
		mIsBallActuralKickable = true;
		double self_pt_dis = mAgent.GetFormation().GetTeammateFormationPointBaseBall(self.GetUnum(), ball.GetPos()).Dist2(ball.GetPos());

		for(unsigned int i = 0; i < p2b.size(); ++i){
			Unum unum = p2b[i];
			if(unum > 0 && unum != self.GetUnum()){
				if (mWorldState.GetPlayer(unum).IsKickable()){
					if(mWorldState.GetPlayMode() != PM_Play_On && mWorldState.GetPlayer(unum).IsGoalie()/*&& unum == PlayerParam::instance().ourGoalieUnum()*/){
						mAgent.Self().UpdateKickable(false); //��playonʱ�������Ա���߰��Լ�ǿ�����óɲ�����
						mController = unum;
						break;
					}
					double tm_pt_dis = mAgent.GetFormation().GetTeammateFormationPointBaseBall(unum, ball.GetPos()).Dist2(ball.GetPos());
					if(tm_pt_dis < self_pt_dis){
						mAgent.Self().UpdateKickable(false);
						mController = unum;
						break;
					}
				}
				else { //������Ϊ�������߲�����
					break;
				}
			}
		}
		mChallenger = mInfoState.GetPositionInfo().GetOpponentWithBall();
	}
	else if (kickable_player != 0 && kickable_player != self.GetUnum()){ //�Լ��߲�����,�����˿���
		mIsBallFree = false;
		if (kickable_player > 0){ //�Լ��˿���
			mChallenger = mInfoState.GetPositionInfo().GetOpponentWithBall();
		}
	}

    // TODO:����������Ϣ����,λ���Ƿ���� ������
    if (mWorldState.GetHearPassInfo().mRecvTime == mWorldState.CurrentTime() &&
        mWorldState.GetHearPassInfo().mIsMultiPass && !mSelfState.IsKickable())//�ر����ʱ������һ�ž͵���
	{//�����еĶ�ų���ǰ������,Ҫ��,����������Ҫball_free������,��Ū���˾�����������������
        mIsBallFree = false;
        mController = mWorldState.GetHearMessage().GetSender();
	}
    else if (mWorldState.GetTacticsInfo().mRecvTime == mWorldState.CurrentTime() && mWorldState.GetControllerType() != BT_None && mWorldState.GetHearMessage().GetSender() != mSelfState.GetUnum())
    {
		mIsBallFree = false; //TODO: -- ���ٴ���ʱballfree��ȻΪtrue
        mController = mWorldState.GetHearMessage().GetSender();//�����Ĳ�һ�����ڣ����ܻ���������ʱ���Է��Ѿ��õ����ˣ���ʱball_free=false
	}

	SetPlayAnalyse(); //����������Ϊ����
}

bool Strategy::SetPlayAnalyse()
{
	PlayMode play_mode = mWorldState.GetPlayMode();
	if (play_mode == PM_Before_Kick_Off){
		mIsBallFree = true;
		mController = mInfoState.GetPositionInfo().GetClosestPlayerToBall();
		return true;
	}
	else if (play_mode < PM_Our_Mode && play_mode > PM_Play_On){
		mIsBallFree = true;
		if (mBallState.GetVel().Mod() < 0.16) { //��������٣�˵���Ѿ�������
			mController = mInfoState.GetPositionInfo().GetClosestTeammateToBall();
		}
		return true;
	}
	else if (play_mode > PM_Opp_Mode){
		mIsBallFree = true;
		if (mBallState.GetVel().Mod() < 0.16) { //��������٣�˵���Ѿ�������
			mController = -mInfoState.GetPositionInfo().GetClosestOpponentToBall();
		}
		return true;
	}
	return false;
}

/**
 * �Ե�ǰ���Ƶķ���
 * the analyse of current situation
 */
void Strategy::SituationAnalyse()
{
	if( mController < 0 && mWorldState.GetBall().GetPos().X() < -10){
		mSituation = ST_Defense;
	}
	else {
		if(!mIsBallFree){
			if(mController >= 0){
				if(mBallInterPos.X() < 32.0){
					if(mInfoState.GetPositionInfo().GetTeammateOffsideLine() > 40.0 && mAgent.GetFormation().GetTeammateRoleType(mController).mLineType == LT_Midfielder && mBallInterPos.X() > 25.0){
						mSituation = ST_Penalty_Attack;
					}
					else {
						mSituation = ST_Forward_Attack;
					}
				}
				else {
					mSituation=ST_Penalty_Attack;
				}
			}
			else {
				mSituation = ST_Defense;
			}
		}
		else{
			if(IsMyControl() || mSureTmInterCycle <= mSureOppInterCycle){
				if(mBallInterPos.X() < 32.0 && mController > 0) {
					if(mInfoState.GetPositionInfo().GetTeammateOffsideLine() > 40.0 && mAgent.GetFormation().GetTeammateRoleType(mController).mLineType == LT_Midfielder && mBallInterPos.X() > 25.0) {
						mSituation = ST_Penalty_Attack;
					}
					else {
						mSituation = ST_Forward_Attack;
					}
				}
				else {
					mSituation=ST_Penalty_Attack;
				}
			}
			else{
				mSituation = ST_Defense;
			}
		}
	}

    // mPenaltyAttackCycle
    if (mInfoState.GetPositionInfo().GetTeammateOffsideLine() > 36.0)
    {
        ++mPenaltyAttackCycle;
    }
    else
    {
        mPenaltyAttackCycle = 0;
    }

    // mIsAttackInAdvantage
    mIsAttackInAdvantage = false;

    if (mSituation != ST_Defense)
    {
        mAgent.GetFormation().SetTeammateFormationType(FT_Attack_Forward);
	}
    else
    {
        mAgent.GetFormation().SetTeammateFormationType(FT_Defend_Back);
	}

	// TODO: ���ֵ����ͷ���������WE2008�õıȽϻ��ң����ܻ���bug
    if (mSituation != ST_Defense)
    {
        if (ServerParam::instance().ourPenaltyArea().IsWithin(mBallInterPos) && mIsBallFree)
        {
            mAgent.GetFormation().SetOpponentFormationType(FT_Attack_Forward); // ��Ϊ���ֻ����ڽ���״̬
		}
        else
        {
            mAgent.GetFormation().SetOpponentFormationType(FT_Defend_Back);
        }
    }
    else
    {
        if (mBallInterPos.X() < -26.0)
        {
            mAgent.GetFormation().SetOpponentFormationType(FT_Attack_Forward);
        }
        else
        {
            mAgent.GetFormation().SetOpponentFormationType(FT_Attack_Midfield);
        }
    }

    mOppForwardLine = 0.0;
	mOppMidLine = 0.0;
	mOppBackLine = 0.0;
	mAttackPhase = AP_None;
	std::vector<Unum>OppForward;
	std::vector<Unum>OppMid;
	std::vector<Unum>OppBack;

    if (mAgent.GetFormation().IsOpponentRoleValid())
    {
        for (int i = 1; i <= TEAMSIZE; i++)
        {
            if (i == mWorldState.GetOpponentGoalieUnum()) continue;
			switch (mAgent.GetFormation().GetOpponentRoleType(i).mLineType)
            {
            case LT_Forward:
				if( mWorldState.GetOpponent(i).IsAlive()&&mWorldState.GetOpponent(i).GetPosDelay()< 8)
				{
				    OppForward.push_back(i);
					mOppForwardLine += mWorldState.GetOpponent(i).GetPos().X();
                }
				break;
            case LT_Midfielder:
				if(mWorldState.GetOpponent(i).IsAlive()&&mWorldState.GetOpponent(i).GetPosDelay()< 8)
				{
				    OppMid.push_back(i);
					mOppMidLine += mWorldState.GetOpponent(i).GetPos().X();
                }
				break;
            case LT_Defender:
				if (mWorldState.GetOpponent(i).IsAlive()&&mWorldState.GetOpponent(i).GetPosDelay()< 8)
                {
				    OppBack.push_back(i);
					mOppBackLine += mWorldState.GetOpponent(i).GetPos().X();
                }
				break;
            default:
			    break;
			}
		}
		mOppForwardLine = mOppForwardLine / OppForward.size();
		mOppMidLine = mOppMidLine / OppForward.size();
		mOppBackLine = mOppBackLine / OppBack.size();
        mAttackPhase = CalcAttackPhase(mBallInterPos.X());
    }
}

/**
 * calculate current attack phase
 * @param x
 * @return
 */
AttackPhase Strategy::CalcAttackPhase(const double & x) const
{
    if (!mAgent.GetFormation().IsOpponentRoleValid() || mController <= 0)
    {
        return AP_None;
    }

    if (x < mOppBackLine)
    {
	    return AP_Back;
    }
    else if (x <mOppMidLine)
    {
        return AP_Back_Mid;
    }
    else if (x < mOppForwardLine)
    {
	    return AP_Mid_Forward;
    }
    else
    {
	    return AP_Forward;
    }
}

/**
 * �õ�t_num�Ŷ��ѵĻ�����λ��
 * get the Situation Based Strategic Positioning for the teammate whose number is "t_num"
 * @param t_num
 * @param ballpos
 * @param normal
 * @return
 */
Vector Strategy::GetTeammateSBSPPosition(int t,const Vector& ballpos,bool normal)
{
	Vector position;
	if (mController > 0 ||
        (mController == 0 && mBallInterPos.X() > 10.0))
    {
		position = mAgent.GetFormation().GetTeammateFormationPoint(t, mController, ballpos);
	}
    else
    {
        position = mAgent.GetFormation().GetTeammateFormationPoint(t);
	}

	if (!normal) // Ҫ��ֱ�Ӹ���������ʱ������offline����
    {
        double x = Min(position.X(),
            mInfoState.GetPositionInfo().GetTeammateOffsideLine() - PlayerParam::instance().AtPointBuffer());
        position.SetX(x);
    }

	return position;
}


double Strategy::ComputeWillTackleProb(const Unum & unum)
{
    const PlayerState & player = mWorldState.GetPlayer(unum);
    if (!player.IsAlive() ||
        player.GetTackleBan() >= 2 || // ��������Ȼ���ܲ�
        mWorldState.GetPlayMode() == PM_Before_Kick_Off ||
        mInfoState.GetPositionInfo().GetBallDistToPlayer(unum) > 3.6)
    {
        return 0.0;
    }

    const Vector & v = player.GetVel();
	double bodyang;
    Vector posdiff = player.GetPos() - mWorldState.GetHistory(1)->GetPlayer(unum).GetPos();
	if (posdiff.Mod() > 0.12)
    {
		bodyang = posdiff.Dir();
	}
    else
    {
        bodyang = player.GetBodyDir();
	}

    if(player.GetBodyDirConf() > FLOAT_EPS)
    {
        bodyang = player.GetBodyDir();
	}
    else if (v.Mod() > 0.20)
    {
		bodyang = v.Dir();
	}

    const Vector & bp = mBallState.GetPredictedPos(1);
    const Vector & pos = player.GetPos();

    if (player.GetTackleBan() == 1) // �����ھͿɲ�
    {
        return GetTackleProb((bp - pos).Rotate(-bodyang));
    }

    //ֱ��
    Vector prepos = pos + v + Polar2Vector(player.GetAccelerationFrontMax(), bodyang);
	Vector relpos = (bp - prepos).Rotate(-bodyang);
	double poss1, poss2;
	poss1 = GetTackleProb(relpos);

    //ת��
	prepos = v + pos;
	relpos = (bp - prepos).Rotate(-bodyang);
	double maxangle = relpos.Dir();
	if (player.GetMaxTurnAngle() > fabs(maxangle))
    {
		relpos = relpos.Rotate(-maxangle);
	}
    else
    {
		relpos = relpos.Rotate(-Sign(maxangle) * maxangle );
	}
	poss2 = GetTackleProb(relpos);
	return Max(poss1, poss2);
}


/**
 * �õ���ǰ�������ŵ÷ֵĶ����б�
 * get a list of teammates who may score a goal
 */
const std::vector<Unum>& Strategy::GetFocusScoreTeammate()
{
	if (mFocusScoreTmTime != mWorldState.CurrentTime()){
		mFocusScoreTm.clear();
		mFocusScoreTmTime = mWorldState.CurrentTime();

		if (mBallInterPos.X() > 0){
			if(mWorldState.GetOpponentGoalieUnum() == 0) return mFocusScoreTm;
			Vector glpos;
			if (mWorldState.GetOpponent(mWorldState.GetOpponentGoalieUnum()).GetPosConf() > FLOAT_EPS){
				glpos = mWorldState.GetOpponent(mWorldState.GetOpponentGoalieUnum()).GetPos();
			}
			else {
				glpos = Vector(45.0, 0);
			}
			if(mSituation == ST_Penalty_Attack){
				Unum i;
				const PlayerState* p;
				for (i = 1; i <= TEAMSIZE; i++){
					p = &(mWorldState.GetTeammate(i));
					if (p->GetPosConf() < FLOAT_EPS) continue;
					Vector pos = p->GetPos();
					if(ServerParam::instance().oppPenaltyArea().IsWithin(pos)){
						if(PossibilityModel::instance().CalcShootSuccessRate(pos, glpos) > 0.26){//�п������
							mFocusScoreTm.push_back(i);
						}
					}
				}
			}
		}
	}
	return mFocusScoreTm;
}

/**
* �õ���ǰ�������ŵ÷ֵĶ����б�
* get a list of opponents who may score a goal
*/
const std::vector<Unum>& Strategy::GetFocusScoreOpponent()
{
	if (mFocusScoreOppTime != mWorldState.CurrentTime()){
		mFocusScoreOpp.clear();
		mFocusScoreOppTime = mWorldState.CurrentTime();

		if (mBallInterPos.X() < 0){
			Vector glpos;
			if (mWorldState.GetTeammateGoalieUnum() && mWorldState.GetTeammate(mWorldState.GetTeammateGoalieUnum()).GetPosConf() > FLOAT_EPS){
				glpos = mWorldState.GetTeammate(mWorldState.GetTeammateGoalieUnum()).GetPos();
			}
			else {
				glpos = Vector(-45.0, 0);
			}
            if (mAgent.GetFormation().GetOpponentFormationType() == FT_Attack_Forward){
				Unum i;
				const PlayerState *p;
				for (i = 1; i <= TEAMSIZE; i++){
					p = &(mWorldState.GetOpponent(i));
					if (p->GetPosConf() < FLOAT_EPS) continue;
					Vector pos = p->GetPos();
					if (ServerParam::instance().ourPenaltyArea().IsWithin(pos)){
						if(PossibilityModel::instance().CalcShootSuccessRate(pos, glpos, 0.0, false) > 0.26){//�п������
							mFocusScoreOpp.push_back(i);
						}
					}
				}
			}
		}
	}
	return mFocusScoreOpp;
}


//==============================================================================
/**
 * ��take_time���ҷ�����˭������
 * get the number of the teammate who should have a penalty kick at the "take_time" times
 * @param take_time
 * @return the number of the teammate
 */
int Strategy::GetOurPenaltyTaker(int take_time)
{
    if (take_time <= 0)
    {
        PRINT_ERROR("penalty take time error");
        return mWorldState.GetTeammateGoalieUnum();
    }

    if (take_time != 1)
    {
        take_time = take_time % TEAMSIZE; // 0 - 10
        if (take_time == 0)
        {
            take_time = 11;
        }
        return mPenaltyTakerSequence[take_time];
    }

    // �������mPenaltyTakerSequence���飬ֻ��һ��
    bool is_chosen[12];
    memset(is_chosen, 0, sizeof(is_chosen));
    is_chosen[mWorldState.GetTeammateGoalieUnum()] = true;
    mPenaltyTakerSequence[TEAMSIZE] = mWorldState.GetTeammateGoalieUnum(); // ����Ա���һ����

    double unum_rate[TEAMSIZE + 1];
    for (int i = 1; i <= TEAMSIZE; ++i)
    {
        if (i != mWorldState.GetTeammateGoalieUnum())
        {
            unum_rate[i] = 0.99 * (1.0 - mWorldState.GetTeammate(i).GetKickRand()) +
                0.01 * mWorldState.GetTeammate(i).GetEffectiveSpeedMax();
        }
    }

    int max_unum    = 0;
    double max_rate  = 0.0; // rateԽ��Խ��
    for (int i = 1; i <= TEAMSIZE - 1; ++i)
    {
        max_rate    = 0.0;
        for (int j = 1; j <= TEAMSIZE; ++j)
        {
            if (is_chosen[j] == false && unum_rate[j] > max_rate)
            {
                max_rate = unum_rate[j];
                max_unum = j;
            }
        }

        is_chosen[max_unum] = true;
        mPenaltyTakerSequence[i] = max_unum;
    }

    return mPenaltyTakerSequence[1];
}


/**
 * �Ե�ǰӦ��˭������ķ���
 * analyze who should have a penalty kick
 */
void Strategy::PenaltyAnalyze()
{
    if (IsPenaltyPlayMode() == false)
    {
        return;
    }

    if (mWorldState.GetPlayModeTime() == mWorldState.CurrentTime())
    {
        const PlayMode &play_mode = mWorldState.GetPlayMode();
        if (play_mode == PM_Our_Penalty_Setup)
        {
            ++mPenaltySetupTime;
            mPenaltyTaker = GetOurPenaltyTaker(mPenaltySetupTime);
        }
        else if (play_mode == PM_Opp_Penalty_Setup)
        {
            mPenaltyTaker = -1;
        }
    }
}

/**
 * �жϵ�ǰ�Ƿ����ҷ�������
 * judge whether it is turn for we to have a penalty kick
 * @return true when it is turn for we to have a penalty kick
 */
bool Strategy::IsOurPenaltyPlayMode() const
{
    const PlayMode &play_mode = mWorldState.GetPlayMode();
    return (play_mode == PM_Our_Penalty_Score) ||
        (play_mode == PM_Our_Penalty_Miss) ||
        (play_mode == PM_Our_Penalty_Setup) ||
    	(play_mode == PM_Our_Penalty_Ready) ||
	    (play_mode == PM_Our_Penalty_Taken);
}

/**
 * �жϵ�ǰ�Ƿ����ҷ�������
 * judge whether it is turn for opponents to have a penalty kick
 * @return true when it is turn for opponents to have a penalty kick
 */
bool Strategy::IsOppPenaltyPlayMode() const
{
    const PlayMode &play_mode = mWorldState.GetPlayMode();
    return (play_mode == PM_Opp_Penalty_Score) ||
        (play_mode == PM_Opp_Penalty_Miss) ||
        (play_mode == PM_Opp_Penalty_Setup) ||
        (play_mode == PM_Opp_Penalty_Ready) ||
        (play_mode == PM_Opp_Penalty_Taken);
}

/**
 * �жϵ�ǰ�Ƿ��ǵ���ģʽ
 * judge whether it is time for penalty now
 * @return true whether it is time for penalty now
 */
bool Strategy::IsPenaltyPlayMode() const
{
    const PlayMode &play_mode = mWorldState.GetPlayMode();
    return (play_mode == PM_Penalty_On_Our_Field) ||
        (play_mode == PM_Penalty_On_Opp_Field) ||
        (IsOurPenaltyPlayMode() == true)||
        (IsOppPenaltyPlayMode() == true);
}

/**
 * ��ǰ��Աȥ�������ѽ����
 * get the best position where I go to intercept the ball
 * @return the best position where I go to intercept the ball
 */
Vector Strategy::GetMyInterPos()
{
	return mBallState.GetPredictedPos(mMyInterCycle);
}

/**
 * Get the fastest teammate to a virtual ball.
 * \param ballpos position of the virtual ball.
 * \param ballvel velocity of the virtual ball.
 * \param teammate will be set to the fastest teammate's unum or 0 if there's none.
 *                 this value is always non-negtive.
 * \param include_self if "teammate" inculde the agent itself.
 * \return PlayerInterceptInfo
 */
PlayerInterceptInfo Strategy::GetFastestTmToVirtualBall(Vector ballpos, Vector ballvel, Unum & teammate, bool include_self,bool include_goalie) const
{
	PlayerInterceptInfo t_info, fastest_info;
	fastest_info.mRes = IR_None;
	int cycles, min_cycles = 1000;
	teammate = 0;

	for (int i(1); i <= ServerParam::instance().TEAM_SIZE; ++i)
	{
		if (i == mAgent.GetSelfUnum() && !include_self) continue;
		if (i == mWorldState.GetTeammateGoalieUnum() && !include_goalie) continue;
		if (!mWorldState.GetTeammate(i).IsAlive() || mWorldState.GetTeammate(i).GetPosConf() < 0.8) continue;

		t_info.mpPlayer = &mWorldState.GetTeammate(i);
		t_info.mIdleCycle = t_info.mpPlayer->GetTackleBan();

		if (t_info.mIdleCycle > 0) {
			for (int j = 0; j < t_info.mIdleCycle; ++j){
				ballpos += ballvel;
				ballvel *= ServerParam::instance().ballDecay();
			}
		}

		InterceptInfo::CalcInterception(ballpos, ballvel, &t_info);
		if (/*t_info.mRes == IR_Success &&*/ (cycles = t_info.mMinCycle) < min_cycles)
		{
			min_cycles = cycles;
			fastest_info = t_info;
			teammate= i;
		}
	}
	return fastest_info;
}

/**
 * Get the fastest opponent to a virtual ball.
 * \param ballpos position of the virtual ball.
 * \param ballvel velocity of the virtual ball.
 * \param opponent will be set to the fastest opponent's unum or 0 if there's none.
 *                 this value is always non-negtive.
 * \return PlayerInterceptInfo
 */
PlayerInterceptInfo Strategy::GetFastestOppToVirtualBall(Vector ballpos, Vector ballvel, Unum & opponent) const
{
	PlayerInterceptInfo t_info, fastest_info;
	fastest_info.mRes = IR_None;
	int cycles, min_cycles = 1000;
	opponent = 0;

	for (int i(1); i <= ServerParam::instance().TEAM_SIZE; ++i)
	{
		if (!mWorldState.GetOpponent(i).IsAlive() || mWorldState.GetOpponent(i).GetPosConf() < 0.8) continue;

		t_info.mpPlayer = &mWorldState.GetOpponent(i);
		t_info.mIdleCycle = t_info.mpPlayer->GetTackleBan();

		for (int j = 0; j < t_info.mIdleCycle; ++j){
			ballpos += ballvel;
			ballvel *= ServerParam::instance().ballDecay();
		}

		InterceptInfo::CalcInterception(ballpos, ballvel, &t_info);
		if (/*t_info.mRes == IR_Success &&*/ (cycles = t_info.mMinCycle) < min_cycles)
		{
			min_cycles = cycles;
			fastest_info = t_info;
			fastest_info.mMinCycle -= t_info.mpPlayer->GetPosDelay(); //��������Ѿ�������
			fastest_info.mMinCycle = Max(fastest_info.mMinCycle, 1);
			opponent = i;
		}
	}
	return fastest_info;
}

//==============================================================================
void Strategy::SaveActiveBehavior(const ActiveBehavior & beh)
{
	BehaviorType type = beh.GetType();

	Assert(type > BT_None && type < BT_Max);

	if (mActiveBehavior[type] != 0) {
		if (*mActiveBehavior[type] < beh) {
			delete mActiveBehavior[type];
			mActiveBehavior[type] = new ActiveBehavior(beh);
		}
	}
	else {
		mActiveBehavior[type] = new ActiveBehavior(beh);
	}
}

ActiveBehavior *Strategy::GetLastActiveBehavior(BehaviorType type) const
{
	Assert(type > BT_None && type < BT_Max);

	return mLastActiveBehavior[type];
}

/**
 * ���ñ�����ʵ��ִ�е�activebehavior -- excuteʱ����
 * set the the type of the activebehavior in its actual execution this cycle when it is "excute"
 * @param type
 */
void Strategy::SetActiveBehaviorInAct(BehaviorType type)
{
	Assert(type > BT_None && type < BT_Max);
	Assert(mActiveBehavior[0] == 0);

	mActiveBehavior[0] = mActiveBehavior[type];
}

void Strategy::ResetSavedActiveBehavior()
{
	for (int type = BT_None + 1; type < BT_Max; ++type) {
		delete mLastActiveBehavior[type];
		mLastActiveBehavior[type] = mActiveBehavior[type];
		mActiveBehavior[type] = 0;
	}

	mLastActiveBehavior[0] = mActiveBehavior[0];
	mActiveBehavior[0] = 0;
}

void Strategy::SaveActiveBehaviorList(const std::list<ActiveBehavior> & behavior_list)
{
	for (std::list<ActiveBehavior>::const_iterator it = behavior_list.begin(); it != behavior_list.end(); ++it) {
		SaveActiveBehavior(*it);
	}
}

/**
 * ���Լ�����ĳ����ĳ����ɴ��ľ���
 * calculate roughly the foward distance at "pt" point towards the "angle" direction
 * @param pt ���Ե�
 * @param angle ���Է���
 * @return �ɴ�������
 */
double Strategy::CalcForwardDistance(const Vector & pt, const double dribble_speed, AngleDeg angle, double fix, bool ourside, Unum *pOppUnum) const
{
	Ray runcourse(pt, angle);
	Vector intersectpt;
	if (!ServerParam::instance().pitchRectanglar().Intersection(runcourse, intersectpt)){
		return 0.0;
	}

	double dis, mindis = pt.Dist(intersectpt);
	if (ourside){
		for (Unum opp = 1; opp <= TEAMSIZE; opp++){
			if (mWorldState.GetOpponent(opp).GetPosConf() > FLOAT_EPS){
                dis = CalcDribbleDistanceVsPlayer(pt, dribble_speed, mWorldState.GetOpponent(opp), angle, fix);
				if(dis < mindis){
					if(pOppUnum != 0){
						*pOppUnum = opp;
					}
					mindis = dis;
				}
			}
		}
	}
	else {
		for (Unum opp = 1; opp <= TEAMSIZE; opp++) {
			if (mWorldState.GetTeammate(opp).GetPosConf() > FLOAT_EPS){
				dis = CalcDribbleDistanceVsPlayer(pt, dribble_speed, mWorldState.GetTeammate(opp), angle, fix);
				if(dis < mindis){
					if(pOppUnum != 0){
						*pOppUnum = opp;
					}
					mindis = dis;
				}
			}
		}
	}
	return mindis;
}
/**
 * ���㳯ĳ������Դ������Զ
 * ����fix������cycdelay�ȣ��󣬶Է����Χ��һ��ԲC�������bp����Բ����angle�ϵ���C���е�ԲD��D��Բ�ļ����Ե���ĵ�
 * estimate the forward distance with dribbling the ball at "bp" point toward the "angle "direction
 * \param bp ��ʼλ��
 * \param p ����
 * \param angle ����
 * \param fix �����ߵ��ӳ٣�������ת���ȣ�����ʱģ��Ĭ�ϴ������¸����ڿ�ʼ���Է��������������kick��1cyc�ӳٵ���
 * \return
 */
double Strategy::CalcDribbleDistanceVsPlayer(const Vector & bp, const double dribble_speed, const PlayerState & player, AngleDeg angle, double fix) const
{
    if (player.IsAlive() == false)
    {
        return 100.0;
    }

    const double f = fix + player.GetEffectiveSpeedMax() * player.GetPosDelay();
	Vector oppos = (player.GetPredictedPos(1) - bp).Rotate(-angle);

    const double d = oppos.Mod();
	const double x = oppos.X();

	if (x + f < 0)
    {
        return 100.0;//���󹻲���
    }

	//��ǰ��Ϊ�����ٶȺͶ�����ƴ�����ٶ���ͬ�����ڸĳɲ���ͬ
	const double block_speed = player.GetEffectiveSpeedMax() * 0.9; //������ƴ�����ٶ�
	const double k = block_speed / dribble_speed;

	if (fabs(1.0 - k) < FLOAT_EPS) {
		if (d > f) {
			return (d * d - f * f) / (2.0 * (x + k * f));
		}
		else {
			return d / 50.0;
		}
	}
	else {
		const double delta = (x + k * f) * (x + k * f) - (1.0 - k * k) * (d * d - f * f);
		if (delta >= 0.0) {
			const double dist = (x + k * f - sqrt(delta)) / (1.0 - k * k);
			if (dist > 0.0) {
				return dist;
			}
			else {
				return d / 50.0;
			}
		}
		else {
			return 100.0; //���ֿ϶�׷����
		}
	}
}




// end of file Strategyinfo.cpp

