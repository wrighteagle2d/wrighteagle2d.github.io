/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef PLOTTER_H_
#define PLOTTER_H_

/**
* refer to gnuplot_i.[ch]
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifndef WIN32
#include <unistd.h>
#endif

#include <list>
#include <string>

class Plotter {
	Plotter();

public:
	virtual ~Plotter();
	static Plotter & instance();

	/**
	@brief    Change the plotting style of a gnuplot session.
	@param    h Gnuplot session control handle
	@param    plot_style Plotting-style to use (character string)
	@return   void

	The provided plotting style is a character string. It must be one of
	the following:

	- lines
	- points
	- linespoints
	- impulses
	- dots
	- steps
	- errorbars
	- boxes
	- boxeserrorbars
	*/
	/*--------------------------------------------------------------------------*/
	void SetStyle(char * plot_style);

	/**
	@brief    Sets the x label of a gnuplot session.
	@param    h Gnuplot session control handle.
	@param    label Character string to use for X label.
	@return   void

	Sets the x label for a gnuplot session.
	*/
	void SetXLabel(char * label);

	/**
	@brief    Sets the y label of a gnuplot session.
	@param    h Gnuplot session control handle.
	@param    label Character string to use for Y label.
	@return   void

	Sets the y label for a gnuplot session.
	*/
	void SetYLabel(char * label);


	/**
	@brief    Resets a gnuplot session (next plot will erase previous ones).
	@param    h Gnuplot session control handle.
	@return   void

	Resets a gnuplot session, i.e. the next plot will erase all previous
	ones.
	*/
	void Reset();

	/**
	@brief    Sends a command to an active gnuplot session.
	@param    handle Gnuplot session control handle
	@param    cmd    Command to send, same as a printf statement.

	This sends a string to an active gnuplot session, to be executed.
	There is strictly no way to know if the command has been
	successfully executed or not.
	The command syntax is the same as printf.

	Examples:

	@code
	gnuplot_cmd(g, "plot %d*x", 23.0);
	gnuplot_cmd(g, "plot %g * cos(%g * x)", 32.0, -3.0);
	@endcode

	Since the communication to the gnuplot process is run through
	a standard Unix pipe, it is only unidirectional. This means that
	it is not possible for this interface to query an error status
	back from gnuplot.
	*/
	void GnuplotExecute(const char *  cmd, ...);

	/**
	@brief    Plots a 2d graph from a list of doubles.
	@param    handle  Gnuplot session control handle.
	@param    d       Array of doubles.
	@param    n       Number of values in the passed array.
	@param    title   Title of the plot.
	@return   void

	Plots out a 2d graph from a list of doubles. The x-coordinate is the
	index of the double in the list, the y coordinate is the double in
	the list.

	Example:

	@code
	gnuplot_ctrl    *h ;
	double          d[50] ;
	int             i ;

	h = gnuplot_init() ;
	for (i=0 ; i<50 ; i++) {
	d[i] = (double)(i*i) ;
	}
	gnuplot_plot_x(h, d, 50, "parabola") ;
	sleep(2) ;
	gnuplot_close(h) ;
	@endcode
	*/
	void PlotX(double * d, int n, char * title);

	/**
	@brief    Plot a 2d graph from a list of points.
	@param    handle      Gnuplot session control handle.
	@param    x           Pointer to a list of x coordinates.
	@param    y           Pointer to a list of y coordinates.
	@param    n           Number of doubles in x (assumed the same as in y).
	@param    title       Title of the plot.
	@return   void

	Plots out a 2d graph from a list of points. Provide points through a list
	of x and a list of y coordinates. Both provided arrays are assumed to
	contain the same number of values.

	@code
	gnuplot_ctrl    *h ;
	double          x[50] ;
	double          y[50] ;
	int             i ;

	h = gnuplot_init() ;
	for (i=0 ; i<50 ; i++) {
	x[i] = (double)(i)/10.0 ;
	y[i] = x[i] * x[i] ;
	}
	gnuplot_plot_xy(h, x, y, 50, "parabola") ;
	sleep(2) ;
	gnuplot_close(h) ;
	@endcode
	*/
	void PlotXY(double * x, double * y, int n, char * title);

	/**
	 * save to file_name which will be a png file
	 * @param file_name
	 */
	void PlotToFile(char * file_name);

	/**
	 * plot to display
	 */
	void PlotToDisplay();

private:
	void Init();
	void Close();

private:
	bool mIsDisplayOk;
	bool mIsGnuplotOk;

	FILE *mpGnupolot; //pointer to gnuplot process stdin

	char mPlotStyle[32];

	std::list<std::string> mTmpFile;

private:
	static const int PATH_MAXNAMESZ = 4096;
	static const int GP_CMD_SIZE = 2048;
};

#endif /* PLOTTER_H_ */
