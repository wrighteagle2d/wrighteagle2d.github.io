/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include <stdio.h>
#include "BehaviorSetplay.h"
#include "WorldState.h"
#include "Agent.h"
#include "Strategy.h"
#include "Formation.h"
#include "Geometry.h"
#include "ServerParam.h"


const BehaviorType BehaviorSetplayExecuter::BEHAVIOR_TYPE = BT_Setplay;

namespace
{
bool ret = BehaviorExecutable::AutoRegister<BehaviorSetplayExecuter>();
}

BehaviorSetplayExecuter::BehaviorSetplayExecuter(Agent & agent): BehaviorExecuterBase<BehaviorAttackData>( agent )
{
	Assert(ret);
}

BehaviorSetplayExecuter::~BehaviorSetplayExecuter(void)
{
}


bool BehaviorSetplayExecuter::Execute(const ActiveBehavior &act_bhv)
{
	switch (act_bhv.mSetPlayType)
	{
	case TAT_Scan:
			mAgent.Turn(sight::ViewAngle(VW_Narrow) - 5.0);
			mAgent.ChangeView(VW_Narrow);
		break;
	case TAT_Move:
		mAgent.Move(act_bhv.mTarget);
		break;
	default:
		break;
	}
	return true;
}

BehaviorSetplayPlanner::BehaviorSetplayPlanner(Agent & agent): BehaviorPlannerBase<BehaviorAttackData>( agent )
{
}

BehaviorSetplayPlanner::~BehaviorSetplayPlanner(void)
{
}

void BehaviorSetplayPlanner::Plan(std::list<ActiveBehavior> & behavior_list)
{
	ActiveBehavior act_bhv(mAgent, BehaviorSetplayExecuter::BEHAVIOR_TYPE);
	if(mStrategy.IsPenaltyPlayMode() == true) return;
	if (mWorldState.GetBall().GetPosConf() < FLOAT_EPS && (!( mWorldState.GetPlayMode() == PM_Before_Kick_Off ||
		mWorldState.GetPlayMode()  == 	PM_Goal_Ours ||
		mWorldState.GetPlayMode() == PM_Goal_Opps)))
	{
		act_bhv.mSetPlayType = TAT_Scan;
		behavior_list.push_back(act_bhv);
		return;
	}
	if( mWorldState.GetPlayMode() == PM_Before_Kick_Off ||
		mWorldState.GetPlayMode()  == 	PM_Goal_Ours ||
		mWorldState.GetPlayMode() == PM_Goal_Opps)
	{
		   Vector init_pos[TEAMSIZE]; // ��ӦTeammateFormation�е�

		    // ����Ա
		    init_pos[0] = Vector(-45.0, 0.0);

		    // ����
		    init_pos[1] = Vector(-25.0, -13.0);
		    init_pos[7] = Vector(-20.0, -5.0);
		    init_pos[8] = Vector(-20.0, 5.0);
		    init_pos[4] = Vector(-25.0, 13.0);

		    // �г�
		    init_pos[2] = Vector(-5.0, -8.0);
		    init_pos[9] = Vector(-10.0, 0.0);
		    init_pos[5] = Vector(-5.0, 8.0);

		    // ǰ��
		    init_pos[3] = Vector(-1.0, -18.0);
		    init_pos[10] = Vector(-1.0, 0.0);
		    init_pos[6] = Vector(-1.0, 18.0);

		    if (mWorldState.GetKickOffMode() == KO_Opps) // �Է����򣬲���վ����Ȧ��
		    {
		        init_pos[9] = Vector(-9.0, -3.0);
		        init_pos[3] = Vector(-1.0, -10.0);
		        init_pos[10] = Vector(-9.0, 3.0);
		        init_pos[6] = Vector(-1.0, 10.0);
		    }
		    act_bhv.mTarget = init_pos[mAgent.GetSelfUnum() -1];
		    act_bhv.mSetPlayType = TAT_Move;
			if (act_bhv.mTarget.Dist(mAgent.GetSelf().GetPos()) < 1.0)
			{
				act_bhv.mSetPlayType = TAT_Scan;
			}
			else act_bhv.mSetPlayType = TAT_Move;
			behavior_list.push_back(act_bhv);
	}
}

