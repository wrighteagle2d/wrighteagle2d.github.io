/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "PlayerState.h"
#include "ActionEffector.h"

PlayerState::PlayerState():
	MobileState(ServerParam::instance().playerDecay(), PlayerParam::instance().HeteroPlayer(0).effectiveSpeedMax())
{
	mBallCatchable = false;
	mCatchBan = 0;
	mCollideWithBall = false;
	mCollideWithPlayer = false;
	mCollideWithPost = false;
	mIsAlive = false;
	mIsGoalie = false;
    mIsSensed = false;
	mIsKicked = false;
	mKickRate = 0.0;
	mIsKickable = false;
	mMaxTurnAngle = 0.0;
	mPlayerType = 0;
	mCardType = CR_None;

	mStamina = ServerParam::instance().staminaMax();
	mEffort  = ServerParam::instance().effortInit();
	mCapacity = ServerParam::instance().staminaCapacity();
	mRecovery = ServerParam::instance().recoverInit();

	mTackleBan = 0;
	mTackleProb = 0.0;
	mUnum = 0;
	mViewWidth = VW_Normal;
	mIsTired = false;
    mMinStamina = PlayerParam::instance().MinStamina();

    mIsLying = false;
	mCardType = CR_None;
	mIsBodyDirMayChanged = true;
}

/**
 * Check if the ball is kickable.
 * @param mBallState the ball state.
 * @param buffer kick area buffer.
 * @return true means kickable.
 */
bool PlayerState::IsKickable(const BallState &mBallState,double buffer) const
{
	if (mBallState.GetPosConf() < FLOAT_EPS || GetPosConf() < FLOAT_EPS) return false;
	double dis2self = GetPos().Dist(mBallState.GetPos());
	return (dis2self <= GetKickableArea() - buffer);
}

/**
 * Get a reverse player state.
 * param o the player state to get reverse from.
 */
void PlayerState::GetReverseFrom(const PlayerState & o)
{
	SetIsAlive(o.IsAlive());

	UpdateIsGoalie(o.IsGoalie());
	UpdateIsSensed(o.IsSensed());

	UpdatePlayerType(o.GetPlayerType());
	UpdateViewWidth(o.GetViewWidth());

	UpdateBallCatchable(o.IsBallCatchable());
	UpdateCatchBan(o.GetCatchBan());

	UpdateKickable(o.IsKickable());
	UpdateKicked(o.IsKicked());
	UpdateLying(o.IsLying());
	UpdatePlayerCardType(o.GetPlayerCardType());

	UpdateStamina(o.GetStamina());
	UpdateEffort(o.GetEffort());
	UpdateCapacity(o.GetCapacity());
	UpdateRecovery(o.GetRecovery());

	UpdateMaxTurnAngle(o.GetMaxTurnAngle());

	UpdateBodyDir(GetNormalizeAngleDeg(o.GetBodyDir() + 180.0), o.GetBodyDirDelay(), o.GetBodyDirConf());
	UpdateNeckDir(GetNormalizeAngleDeg(o.GetNeckDir() + 180.0), o.GetNeckDirDelay(), o.GetNeckDirConf());

	UpdatePos(o.GetPos().Rotate(180.0), o.GetPosDelay(), o.GetPosConf());
	UpdateVel(o.GetVel().Rotate(180.0), o.GetVelDelay(), o.GetVelConf());

	UpdateTackleBan(o.GetTackleBan());
	UpdateTackleProb(o.GetTackleProb());
	UpdateTackleProbFoul(o.GetTackleProbFoul());

	UpdateArmPoint(GetNormalizeAngleDeg(o.GetArmPointAngle() + 180.0), o.GetArmPointDelay(), o.GetArmPointConf(), o.GetArmPointDist(), o.GetArmPointMovableBan(), o.GetArmPointExpireBan());
	UpdateFocusOn(o.GetFocusOnSide(), o.GetFocusOnUnum(), o.GetFocusOnDelay(), o.GetFocusOnConf());
}

/**
 * Get the predicted position with a turn and some dashes.
 * @param angle the turn angle.
 * @param steps the total steps to predict.
 * @param dash_power the intend dash power.
 * @param dash_dir the dash direction.
 * @param with_turn true means considering a turn.
 * @param idle_cycles the idle cycles before action.
 * @param last_vel the last cycle velocity.
 * @return a vector to show the prediction.
 */
Vector PlayerState::GetPredictedPosWithTurn(double angle, int steps, double dash_power, AngleDeg dash_dir, bool with_turn, int idle_cycles, Vector *last_vel) const
{
	Assert(steps > 0);
	if (with_turn == false && fabs(dash_power) < FLOAT_EPS){
		if (last_vel){
			*last_vel = GetPredictedVel(steps);
		}
		return GetPredictedPos(steps);
	}

	dash_power = NormalizeDashPower( dash_power );
	dash_dir = NormalizeDashAngle( dash_dir );

    if ( ServerParam::instance().dashAngleStep() < FLOAT_EPS )
    {
        // players can dash in any direction.
    }
    else
    {
        // The dash direction is discretized by server::dash_angle_step
        dash_dir = ServerParam::instance().dashAngleStep() * Rint( dash_dir / ServerParam::instance().dashAngleStep() );
    }

    double dir_rate = ( std::fabs( dash_dir ) > 90.0
                        ? ServerParam::instance().backDashRate() - ( ( ServerParam::instance().backDashRate() - ServerParam::instance().sideDashRate() )
                                                   * ( 1.0 - ( std::fabs( dash_dir ) - 90.0 ) / 90.0 ) )
                        : ServerParam::instance().sideDashRate() + ( ( 1.0 - ServerParam::instance().sideDashRate() )
                                                   * ( 1.0 - std::fabs( dash_dir ) / 90.0 ) )
                        );

    if (dash_power < 0.0) {
    	dash_dir += 180.0;
    }

	double curr_turn_ang = GetNormalizeAngleDeg(angle);
	double corrected_dash_power = dash_power;
	double effective_power;
	double predicted_stamina = GetStamina();
	double predicted_effort = GetEffort();
	double predicted_recovery = GetRecovery();
	double myang = GetBodyDir();
	Vector position = GetPos();
	Vector velocity;
	if (GetVelConf() < FLOAT_EPS) velocity = Vector(0.0, 0.0);
	else velocity = GetVel();

	for (int i = 0; i < steps; i++){
		corrected_dash_power = CorrectDashPowerForStamina(dash_power, predicted_stamina);
		if (i < idle_cycles) {
			/* do nothing, we're idling! */
			effective_power = 0;
		} else if (with_turn &&
				(i==0 || curr_turn_ang != 0.0)) {
			double this_turn = MinMax(-GetMaxEffectiveTurn(velocity.Mod()),
					curr_turn_ang,
					GetMaxEffectiveTurn(velocity.Mod()));
			myang += this_turn;
			curr_turn_ang -= this_turn;
			effective_power = 0;
		} else if (fabs(corrected_dash_power) > predicted_stamina)
			effective_power = Sign(corrected_dash_power) * predicted_stamina ;
		else
			effective_power = corrected_dash_power;

		effective_power *= predicted_effort;
		effective_power *= GetDashPowerRate();
		effective_power *= dir_rate;
		velocity += Polar2Vector( effective_power, GetNormalizeAngleDeg(myang + dash_dir) );

		if ( velocity.Mod() > GetEffectiveSpeedMax() )
			velocity *= ( GetEffectiveSpeedMax() / velocity.Mod() );

		position += velocity;
		velocity *= GetPlayerDecay();

		UpdatePredictedStaminaWithDash(&predicted_stamina, &predicted_effort,
				&predicted_recovery, corrected_dash_power);
	}

	if (last_vel != NULL){
		*last_vel = velocity;
	}
	return position;
}

//return the last_vel
Vector PlayerState::GetPredictedVelWithTurn(double angle, int steps, double dash_power,	AngleDeg dash_dir, bool with_turn, int idle_cycles) const
{
	Vector last_vel;
	GetPredictedPosWithTurn(angle, steps, dash_power, dash_dir, with_turn, idle_cycles, & last_vel);
	return last_vel;
}

/**
 * Correct the dash power for stamina.
 * @param dash_power the intend dash power.
 * @param stamina the stamina now.
 * @param effort the effort.
 * @param recovery the player's stamina recovery.
 * @return dash power corrected.
 */
double PlayerState::CorrectDashPowerForStamina(double dash_power, double stamina, double effort, double recovery) const
{
	(void) effort;
	(void) recovery;

	double new_power;

	if (dash_power >= 0) {
		new_power = Min( dash_power, stamina - GetMinStamina() );
		if ( new_power < 0 ) new_power = 0;
	}
	else {
		new_power = Min( -dash_power, (stamina - GetMinStamina()) / 2.0);
		if ( new_power < 0 ) new_power = 0;

		new_power = -new_power;
	}

	return new_power;
}

/**
 * Get the effective turn angle.
 * @param turn_ang the angle for turn command.
 * @param my_speed the player's speed.
 * @param the effective turn angle.
 */
AngleDeg PlayerState::GetEffectiveTurn(AngleDeg turn_ang, double my_speed) const
{
	return GetActualTurnAngle(turn_ang, GetPlayerType(), my_speed);
}

/**
 * Update the predicted stamina with dash.
 * @param stamina the stamina to update.
 * @param effort the effort to update.
 * @param recovery the recovery to update.
 * @param dash_power the dash power.
 */
void PlayerState::UpdatePredictedStaminaWithDash(double* stamina, double* effort, double* recovery, double dash_power) const
{
	if (dash_power > 0)
		*stamina -= dash_power;
	else
		*stamina -= 2 * dash_power;
	if (*stamina < 0) *stamina = 0;

	if ( *stamina <= ServerParam::instance().recoverDecThr() * ServerParam::instance().staminaMax() && *recovery > ServerParam::instance().recoverMin() ) {
		*recovery -= ServerParam::instance().recoverDec();
	}

	if ( *stamina <= ServerParam::instance().effortDecThr() * ServerParam::instance().staminaMax() && *effort > GetEffortMin())
		*effort -= ServerParam::instance().effortDec();
	if (*stamina >= ServerParam::instance().effortIncThr() * ServerParam::instance().staminaMax() && *effort < 1.0){
		*effort += ServerParam::instance().effortInc();
		if ( *effort > 1.0 )
			*effort = 1.0;
	}
	*stamina += *recovery * GetStaminaIncMax();
	if ( *stamina > ServerParam::instance().staminaMax() )
		*stamina = ServerParam::instance().staminaMax();
}

//end of file pLayerState.cpp
