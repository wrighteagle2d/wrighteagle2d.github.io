/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include <iostream>
#include <cmath>
#include "CommunicateSystem.h"
#include "WorldState.h"
#include "Agent.h"
#include "ServerParam.h"
#include "PlayerParam.h"
#include "Logger.h"
#include "Formation.h"
//==============================================================================
CommunicateSystem::CommunicateSystem() {
    mLastPointTime = Time(-3, 0);
}

//==============================================================================
CommunicateSystem::~CommunicateSystem() {
}

//==============================================================================
CommunicateSystem & CommunicateSystem::instance()
{
    static CommunicateSystem communicate_system;
    return communicate_system;
}

/*
 * Initial the observer and agent.
 */
void CommunicateSystem::Initial(Observer *observer , Agent* agent)
{
    mpObserver = observer;
	mpAgent  = agent;
	mpHM = &(mpAgent->World().HearMsg());
}

/*
 * Parsing the messages received from our coach.
 * \param msg pointer to a c style string received this cycle.
 */
void CommunicateSystem::ParseReceivedOurCoachMsg(char *msg)
{
	mpObserver->HearOurCoachSayType(AudioObserver::OCST_None);
	(void)msg;
	return;
}

/*
 * Parsing the messages received from teammate.
 * \param msg pointer to a c style string received this cycle.
 */
void CommunicateSystem::ParseReceivedTeammateMsg(char *msg)
{
	(void)msg;
	return;
}

/**
 * reset some values at the beginning of every cycle and deal with hear message from server
 */
void CommunicateSystem::Update()
{	
	// our coach say
    if (mpObserver->Audio().IsOurCoachSayValid())
    {
        ParseReceivedOurCoachMsg((char *)mpObserver->Audio().GetOurCoachSayContent().c_str());
		Logger::instance().GetTextLogger("Test_Say_Listen") << "fr-Coach Listen-Time:" << mpAgent->World().CurrentTime() << "-MSG:" << (char *)mpObserver->Audio().GetOurCoachSayContent().c_str() << std::endl;
	}

    // teammate say
    if (mpObserver->Audio().IsTeammateSayValid())
    {
        ParseReceivedTeammateMsg((char *)(mpObserver->Audio().GetTeammateSayContent().c_str()));
		Logger::instance().GetTextLogger("Test_Say_Listen") << "fr-Teammate Listen-Time:" << mpAgent->World().CurrentTime() << "-MSG:" << (char *)(mpObserver->Audio().GetTeammateSayContent().c_str()) << std::endl;
    }
	return;
}

/**
 * send say message to server
 */
void CommunicateSystem::Decision()
{
	std::string s;
	if (mpAgent->GetSelfUnum() == 10)
	{
		s += "10";
	}
	else if (mpAgent->GetSelfUnum() == 11)
	{
		s += "11";
	}
	else
	{
		s += '0' + mpAgent->GetSelfUnum();
	}
	mpAgent->Say(s);
	if (!mpAgent->GetActionEffector().IsAttentionto())
	{
		mpAgent->Attentionto(mpAgent->GetSelfUnum() + 1 % 11 + 1);
	}
	else
	{
		mpAgent->AttentiontoOff();
	}
	return;
}

/**
 * Point to a certain point.
 * @param target target point��global position��.
 * @return true means success.
 */
bool CommunicateSystem::Pointto(Vector target)
{
    const WorldState & world_state = mpAgent->GetWorldState();
    const PlayerState & self_state = mpAgent->GetSelf();

    if (mLastPointTime == world_state.CurrentTime() || self_state.GetArmPointMovableBan() > 0)
    {
        return false;
    }

    Vector target_2_me = target - self_state.GetPos();
    double my_neck_angle = self_state.GetNeckGlobalDir();
    double dist = target_2_me.Mod();
    double angle = GetNormalizeAngleDeg(target_2_me.Dir() - my_neck_angle);

    mpAgent->Pointto(dist, angle);
    mLastPointTime = world_state.CurrentTime();
    return true;
}


/**
 * Cancel the point to command.
 * @return true means success.
 */
bool CommunicateSystem::PointtoOff()
{
    const WorldState & world_state = mpAgent->GetWorldState();
    const PlayerState & self_state = mpAgent->GetSelf();

    if (mLastPointTime == world_state.CurrentTime() || self_state.GetArmPointMovableBan() > 0)
    {
        return false;
    }

    mpAgent->PointtoOff();
    mLastPointTime = world_state.CurrentTime();
    return true;
}

