/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "BehaviorPenalty.h"
#include "WorldState.h"
#include "Agent.h"
#include "Kicker.h"
#include "Dasher.h"
#include "BehaviorAttack.h"
#include "BehaviorDefense.h"

const BehaviorType BehaviorPenaltyExecuter::BEHAVIOR_TYPE = BT_Penalty;

namespace
{
	bool ret = BehaviorExecutable::AutoRegister<BehaviorPenaltyExecuter>();
}


//==============================================================================
BehaviorPenaltyExecuter::BehaviorPenaltyExecuter(Agent & agent): BehaviorExecuterBase<BehaviorAttackData>(agent)
{
	Assert(ret);
}


//==============================================================================y
bool BehaviorPenaltyExecuter::Execute(const ActiveBehavior &beh)
{
    int unum = mWorldState.GetOpponentGoalieUnum();
    if (unum < 1 || unum > TEAMSIZE) // TODO: ��������Աʶ�����bug����ʱ������   2009-06-08
    {
        if (mPositionInfo.GetXSortOpponent().empty())
        {
            PRINT_ERROR("opponent goalie unum error @ " << mWorldState.CurrentTime());
            return false;
        }
        unum = mPositionInfo.GetXSortOpponent().rbegin()->mUnum;
    }

	switch (beh.mSetPlayType)
    {
    case TAT_Scan:
        break;
    case TAT_Turn:
		mAgent.Turn(beh.mAngle);
        break;
    case TAT_Move:
        if (mSelfState.IsGoalie())
        {
            if (mSelfState.GetPos().Dist(beh.mTarget) > 0.5)
            {
                Dasher::instance().GoToPoint(mAgent, beh.mTarget, 0.26);
            }
            else
            {
                Dasher::instance().GetTurnBodyToAngleAction(mAgent, (mBallState.GetPos() - mSelfState.GetPos()).Dir()).Execute(mAgent);
            }
        }
        else if (mAgent.GetSelfUnum() != mStrategy.GetPenaltyTaker())
        {
			if (mSelfState.GetPos().Dist(beh.mTarget) > 1.0)
            {
				Dasher::instance().GoToPoint(mAgent, beh.mTarget, 0.26);
            }
            else
            {
                Dasher::instance().GetTurnBodyToAngleAction(mAgent, 0.0).Execute(mAgent);
            }
        }
        else
        {
			if (mStrategy.IsPenaltyFirstStep() == false)
            {
                double power = mSelfState.GetStamina() + mSelfState.GetStaminaIncMax() - 6600.0;
                power = MinMax(mSelfState.GetStaminaIncMax() - 5.0, power, ServerParam::instance().maxPower());
                Dasher::instance().GoToPoint(mAgent, beh.mTarget, 0.26, power);
            }
            else
            {
                const double ball_2_self_ang = (mBallState.GetPos() - mSelfState.GetPos()).Dir();
                if (GetAngleDegDiffer(mSelfState.GetBodyDir(), ball_2_self_ang) > 16.0)
                {
                    Dasher::instance().GetTurnBodyToAngleAction(mAgent, ball_2_self_ang).Execute(mAgent);
                }
                else if (mSelfState.GetPos().Dist(beh.mTarget) > 0.66) // ������
                {
					Dasher::instance().GoToPoint(mAgent,beh.mTarget, 0.26, 26.0);
                }
				else if (beh.mTarget.X() < mSelfState.GetPos().X()) // �����������ǰ
                {
					mAgent.Dash(-100.0, 0.0); // ���ܵ����ʱ����������
                }
                else // �ȴ�
                {
                    Dasher::instance().GetTurnBodyToAngleAction(mAgent, 0.0).Execute(mAgent);
                }
            }
        }
        break;
    case TAT_Face:
		if (mAgent.GetSelfUnum() == mStrategy.GetPenaltyTaker())
        {
			if (mWorldState.GetPlayMode() == PM_Our_Penalty_Ready)
            {
                if (mWorldState.CurrentTime() - mWorldState.GetPlayModeTime() < 
                    ServerParam::instance().penReadyWait() - 6) // wait
                {
                    Dasher::instance().GetTurnBodyToAngleAction(mAgent, 0.0).Execute(mAgent);
                }
				else if (mSelfState.IsKickable() == true)
                {
                    Kicker::instance().KickBall(mAgent, beh.mAngle, beh.mKickSpeed);
                }
                else // һ�㲻��տ�ʼ�Ͳ����ߣ��Է���һ
                {
					Dasher::instance().GoToPoint(mAgent, beh.mTarget, 0.26);
                }
            }
			else if (mWorldState.GetPlayMode() == PM_Our_Penalty_Taken)
            {
				Dasher::instance().GoToPoint(mAgent,beh.mTarget, 0.26,100/*_pMem->SP_max_dash_power*/);
            }
            else
            {
                std::cerr << "what penalty_taker will do ???" << std::endl;
            }
        }
        else
        {
            Dasher::instance().GetTurnBodyToAngleAction(mAgent, 0.0).Execute(mAgent);
        }
        break;
    default:
        break;
	}
	return true;
}


BehaviorPenaltyPlanner::BehaviorPenaltyPlanner(Agent & agent): BehaviorPlannerBase<BehaviorAttackData>( agent )
{
}

BehaviorPenaltyPlanner::~BehaviorPenaltyPlanner()
{
}

//==============================================================================
void BehaviorPenaltyPlanner::Plan(std::list<ActiveBehavior> &behaviorlist)
{
	ActiveBehavior penaltyKO(mAgent, BT_Penalty);

    if (mSelfState.IsGoalie())
    {
        switch (mWorldState.GetPlayMode())
        {
            case PM_Penalty_On_Our_Field:
		    case PM_Penalty_On_Opp_Field:
                penaltyKO.mSetPlayType = TAT_Scan;
			    break;
            case PM_Our_Penalty_Score:
            case PM_Our_Penalty_Miss:
            case PM_Opp_Penalty_Score:
            case PM_Opp_Penalty_Miss: // ���ֻ���Ѹշ������ԭ����Ϣһ��
            case PM_Our_Penalty_Setup:
            case PM_Our_Penalty_Ready:
	        case PM_Our_Penalty_Taken: // ���ѷ���������Ա���Ա���Ϣ��Ϊ�˽�ʡ���������Լ�dash��ȥ��rcssserver-13.*�²�����������Ա�Լ�����
                penaltyKO.mSetPlayType = TAT_Turn;
                break;
            case PM_Opp_Penalty_Setup:
                penaltyKO.mSetPlayType = TAT_Move;
                break;
            default:
                return; // PM_Opp_Penalty_Ready��PM_Opp_Penalty_Taken����BehaviorGoalie���о���
        }
    }
    else
    {
	    switch (mWorldState.GetPlayMode())
        {
		    case PM_Penalty_On_Our_Field:
		    case PM_Penalty_On_Opp_Field:
			    penaltyKO.mSetPlayType = TAT_Scan; // ԭ����Ϣ
			    break;
            case PM_Our_Penalty_Score:
            case PM_Our_Penalty_Miss:
            case PM_Opp_Penalty_Score:
            case PM_Opp_Penalty_Miss:
			    penaltyKO.mSetPlayType = TAT_Turn; // ԭ��ת��
                break;
            case PM_Our_Penalty_Setup:
            case PM_Opp_Penalty_Setup:
			    penaltyKO.mSetPlayType = TAT_Move; // ����Ŀ��λ��
			    break;
            case PM_Our_Penalty_Ready:
		    case PM_Our_Penalty_Taken:
            case PM_Opp_Penalty_Ready:
            case PM_Opp_Penalty_Taken:
			    penaltyKO.mSetPlayType = TAT_Face; // ���ڷ�����
			    break;
		    default:
			    return;
	    }
    }

	const Vector setup_ball_pos = Vector(ServerParam::instance().PITCH_LENGTH / 2.0 - ServerParam::instance().penDistX(), 0.0);
	if (mBallState.GetPosConf() < FLOAT_EPS)
    {
		penaltyKO.mSetPlayType = TAT_Scan;
		behaviorlist.push_back(penaltyKO);
		return;
	}

    if (penaltyKO.mSetPlayType == TAT_Scan)
    {
        behaviorlist.push_back(penaltyKO);
    }
    else if (penaltyKO.mSetPlayType == TAT_Turn)
    {
		penaltyKO.mAngle = 60.0;
        behaviorlist.push_back(penaltyKO);
    }
	else if (penaltyKO.mSetPlayType == TAT_Move)
    {
        if (mSelfState.IsGoalie())
        {
            penaltyKO.mTarget = Vector(-ServerParam::instance().PITCH_LENGTH / 2.0 + ServerParam::instance().penMaxGoalieDistX() - 1.0, 0.0);
        }
		else if (mAgent.GetSelfUnum() == mStrategy.GetPenaltyTaker())
        {
			if (mWorldState.CurrentTime() - mWorldState.GetPlayModeTime() < 5 && mStrategy.IsPenaltyFirstStep() != false)
            {
				mStrategy.SetPenaltyFirstStep(false);
            }

			if (mSelfState.GetPos().Dist(Vector(6.6, 0.0)) < 1.0 && mStrategy.IsPenaltyFirstStep() != true)
            {
                mStrategy.SetPenaltyFirstStep(true);
            }

            if (mStrategy.IsPenaltyFirstStep() == false)
            {
				penaltyKO.mTarget = Vector(6.6, 0.0);
            }
            else
            {
				penaltyKO.mTarget = (mBallState.GetPos().Dist(setup_ball_pos) < 1.0) ? setup_ball_pos : mBallState.GetPos();
            }
        }
		else
        {
			penaltyKO.mAngle = (mAgent.GetSelfUnum() - 2) * 36.0 + 18.0; // 2 ~ 11
			penaltyKO.mTarget = Polar2Vector(8.26, penaltyKO.mAngle);
		}

		penaltyKO.mSuccessPoss = 1.0;
        penaltyKO.mSuccessEffect = 1.0;
		penaltyKO.mFailureEffect = 0.0;
		penaltyKO.mEvaluation = 1.0;

		behaviorlist.push_back(penaltyKO);
	}
	else if (penaltyKO.mSetPlayType == TAT_Face)
    {
		if (mStrategy.IsMyPenaltyTaken() == true)
        {
			BehaviorAttackPlanner(mAgent).Plan(behaviorlist);
        }

        if (behaviorlist.size() > 0)
        {
            return;
        }

        penaltyKO.mTarget = mBallState.GetPos();
        penaltyKO.mAngle = ((mBallState.GetPos() - mSelfState.GetPos()).Dir() > 0.0) ? 36.0 : -36.0;
		penaltyKO.mKickSpeed = Min(1.0, Kicker::instance().GetMaxSpeed(mAgent,penaltyKO.mAngle, 1));

        penaltyKO.mSuccessPoss = 1.0;
        penaltyKO.mSuccessEffect = 1.0;
		penaltyKO.mFailureEffect = 0.0;
		penaltyKO.mEvaluation = 1.0;
        
        behaviorlist.push_back(penaltyKO);
    }
}

