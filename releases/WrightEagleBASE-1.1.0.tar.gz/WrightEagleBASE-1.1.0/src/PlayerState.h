/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __PLAYERSTATE_H__
#define __PLAYERSTATE_H__

#include "BaseState.h"
#include "PlayerParam.h"
#include "BallState.h"
class PlayerState : public MobileState
{
public:
	/**�ֱ�ָ�������� ע���Լ���Ա���Լ���õ���Ϣ��һ����
	* ��ʱ���Լ��ɻ�õ���ϢΪ��׼�����࣬������Աֻ�ܻ����Ϣ��һ����*/
	class ArmPoint
	{
	public:
		ArmPoint(int = 0):
			mMovableBan(0),
			mExpireBan(0),
			mTargetDist(0),
			mTargetDir(0)
		{
		}

		/**���´��ֱ��ܶ���ʣ��������*/
		int mMovableBan;

		/**ֱ���ֱ۶���ʧЧʣ���������*/
		int mExpireBan;

		/**ָ��Ŀ��ľ���*/
		double mTargetDist;

		/**ָ��Ŀ��ķ���*/
		AngleDeg mTargetDir;
	};

	/**ע�Ӷ������ ע����ʱֻ���Լ����Ի��ע�ӵ���Ϣ������ֻ��Ϊ�Ժ����ӿ�*/
	class FocusOn
	{
	public:
		FocusOn(int = 0):
			mFocusSide('?'),
			mFocusNum(0)
		{
		}

		/**ע�ӵĶ���Ϊ��һ��*/
		char mFocusSide;

		/**ע�ӵ���Ա��*/
		Unum mFocusNum;
	};

public:
	PlayerState();
	virtual ~PlayerState() {}

	/**��������
	* @param ����
	* @param ʱ��
	* @param ���Ŷ�*/
	/**
	 * Update the stamina.
	 * @param stamina.
	 */
	void UpdateStamina(double stamina);

	/**��õ�ǰ��ǰ���ε�����
	*/
	/**
	 * Get the stamina.
	 * @return the stamina.
	 */
	const double & GetStamina() const { return mStamina; }

	/**����effort
	* @param ����
	* @param ʱ��
	* @param ���Ŷ�*/
	/**
	 * Update the effort.
	 * @param effort.
	 */
	void UpdateEffort(double effort);

	/**
	 * Update the capacity.
	 * @param capacity.
	 */
	void UpdateCapacity(double capacity);

	/**��õ�ǰ��ǰ���ε�effort
	*/
	/**
	 * Get the effort.
	 * @return the effort.
	 */
	const double & GetEffort() const { return mEffort; }

	/**
	 * Get the capacity.
	 * @return the capacity.
	 */
	const double & GetCapacity() const { return mCapacity; }

	/**
	 * Update recovery
	 * @param recovery
	 */
	void UpdateRecovery(double recovery) { mRecovery = recovery;}

	/** 
	 * get recovery
	 * @return recovery.
	 */
	const double & GetRecovery() const { return mRecovery;}

	/**���²��ӳ���
	* @param ����
	* @param ʱ��
	* @param ���Ŷ�*/
	/**
	 * Update the neck direction.
	 * @param dir the direction of neck.
	 * @param delay the sense delay.
	 * @param conf the confidence.
	 */
	void UpdateNeckDir(double dir , int delay = 0, double conf = 1);

	/**��õ�ǰ��ǰ���εĲ���ȫ�ֳ���
	*/
	/**
	 * Get global direction of neck.
	 * @return the global direction of neck.
	 */
	double GetNeckGlobalDir() const { return GetNormalizeAngleDeg(GetNeckDir() + GetBodyDir()); }

	/**��õ�ǰ�������������ĽǶ�
	* ע��������GetGlobalNeckDir����
	*/
	/**
	 * Get the neck angle relative to body.
	 * @return the neck angle.
	 */
	double GetNeckDir() const { return NormalizeNeckAngle(mNeckDir.mValue); }

	/**��õ�ǰ��ǰ���εĲ��ӳ����ʱ��
	*/
	/**
	 * Get the neck direction sense delay.
	 * @return the delay.
	 */
	int GetNeckDirDelay() const { return mNeckDir.mCycleDelay; }

	/**��õ�ǰ��ǰ���εĲ��ӳ�������Ŷ�
	*/
	/**
	 * Get the neck direction confidence.
	 * @return the confidence of the neck direction.
	 */
	double GetNeckDirConf() const { return mNeckDir.mConf; }

	/**�������峯��
	* @param ����
	* @param ʱ��
	* @param ���Ŷ�*/
	/**
	 * Update the body direction.
	 * @param dir the body direction.
	 * @param delay the body direction sence delay.
	 * @param double the body direction confidence.
	 */
	void UpdateBodyDir(double dir , int delay = 0, double conf = 1);

	/**��õ�ǰ��ǰ���ε����峯��
	*/
	/**
	 * Get the body direction.
	 * @return the body direction.
	 */
    const double & GetBodyDir() const { return mBodyDir.mValue; }

	/**��õ�ǰ��ǰ���ε����峯���ʱ��
	*/
    	/**
	 * Get the body direction delay.
	 * @return the body direction delay.
	 */
	int GetBodyDirDelay() const { return mBodyDir.mCycleDelay; }

	/**��õ�ǰ��ǰ���ε����峯������Ŷ�
	*/
	/**
	 * Get the confidence of body direction.
	 * @return the confidence.
	 */
	double GetBodyDirConf() const { return mBodyDir.mConf; }

	/**���¿ɲ��������
	* @param��ʣ�������ڿ��Բ���
	*/
	/**
	 * Update the tackle ban cycles.
	 * @param ban the ban cycles of tackle.
	 */
	void UpdateTackleBan(int ban);

	/**��õ�ǰ���ں��ж������ڿ��Բ���*/
	/**
	 * Get the tackle ban cycles after the current cycle.
	 * @retrun the tackle ban cycles.
	 */
	int GetTackleBan() const { return mTackleBan; }

	/**���¿����������
	* @param ��ʣ�������ڿ�������
	*/
	/**
	 * Update the catch ban cycles.
	 * @param ban the ban cycles of catch.
	 */
	void UpdateCatchBan(int ban);

	/**��õ�ǰ���ڻ��ж������ڿ������� ��ʱ�޷���*/
	/**
	 * Get the catch ban cycles after the current cycle.
	 * @return the catch ban cycles.
	 */
	int GetCatchBan() const { return mCatchBan; }

	/**������ָ����
	* @param �ֳ���
	* @param ʱ��
	* @param ���Ŷ�
	* @param ����
	* @param �´οɶ�ʱ��
	* @param ��Чʱ��ʣ��*/
	/**
	 * Update the arm point.
	 * @param dir the direction of arm to point to.
	 * @param delay the point to delay.
	 * @param conf the confidence.
	 * @param dist the distance of the point.      
	 * @param move_ban the ban cycles of moving arm.
	 * @param expire_ban the ban cycles of expiration.
	 */
	void UpdateArmPoint(AngleDeg dir , int delay = 0, double conf = 1 , double  dist = 0 , int move_ban = -1 , int expire_ban = -1);

	/**�����ָ��ĳ���*/
	/**
	 * Get the arm point angle.
	 * @return the arm point angle.
	 */
	AngleDeg GetArmPointAngle() const { return GetNormalizeAngleDeg(mArmPoint.mValue.mTargetDir); }

	/**�����ָ��ľ��� ��ʱ���Լ�������*/
	/**
	 * Get the arm point distance. //can only be used by the agent itself.
	 * @return the distance.
	 */
	double  GetArmPointDist() const { return mArmPoint.mValue.mTargetDist; }

	/**����ֻ�ʣ����ʱ��ſɶ� ��ʱ���Լ�������*/
	/**
	 * Get arm point movable ban cycles. //can only be used by the agent itself.
	 * @return the movable ban cycles.
	 */
	int GetArmPointMovableBan() const { return mArmPoint.mValue.mMovableBan; }

	/**����ֶ�����Чʱ��ʣ�� ��ʱ���Լ�������*/
	/**
	 * Get arm point expire ban cycles. //can only be used by the agent itself.
	 * @return the expire ban cycles.
	 */
	int GetArmPointExpireBan() const { return mArmPoint.mValue.mExpireBan; }

	/**�����ָ���ʱ���ӳ�*/
	/**
	 * Get arm point delay.
	 * @return delay.
	 */
	int GetArmPointDelay() const { return mArmPoint.mCycleDelay; }

	/**�����ָ������Ŷ�*/
	/**
	 * Get arm point confidence.
	 * @return the confidence.
	 */
	double GetArmPointConf() const { return mArmPoint.mConf; }

	/**����ע��Ŀ��
	* @param ע���ķ�
	* @param ע�Ӷ�Ա��
	* @param ʱ��
	* @param ���Ŷ�*/
	/**
	 * Update the focus on state.
	 * @param side the side to focus on.
	 * @param num the number of player to focus on.
	 * @param delay the focus on delay.
	 * @param confidence the confidence of focus on.
	 */
	void UpdateFocusOn(char side , Unum num , int delay = 0 , double conf = 1);

	/**���ע�ӵĶ�Ա��λ*/
	/**
	 * Get the side of player to focus on.
	 * @return the side.
	 */
	char GetFocusOnSide() const { return mFocusOn.mValue.mFocusSide; }

	/**���ע�ӵĶ�Ա����*/
	/**
	 * Get the number of player to focus on.
	 * @return the number.
	 */
	Unum GetFocusOnUnum() const { return mFocusOn.mValue.mFocusNum; }

	/**���ע�ӵ�ʱ���ӳ�*/
	/**
	 * Get the delay of focus on.
	 * @return the delay.
	 */
	int GetFocusOnDelay() const { return mFocusOn.mCycleDelay; }

	/**���ע�ӵ����Ŷ�*/
	/**
	 * Get the confidence of focus on.
	 * @return the confidence.
	 */
	double GetFocusOnConf() const { return mFocusOn.mConf; }

	/**�����Ƿ���������*/
	/**
	 * Update if kicked in the current cycle.
	 * @param is_kicked true means kicked.
	 */
	void UpdateKicked(bool is_kicked);

	/**���±������Ƿ����*/ //  ***********************���ڸú�����Ч**********************
	/**
	 * Update if tackled in the current cycle.
	 * @param is_tackling true means tackling.
	 */
	void UpdateTackling(bool is_tackling);

	/**���±������Ƿ񱻲���*/
	/**
	 * Update if lying in the current cycle.
	 * @param is_lying true means tackling.
	 */
	void UpdateLying(bool is_lying);
	/**����������Ƿ����� ��ʱ���Լ������޷���*/
	/**
	 * Check if kicked last cycle.
	 * @return true mean kicked.
	 */
	bool IsKicked() const { return mIsKicked; }

	/**��ñ������Ƿ���� ��ʱ���Լ������޷���*/
	/**
	 * Check if the player is alive this cycle.
	 * @return true means alive.
	 */
	bool IsAlive() const { return mIsAlive; }

	/**
	 * Set the player alive.
	 * @param alive true to set the player alive.
	 */
	void SetIsAlive(bool alive);

	/**��ñ������Ƿ��ڲ���*/
	/**
	 * Check if the player is tackling this cycle.
	 * @return true means tackling.
	 */
	bool IsTackling() const { return mTackleBan > 0; }
	/**��ñ������Ƿ��Ա�������*/
	/**
	 * Check if the player is lying this cycle.
	 * @return true means lying.
	 */
	bool IsLying() const { return mIsLying; }

	/**�����Ա�����¼*/
	/**
	 * Check which kind of card the playe holds this cycle.
	 * @return the player card type.
	 */
	CardType GetPlayerCardType() const { return mCardType; }

	/**������Ա�����¼*/
	/**
	 * Update the player card type.
	 * @param cardtype the player card type.
	 */
	void UpdatePlayerCardType(CardType card_type) { if ( mCardType == CR_None || ( mCardType == CR_Yellow && card_type == CR_Red ) ) mCardType = card_type; }

	/**�����Ա����ʱ��*/
	/**
	 * Get the playe  idle cycle this cycle.
	 * @return the player card type.
	 */
	int GetPlayerIdleCycle() const { return mIdleCycle; }

	/**������Ա����ʱ��*/
	/**
	 * Update the player idle cycle.
	 * @param idle_cycle the player idle cycle.
	 */
	void UpdatePlayerIdleCycle(int idle_cycle) { Assert( idle_cycle >= 0 && idle_cycle <= 5 ); mIdleCycle = idle_cycle; }

	/**�����Ա������*/
	/**
	 * Get player type.
	 * @return the player type.
	 */
	int GetPlayerType() const { return mPlayerType; }

	/**������Ա������*/
	/**
	 * Update the player type.
	 * @param type the player type.
	 */
	void UpdatePlayerType(int type);

	/**������Ա���ӽǿ���*/
	/**
	 * Update the view width of the player.
	 * @param width the view width.
	 */
	void UpdateViewWidth(ViewWidth width);

	/**����ӽǿ���*/
	/**
	 * Get the view width.
	 * @return the view width.
	 */
	ViewWidth GetViewWidth() const { return mViewWidth; }

	/**
	 * Get the view angle.
	 * @return the view angle.
	 */
	AngleDeg GetViewAngle() const { return sight::ViewAngle(mViewWidth);}

	/**�ڲ��Ը���
	* @param ÿ����delay���ϵ�����
	* @param ÿ����conf˥��������*/
	/**
	 * Automatic update.
	 * @param delay_add the delay added per cycle.
	 * @param conf_dec_factor the confidence decreased per cycle.
	 */
	void AutoUpdate(int delay_add = 1 , double conf_dec_factor = 1);

	/**������Ա�ߺ�Unum*/
	/**
	 * Update the unum.
	 * @param num the unum of player.
	 */
	void UpdateUnum(Unum num);

	/**���Unum*/
	/**
	 * Get the unum of the player.
	 * @return the unum.
	 */
	Unum GetUnum() const { return mUnum; }

	/**update collide with ball*/
	void UpdateCollideWithBall(bool collide) { mCollideWithBall = collide;}

	/**get collide with ball*/
	bool GetCollideWithBall() const { return mCollideWithBall;}

	/**update collide with player*/
	void UpdateCollideWithPlayer(bool collide) { mCollideWithPlayer = collide;}

	/** get collide with player*/
	bool GetCollideWithPlayer() const { return mCollideWithPlayer;}

	/** update collide with post*/
	void UpdateCollideWithPost(bool collide) { mCollideWithPost = collide;}

	/** get collide with post*/
	bool GetCollideWithPost() const { return mCollideWithPost;}

	/**ת���õ�һ�����ڷ����PlayerState*/
	/**
	 * Get a reverse player state.
	 * param o the player state to get reverse from.
	 */
	void GetReverseFrom(const PlayerState & o);

private:
	/**�洢�������ڵ�����*/
	double mStamina;

	/**�洢Effort*/
	double mEffort;

	/**�洢capacity*/
	double mCapacity;

	/**store Recovery*/
	double mRecovery;

	/**�洢���ӵĳ���*/
	StateValue<double> mNeckDir;

	/**�洢����ĳ���*/
	StateValue<double> mBodyDir;

	/**���ж������ڿ��Բ���*/
	int mTackleBan;

	/**���ж������ڿ������� ��ʱ�޷���*/
	int mCatchBan;//not available now

	/**��Աָ����Ϣ*/
	StateValue<ArmPoint> mArmPoint;

	/**��Աע����Ϣ*/
	StateValue<FocusOn>  mFocusOn;

	/**�������Ƿ�����*/
	bool mIsKicked;

	/**�Ƿ񱻲���*/
	bool mIsLying;

	/**�Ƿ���� ��ʱ�Լ������޷���*/
	bool mIsAlive;

	/**��Ա����*/
	int mPlayerType;

	/**�ӽǿ���*/
	ViewWidth mViewWidth;

	/**
	 * �Լ���Unum
	 * + ��ʾ�Ƕ��ѣ�- ��ʾ�Ƕ���
	 * */
	Unum mUnum;

	/**
	 * whether collide with ball
	 */
	bool mCollideWithBall;

	/**
	 * whether collide with player
	 */
	bool mCollideWithPlayer;

	/**
	 * whether collide with post
	 */
	bool mCollideWithPost;

	//==============================================================================
public:
	bool IsKickable() const { return mIsKickable; }

	/**
	 * Check if the ball is kickable.
	 * @param mBallState the ball state.
	 * @param buffer kick area buffer.
	 * @return true means kickable.
	 */
	bool IsKickable(const BallState &mBallState,double buffer) const;
	void UpdateKickable(bool kickable) { mIsKickable = kickable; }

	double GetKickRate() const { return mKickRate; }
	void UpdateKickRate(double kick_rate) { mKickRate = kick_rate; }

	bool IsBallCatchable() const { return mIsGoalie && mBallCatchable; }
	void UpdateBallCatchable(bool ball_catchable) { mBallCatchable = ball_catchable; }

	double GetTackleProb() const { return mTackleProb; }
	void UpdateTackleProb(double tackle_prob) { mTackleProb = tackle_prob; }

	double GetTackleProbFoul() const { return mTackleProbFoul; }
	void UpdateTackleProbFoul(double tackle_prob_foul) { mTackleProbFoul = tackle_prob_foul; }

	AngleDeg GetMaxTurnAngle() const { return mMaxTurnAngle; }
	void UpdateMaxTurnAngle(AngleDeg max_turn_angle) { mMaxTurnAngle = max_turn_angle; }

	bool IsTired() const {return mIsTired;}
	void UpdateTired(bool is_tired) { mIsTired = is_tired;}

    const double & GetMinStamina() const { return mMinStamina; }
    void UpdateMinStamina(const double min_stamina) { mMinStamina = min_stamina; } 

	bool IsBodyDirMayChanged() const { return mIsBodyDirMayChanged;}
	void UpdateBodyDirMayChanged(bool may_changed) { mIsBodyDirMayChanged = may_changed;}

	//��������Pos_delay  ��Ҫ��BT_Interceptʹ��;
	/**
	 * Reset the position delay, to be used in BT_Intercept.
	 * @param delay the position delay to be reset.
	 */
	void ResetPosDelay(int delay)
	{
		Assert(delay >= 0);
		double conf = 1;
		for (int i = 0;i < delay;i++)
		{
			conf  *= PlayerParam::instance().playerConfDecay();
		}

		UpdatePos(GetPos() , delay , conf);
	}

private:
	bool        mIsKickable;  /** kick */
	double      mKickRate;
	bool        mBallCatchable; /** catch */
	double      mTackleProb;    /** tackle */
	double      mTackleProbFoul;/** tackle foul */
	AngleDeg    mMaxTurnAngle;  /** turn */
	bool		mIsTired;		/** tell is  tired or not*/
    double      mMinStamina; // �������ֵ��������player��extraStamina
    // considering extraStamina.
	CardType    mCardType;  /** card */
	int			mIdleCycle; /** idle cycle */
	//just for update body dir other should not use
	bool        mIsBodyDirMayChanged;

public:
	bool IsGoalie() const { return mIsGoalie; }
	void UpdateIsGoalie(bool is_goalie) { mIsGoalie = is_goalie; }

private:
	bool        mIsGoalie;

public:
    bool IsSensed() const { return mIsSensed; }
    void UpdateIsSensed(bool is_sensed) { mIsSensed = is_sensed; }

private:
    bool        mIsSensed; // Ϊtrue��ʾ�ǿ����յ�sense��Ϣ����Ա���������������Լ�
    // true means a player sensable, it's the agent itself.

public:
	/** some useful interfaces */
	const double & GetPlayerSpeedMax() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).playerSpeedMax(); }
	const double & GetStaminaIncMax() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).staminaIncMax(); }
	const double & GetPlayerDecay() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).playerDecay(); }
	const double & GetInertiaMoment() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).inertiaMoment(); }
	const double & GetDashPowerRate() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).dashPowerRate(); }
	const double & GetPlayerSize() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).playerSize(); }
	const double & GetKickableMargin() const {return PlayerParam::instance().HeteroPlayer(mPlayerType).kickableMargin(); }
	const double & GetKickRand() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).kickRand(); }
	const double & GetKickPowerRate() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).kickPowerRate(); }
	const double & GetExtraStamina() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).extraStamina(); }
	const double & GetEffortMax() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).effortMax(); }
	const double & GetEffortMin() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).effortMin(); }
	virtual const double & GetKickableArea() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).kickableArea(); }
	const double & GetCatchAreaLStretch() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).catchAreaLStretch(); }
	const double & GetFoulDetectProbability() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).foulDetectProbability(); }
	//TODO: returned value isn't a reference
	double GetAccelerationRateOnDir(const double dir) const { return PlayerParam::instance().HeteroPlayer(mPlayerType).accelerationRateOnDir(dir); }
    const double & GetAccelerationFrontRate() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).accelerationFrontRate(); }
    const double & GetAccelerationSideRate() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).accelerationSideRate(); }
    const double & GetAccelerationFrontMax() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).accelerationFrontMax(); }
    const double & GetAccelerationSideMax() const { return PlayerParam::instance().HeteroPlayer(mPlayerType).accelerationSideMax(); }
    const double & GetAccelerationFront(const double & power) const { return PlayerParam::instance().HeteroPlayer(mPlayerType).accelerationFront(power); }
    const double & GetAccelerationSide(const double & power) const { return PlayerParam::instance().HeteroPlayer(mPlayerType).accelerationSide(power); }

	/**
	 * Get the predicted position with a turn and some dashes.
	 * @param angle the turn angle.
	 * @param steps the total steps to predict.
	 * @param dash_power the intend dash power.
	 * @param dash_dir the dash direction.
	 * @param with_turn true means considering a turn.
	 * @param idle_cycles the idle cycles before action.
	 * @param last_vel the last cycle velocity.
	 * @return a vector to show the prediction.
	 */
	Vector GetPredictedPosWithTurn(double angle, int steps = 1, double dash_power = 0,	AngleDeg dash_dir = 0.0, bool with_turn = true, int idle_cycles = 0, Vector *last_vel = NULL) const;
	Vector GetPredictedPosWithDash(int steps = 1, double dash_power = 0, AngleDeg dash_dir = 0.0, int idle_cycles = 0, Vector *last_vel = NULL)  const{ return GetPredictedPosWithTurn(0.0, steps, dash_power, dash_dir, false, idle_cycles, last_vel); }
	//return the last_vel
	Vector GetPredictedVelWithTurn(double angle, int steps = 1, double dash_power = 0,	AngleDeg dash_dir = 0.0, bool with_turn = true, int idle_cycles = 0) const;
	Vector GetPredictedVelWithDash(int steps = 1, double dash_power = 0, AngleDeg dash_dir = 0.0, int idle_cycles = 0)  const{ return GetPredictedVelWithTurn(0.0, steps, dash_power, dash_dir, false, idle_cycles); }

	/**
	 * Correct the dash power for stamina.
	 * @param dash_power the intend dash power.
	 * @param stamina the stamina now.
	 * @param effort the effort.
	 * @param recovery the player's stamina recovery.
	 * @return dash power corrected.
	 */
	double CorrectDashPowerForStamina(double dash_power, double stamina, double effort, double recovery) const;
	double CorrectDashPowerForStamina(double dash_power, double stamina) const
	{ return CorrectDashPowerForStamina(dash_power, stamina, GetEffort(), GetRecovery()); }
	double CorrectDashPowerForStamina(double dash_power) const
	{ return CorrectDashPowerForStamina(dash_power, GetStamina(), GetEffort(), GetRecovery()); }

	/**
	 * Get the effective turn angle.
	 * @param turn_ang the angle for turn command.
	 * @param my_speed the player's speed.
	 * @param the effective turn angle.
	 */
	AngleDeg GetEffectiveTurn(AngleDeg turn_ang, double my_speed) const;
	AngleDeg GetEffectiveTurn(AngleDeg turn_ang) const
	{ return GetEffectiveTurn(turn_ang, GetVel().Mod()); }
	AngleDeg GetMaxEffectiveTurn(double my_speed) const /* how much we'll actually turn if we try max turn */
	{ return GetEffectiveTurn(ServerParam::instance().maxMoment(), my_speed); }

	/**
	 * Update the predicted stamina with dash.
	 * @param stamina the stamina to update.
	 * @param effort the effort to update.
	 * @param recovery the recovery to update.
	 * @param dash_power the dash power.
	 */
	void UpdatePredictedStaminaWithDash(double* stamina, double* effort, double* recovery, double dash_power) const;

public:
	/**
	 * �����Ǽ����ж��Ƿ�valid�Ľ�ڣ�TODO: ���谴��08����ʣ�µĲ��� -- ע�⣬��08�У�Memory�����State���治��ȫһ��
	 *
	 * @return
	 */
	/**
	 * It's a interface to check if valid.
	 */
	bool IsBodyDirValid() const { return GetBodyDirConf() > 0.991; }
};

//make to be inlined
inline void PlayerState::UpdateStamina(double stamina)
{
	mStamina = stamina;
}

inline void PlayerState::UpdateEffort(double effort)
{
	mEffort = effort;
}

inline void PlayerState::UpdateCapacity(double capacity)
{
	mCapacity = capacity;
}

inline void PlayerState::UpdateNeckDir(double dir, int delay, double conf)
{
	mNeckDir.mValue = GetNormalizeAngleDeg(dir);
	mNeckDir.mCycleDelay = delay;
	mNeckDir.mConf  = conf;
}

inline void PlayerState::UpdateBodyDir(double dir, int delay, double conf)
{
	mBodyDir.mValue = GetNormalizeAngleDeg(dir);
	mBodyDir.mCycleDelay = delay;
	mBodyDir.mConf = conf;
}

inline void PlayerState::UpdateTackleBan(int ban)
{
	mTackleBan = ban;
}

inline void PlayerState::UpdateCatchBan(int ban)
{
	mCatchBan = ban;
}

inline void PlayerState::UpdateArmPoint(AngleDeg dir, int delay, double conf, double dist, int move_ban , int expire_ban )
{
	ArmPoint arm;
	arm.mTargetDir = GetNormalizeAngleDeg(dir);
	arm.mTargetDist = dist;
	arm.mMovableBan = move_ban;
	arm.mExpireBan  = expire_ban;

	mArmPoint.mValue = arm;
	mArmPoint.mCycleDelay = delay;
	mArmPoint.mConf  = conf;
}

inline void PlayerState::UpdateFocusOn(char side, Unum num, int delay, double conf)
{
	FocusOn focus;
	focus.mFocusSide = side;
	focus.mFocusNum  = num;

	mFocusOn.mValue = focus;
	mFocusOn.mCycleDelay = delay;
	mFocusOn.mConf  = conf;
}

inline void PlayerState::UpdateKicked(bool is_kicked)
{
	mIsKicked = is_kicked;
}

inline void PlayerState::UpdateLying(bool is_lying)
{
	mIsLying = is_lying;
}

inline void PlayerState::AutoUpdate(int delay_add, double conf_dec_factor)
{
	MobileState::AutoUpdate(delay_add , conf_dec_factor);

	mNeckDir.AutoUpdate(delay_add , conf_dec_factor);
	mBodyDir.AutoUpdate(delay_add , conf_dec_factor);
	mArmPoint.AutoUpdate(delay_add , conf_dec_factor);
	mFocusOn.AutoUpdate(delay_add , conf_dec_factor);

	mCollideWithPost = false;
	mCollideWithPlayer = false;
	mCollideWithBall = false;
	mIsKicked    = false;
	mIsTired     = false;

	if (mTackleBan > 0) {
		mTackleBan -= delay_add;
		mTackleBan = Max(mTackleBan, 0);
	}

	if (GetPosDelay() > delay_add)
	{
		mIsBodyDirMayChanged = true;
	}
}

inline void PlayerState::UpdatePlayerType(int type)
{
	if (mPlayerType != type) {
		mPlayerType = type;

		SetDecay(PlayerParam::instance().HeteroPlayer(mPlayerType).playerDecay());
		SetEffectiveSpeedMax(PlayerParam::instance().HeteroPlayer(mPlayerType).effectiveSpeedMax());
	}
}

inline void PlayerState::UpdateViewWidth(ViewWidth width)
{
	mViewWidth = width;
}

inline void PlayerState::UpdateUnum(Unum num)
{
	mUnum = num;
}

inline void PlayerState::SetIsAlive(bool alive)
{
	mIsAlive = alive;

	if (!mIsAlive) {
		UpdatePos(GetPos(), GetPosDelay(), 0.0);
		UpdateVel(GetVel(), GetVelDelay(), 0.0);

		mNeckDir.mConf = 0.0;
		mBodyDir.mConf = 0.0;
	}
}

#endif
