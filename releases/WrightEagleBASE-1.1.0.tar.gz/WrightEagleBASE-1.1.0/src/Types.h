/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __Types_H__
#define __Types_H__

#include <algorithm>
#include <iostream>
#include <cmath>

#ifndef M_PI
#define M_PI        3.14159265358979323846
#endif

#ifndef M_E
#define M_E         2.71828182845904523536
#endif

#define SQRT_2      1.41421356237309504880 // ����2
#define FLOAT_EPS   0.000006
#define MAX_MESSAGE 4096

#define PRINT_ERROR(error)     std::cerr << __FILE__ << ":" << __LINE__ << " : " << error << std::endl;

/**
 * ǿ����ɶδ����Ա㱻�����ܼ�¼��log��coredump
 * Create a segmentation fault for recording log and coredump file.
 */
extern int abort_with_SIGSEGV(const char *expr = 0, const char *file = 0, int line = 0, const char *function = 0);

/**
 * ��Ϊrelease�汾������û�ж���Assert�ģ�����Assert���治Ҫ����Ч�ı���ʽ������release�汾�н���ʧ��
 * Because there is no release version of the definition of Assert, so do not put inside Assert effective
 * expression, or release version will be lost.
 */
#ifdef _Debug
#ifndef WIN32
#define Assert(expr)							\
	     ((expr)								\
         ? (0)          						\
         : abort_with_SIGSEGV (__STRING(expr), __FILE__, __LINE__, __PRETTY_FUNCTION__))
#else
#include <cassert>
#define Assert(expr) assert(expr)
#endif
#define Sqrt(x) (Assert(x >= -0.0), sqrt(x))
#else
#define Assert(expr)
#define Sqrt(x) (sqrt(x))
#endif

#ifndef WIN32
#define Isnan(val) isnan(val)
#else
#include <float.h>
#define Isnan(val) _isnan(val)
#endif

#define Min(x,y) ((x) < (y) ? (x) : (y))
#define Max(x,y) ((x) > (y) ? (x) : (y))
#define MinMax(min, x, max) Min(Max((min),(x)), (max))

#define Rint(x) (floor(x + 0.5))
#define Sign(x) ((x) >= 0 ? 1 : -1)
#define Sqr(x) ((x)*(x))

/**
 * ��Ա�ĸ���
 * Number of players.
 */
#define TEAMSIZE 11

/**
 * pointҪ������Ƕ�
 * Max point direction.
 */
#define MAX_POINT_DIR 120

#define HUGE_DIST    (1000000.0)

/**
 * ��dash power��ɢΪ100�����洢һЩ����
 * Dash power will be divided into 100, some data storage.
 */
#define DASH_POWER_NUM 100

typedef double AngleRad;
typedef double AngleDeg;
typedef int    Unum;

extern const char *ServerPlayModeString[];
extern const Unum Unum_Unknown;

/**
 * ������4�ֿ�ѡ���ͣ�����teammate��һ��ֻ��FT_Attack_Forward��FT_Defend_Back���֣�����opponent�������������������ǰ���4������ֱ�������
 * There are four kinds of optional formation, the teammate, the general FT_Attack_Forward and FT_Defend_Back
 * only two, the opponent, the coach sent in accordance with the formation for each of four kinds of fat to the
 */
enum FormationType
{
    FT_Attack_Forward,  // ǰ������
    FT_Attack_Midfield, // �г�����
    FT_Defend_Midfield, // �г�����
    FT_Defend_Back,     // �󳡷���
    FT_Max
};

/**
 * ��������
 * Front type
 */
enum LineType
{
    LT_Null,
    LT_Goalie,
    LT_Defender,
    LT_Midfielder,
    LT_Forward
};

/**
 * λ������
 * Position type.
 */
enum PositionType
{
    PT_Null,
    PT_Left,
    PT_Middle,
    PT_Right,
	PT_RightRight,
	PT_RightMiddle,
	PT_LeftMiddle,
	PT_LeftLeft
};

enum Pside
{
  PS_None,
  PS_Left,
  PS_Center,
  PS_Right
};

/**
 * ��̬�����м�¼��Ϣ������
 * Message type in dynamic debugging.
 */
enum MessageType
{
    MT_Null,
    MT_Parse,
    MT_Run,
    MT_Send
};

enum EarMode
{
	EM_Null,
	EM_Partial,
	EM_Complete,
    EM_All
};

enum CommandType
{
	CT_None,
	CT_Turn,
	CT_Dash,
	CT_TurnNeck,
	CT_Say,
	CT_Attentionto,
	CT_Kick,
	CT_Tackle,
	CT_Pointto,
	CT_Catch,
	CT_Move,
	CT_ChangeView,
	CT_Compression,
	CT_SenseBody,
	CT_Score,
	CT_Bye,
	CT_Done,
	CT_Clang,
	CT_Ear,
	CT_SynchSee,
	CT_ChangePlayerType
};

enum ViewWidth
{
	VW_None,
	VW_Narrow,
	VW_Normal,
	VW_Wide
};


enum ServerPlayMode {
	SPM_Null,
	SPM_BeforeKickOff,
	SPM_TimeOver,
	SPM_PlayOn,
	SPM_KickOff_Left,
	SPM_KickOff_Right,
	SPM_KickIn_Left,
	SPM_KickIn_Right,
	SPM_FreeKick_Left,
	SPM_FreeKick_Right,
	SPM_CornerKick_Left,
	SPM_CornerKick_Right,
	SPM_GoalKick_Left,
	SPM_GoalKick_Right,
	SPM_AfterGoal_Left,
	SPM_AfterGoal_Right,
	SPM_Drop_Ball,
	SPM_OffSide_Left,
	SPM_OffSide_Right,
	// [I.Noda:00/05/13] added for 3D viewer/commentator/small league
	SPM_PK_Left,
	SPM_PK_Right,
	SPM_FirstHalfOver,
	SPM_Pause,
	SPM_Human,
	SPM_Foul_Charge_Left,
	SPM_Foul_Charge_Right,
	SPM_Foul_Push_Left,
	SPM_Foul_Push_Right,
	SPM_Foul_MultipleAttacker_Left,
	SPM_Foul_MultipleAttacker_Right,
	SPM_Foul_BallOut_Left,
	SPM_Foul_BallOut_Right,
	SPM_Back_Pass_Left,
	SPM_Back_Pass_Right,
	SPM_Free_Kick_Fault_Left,
	SPM_Free_Kick_Fault_Right,
	SPM_CatchFault_Left,
	SPM_CatchFault_Right,
	SPM_IndFreeKick_Left,
	SPM_IndFreeKick_Right,
	SPM_PenaltySetup_Left,
	SPM_PenaltySetup_Right,
	SPM_PenaltyReady_Left,
	SPM_PenaltyReady_Right,
	SPM_PenaltyTaken_Left,
	SPM_PenaltyTaken_Right,
	SPM_PenaltyMiss_Left,
	SPM_PenaltyMiss_Right,
	SPM_PenaltyScore_Left,
	SPM_PenaltyScore_Right,
	SPM_GoalieCatchBall_Left,
	SPM_GoalieCatchBall_Right,
	SPM_TimeUp,
	SPM_HalfTime,
	SPM_TimeExtended,
	SPM_PenaltyOnfield_Left,
	SPM_PenaltyOnfield_Right,
	SPM_PenaltyFoul_Left,
	SPM_PenaltyFoul_Right,
	SPM_PenaltyWinner_Left,
	SPM_PenaltyWinner_Right,
    SPM_Foul_Left,
    SPM_Foul_Right,
	SPM_MAX
};

enum CardType
{
	CR_None,
	CR_Yellow,
	CR_Red
};

enum KickOffMode
{
	KO_Ours,
	KO_Opps,
};

/**
 * ��ServerPlayMode�н����������߲�ֱ�����������
 * Generated from ServerPlayMode, it's better to use this one.
 */
enum PlayMode
{
	PM_No_Mode,

	PM_Play_On,

	PM_Our_Kick_In,
	PM_Our_Kick_Off,
	PM_Our_Corner_Kick,
	PM_Our_Goal_Kick,
	PM_Our_Free_Kick,
	PM_Our_Goalie_Free_Kick,    /* not a real play mode */
	PM_Our_Offside_Kick,
	PM_Our_Back_Pass_Kick,
	PM_Our_Indirect_Free_Kick,
	PM_Our_Free_Kick_Fault_Kick,

	PM_Our_Penalty_Setup,
	PM_Our_Penalty_Ready,
	PM_Our_Penalty_Taken,
	PM_Our_Penalty_Score,
	PM_Our_Penalty_Miss,
    PM_Our_Penalty_Foul,
    PM_Our_Penalty_Winner,
	PM_Our_CatchFault_Kick,

	PM_Our_Mode,

	PM_Before_Kick_Off,
	PM_Penalty_On_Our_Field,
	PM_Our_Penalty,
	PM_Opp_Penalty,
	PM_Penalty_On_Opp_Field,
	PM_Drop_Ball,
	PM_Half_Time,
	PM_Time_Over,
    PM_Time_Up,
	PM_Extended_Time,
	PM_Goal_Ours,
	PM_Goal_Opps,
    PM_Our_Foul,
    PM_Opp_Foul,
	PM_Our_Foul_Charge_Mode,
	PM_Opp_Foul_Charge_Mode,

	PM_Opp_Mode,

	PM_Opp_Corner_Kick,
	PM_Opp_Kick_Off,
	PM_Opp_Kick_In,
	PM_Opp_Goal_Kick,
	PM_Opp_Free_Kick,
	PM_Opp_Goalie_Free_Kick,  /* not a real play mode */
	PM_Opp_Offside_Kick,
	PM_Opp_Free_Kick_Fault_Kick,
	PM_Opp_Indirect_Free_Kick,
	PM_Opp_Back_Pass_Kick,

	PM_Opp_Penalty_Setup,
	PM_Opp_Penalty_Ready,
	PM_Opp_Penalty_Taken,
	PM_Opp_Penalty_Score,
	PM_Opp_Penalty_Miss,
    PM_Opp_Penalty_Foul,
    PM_Opp_Penalty_Winner,
	PM_Opp_CatchFault_Kick,
};

enum ObjectType{
	OBJ_Line,
	OBJ_Ball,
	OBJ_Marker,
	OBJ_Marker_Behind,  /* Not seen */
	OBJ_Player,
	OBJ_None
};

enum SideLineType
{
	SL_Left = 0,
	SL_Right,
	SL_Top,
	SL_Bottom,

	SL_MAX,
	SL_NONE
};

enum MarkerType
{
	Goal_L = 0,
	Goal_R,

	Flag_C,
	Flag_CT,
	Flag_CB,
	Flag_LT,
	Flag_LB,
	Flag_RT,
	Flag_RB,

	Flag_PLT,
	Flag_PLC,
	Flag_PLB,
	Flag_PRT,
	Flag_PRC,
	Flag_PRB,

	Flag_GLT,
	Flag_GLB,
	Flag_GRT,
	Flag_GRB,

	Flag_TL50,
	Flag_TL40,
	Flag_TL30,
	Flag_TL20,
	Flag_TL10,
	Flag_T0,
	Flag_TR10,
	Flag_TR20,
	Flag_TR30,
	Flag_TR40,
	Flag_TR50,

	Flag_BL50,
	Flag_BL40,
	Flag_BL30,
	Flag_BL20,
	Flag_BL10,
	Flag_B0,
	Flag_BR10,
	Flag_BR20,
	Flag_BR30,
	Flag_BR40,
	Flag_BR50,

	Flag_LT30,
	Flag_LT20,
	Flag_LT10,
	Flag_L0,
	Flag_LB10,
	Flag_LB20,
	Flag_LB30,

	Flag_RT30,
	Flag_RT20,
	Flag_RT10,
	Flag_R0,
	Flag_RB10,
	Flag_RB20,
	Flag_RB30,

	FLAG_MAX,
	FLAG_NONE
};


enum ServerMsgType{
	None_Msg,
	Sight_Msg,
	CoachSight_Msg,
	Hear_Msg,
	Sense_Msg,
	Fullstate_Msg,
	ServerParam_Msg,
	PlayerParam_Msg,
	ChangePlayerType_Msg,
    Clang_Msg,
	PlayerType_Msg,
	Error_Msg,
    Disp_Msg,
	Ok_Msg,
	Score_Msg,
	Initialize_Msg
};

enum KickMode
{
    KM_Null,
    KM_Hard,
    KM_Quick
};

enum PlayerRole
{
	PR_BackCenter,
	PR_BackSide,
	PR_MidCenter,
	PR_MidSide,
	PR_ForwardCenter,
	PR_ForwardSide,
	PR_Max
};

enum Situation
{
	ST_Forward_Attack,
	ST_Penalty_Attack,
	ST_Defense
};

enum AttackPhase
{
    AP_None,
    AP_Back,
    AP_Back_Mid,
    AP_Mid_Forward,
    AP_Forward
};

#endif
