/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include <cstdlib>
#include "InterceptInfo.h"
#include "InterceptModel.h"
#include "Dasher.h"
#include "Logger.h"

//==============================================================================
InterceptInfo::InterceptInfo(WorldState *pWorldState, InfoState *pInfoState): InfoStateBase( pWorldState, pInfoState )
{
}


//==============================================================================
InterceptInfo::~InterceptInfo()
{
}


//==============================================================================
/**
 * Update Routine information
 */
void InterceptInfo::UpdateRoutine()
{
	SortInterceptInfo();
}

/**
 * Sort InterceptInfo
 */
void InterceptInfo::SortInterceptInfo()
{
	mOIT.clear();
	OrderedIT oit;

	for (int i = 1; i <= TEAMSIZE; i++){
		oit.mUnum = i;
		if (mpWorldState->GetPlayer(i).IsAlive()){
			oit.mpInterceptInfo = VerifyIntInfo(i);
			oit.mCycleDelay = mpWorldState->GetPlayer(i).GetPosDelay();
			mOIT.push_back(oit);
		}

		oit.mUnum = -i;
		if (mpWorldState->GetPlayer(-i).IsAlive()){
			oit.mpInterceptInfo = VerifyIntInfo(-i);
			oit.mCycleDelay = mpWorldState->GetPlayer(-i).GetPosDelay();
			mOIT.push_back(oit);
		}
	}
	mOIT.sort();

	if (PlayerParam::instance().SaveTextLog()) {
		Logger::instance().GetTextLogger("oit") << "\n" << mpWorldState->CurrentTime() << ": "<< std::endl;
		Logger::instance().GetTextLogger("oit") << "#" << "\t" << "cd" << "\t" << "min" << "\t" << "idl" << "\t" << "its" << "\t" << "it0" << "\t" << "it1" << "\t" << "it2" << std::endl;

		for (std::list<OrderedIT>::iterator it = mOIT.begin(); it != mOIT.end(); ++it) {
			Logger::instance().GetTextLogger("oit") << it->mUnum
			<< "\t" << it->mCycleDelay
			<< "\t" << it->mpInterceptInfo->mMinCycle
			<< "\t" << it->mpInterceptInfo->mIdleCycle
			<< "\t" << it->mpInterceptInfo->mIntervals;

			for (int i = 0; i < it->mpInterceptInfo->mIntervals; ++i) {
				Logger::instance().GetTextLogger("oit") << "\t" << it->mpInterceptInfo->mInterCycle[i];
			}

			Logger::instance().GetTextLogger("oit") << std::endl;
		}
	}
}

/**
 * Calculate Player unum Intercept information
 */
PlayerInterceptInfo *InterceptInfo::VerifyIntInfo(Unum unum)
{
	PlayerInterceptInfo* pInfo = GetPlayerInterceptInfo(unum);
	if (pInfo == NULL) {
		return NULL;
	}

	if(pInfo->mTime != mpWorldState->CurrentTime()){
		pInfo->mIdleCycle = 0;

		Vector vBallPos = mpWorldState->GetBall().GetPos();
		Vector vBallVel = mpWorldState->GetBall().GetVel();

		if (pInfo->mpPlayer->IsTackling()){ //����Է�����Ҫ���ǻ���м�������
											//if opponent tackling, then he idle for a few cycles
			pInfo->mIdleCycle = pInfo->mpPlayer->GetTackleBan();	//���е�����
																	//idle cycle
			for (int i = 0; i < pInfo->mIdleCycle; ++i){
				vBallPos += vBallVel;
				vBallVel *= ServerParam::instance().ballDecay();
			}
		}

		CalcInterception(vBallPos, vBallVel, pInfo);
		pInfo->mTime = mpWorldState->CurrentTime();
	}

	return pInfo;
}

/**
 * Caclulate intercept method
 * @param ball_pos ball position
 * @param ball_vel ball velocity
 * @param pInfo player intercept information
 * @param can_inverse 
 * @return
 */
void InterceptInfo::CalcInterception(const Vector & ball_pos, const Vector & ball_vel, PlayerInterceptInfo *pInfo,  bool can_inverse)
{
	//step 1. ���򻯽���ģ��
	//step 1. solve the simplified intercept model
	InterceptModel::instance().CalcInterception(ball_pos, ball_vel, pInfo->mpPlayer, &(pInfo->solution));

	//step 2. ������������
	//step 2. fix the intercept area
	//	ȡ��
	//  take the integer value of 
	if (pInfo->solution.interc == 1){
		pInfo->mInterCycle[0] = (int)floor(pInfo->solution.intert[0]);	//�����ֲ���idle_cycle����Ϊ���滹Ҫ������������������ball_pos�Ѿ��ǹ���idle_cycle���λ��
																		//No idle_cycle plus here for the fixing followed and the ball_pos have been the position after idle_cycle.
		//������ȡ�½磬����������
		//lower bound, fix latter 
	}
	else { //3
		pInfo->mInterCycle[0] = (int)floor(pInfo->solution.intert[0]);	//������ȡ�½磬����������
																		//lower bound
		pInfo->mInterCycle[1] = (int)ceil(pInfo->solution.intert[1]);	//������ȡ�Ͻ磬����������
																		//upper bound
		pInfo->mInterCycle[2] = (int)floor(pInfo->solution.intert[2]);	//������ȡ�½磬����������
																		//lower bound


		if (pInfo->mInterCycle[0] > pInfo->mInterCycle[1]){ //���������ɵ�
															//intercept area shrink to a point
			pInfo->mInterCycle[0] = pInfo->mInterCycle[2];
			pInfo->solution.interc = 1;
		}
	}

	bool kickable = pInfo->mpPlayer->GetPos().Dist(ball_pos) < pInfo->mpPlayer->GetKickableArea();	//�������λ�ò�һ��ʱworldstate�е����λ�ã�������player->IsKickable()�ж�
																									//ball position here isn't the position in worldstate. so player->IsKickable() disable here
	if (!kickable) {
		pInfo->mInterCycle[0] = Max(pInfo->mInterCycle[0], 1);
	}
	else {
		pInfo->mInterCycle[0] = 0;
	}

	if (pInfo->solution.interc > 1){
		pInfo->mInterCycle[1] = Max(pInfo->mInterCycle[1], pInfo->mInterCycle[0]);
		pInfo->mInterCycle[2] = Max(pInfo->mInterCycle[2], pInfo->mInterCycle[1]);
	}

	//�ȸ���go_to_pointģ������
	//fix by go_to_point model
	VirtualBall vBall(ball_pos, ball_vel);

	if (pInfo->solution.interc == 1){
		int cycle_sup = pInfo->mInterCycle[0];
		int cycle_inf = VirtualBall::MAX_STEP;
		for (int i = cycle_sup; i <= cycle_inf; ++i){
			int n = Dasher::instance().CycleNeedToPoint(*(pInfo->mpPlayer), vBall.GetPredictPosition(i), can_inverse);
			if (n <= i){	//n�Ժ���ȫ�ɽ�
							//interceptable if i >= n
				break;
			}
			pInfo->mInterCycle[0] ++;
		}
	}
	else { //3
		int cycle_sup = pInfo->mInterCycle[0];
		int cycle_inf = pInfo->mInterCycle[1];
		for (int i = cycle_sup; i <= cycle_inf; ++i){
			int n = Dasher::instance().CycleNeedToPoint(*(pInfo->mpPlayer), vBall.GetPredictPosition(i), can_inverse);
			if (n <= i){
				break;
			}
			pInfo->mInterCycle[0] ++;
		}
		if (pInfo->mInterCycle[0] <= pInfo->mInterCycle[1]){
			cycle_sup = pInfo->mInterCycle[0];
			cycle_inf = pInfo->mInterCycle[1];
			for (int i = cycle_inf; i >= cycle_sup; --i){
				int n = Dasher::instance().CycleNeedToPoint(*(pInfo->mpPlayer), vBall.GetPredictPosition(i), can_inverse);
				if (n <= i){
					break;
				}
				pInfo->mInterCycle[1] --;
			}
			if (pInfo->mInterCycle[0] > pInfo->mInterCycle[1]){ //���������ɵ�
																//the intercept area shrink to a point
				pInfo->solution.interc = 1;
			}
		}
		else {
			pInfo->solution.interc = 1;
		}

		cycle_sup = pInfo->mInterCycle[2];
		cycle_inf = VirtualBall::MAX_STEP;
		for (int i = cycle_sup; i <= cycle_inf; ++i){
			int n = Dasher::instance().CycleNeedToPoint(*(pInfo->mpPlayer),vBall.GetPredictPosition(i), can_inverse);
			if (n <= i){	//n�Ժ���ȫ�ɽ�
							//interceptable if i >= n
				break;
			}
			pInfo->mInterCycle[2] ++;
		}

		if (pInfo->solution.interc == 1){
			pInfo->mInterCycle[0] = pInfo->mInterCycle[2];
		}
	}


	//step 3. �������
	//setp 3. analyse result
	if (pInfo->solution.interc <= 1){
		pInfo->mInterCycle[0] += pInfo->mIdleCycle;
	}
	else {
		pInfo->mInterCycle[0] += pInfo->mIdleCycle;
		pInfo->mInterCycle[1] += pInfo->mIdleCycle;
		pInfo->mInterCycle[2] += pInfo->mIdleCycle;
	}

	pInfo->mIntervals = (pInfo->solution.interc == 1)? 1: 2;
	pInfo->mMinCycle = pInfo->mInterCycle[0];
	if (pInfo->mMinCycle == 0) pInfo->mIntervals = 0;	//��ʾ����
														//kickable
	pInfo->mInterPos = vBall.GetPredictPosition(pInfo->mMinCycle - pInfo->mIdleCycle);	//����Ҫ��idle_cycle����Ϊ��������ball_pos�Ѿ��ǹ���idle_cycle���λ��
																						//It has been idle_cycle cycle since ball_pos is called.

	if (!ServerParam::instance().pitchRectanglar().IsWithin(pInfo->mInterPos, 4.0)){
		pInfo->mRes = IR_Failure;
	}
	else {
		pInfo->mRes = IR_Success;
	}
}

/**
 * Get player intercept information
 * @param unum player's number
 * @return
 */
PlayerInterceptInfo *InterceptInfo::GetPlayerInterceptInfo(Unum unum) const
{
	Assert(abs(unum) >= 1 && abs(unum) <= TEAMSIZE);

	if (!mpWorldState->GetPlayer(unum).IsAlive()) { Assert(0); return 0; }
	if (!(abs(unum) >= 1 && abs(unum) <= TEAMSIZE)) { Assert(0); return 0; }

	PlayerInterceptInfo *pInfo = const_cast<PlayerInterceptInfo *>(unum > 0? &(mTeammateInterceptInfo[unum]): &(mOpponentInterceptInfo[-unum]));
	pInfo->mpPlayer = & (mpWorldState->GetPlayer(unum));
	return pInfo;
}

// end of Intercept.cpp

