/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef OBSERVER_H_
#define OBSERVER_H_

#include "Thread.h"
#include "Geometry.h"
#include "ServerParam.h"
#include "BallState.h"
#include "PlayerState.h"

//======================================================================================================================
template < class T >
class ObserverRecord {
	T    mValue;
	Time mTime;

public:
	ObserverRecord():
		mTime(Time(-1, 0))
	{
		memset(& mValue, 0, sizeof(mValue));
	}

	const T & value() const { return mValue; }
	const Time & time() const { return mTime; }

	void SetValue(const T & value) { mValue = value; }
	void SetTime(const Time & time) { mTime = time; }
	void Set(const T & value, const Time & time) { SetValue(value); SetTime(time); }
};

//======================================================================================================================
/**
 * �������Ӿ��۲���
 */
/**
 * Basic Sight Observer
 */
class SightObserver {
	ObserverRecord<double>   mDist;						//��Ծ���
														//relative distance
	ObserverRecord<AngleDeg> mDir;						//����Լ�ͷ���ķ��� -- ͷ���Ƕ�ָȫ�ֵĲ��ӽǶ�
														//angle relative to my head -- here head direction is global direction
	ObserverRecord<double>   mDistChg;					//��Ծ���ı仯�� -- �����ٶ�
														//changes of relative distance -- radial velocity
	ObserverRecord<AngleDeg> mDirChg;					//��ԽǶȵı仯 --- �����ٶ�
														//changes of relative angle -- normal velocity 

public:
	const double & Dist() const { return mDist.value(); }
	const AngleDeg & Dir() const { return mDir.value(); }
	const double & DistChg() const { return mDistChg.value(); }
	const AngleDeg & DirChg() const { return mDirChg.value(); }

	const ObserverRecord<double>& GetDist() const { return mDist;}
	const ObserverRecord<AngleDeg>& GetDir() const { return mDir;}
	const ObserverRecord<double>& GetDistChg() const { return mDistChg;}
	const ObserverRecord<AngleDeg>& GetDirChg() const { return mDirChg;}

	void SetDist(double dist, const Time & time) { mDist.Set(dist, time); }
	void SetDir(AngleDeg dir, const Time & time) { mDir.Set(dir, time); }
	void SetDistChg(double dist_chg, const Time & time) { mDistChg.Set(dist_chg, time); }
	void SetDirChg(AngleDeg dir_chg, const Time & time) { mDirChg.Set(dir_chg, time); }
};

//======================================================================================================================
class BallObserver: public SightObserver {
};

//======================================================================================================================
class FlagObserver: public SightObserver {
	Vector mGlobalPosition;

public:
	Vector GlobalPosition() const{ return mGlobalPosition; }
	void SetGlobalPosition(Vector global_position) { mGlobalPosition = global_position; }
};

//======================================================================================================================
class MarkerObserver: public FlagObserver {
	MarkerType mType;											///marker������
	void SetType(MarkerType type) { mType = type; }

public:
	MarkerObserver() { mType = FLAG_NONE; }

	const MarkerType & Type() const { return mType; }
	void Initialize(MarkerType type, Vector global_pos, bool rotate)
	{
		SetGlobalPosition(rotate? -global_pos: global_pos);  /* If on the right side of the field, flip all coords */
		SetType(type);
	}
};

//======================================================================================================================
/**
 * Edge of pitch
 */
class LineObserver: public FlagObserver {
	SideLineType mType;										 		//line������
																	//type of line
	void SetType(SideLineType type) { mType = type; }
	const double & DistChg();  // not used
	const AngleDeg & DirChg(); // not used

public:
	LineObserver() { mType = SL_NONE; }

	const SideLineType & Type() const { return mType; }
	void Initialize(SideLineType type, Vector global_pos, bool rotate)
	{
		SetGlobalPosition(rotate? -global_pos: global_pos);  /* If on the right side of the field, flip all coords */
		SetType(type);
	}
};

//======================================================================================================================
class PlayerObserver: public SightObserver {
	char mSide;
	int  mUnum;
	ObserverRecord<AngleDeg> mBodyDir;					//�Է���������Լ�ͷ���ĽǶ�
														//opponent's angle relative to my head angle
	ObserverRecord<AngleDeg> mHeadDir;					//�Է�ͷ������Լ�ͷ���ĽǶ�
														//opponent's head angle relative to my head angle
	ObserverRecord<bool>     mIsTackling;				//����Ƿ��ڲ���
														//used to tag if is tackling
	ObserverRecord<bool>     mIsKicked;				    //����Ƿ����������߹���
														//used to tag if kicked last cycle
	ObserverRecord<bool>     mIsPointing;				//����Ƿ���ָ
														//used to tag if is pointing
	ObserverRecord<bool>     mIsLying;					//����Ƿ񱻲���
														//used to tag if is lying
	CardType				 mCardType;					//��Ƿ����¼
														//the player card type
	AngleDeg                 mPointDir;					//���ͷ����ָ��Ƕ�
														//point angle relative to head angle

public:
	PlayerObserver() { mSide = '?'; mUnum = 0; }

	const char & Side() const { return mSide; }
	const int & Unum() const { return mUnum; }
	const AngleDeg & BodyDir() const { return mBodyDir.value(); }
	const AngleDeg & HeadDir() const { return mHeadDir.value(); }
	const bool & IsTackling() const { return mIsTackling.value(); }
	const bool & IsKicked() const { return mIsKicked.value(); }
	const bool & IsLying()  const { return mIsLying.value(); }
	const bool & IsPointing() const { return mIsPointing.value(); }
	const AngleDeg & PointDir() const { return mPointDir; }
	const CardType & GetCardType() const { return mCardType; }

	const ObserverRecord<AngleDeg> & GetBodyDir() const { return mBodyDir; }
	const ObserverRecord<AngleDeg> & GetHeadDir() const { return mHeadDir; }
	const ObserverRecord<bool>     & GetIsTackling() const { return mIsTackling; }
	const ObserverRecord<bool>     & GetIsKicked() const { return mIsKicked; }
	const ObserverRecord<bool>     & GetIsLying() const { return mIsLying; }
	const ObserverRecord<bool>     & GetIsPointing() const { return mIsPointing; }

	void SetSide(char side) { mSide = side; }
	void SetUnum(int unum) {mUnum = unum; }
	void SetBodyDir(AngleDeg body_dir, const Time & time) { mBodyDir.Set(body_dir, time); }
	void SetHeadDir(AngleDeg head_dir, const Time & time) { mHeadDir.Set(head_dir, time); }
	void SetIsTcakling(bool is_tackling, const Time & time) { mIsTackling.Set(is_tackling, time); }
	void SetIsKicked(bool is_kicked, const Time & time) { mIsKicked.Set(is_kicked, time); }
	void SetIsLying(bool is_lying, const Time & time) { mIsLying.Set(is_lying, time); }
	void SetCardType(CardType card_type) { mCardType = card_type; }
	void SetIsPointing(bool is_pointing, const Time & time) { mIsPointing.Set(is_pointing, time); }
	void SetPointDir(AngleDeg point_dir) { mPointDir = point_dir; }
};

//======================================================================================================================
/**
* δ��ʶ���unum��side����Ա
*/
/**
 * Unrecognized unum and size
 */
//============================use the server's bug  add by oldtai==========================
class ServerBugInfo
{
public:
    char mSide; //the most probable side;
    Unum mLeastNum; //the least num;
	char mSupSide;
	Unum mSupNum;

    ServerBugInfo()
    {
	    mSide = 'l'; //server send left player as default
	    mLeastNum = 1; //the default least num is 1;
		mSupSide = 'r';
		mSupNum = TEAMSIZE;//THE DEFUALT 
	}
};

//======================================================================================================================
/**
* δ��ʶ�������Ա
*/
/**
 * Unrecognized player
 */
class UnknownPlayerObserver: public SightObserver {
	bool mIsKnownSide;			//tell whether it know the side
	char mSide;
	ObserverRecord<bool>     mIsTackling;			//����Ƿ��ڲ���
													//used to tag if is tackling
	ObserverRecord<bool>     mIsKicked;				//����Ƿ�������
													//used to tag if is kicking
	ObserverRecord<bool>     mIsLying;              //����Ƿ񱻲���
													//used to tag if is lying
	const double & DistChg();  // not used
	const AngleDeg & DirChg(); // not used
	CardType mCardType;

public:
	UnknownPlayerObserver() { mSide = '?'; mIsKnownSide = false;}

	bool  IsKnownSide() const { return mIsKnownSide;}
	const char & Side() const { return mSide; }
	const bool & IsTackling() const { return mIsTackling.value(); }
	const bool & IsKicked() const { return mIsKicked.value(); }
	const bool & IsLying() const { return mIsLying.value(); }
	const ObserverRecord<bool> & GetIsTackling() const { return mIsTackling; }
	const ObserverRecord<bool> & GetIsKicked() const { return mIsKicked; }
	const ObserverRecord<bool> & GetIsLying() const { return mIsLying; }

	void SetSide(char side) { mSide = side; }
	void SetIsTcakling(bool is_tackling, const Time & time) { mIsTackling.Set(is_tackling, time); }
	void SetIsKicked(bool is_kicked, const Time & time) { mIsKicked.Set(is_kicked, time); }
	void SetIsLying(bool is_lying, const Time & time) { mIsKicked.Set(is_lying, time); }
	void SetCardType(CardType card_type) { mCardType = card_type; }
	void SetIsKnownSide(bool known) { mIsKnownSide = known;}
};

//======================================================================================================================
/**
* ��Ա�Լ���sense�۲���
*/
/** 
 * Player's own sense observer
 */
class SenseObserver {
	ViewWidth mViewWidth;	//ͬ��ģʽ�º��� ViewQuality
							//ignore VewQuality when synchronization mode

	double    mStamina;
	double    mEffort;
	double    mCapacity;

	double    mSpeed;
	AngleDeg  mSpeedDir;
	AngleDeg  mNeckDir;

	//counter
	int       mKickCount;
	int       mDashCount;
	int       mTurnCount;
	int       mSayCount;
	int       mTurnNeckCount;
	int       mCatchCount;
	int       mMoveCount;
	int       mChangeViewCount;

	//arm
	int       mArmMovableBan;
	int       mArmExpires;
	double    mArmTargetDist;
	double    mArmTargetDir;
	int       mArmCount;

	//focus
	char      mFocusSide;
	int       mFocusUnum;
	int       mFocusCount;

	//tackle
	int       mTackleExpires;
	int       mTackleCount;

	//foul record
	CardType mCardType;

	//idle cycle
	int mIdleCycle;

	//collision
	bool mIsCollideWithPost;
	bool mIsCollideWithPlayer;
	bool mIsCollideWithBall;

	Time mSenseTime;		//��֪��Ϣ���������
							//time when sense information arrive
public:
	SenseObserver()
	{
		mViewWidth = VW_None;

		mStamina = ServerParam::instance().staminaMax();
		mEffort = ServerParam::instance().effortInit();
		mCapacity = ServerParam::instance().staminaCapacity();

		mSpeed = 0.0;
		mSpeedDir = 0.0;
		mNeckDir = 0.0;

		mKickCount = 0;
		mDashCount = 0;
		mTurnCount = 0;
		mSayCount = 0;
		mTurnNeckCount = 0;
		mCatchCount = 0;
		mMoveCount = 0;
		mChangeViewCount = 0;

		mArmMovableBan = 0;
		mArmExpires = 0;
		mArmTargetDir = 0.0;
		mArmTargetDist = 0.0;
		mArmCount = 0;

		mFocusSide = '?';
		mFocusUnum = 0;
		mFocusCount = 0;

		mTackleExpires = 0;
		mTackleCount = 0;

		mCardType = CR_None;
		mIdleCycle = 0;
		ClearCollisionState();
	}

	const ViewWidth & GetViewWidth() const { return mViewWidth; }
	const double & GetStamina() const { return mStamina; }
	const double & GetEffort() const { return mEffort; }
	const double & GetCapacity() const { return mCapacity; }
	const double & GetSpeed() const { return mSpeed; }
	const AngleDeg & GetSpeedDir() const { return mSpeedDir; }
	const AngleDeg & GetNeckDir() const { return mNeckDir; }

	const int & GetKickCount() const { return mKickCount; }
	const int & GetDashCount() const { return mDashCount; }
	const int & GetTurnCount() const { return mTurnCount; }
	const int & GetSayCount() const { return mSayCount; }
	const int & GetTurnNeckCount() const { return mTurnNeckCount; }
	const int & GetCatchCount() const { return mCatchCount; }
	const int & GetMoveCount() const { return mMoveCount; }
	const int & GetChangeViewCount() const { return mChangeViewCount; }

	const int & GetArmMovableBan() const { return mArmMovableBan; }
	const int & GetArmExpires() const { return mArmExpires; }
	const double & GetArmTargetDist() const { return mArmTargetDist; }
	const double & GetArmTargetDir() const { return mArmTargetDir; }
	const int & GetArmCount() const { return mArmCount; }

	const char & GetFocusSide() const { return mFocusSide; }
	const int & GetFocusUnum() const { return mFocusUnum; }
	const int & GetFocusCount() const { return mFocusCount; }

	const int & GetTackleExpires() const { return mTackleExpires; }
	const int & GetTackleCount() const { return mTackleCount; }

	const CardType & GetMyCardType() const { return mCardType; }
	const int & GetIdleCycle() const { return mIdleCycle; }

	bool IsCollideNone() const { return (mIsCollideWithPost || mIsCollideWithPlayer || mIsCollideWithBall) == false; }
	bool IsCollideWithPost() const { return mIsCollideWithPost; }
	bool IsCollideWithPlayer() const { return mIsCollideWithPlayer; }
	bool IsCollideWithBall() const { return mIsCollideWithBall; }

	const Time & GetSenseTime() const { return mSenseTime; }

	void SetViewWidth(ViewWidth view_width) { mViewWidth = view_width; }
	void SetStamina(double stamina) { mStamina = stamina; }
	void SetEffort(double effort) { mEffort = effort; }
	void SetCapacity(double capacity) { mCapacity = capacity; }
	void SetSpeed(double speed) { mSpeed = speed; }
	void SetSpeedDir(AngleDeg speed_dir) { mSpeedDir = speed_dir; }
	void SetNeckDir(AngleDeg neck_dir) { mNeckDir = neck_dir; }

	void SetKickCount(int kick_count) { mKickCount = kick_count; }
	void SetDashCount(int dash_count) { mDashCount = dash_count; }
	void SetTurnCount(int turn_count) { mTurnCount = turn_count; }
	void SetSayCount(int say_count) { mSayCount = say_count; }
	void SetTurnNeckCount(int turn_neck_count) { mTurnNeckCount = turn_neck_count; }
	void SetCatchCount(int catch_count) { mCatchCount = catch_count; }
	void SetMoveCount(int move_count) { mMoveCount = move_count; }
	void SetChangeViewCount(int change_view) { mChangeViewCount = change_view; }

	void SetArmMovableBan(int arm_movable_ban) { mArmMovableBan = arm_movable_ban; }
	void SetArmExpires(int arm_expires) { mArmExpires = arm_expires; }
	void SetArmTargetDist(double arm_target_dist) { mArmTargetDist = arm_target_dist; }
	void SetArmTargetDir(AngleDeg arm_target_dir) { mArmTargetDir = arm_target_dir; }
	void SetArmCount(int arm_count) { mArmCount = arm_count; }

	void SetFocusSide(char focus_side) { mFocusSide = focus_side; }
	void SetFocusUnum(Unum unum) { mFocusUnum = unum; }
	void SetFocusCount(int focus_count) { mFocusCount = focus_count; }

	void SetTackleExpires(int tackle_expires) { mTackleExpires = tackle_expires; }
	void SetTackleCount(int tackle_count) { mTackleCount = tackle_count; }

	void SetMyCardType( CardType card_type ) { mCardType = card_type; }
	void SetIdleCycle( int idle_cycle ) { mIdleCycle = idle_cycle; }
	void ClearCollisionState() { mIsCollideWithPost = false; mIsCollideWithPlayer = false; mIsCollideWithBall = false; }
	void SetCollideWithPost() { mIsCollideWithPost = true; }
	void SetCollideWithPlayer() { mIsCollideWithPlayer = true; }
	void SetCollideWithBall() { mIsCollideWithBall = true; }

	void SetSenseTime(Time sense_time) { mSenseTime = sense_time; }
};

//======================================================================================================================
/**
 * Audio observer
 */
class AudioObserver {
public:
	enum HearInfoType {
		HearInfo_Null = 0,
		HearInfo_Ball = 1,
		HearInfo_Teammate = 2,
		HearInfo_Opponent = 4
	};

	class AudioPlayer
	{
	public:
		AudioPlayer():
			mPos (Vector(0,0)),
			mUnum(-1)
		{
		}

		AudioPlayer(Vector pos , Unum unum)
		{
			mPos = pos;
			mUnum = unum;
		}

		Vector mPos;
		Unum   mUnum;
	};

    enum OurCoachSayType
    {
        OCST_None, 
        OCST_OpponentFormation,
        OCST_SetplayCycle,
        OCST_PlayerType,
		OCST_ChangeFormation
    };

public:
    const bool & IsOurCoachSayValid() const { return mIsOurCoachSayValid; }
    const std::string & GetOurCoachSayContent() const { return mOurCoachSayContent; }
    const bool & IsTeammateSayValid() const { return mIsTeammateSayValid; }
    const std::string & GetTeammateSayContent() const { return mTeammateSayContent; }

    void SetOurCoachSayValid(const bool valid) { mIsOurCoachSayValid = valid; }
    void SetOurCoachSayConent(const std::string & content) { mOurCoachSayContent = content; }
    void SetTeammateSayValid(const bool valid) { mIsTeammateSayValid = valid; }
    void SetTeammateSayConent(const std::string & content) { mTeammateSayContent = content; }

private:
    bool mIsOurCoachSayValid;           // ����˵����ǰ�Ƿ�Ϸ�
    std::string mOurCoachSayContent;    // ����˵������
    bool mIsTeammateSayValid;           // ����˵����ǰ�Ƿ�Ϸ�
    std::string mTeammateSayContent;	// ����˵������

public:
    const OurCoachSayType & GetOurCoachSayType() const { return mOurCoachSayType; }
    const int & GetOpponentType(const Unum & unum) const { Assert(unum >= 1 && unum <= TEAMSIZE); return mOpponentType[unum]; }
    const Time & GetHearSetplayTime() const { return mHearSetplayTime; }
    const int & GetSetplayStaminaCycle() const { return mSetplayStaminaCycle; }
    const int & GetSetplayCapacityCycle() const { return mSetplayCapacityCycle; }

    void SetOurCoachSayType(const OurCoachSayType & type) { mOurCoachSayType = type; }
    void SetOpponentType(const Unum & unum, const int & type) { Assert(unum >= 1 && unum <= TEAMSIZE); mOpponentType[unum] = type; }
    void SetHearSetplayTime(const Time & time) { mHearSetplayTime = time; }
    void SetSetplayStaminaCycle(const int & cycle) { mSetplayStaminaCycle = cycle; }
    void SetSetplayCapacityCycle(const int & cycle) { mSetplayCapacityCycle = cycle; }

private:
    OurCoachSayType mOurCoachSayType;
    int mOpponentType[TEAMSIZE + 1];	// ��������˵�Ķ�������
										// heard from coach

    Time mHearSetplayTime;
    int mSetplayStaminaCycle; // cycles that current player need to recover stamina and 
    int mSetplayCapacityCycle; // the cycles that current player cannot recover stamina in this half match

private:
	AngleDeg    mHearDir;		//��Դ����
								//source direction
	Unum        mHearUnum;		//˵���Ķ�Ա����
								//speaker's number

	//���������¼������Ϣ���������Ϣ����
	//the followings record hear message after decoding
	ObserverRecord<Vector> mBallPos;
	ObserverRecord<Vector> mBallVel;
	ObserverRecord<AudioPlayer> mTeammate[TEAMSIZE];
	ObserverRecord<AudioPlayer> mOpponent[TEAMSIZE];
	int mTeammateCount;
	int mOpponentCount;
	int mHearInfoType;	//��¼���һ����������Ϣ����
						//record the last heard information type

public:
	AudioObserver() {
        mIsOurCoachSayValid = false;
        mIsTeammateSayValid = false;
		mHearDir = 0.0;
		mHearUnum = 0;
		mHearInfoType = HearInfo_Null;
		mTeammateCount = mOpponentCount = 0;
	}
	const AngleDeg & GetHearDir() const { return mHearDir; }
	const Unum & GetHearUnum() const { return mHearUnum; }

	void SetHearDir(AngleDeg hear_dir) { mHearDir = hear_dir; }
	void SetHearUnum(int hear_unum) { mHearUnum = hear_unum; }

	int GetHearInfoType() const { return mHearInfoType; }

	void SetBall(Vector pos, Vector vel, const Time & time) { mBallPos.Set(pos, time); mBallVel.Set(vel, time); mHearInfoType |= HearInfo_Ball; }
	void SetBall(Vector pos, const Time & time) { mBallPos.Set(pos, time); mHearInfoType |= HearInfo_Ball; }
	void SetTeammate(Unum num, Vector pos, const Time & time) { mTeammate[mTeammateCount].Set(AudioPlayer(pos , num), time); mTeammateCount++; mHearInfoType |= HearInfo_Teammate;}
	void SetOpponent(Unum num, Vector pos, const Time & time) { mOpponent[mOpponentCount].Set(AudioPlayer(pos , num) ,time); mOpponentCount++; mHearInfoType |= HearInfo_Opponent;}

	const ObserverRecord<Vector> & GetBallPos() const { return mBallPos; }
	const ObserverRecord<Vector> & GetBallVel() const { return mBallVel; }
	const ObserverRecord<AudioPlayer> & GetTeammate(int i) const { Assert(i >= 0 && i < TEAMSIZE); return mTeammate[i]; }
	const ObserverRecord<AudioPlayer> & GetOpponent(int i) const { Assert(i >= 0 && i < TEAMSIZE);  return mOpponent[i]; }
	int GetTeammateCount() const{ return mTeammateCount;}
	int GetOpponentCount() const{ return mOpponentCount;}

	//��ʼ�����С��Ϊ��
	//initial 0
	void Reset()
	{
		mTeammateCount = mOpponentCount = 0;
		mHearInfoType = HearInfo_Null;
	}
};

//======================================================================================================================
/**
* �۲��࣬��Ŵ� Parser ��õ��ĵ�һ�����ݣ��������ݶ��Ӵ˼���õ�
*/
/**
 * Observer
 * Updated from Parser directly, all the other information calculated according to this class
 */
class Observer {
public:
	Observer();
	virtual ~Observer();

	void Reset();	//ÿ����ֻ����һ��
					//run one time every cycle
	void ResetSight();	//���³�ʼ���Ӿ���Ϣ,��Ҫ��Ϊ������ʶ��ĸ���,��ʱΪȨ��,���ڿ��ܻ�Դ�bug�Ľ�
						//initial sight information. mainly for identity identification.

	//�ṩ�� Parser �Ľӿ�
	//interface for Parser
    void SetOurInitSide(char side) { mOurInitSide = side; }
	void SetOurSide(char side) { mOurSide = side; mOppSide = (mOurSide == 'l'? 'r': 'l'); }
	void SetMyNumber(char unum) { mMyUnum = unum; }
	void SetCurrentTime(const Time & time) { mCurrentTime = time;	}
	void SetPlayMode(PlayMode play_mode) { mPlayMode = play_mode; }
	void SetKickOffMode(KickOffMode kickoffmode) {mKickOffMode = kickoffmode;}
	void SetServerPlayMode(ServerPlayMode server_play_mode) { mServerPlayMode = server_play_mode; }
	void Initialize();	//��Ҫ��֪���Լ���side�󣬲��ܳ�ʼ��
						//initialize after side has been known
	void SetTeammateType(Unum unum, int type) { mTeammateType[unum] = type; }
	void SetOpponentType(Unum unum, int type) { mOpponentType[unum] = type; }
	void SetTeammateCardType(Unum unum, CardType type) { mTeammateCardType[unum] = type; }
	void SetOpponentCardType(Unum unum, CardType type) { mOpponentCardType[unum] = type; }
	void AddOpponentTypeChangedCount(Unum player) { mOpponentTypeChangedCount[player] ++; };

	void SetSenseBody(
			ViewWidth view_width,
			double stamina,
			double effort,
			double capacity,

			double speed,
			AngleDeg speed_dir,
			AngleDeg neck_dir,

			int kicks,
			int dashes,
			int turns,
			int says,
			int turn_necks,
			int catchs,
			int moves,
			int change_views,

			int arm_movable_ban,
			int arm_expires,
			double arm_target_dist,
			AngleDeg arm_target_dir,
			int arm_count,

			char focus_side,
			Unum focus_unum,
			int  focus_count,

			int tackle_expires,
			int tackle_count,

			int idle_cycle,
			CardType card_type,

			Time sense_time
	);

    // coachû��sense��Ϣ������ֻ��ͨ��ok��Ϣ
	// coach has no sense information, so only ok information can be check
    const int & GetCoachSayCount() const { return mSenseObserver.GetSayCount(); }
    void SetCoachSayCount(const int count) { mSenseObserver.SetSayCount(count); }

	void ClearCollisionState() { mSenseObserver.ClearCollisionState(); }
	void SetCollideWithPost() { mSenseObserver.SetCollideWithPost(); }
	void SetCollideWithPlayer() { mSenseObserver.SetCollideWithPlayer(); }
	void SetCollideWithBall() { mSenseObserver.SetCollideWithBall(); }

    void ResetOurCoachSayValid() { mAudioObserver.SetOurCoachSayValid(false); }
    void ResetTeammateSayValid() { mAudioObserver.SetTeammateSayValid(false); }
	void HearOurCoachSay(const std::string & hear_content);
	void HearTeammateSay(AngleDeg hear_dir, Unum hear_unum, const std::string & hear_content);

	//ͬ��ģʽ��ֻ�и��������Ӿ������Բ�����ֻ�����Ƕȿ�������������
	//������ʱ�䣬��Ĭ�� mCurrentTime
	//last seen of time is set to mCurrentTime
	void SeeLine  (SideLineType line, double dist, double dir);

	void SeeMarker(MarkerType marker, double dist, double dir);
	void SeeMarker(MarkerType marker, double dist, double dir, double dist_chg, double dir_chg);

	void SeeBall(double dist, double dir);
	void SeeBall(double dist, double dir, double dist_chg, double dir_chg);

	void SeePlayer(double dist, double dir);
	void SeePlayer(char side, double dist, double dir, bool is_tackling, bool is_kicked, bool is_lying, CardType card_type);
	void SeePlayer(char side, double dist, double dir, bool is_tackling, bool is_kicked);
	void SeePlayer(char side, int num, double dist, double dir, double dist_chg, double dir_chg, double body_dir,
			double head_dir, bool is_pointing, double point_dir, bool is_tackling, bool is_kicked, bool is_lying, CardType card_type);
	void SeePlayer(char side, int num, double dist, double dir, bool is_pointing, double point_dir, bool is_tackling, bool is_kicked, bool is_lying, CardType card_type);

	void SeeOppGoalie(int unum) { Assert(unum >= 1 && unum <= 11); mOppGoalieUnum = unum; }

	void HearBall(Vector pos, Vector vel);
	void HearBall(Vector pos);
	void HearTeammate(Unum num, Vector pos);
	void HearOpponent(Unum num, Vector pos);

    void HearOurCoachSayType(const AudioObserver::OurCoachSayType & type) { mAudioObserver.SetOurCoachSayType(type); }
    void HearOpponentType(const Unum & unum, const int & type) { mAudioObserver.SetOpponentType(unum, type); }
    void HearSetplayTime(const Time & time) { mAudioObserver.SetHearSetplayTime(time); }
    void HearSetplayStaminaCycle(const int & cycle) { mAudioObserver.SetSetplayStaminaCycle(cycle); }
    void HearSetplayCapacityCycle(const int & cycle) { mAudioObserver.SetSetplayCapacityCycle(cycle); }

	//�ṩ�� WorldModel �Ľӿ�
	//interface for WorldModel
	const Unum & MyUnum() const { return mMyUnum; }
    const char & OurInitSide() const { return mOurInitSide; }
	const char & OurSide() const { return mOurSide; }
	const char & OppSide() const { return mOppSide; }

	const Time & CurrentTime() const { return mCurrentTime; }
	const Time & LatestSightTime() const { return mLatestSightTime; }
	void SetLatestSightTime(const Time & time) { mLatestSightTime = time; }

	const PlayMode & GetPlayMode() const { return mPlayMode; }
	const KickOffMode & GetKickOffMode() const {return mKickOffMode;}
	const ServerPlayMode & GetServerPlayMode() const { return mServerPlayMode; }
	const int  & OppGoalieUnum() const { return mOppGoalieUnum; }
	const int  & OurScore() const { return mOurScore; }
	void OurScoreInc() { ++mOurScore; }
	const int  & OppScore() const { return mOppScore; }
	void OppScoreInc() { ++mOppScore; }
	const MarkerObserver & Marker(MarkerType type) const { return mMarkerObservers[type]; }
	const LineObserver & SideLine(SideLineType type) const { return mLineObservers[type]; }
	const PlayerObserver & Teammate(int num) const { return mTeammateObservers[num]; }
	const PlayerObserver & Opponent(int num) const { return mOpponentObservers[num]; }
	const BallObserver & Ball() const { return mBallObserver; }
	const int & GetTeammateType(Unum unum) { return mTeammateType[unum]; }
	const int & GetOpponentType(Unum unum) { return mOpponentType[unum]; }
	const CardType & GetTeammateCardType(Unum unum) { return mTeammateCardType[unum]; }
	const CardType & GetOpponentCardType(Unum unum) { return mOpponentCardType[unum]; }
	const SenseObserver & Sense() const { return mSenseObserver; }
	const AudioObserver & Audio() const { return mAudioObserver; }
	const UnknownPlayerObserver& UnknownPlayer( int num) { num = num % (TEAMSIZE * 2) ; return mUnknownPlayers[num];}
	int   GetUnknownPlayerCount() { return mUnknownPlayerCount;}

	const ServerBugInfo & UnknownPlayerBugInfo(int num)
	{
		Assert(num >= 0 && num < TEAMSIZE * 2);
		return mUnknownPlayersBugInfo[num];
	}

	bool IsBallDropped() const { return mIsBallDropped; }
	void DropBall() { mIsBallDropped = true; }

private:
	Time mCurrentTime;							//��ǰʱ��
												//current time
	Time mLatestSightTime;                      //�յ������Ӿ���ʱ�䣬�ڵ�©�Ӿ�������£���mCurrentTimeС
												//time when new sight sense arrive

	PlayMode mPlayMode;
	KickOffMode mKickOffMode;
	ServerPlayMode mServerPlayMode; //����server��playmode��sight_logҪ��
									//play mode from server
	char mOurInitSide;	// ��¼��ʼside����Զ����䣬��mOurSide�ڵ����սʱ�п��ܱ�
						// record initial side and this never change. But when penalty taken,mOurside may change
    char mOurSide;
	char mOppSide;
	int  mMyUnum;
	int  mOppGoalieUnum;
	int  mOurScore;
	int  mOppScore;
	int  mTeammateType[TEAMSIZE + 1];	//���ѵ���Ա���� ���� ��server���
										//teammate's type
	int  mOpponentType[TEAMSIZE + 1];	//���ֵ���Ա���� ���� ��coach���
										//opponent's type
	int  mOpponentTypeChangedCount[TEAMSIZE + 1];	//���ֵ���Ա���͸ı�Ĵ���
													//time of opponent's type changing
	CardType mTeammateCardType[TEAMSIZE + 1];//���ѷ����¼
											 //record of teammate's foul
	CardType mOpponentCardType[TEAMSIZE + 1];//���ַ����¼ ����server���
											 //record of teammate's foul
	bool mIsBallDropped;	//���Ƿ�drop
							//if ball is dropped

	SenseObserver  mSenseObserver;
	AudioObserver  mAudioObserver;
	MarkerObserver mMarkerObservers[FLAG_MAX];
	BallObserver   mBallObserver;
	PlayerObserver mTeammateObservers[ 1 + TEAMSIZE ];	//index 0 not used
	PlayerObserver mOpponentObservers[ 1 + TEAMSIZE ];	//index 0 not used
	LineObserver   mLineObservers[SL_MAX];
	UnknownPlayerObserver mUnknownPlayers[ TEAMSIZE * 2 ];
	int mUnknownPlayerCount;							//ÿ�����ڸ���ʱ��Ҫ��Ϊ0
														//set 0 when update

	ServerBugInfo         mUnknownPlayersBugInfo[ TEAMSIZE * 2]; 
	ServerBugInfo             mCurrentBugInfo;          //current record info;
	int mBugInfoRanged;
	int mLastLeftPlayer;
	int mFirstRightPlayer;


	static const int MAX_UNKNOWN_PLAYES = TEAMSIZE * 2;

	void InitializeFlags(bool rotation);
	void InitializePlayers();

	void AdjustUnum(char side , Unum unum);

public:
	/*
	 * synch with parser thread
	 */
	bool WaitForNewInfo();
	bool WaitForNewSense();
	bool WaitForNewSight();
	bool WaitForCommandSend();
    bool WaitForCoachNewHear(); // coach�����ȴ�hear��Ϣ
								// wait for information (for coach)
	void SetNewSense();
	void SetNewSight();
	void SetCommandSend();
	void Lock() { mUpdateMutex.Lock(); };
	void UnLock() { mUpdateMutex.UnLock(); }
	bool IsNewSight() { return mIsNewSight;}

	RealTime GetLastCycleBeginRealTime() const      { return mLastCycleBeginRealTime; }
	void SetLastCycleBeginRealTime(RealTime time)   { mLastCycleBeginRealTime = time; }
	RealTime GetLastSightRealTime() const           { return mLastSightRealTime; }
	void SetLastSightRealTime(RealTime time)        { mLastSightRealTime = time; }

	bool WillBeNewSight(); /** whether there will be the sight msg in this cycle */

	void SetPlanned() { mIsPlanned = true; }
	bool IsPlanned() const { return mIsPlanned; }

private:
	RealTime        mLastCycleBeginRealTime;    /** last cycle begin time */
	RealTime        mLastSightRealTime;         /** last sight msg time */

    bool            mIsBeginDecision;
	bool            mIsNewSense;
	bool            mIsNewSight;	//�ж��Ƿ����Ӿ� add by tai ��9/7/08)
									//judge if is new sight
	bool            mIsCommandSend;
	bool            mIsPlanned;		//�������Ѿ����߹���
									//if planned
	bool            mIsNewHear;
	bool            mSenseArrived;	//��sense��Ϣ����
									//new sense arrived
	bool            mSightArrived;
	ThreadCondition mCondNewSense;
	ThreadCondition mCondNewSight;
	ThreadCondition mCondCommandSend;
	ThreadCondition mCondCoachNewHear;	//ֻ�е��Լ���coachʱ���������
										//used by coach only

	ThreadMutex     mUpdateMutex;	//����ʱ��parser����
									//when update happens,mutex with parser

private:
	//ֻ�е��Լ���coachʱ�����������
	//for coach only
	BallState *mpBall_Coach;
	PlayerState *mpTeammate_Coach;
	PlayerState *mpOpponent_Coach;

public:
	BallState & Ball_Coach() { return *mpBall_Coach; }
	PlayerState & Teammate_Coach(Unum num) { return mpTeammate_Coach[num]; }
	PlayerState & Opponent_Coach(Unum num) { return mpOpponent_Coach[num]; }

	//==============================================================================
public:
	inline Time GetBallKickTime() const { return mBallKickTime; }
	inline Vector GetBallPosByKick() const { return mBallPosByKick; }
	inline Vector GetBallVelByKick() const { return mBallVelByKick; }
	inline void SetBallKickTime(Time ball_kick_time) { mBallKickTime = ball_kick_time; }
	inline void SetBallPosByKick(Vector ball_pos) { mBallPosByKick = ball_pos; }
	inline void SetBallVelByKick(Vector ball_vel) { mBallVelByKick = ball_vel; }

	inline Time GetPlayerDashTime() const { return mPlayerDashTime; }
	inline Vector GetPlayerPosByDash() const { return mPlayerPosByDash; }
	inline Vector GetPlayerVelByDash() const { return mPlayerVelByDash; }
	inline void SetPlayerDashTime(Time player_dash_time) { mPlayerDashTime = player_dash_time; }
	inline void SetPlayerPosByDash(Vector player_pos) { mPlayerPosByDash = player_pos; }
	inline void SetPlayerVelByDash(Vector player_vel) { mPlayerVelByDash = player_vel; }

	inline Time GetPlayerMoveTime() const { return mPlayerMoveTime; }
	inline Vector GetPlayerPosByMove() const { return mPlayerPosByMove; }
	inline Vector GetPlayerVelByMove() const { return mPlayerVelByMove; }
	inline void SetPlayerMoveTime(Time player_move_time) { mPlayerMoveTime = player_move_time; }
	inline void SetPlayerPosByMove(Vector player_pos) { mPlayerPosByMove = player_pos; }
	inline void SetPlayerVelByMove(Vector player_vel) { mPlayerVelByMove = player_vel; }

	inline Time GetPlayerTurnTime() const { return mPlayerTurnTime; }
	inline AngleDeg GetPlayerBodyDirByTurn() const { return mPlayerBodyDirByTurn; }
	inline void SetPlayerTurnTime(Time player_turn_time) { mPlayerTurnTime = player_turn_time; }
	inline void SetPlayerBodyDirByTurn(AngleDeg body_dir) { mPlayerBodyDirByTurn = body_dir; }

	inline Time GetPlayerTurnNeckTime() const { return mPlayerTurnNeckTime; }
	inline AngleDeg GetPlayerNeckDirByTurnNeck() const { return mPlayerNeckDirByTurnNeck; }
	inline void SetPlayerTurnNeckTime(Time player_turn_neck_time) { mPlayerTurnNeckTime = player_turn_neck_time; }
	inline void SetPlayerNeckDirByTurnNeck(AngleDeg neck_dir) { mPlayerNeckDirByTurnNeck = neck_dir; }

private:
	Time    mBallKickTime;
	Vector  mBallPosByKick;
	Vector  mBallVelByKick;

	Time    mPlayerDashTime;
	Vector  mPlayerPosByDash;
	Vector  mPlayerVelByDash;

	Time    mPlayerMoveTime;
	Vector  mPlayerPosByMove;
	Vector  mPlayerVelByMove;

	Time        mPlayerTurnTime;
	AngleDeg    mPlayerBodyDirByTurn;

	Time        mPlayerTurnNeckTime;
	AngleDeg    mPlayerNeckDirByTurnNeck;
};

#endif /* OBSERVER_H_ */
