/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __Geometry_H__
#define __Geometry_H__

#include <iostream>
#include <cmath>
#include <cstring>
#include "Utilities.h"
#include "Plotter.h"

/**
 * ������
 */
class Vector
{
public:
	explicit Vector(const double x = 0.0, const double y = 0.0): mX(x), mY(y) {}

    const double & X() const { Assert(!Isnan(mX)); return mX; }
    const double & Y() const { Assert(!Isnan(mY)); return mY; }

    void SetX(const double x) { mX = x; }
    void SetY(const double y) { mY = y; }
    void SetValue(const double x, const double y) { mX = x; mY = y; }
    void SetValuePolar(const double r, const AngleDeg theta) { mX = r*Cos(theta); mY = r*Sin(theta); }

    Vector operator-() const { return Vector(-mX, -mY); }
    Vector operator+(const Vector &a) const { return Vector(mX + a.mX, mY + a.mY); }
    Vector operator-(const Vector &a) const { return Vector(mX - a.mX, mY - a.mY); }
    Vector operator*(const double &a) const { return Vector(mX * a, mY * a); }
    Vector operator*(const Vector &a) const { return Vector(mX * a.mX, mY * a.mY); }  //��֪����ʲô�˷�����
    Vector operator/(const double &a) const { return Vector(mX / a, mY / a); }
    Vector operator/(const Vector &a) const { return Vector(mX / a.mX, mY / a.mY); }

    void operator+=(const Vector &a) { mX += a.mX; mY += a.mY; }
    void operator+=(const double &a) { mX += a; mY += a; }
    void operator-=(const Vector &a) { mX -= a.mX; mY -= a.mY; }
    void operator-=(const double &a) { mX -= a; mY -= a; }
    void operator*=(const double &a) { mX *= a; mY *= a; }
    void operator/=(const double &a) { mX /= a; mY /= a; }

    bool operator!=(const Vector &a) const { return (mX != a.mX) || (mY != a.mY); }
    bool operator!=(const double &a) const { return (mX != a) || (mY != a); }
    bool operator==(const Vector &a) const { return (mX == a.mX) && (mY == a.mY); }

    friend std::ostream& operator<<(std::ostream & os, const Vector & v) { return os << "(" << v.mX << ", " << v.mY << ")"; }

    double Mod() const { return sqrt(mX * mX + mY * mY); }
    double Mod2() const { return mX * mX + mY * mY; }
    double Dist(const Vector &a) const { return (*this - a).Mod(); }
    double Dist2(const Vector &a) const { return (*this - a).Mod2(); }

    AngleDeg Dir() const { return ATan2(mY, mX); }

    /**
     * \return a Vector with length "length" at the same direction, or Vector (0, 0) if the original
     *         Vector was (0, 0).
     */
    Vector SetLength(double length) const
	{
		//Assert( Mod() > 0.0 );
		if (Mod() > 0.0) {
			return (*this) * (length / Mod());
		}
		return Vector(0.0, 0.0);
	}

    /**
     * Set length to "length" or do nothing if the original Vector was (0, 0). It's not
     * "the 2nd SetLength", but "SetLength to".
     */
    void   SetLength2(double length)
    {
    	//Assert( Mod() > 0.0 );
    	if (Mod() > 0.0) {
    		*this *= (length / Mod());
    	}
    }

    /**
     * \return a Vector with length 1.0 at the same direction.
     */
    Vector Normalize() const { return SetLength(1.0); }

    /**
     * Set length to 1.0. It's not "the 2nd Normalize", but "Normalize to".
     */
    void   Normalize2() { SetLength2(1.0); }

    /**
     * \return a Vector rotated by angle.
     */
    Vector Rotate(AngleDeg angle) const
    {
    	double cos=Cos(angle), sin=Sin(angle);
    	return Vector(mX*cos-mY*sin, mY*cos+mX*sin);
    }

    /**
     * check if a point is approximate equal to *this;
     * @param point to be checked.
     * return true when they are approximate equal, false else;
     */
    bool ApproxEqual(const Vector& a) const;

private:
    double mX;
    double mY;
};


/**
 * ������
 */
class Line;
inline Vector Polar2Vector(double mod, AngleDeg ang);
class Ray
{
public:
	Ray() {}
    explicit Ray(const Vector origin, const AngleDeg direction) { SetValue(origin, direction); }

    const Vector & Origin() const      { return mOrigin; }
    const AngleDeg & Dir() const       { return mDirection; }
    const AngleDeg & Direction() const { return mDirection; }

    void SetOrigin(const Vector & origin)       { mOrigin = origin; }
    void SetDirection(const AngleDeg direction) { mDirection = direction; }
    void SetValue(const Vector & origin, const AngleDeg direction) { mOrigin = origin; mDirection = direction; }

    Vector GetPoint(double dist) const            { return mOrigin + Polar2Vector(dist, mDirection); }

    bool IsInRightDir(const Vector & point) const { return (fabs(GetNormalizeAngleDeg((point - mOrigin).Dir() - mDirection)) < 10.0);}

    bool OnRay(const Vector& point) const
    {
        Vector v = point - mOrigin;
        return (fabs(Sin(v.Dir() - mDirection) * v.Mod()) < FLOAT_EPS && IsInRightDir(point))
            ? true : false;
    }

    bool OnRay(const Vector& point,double buffer) const
    {
        Vector v = point - mOrigin;
        return (fabs(Sin(v.Dir() - mDirection) * v.Mod()) < buffer && IsInRightDir(point))
            ? true : false;
    }

    bool Intersection(const Line & l, double & intersection_dist) const;
    bool Intersection(const Line & l, Vector & point) const;
    bool Intersection(const Ray & r, Vector & point) const;
    bool Intersection(const Ray & r, double & intersection_dist) const;
    double Intersection(const Line & l) const;

    /*�õ�һ�������������������ĵ�*/
    Vector GetClosestPoint(const Vector& point) const;// add by wang yu hang -09.1.14

    inline double GetDistanceFromOrigin(const Vector& point) const
    {
    	return (point - mOrigin).Mod();
    }

private:
    Vector mOrigin;
    AngleDeg mDirection;
};


/**
 * ֱ����
 */
class Line
{
public:
    /** a*x+b*y+c=0 */
	explicit Line(const double a = 0.0, const double b = 0.0, const double c = 0.0): mA(a), mB(b), mC(c) {}

    Line(const Vector point1, const Vector point2)
    {
    	if (fabs(point1.X() - point2.X()) < FLOAT_EPS)
    	{
    		mA = 1.0;
    		mB = 0.0;
    		mC = -point1.X();
    	}
    	else
    	{
    		mA = (point2.Y() - point1.Y()) / (point2.X() - point1.X());
    		mB = -1.0;
    		mC = point1.Y() - point1.X() * mA;
    	}
    }

    Line(const Ray &r)
    {
    	*this = Line(r.Origin(), r.Origin() + Polar2Vector(1.0, r.Direction()));
    }

    double A() const         { return mA; }
    double B() const         { return mB; }
    double C() const         { return mC; }
    double Dir() const       { return ATan(-mA / mB); }

    double GetX(double y) const
    {
        if (mA != 0.0)
        {
            return ((-mC - mB * y) / mA);
        }
        else
        {
            return 0.0;
        }
    }

    double GetY(double x) const
    {
        if (mB != 0.0)
        {
            return ((-mC - mA * x) / mB);
        }
        else
        {
            return 0.0;
        }
    }

    /** �Ƿ���ֱ���� */
    bool IsOnLine(const Vector & point, double buffer = FLOAT_EPS) const
    {
    	return (fabs(mA * point.X() + mB * point.Y() + mC) < buffer);
    }

    /** �Ƿ���ֱ���Ϸ� */
    bool IsUpLine(const Vector & point) const
    {
        return (!IsOnLine(point) && (mA * point.X() + mB * point.Y() + mC > 0));
    }

    bool HalfPlaneTest(const Vector & pt)
    {
      if (mB == 0)
        return (pt.X() < -mC / mA);
      return (pt.Y() > GetY(pt.X()));
    }

    /** б���Ƿ���� */
    bool IsSameSlope(Line l, double buffer = FLOAT_EPS) const
    {
    	return ((fabs(mB) < buffer && fabs(l.mB) < buffer) || fabs(mA / mB - l.mA / l.mB) < buffer);
    }

    /**
     * �ж�һ��Ĵ����Ƿ�������֮��
     */
    bool IsInBetween(Vector pt, const Vector & end1, const Vector & end2) const;

    /** �󽻵� */
    bool Intersection(const Line &l, Vector &point) const;
    Vector Intersection(const Line &l) const;

    /** �������ߵĽ��� */
    bool Intersection(const Ray &r, Vector &point) const;

    /** �㵽ֱ�ߵľ��� */
    double Dist(const Vector& point) const
    {
        return fabs(mA * point.X() + mB * point.Y() + mC) / sqrt(mA * mA + mB * mB);
    }

    /** �����Ƿ���ֱ��ͬ�� */
    bool IsPointInSameSide(Vector pt1, Vector pt2) const
    {
        Line tl(pt1, pt2);
        if(IsSameSlope(tl)) return true;

        Vector tPt;

        Intersection(tl, tPt);

        return ((tPt.X()-pt1.X())*(pt2.X()-tPt.X()) <= 0);
    }

    /** ��pt��Ĵ��� **/
    Line GetPerpendicular(Vector pt) const
    {
    	return Line(mB, -mA, mA * pt.Y() - mB * pt.X());
    }

    /**
     * Set this line be the perpendicular bisector of pos1 and pos2;
     * @param one point;
     * @param another point;
     */
    void PerpendicularBisector(Vector pos1, Vector pos2)
    {
        mA = 2 * (pos2.X() - pos1.X());
        mB = 2 *(pos2.Y() - pos1.Y());
        mC = pos1.X() * pos1.X() - pos2.X() * pos2.X() + pos1.Y() * pos1.Y() - pos2.Y() * pos2.Y();
    }

    /** �õ�ͶӰ�� */
    Vector GetProjectPoint(const Vector & pt) const
    {
    	Vector joint_pt;
    	Intersection(GetPerpendicular(pt), joint_pt);
    	return joint_pt;
    }

    //�õ��ԳƵ�
    inline Vector MirrorPoint(Vector pt)
    {
    	Line Per_Line = GetPerpendicular(pt);
    	return (Intersection(Per_Line)*2.0 - pt);
    }

    /**
     * �õ�ֱ���������������������ĵ�
     */
    Vector GetClosestPointInBetween(const Vector pt, const Vector end1, const Vector end2) const;

    void LineFromPline(const Vector & pos1, const Vector & pos2)
    {
    	mA = 2* (pos2.X() - pos1.X());
    	mB = 2 *(pos2.Y() - pos1.Y());
    	mC= pos1.X() * pos1.X() - pos2.X() * pos2.X() + pos1.Y() * pos1.Y() - pos2.Y() * pos2.Y();
    }

    const double & GetA() const { return mA; }
    const double & GetB() const { return mB; }
    const double & GetC() const { return mC; }

private:
	/**
	 * Ax + By + C = 0
     */
    double mA;
    double mB;
    double mC;
};


/**
 * ������
 */
class Rectangular
{
public:
    Rectangular(): mLeft(0.0), mRight(0.0), mTop(0.0), mBottom(0.0) {}
    Rectangular(const double left, const double right, const double top, const double bottom): mLeft(left), mRight(right), mTop(top), mBottom(bottom) {}

    Rectangular(const Vector center, const Vector size)
    {
    	mLeft   = center.X() - size.X() / 2.0;
    	mRight  = center.X() + size.X() / 2.0;
    	mTop    = center.Y() - size.Y() / 2.0;
    	mBottom = center.Y() + size.Y() / 2.0;
    }

    double Left() const { return mLeft; }
    double Right() const { return mRight; }
    double Top() const { return mTop; }
    double Bottom() const { return mBottom; }

    void SetLeft(const double left) { mLeft = left; }
    void SetRight(const double right) { mRight = right; }
    void SetTop(const double top) { mTop = top; }
    void SetBottom(const double bottom) { mBottom = bottom; }

    Vector TopLeftCorner() const { return Vector(mLeft, mTop); }
    Vector TopRightCorner() const { return Vector(mRight, mTop); }
    Vector BottomLeftCorner() const { return Vector(mLeft, mBottom); }
    Vector BottomRightCorner() const { return Vector(mRight, mBottom); }

    Line TopEdge() const     { return Line(TopLeftCorner(), TopRightCorner()); }
    Line BottomEdge() const  { return Line(BottomLeftCorner(), BottomRightCorner()); }
    Line LeftEdge() const    { return Line(TopLeftCorner(), BottomLeftCorner()); }
    Line RightEdge() const   { return Line(TopRightCorner(), BottomRightCorner()); }
    Line GetEdge(const int idx) const
    {
        switch (idx)
        {
        case 0:     return TopEdge();
        case 1:     return BottomEdge();
        case 2:     return LeftEdge();
        case 3:     return RightEdge();
        default:    Assert(0); return Line(0.0, 0.0, 0.0);
        }
    }

    bool IsWithin(const Vector &v, double buffer = 0.0) const
    {
    	return (v.X() >= mLeft - buffer) && (v.X() <= mRight + buffer) && (v.Y() >= mTop - buffer) && (v.Y() <= mBottom + buffer);
    }

    bool Intersection(const Ray &r, Vector &point) const;
    Vector Intersection(const Ray &r) const;

    Vector AdjustToWithin(const Vector &v) const
    {
    	Vector r = v;

    	if (r.X() < mLeft)
    	{
    		r.SetX(mLeft);
    	}
    	else if (r.X() > mRight)
    	{
    		r.SetX(mRight);
    	}

    	if (r.Y() < mTop)
    	{
    		r.SetY(mTop);
    	}
    	else if (r.Y() > mBottom)
    	{
    		r.SetY(mBottom);
    	}

    	return r;
    }

private:
    double mLeft; // �������
    double mRight; // �����ұ�
    double mTop; // �����ϱ�
    double mBottom; // �����±�
};


/**
 * ������
 */
class ReciprocalCurve
{
public:
	explicit ReciprocalCurve(double a = 0.0, double b = 0.0, double c = 0.0, double out_min = 0.0, double out_max = 1.0): mA(a), mB(b), mC(c), mOutMin(out_min), mOutMax(out_max) { }

    double A() const { return mA; }
    double B() const { return mB; }
    double C() const { return mC; }
    double OutMin() const { return mOutMin; }
    double OutMax() const { return mOutMax; }

    void SetABC(const double a, const double b, const double c)
    {
        mA = a;
        mB = b;
        mC = c;
    }

    void SetOutMinMax(const double out_min, const double out_max)
    {
        mOutMin = out_min;
        mOutMax = out_max;
    }

    void Interpolate(double x1, double y1, double x2, double y2, double x3, double y3)
    {
    	Assert(((x1 - x2) / (y2 - y1) - (x1 - x3) / (y3 - y1)) != 0);
    	Assert((y1 - y2) != 0);

    	mA = ((x1 * y1 - x2 * y2) / (y2 - y1) - (x1 * y1 - x3 * y3) / (y3 - y1)) / ((x1 - x2) / (y2 - y1) - (x1 - x3) / (y3 - y1));
    	mC = (mA * (x1 - x2) - (x1 * y1 - x2 * y2)) / (y1 - y2);
    	mB = (y1 - mA) * (x1 + mC);
    	mB = (y2 - mA) * (x2 + mC);
    	mB = (y3 - mA) * (x3 + mC);
    }

    double GetOutput(const double & x, const bool limited = true) const
    {
    	double value = mA + mB / (x + mC);
    	if (limited == true)
    	{
    		if (value < mOutMin)
    		{
    			value = mOutMin;
    		}
    		else if (value > mOutMax)
    		{
    			value = mOutMax;
    		}
    	}
    	return value;
    }

    void Show(const char * title, double minx, double maxx) {
    	std::cerr << mA << " + " << mB << " / ( x + " << mC << " )" << std::endl;
    	Plotter::instance().GnuplotExecute("set xrange [%g:%g]", minx, maxx);
    	Plotter::instance().GnuplotExecute("plot %g + %g / (x + %g) title \"%s\"", mA, mB, mC, title);
    }

private:
    double mA;
    double mB;
    double mC;
    double mOutMin;
    double mOutMax;
};

//===========================������Ͷ�ά�����໥ת�� add by oldtai=================================
inline Vector Polar2Vector(double mod, AngleDeg ang)
{
  return Vector(mod * Cos(ang), mod * Sin(ang));
}


/** Get the central perpendicular line from two points */
inline Line GetCentralPerpendicularLine(const Vector &pos1, const Vector &pos2)
{
    double a = 2.0 * (pos2.X() - pos1.X());
    double b = 2.0 * (pos2.Y() - pos1.Y());
    double c = pos1.X() * pos1.X() - pos2.X() * pos2.X() + pos1.Y() * pos1.Y() - pos2.Y() * pos2.Y();
    return Line(a, b, c);
}

/**
 * Բ��
 */
class Circle
{
public:
	explicit Circle(const Vector center = Vector(0.0, 0.0), const double radius = 0.0): mCenter(center), mRadius(radius) {}
    Circle(const double center_x, const double center_y, const double radius): mCenter(Vector(center_x, center_y)), mRadius(radius) {}
    Circle(const Vector point1, const Vector point2, const Vector point3)
    {
    	Line l1 = GetCentralPerpendicularLine(point1, point2);
    	Line l2 = GetCentralPerpendicularLine(point2, point3);

    	if (l1.Intersection(l2, mCenter) == false)
    	{
    		mCenter = Vector(0.0, 0.0);
    	}
    	mRadius = mCenter.Dist(point1);
    }

    Vector Center() const { return mCenter; }
    double Radius() const { return mRadius; }
    void SetCenter(const Vector center) { mCenter = center; }
    void SetRadius(const double radius) { mRadius = radius; }

    bool IsWithin(const Vector p, double buffer = 0.0)
    {
        return (mCenter.Dist(p) <= mRadius + buffer) ;
    }

    /**
     * Get intersection points between the circle and the ray.
     * t1 is nearer to the origin than t2.
     * \param r the ray.
     * \param t1 will be set to the distance from origin of the ray to intersection point 1.
     * \param t2 will be set to the distance from origin of the ray to intersection point 2.
     * \param buffer controls precision.
     * \return number of intersection points.
     */
    int	Intersection(const Ray &r, double &t1, double &t2, double buffer = 0.0) const;

private:
    Vector mCenter;
    double mRadius;
};

#endif
