/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef PLAYERPARAM_H_
#define PLAYERPARAM_H_

#include "ParamEngine.h"
#include "Types.h"

class HeteroParam: public ParamEngine {
	HeteroParam( const HeteroParam & ); // not used
	HeteroParam & operator=( const HeteroParam & ); // not used

	/**
	 * Parse from command line.
	 * @param argc argument count.
	 * @param argv argument value.
	 */
	void ParseFromCmdLine(int argc, char **argv);

	/**
	 * Parse from config file.
	 * @param file_name the file name of the config file,
	 */
	bool ParseFromConfigFile(const char *file_name);

public:
	HeteroParam();
	~HeteroParam(){};
private:
	/**
	 * Add params.
	 */
	void AddParams();

	double player_speed_max;
	double stamina_inc_max;
	double player_decay;
	double inertia_moment;
	double dash_power_rate;
	double player_size;
	double kickable_margin;
	double kick_rand;
	double extra_stamina;
	double effort_max;
	double effort_min;
	int    M_type;
	double kickable_area;
	double kick_power_rate;
	double catch_area_l_stretch;
	double foul_detect_probability;

    // ����5����������effort_max������ģ�ʹ��ʱҪע��
    // the following 5 values are caculated with effort == effort_max.
    double effective_speed_max;
    double acceleration_front_rate;
    double acceleration_side_rate;
	//TODO: б��dash�����飿
    double acceleration_front[DASH_POWER_NUM + 1]; // ǰ��dash�ļ��ٶȴ�С���Ƕ�Ϊ0
    double acceleration_side[DASH_POWER_NUM + 1]; // ����dash�ļ��ٶȴ�С���Ƕ�Ϊ+90��-90

public:
	const double & playerSpeedMax() const { return player_speed_max; }
	const double & staminaIncMax() const { return stamina_inc_max; }
	const double & playerDecay() const { return player_decay; }
	const double & inertiaMoment() const { return inertia_moment; }
	const double & dashPowerRate() const { return dash_power_rate; }
	const double & playerSize() const { return player_size; }
	const double & kickableMargin() const { return kickable_margin; }
	const double & kickRand() const { return kick_rand; }
	const double & extraStamina() const { return extra_stamina; }
	const double & effortMax() const { return effort_max; }
	const double & effortMin() const { return effort_min; }
	const int & type() const { return M_type; }
	const double & kickableArea() const { return kickable_area; }
	const double & effectiveSpeedMax() const { return effective_speed_max; }
	const double & kickPowerRate() const { return kick_power_rate; }
	const double & catchAreaLStretch() const { return catch_area_l_stretch; }

	const double & foulDetectProbability() const { return foul_detect_probability; }
    const double & accelerationFrontRate() const { return acceleration_front_rate; }
    const double & accelerationSideRate() const { return acceleration_side_rate; }
    const double & accelerationFrontMax() const { return acceleration_front[DASH_POWER_NUM]; }
    const double & accelerationSideMax() const { return acceleration_side[DASH_POWER_NUM]; }
    const double & accelerationFront(const double & power) const;
    const double & accelerationSide(const double & power) const;
	//v14
	double accelerationRateOnDir(const double & dir) const;

	/**
	*  һЩ��������ϵ�ı����ĳ�ʼ���͸�ֵ
	*/
        /**
	 * Initialize some variables' value, which may have some dependences.
	 */
	void MaintainConsistency();
};

class PlayerParam: public ParamEngine {
	PlayerParam(); // private
	PlayerParam( const PlayerParam & ); // not used
	PlayerParam & operator=( const PlayerParam & ); // not used

public:
	~PlayerParam();
	static PlayerParam &instance();

	/**
	 * Initialize the player's params.
	 * @param argc argument count.
	 * @param argv argument value.
	 */
	void init(int argc, char **argv);

private:
	//default values
	static const char CONFIG_FILE[];
	static const char TEAM_NAME[];
	static const char OPPONENT_TEAM_NAME[];
	static const char HETERO_TEST_MODEL[];

	static const int DEFAULT_PLAYER_TYPES;
	static const int DEFAULT_SUBS_MAX;
	static const int DEFAULT_PT_MAX;

	static const double DEFAULT_PLAYER_SPEED_MAX_DELTA_MIN;
	static const double DEFAULT_PLAYER_SPEED_MAX_DELTA_MAX;
	static const double DEFAULT_STAMINA_INC_MAX_DELTA_FACTOR;

	static const double DEFAULT_PLAYER_DECAY_DELTA_MIN;
	static const double DEFAULT_PLAYER_DECAY_DELTA_MAX;
	static const double DEFAULT_INERTIA_MOMENT_DELTA_FACTOR;

	static const double DEFAULT_DASH_POWER_RATE_DELTA_MIN;
	static const double DEFAULT_DASH_POWER_RATE_DELTA_MAX;
	static const double DEFAULT_PLAYER_SIZE_DELTA_FACTOR;

	static const double DEFAULT_KICKABLE_MARGIN_DELTA_MIN;
	static const double DEFAULT_KICKABLE_MARGIN_DELTA_MAX;
	static const double DEFAULT_KICK_RAND_DELTA_FACTOR;

	static const double DEFAULT_EXTRA_STAMINA_DELTA_MIN;
	static const double DEFAULT_EXTRA_STAMINA_DELTA_MAX;
	static const double DEFAULT_EFFORT_MAX_DELTA_FACTOR;
	static const double DEFAULT_EFFORT_MIN_DELTA_FACTOR;

	static const int    DEFAULT_RANDOM_SEED;

	static const double DEFAULT_NEW_DASH_POWER_RATE_DELTA_MIN;
	static const double DEFAULT_NEW_DASH_POWER_RATE_DELTA_MAX;
	static const double DEFAULT_NEW_STAMINA_INC_MAX_DELTA_FACTOR;

	static const double DEFAULT_MAX_SHOOT_DISTANCE;
	static const double DEFAULT_BEHAVE_SHOOT;
	static const double DEFAULT_SHOOT_TIME;

	//conf�ĳ��� �ο�we2008
	static const double MAX_CONF;
	static const double MIN_VALID_CONF;
	static const double CONF_DECAY;
	static const double PLAYER_CONF_DECAY;
	static const double BALL_CONF_DECAY;

	int player_types;
	int subs_max;
	int pt_max;

	bool M_allow_mult_default_type;

	double player_speed_max_delta_min;
	double player_speed_max_delta_max;
	double stamina_inc_max_delta_factor;

	double player_decay_delta_min;
	double player_decay_delta_max;
	double inertia_moment_delta_factor;

	double dash_power_rate_delta_min;
	double dash_power_rate_delta_max;
	double player_size_delta_factor;

	double kickable_margin_delta_min;
	double kickable_margin_delta_max;
	double kick_rand_delta_factor;

	double extra_stamina_delta_min;
	double extra_stamina_delta_max;
	double effort_max_delta_factor;
	double effort_min_delta_factor;

	double new_dash_power_rate_delta_min;
	double new_dash_power_rate_delta_max;
	double new_stamina_inc_max_delta_factor;

	double max_shoot_distance;
	double behave_shoot;
	double shoot_time;

	//v14
	double catch_area_l_stretch_min;
	double catch_area_l_stretch_max;

	double kick_power_rate;
	double kick_power_rate_delta_min;
	double kick_power_rate_delta_max;

	double foul_detect_probability;
	double foul_detect_probability_delta_factor;

	int random_seed;

	std::string M_player_conf_file;
	std::string M_team_name;
	int M_team_name_len;
	std::string M_opponent_team_name;
	std::string M_hetero_test_model;

	int M_our_goalie_unum;
	bool M_is_goalie;
	bool M_is_coach;
	double M_player_version;
	double M_coach_version;

	double M_say_pos_x_eps;
	double M_say_pos_y_eps;
	double M_say_ball_speed_eps;
	double M_say_player_speed_eps;
	double M_say_dir_eps;

	double M_max_conf;
	double M_min_valid_conf;
	double M_conf_decay;
	double M_player_conf_decay;
	double M_ball_conf_decay;

	enum
	{
		SIGHTSIZE = 62,
		MARKSIZE = 388
	};
	double mSightChange[SIGHTSIZE][3];
	double mMarkChange[MARKSIZE][3];

	/**
	 * Add params.
	 */
	void AddParams();
public:


	//sight dist ��Ҫָ�Ӿ���ball player��dist ,�����ӵ�������0.1�Ľض�
	/**
	 * Convert the sight dist of ball and other player.
	 * @param dist the distance to convert.
	 * @return the distance converted.
	 */
    double ConvertSightDist(double dist)
    {
		Assert(dist >= 0);
		int low = 0;
		int middle = 0;
		int high = SIGHTSIZE;

		while(low <=  high)
		{
			middle = (low + high ) / 2;

			if (middle >= SIGHTSIZE || middle < 0)
			{
				break;
			}

			if (fabs(dist - mSightChange[middle][0]) < 0.01)
			{
				return mSightChange[middle][1];
			}

			if (dist < mSightChange[middle][0])
			{
				high = middle;
			}
			else
			{
				low = middle + 1;
			}
		}

		 PRINT_ERROR("can not find this dist " << dist );
		 return dist;
    }

    	/**
	 * Get the eps in sight.
	 * @param dist the dist to get eps of.
	 * @return the eps to return.
	 */
	double GetEpsInSight(double dist)
	{
		 Assert(dist >= 0);
		 int low = 0;
		 int middle = 0;
		 int high = SIGHTSIZE - 1;

		 while(low <= high)
		 {
			middle = (low + high) / 2;

			if (middle + 1 >= SIGHTSIZE)
			{
				return mSightChange[SIGHTSIZE - 1][2];
			}

			if (dist >= mSightChange[middle][0] && dist <= mSightChange[middle + 1][0])
			{
				if (fabs(dist - mSightChange[middle][0]) < fabs (dist - mSightChange[middle + 1][0]))
				{
					return mSightChange[middle][2];
				}
				else
				{
					return mSightChange[middle + 1][2];
				}
			}

			if (middle == 0)
			{
				return mSightChange[middle][2];
			}

			if (dist < mSightChange[middle][0])
			{
				high = middle;
			}
			else
			{
				low = middle + 1;
			}

		 }

		 PRINT_ERROR("can not find this dist " << dist );
		 return 0;
	}

	//mark dist ��Ҫָ�Ӿ���marker ��dist����� ,�����ӵĽض�Ϊ0.01
    	/**
	 * Convert marker dist.
	 * @param the dist to convert of.
	 * @return the dist converted.
	 */
    double ConvertMarkDist(double dist)
    {
		Assert(dist >= 0);
		int low = 0;
		int middle = 0;
		int high = MARKSIZE;

		while(low <=  high)
		{
			middle = (low + high ) / 2;

			if (middle >= MARKSIZE || middle < 0)
			{
				break;
			}

			if (fabs(dist - mMarkChange[middle][0]) < 0.01)
			{
				return mMarkChange[middle][1];
			}

			if (dist < mMarkChange[middle][0])
			{
				high = middle;
			}
			else
			{
				low = middle + 1;
			}
		}

		 PRINT_ERROR("can not find this dist " << dist );
		 return dist;
    }

    	/**
	 * Get the eps in mark.
	 * @param dist the distance to get eps.
	 * @return the eps to return.
	 */
	double GetEpsInMark(double dist)
	{
		 Assert(dist >= 0);
		 int low = 0;
		 int middle = 0;
		 int high = MARKSIZE - 1;

		 while(low <= high)
		 {
			middle = (low + high) / 2;

			if (middle + 1 >= MARKSIZE)
			{
				return mMarkChange[MARKSIZE - 1][2];
			}

			if (dist >= mMarkChange[middle][0] && dist <= mMarkChange[middle + 1][0])
			{
				if (fabs(dist - mMarkChange[middle][0]) < fabs (dist - mMarkChange[middle + 1][0]))
				{
					return mMarkChange[middle][2];
				}
				else
				{
					return mMarkChange[middle + 1][2];
				}
			}

			if (middle == 0)
			{
				return mMarkChange[middle][2];
			}

			if (dist < mMarkChange[middle][0])
			{
				high = middle;
			}
			else
			{
				low = middle + 1;
			}
		 }

		 PRINT_ERROR("can not find this dist " << dist );
		 return 0;
	}

	/**
	 * Convert angle.
	 * @param angle the angle to convert.
	 * @return the angle converted.
	 */
	double ConvertAngle(double angle)
	{
		if (angle > 0)
		{
			angle += 0.5;
		}
		else	if (angle < 0)
		{
			angle -= 0.5;
		}

		return angle;
	}

	/**
	 * Caculate some maintain consistent params.
	 */
	void MaintainConsistency();

	/**
	 * Save the param to a file.
	 */
	bool SaveParam();

	int playerTypes() const { return player_types; }
	int subsMax() const { return subs_max; }
	int ptMax() const { return pt_max; }

	bool allowMultDefaultType() const { return M_allow_mult_default_type; }

	const double & maxConf() const { return M_max_conf; }
	const double & minValidConf() const { return M_min_valid_conf; }
	const double & confDecay() const { return M_conf_decay; }
	const double & playerConfDecay() const { return M_player_conf_decay; }
	const double & ballConfDecay() const { return M_ball_conf_decay; }

	const double & playerSpeedMaxDeltaMin() const { return player_speed_max_delta_min; }

	const double & playerSpeedMaxDeltaMax() const { return player_speed_max_delta_max; }
	const double & staminaIncMaxDeltaFactor() const { return stamina_inc_max_delta_factor; }

	const double & playerDecayDeltaMin() const { return player_decay_delta_min; }
	const double & playerDecayDeltaMax() const { return player_decay_delta_max; }
	const double & inertiaMomentDeltaFactor() const { return inertia_moment_delta_factor; }

	const double & dashPowerRateDeltaMin() const { return dash_power_rate_delta_min; }
	const double & dashPowerRateDeltaMax() const { return dash_power_rate_delta_max; }
	const double & playerSizeDeltaFactor() const { return player_size_delta_factor; }

	const double & kickableMarginDeltaMin() const { return kickable_margin_delta_min; }
	const double & kickableMarginDeltaMax() const { return kickable_margin_delta_max; }
	const double & kickRandDeltaFactor() const { return kick_rand_delta_factor; }

	const double & extraStaminaDeltaMin() const { return extra_stamina_delta_min; }
	const double & extraStaminaDeltaMax() const { return extra_stamina_delta_max; }
	const double & effortMaxDeltaFactor() const { return effort_max_delta_factor; }
	const double & effortMinDeltaFactor() const { return effort_min_delta_factor; }

	int randomSeed() const { return random_seed; }

	const double & newDashPowerRateDeltaMin() const { return new_dash_power_rate_delta_min; }
	const double & newDashPowerRateDeltaMax() const { return new_dash_power_rate_delta_max; }
	const double & newStaminaIncMaxDeltaFactor() const { return new_stamina_inc_max_delta_factor; }

	const double & maxShootDistance() const { return max_shoot_distance; }
	const double & behaveShoot() const { return behave_shoot; }
	const double & shootTime() const { return shoot_time; }

	const std::string & teamName() const { return M_team_name; }
	void setTeamName(const char *name) { M_team_name = std::string(name); }
	const int & teamNameLen() const { return M_team_name_len; }
	const std::string & opponentTeamName() const { return M_opponent_team_name; }
	void setOpponentTeamName(const char *name) 
	{ 
		M_opponent_team_name = std::string(name); 
	}
	const std::string & heteroTestModel() const { return M_hetero_test_model; }

	const int & ourGoalieUnum() const { return M_our_goalie_unum; } //������ھ��߲㲻Ӧ��ʹ�ã����������ʱ�����
	const bool & isGoalie() const { return M_is_goalie; } //������ھ��߲㲻Ӧ��ʹ�ã����������ʱ�����
	const bool & isCoach() const { return M_is_coach; }
	const double & playerVersion() const { return M_player_version; }
	const double & coachVersion() const { return M_coach_version; }

	const double & sayPosXEps() const { return M_say_pos_x_eps; }
	const double & sayPosYEps() const { return M_say_pos_y_eps; }
	const double & sayBallSpeedEps() const { return M_say_ball_speed_eps; }
	const double & sayPlayerSpeedEps() const { return M_say_player_speed_eps; }
	const double & sayDirEps() const { return M_say_dir_eps; }

private:
	HeteroParam *mHeteroPlayer;

public:
	/**
	* add hetero player type from server msg
	* @param line server msg
	*/
	void AddPlayerType(int type, const char *line);

	/**
	 * This method returns the hetro param of a hetro player.
	 * @param type the id of the hetro player.
	 * @return the hetro param of the player.
	 */
	HeteroParam & HeteroPlayer(int type) const;


	//==============================================================================
private:
	static const bool JOINT_DEBUG_MODE;
	static const bool DYNAMIC_DEBUG_MODE;
	static const bool SAVE_SERVER_MESSAGE;
	static const bool SAVE_SIGHT_LOG;
	static const bool SAVE_DEC_LOG;
	static const bool SAVE_TEXT_LOG;
	static const bool USE_PLOTTER;
    static const bool USE_TEAM_GRAPHIC;
	static const bool TIME_TEST;
	static const bool NETWORK_TEST;
	static const int WAIT_SIGHT_BUFFER;
	static const int WAIT_HEAR_BUFFER;
	static const int WAIT_TIME_OUT;
	static const double ROUTE_ANGLE_DIFF;
    static const double OPP_TACKLE_THRESHOLD_FORWARD;
    static const double OPP_TACKLE_THRESHOLD_MID;
    static const double OPP_TACKLE_THRESHOLD_BACK;
    static const double TIRED_BUFFER;
    static const double AT_POINT_BUFFER;
    static const int KICKER_MODE;
	static const double MIN_APPEARANCE_POSS;

	bool mDynamicDebugMode; // DynamicDebugģʽ
	bool mSaveServerMessage; // �Ƿ񱣴�server����Ϣ�����ڶ�̬����
	bool mSaveSightLog; // �Ƿ񱣴�sight_log
	bool mSaveDecLog; // �Ƿ񱣴�dec_log
	bool mSaveTextLog;
	bool mUsePlotter;
    bool mUseTeamGraphic;
	bool mTimeTest;
	bool mNetworkTest;
	int mWaitSightBuffer; // �ȴ��Ӿ����������buffer
	int mWaitHearBuffer; // �ȴ��������������buffer
	int mWaitTimeOut; // �ȴ�server�����ʱ��
    double mTiredBuffer;
    double mMinStamina;
    double mAtPointBuffer;

// =============================================================================

    /**
     * ��ӦKicker�ļ���״̬
     *
     * 0��ʾ��ȡֵ�����ļ���������������
     * 1��ʾ���߼���ֵ��������Ҫ�ص�����log
     */
    /**
     * this param shows the kicker mode.
     * 0:reading the dafa file of kicker.
     * 1:caculating the data of kicker offline, which requires turning off all the logs in player.conf
     */
    int mKickerMode;

// =============================================================================

    	// it can be enlarged to 1 at most if observation costs too much time.
	double M_min_appearance_poss; //����Ӿ����ֵ��³�ʱ���أ��͵���������������Ϊ1

    double mGoalieLowDelay;
    double mGoalieHighDelay;

public:
	const bool & DynamicDebugMode() const { return mDynamicDebugMode; }
	const bool & SaveServerMessage() const { return mSaveServerMessage; }
	const bool & SaveSightLog() const { return mSaveSightLog; }
	const bool & SaveDecLog() const { return mSaveDecLog; }
	const bool & SaveTextLog() const { return mSaveTextLog; }
	const bool & TimeTest() const { return mTimeTest; }
	const bool & NetworkTest() const { return mNetworkTest; }
	const bool & UsePlotter() const { return mUsePlotter; }
    const bool & UseTeamGraphic() const { return mUseTeamGraphic; }
	const int & WaitSightBuffer() const { return mWaitSightBuffer; }
	const int & WaitHearBuffer() const { return mWaitHearBuffer; }
	const int & WaitTimeOut() const { return mWaitTimeOut; }

	const double & minAppearancePoss() const { return M_min_appearance_poss; }
    const double & TiredBuffer() const { return mTiredBuffer; }
    const double & MinStamina() const { return mMinStamina; }
    const double & AtPointBuffer() const { return mAtPointBuffer; }
    const int & KickerMode() const { return mKickerMode; }
};

#endif /* PLAYERPARAM_H_ */
