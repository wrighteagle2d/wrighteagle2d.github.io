/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "Utilities.h"
#include "PlayerParam.h"
#include "DynamicDebug.h"

timeval RealTime::mStartTime = GetRealTime();
const long RealTime::ONE_MILLION = 1000000;

/**
* �����ĸ��������ǵõ�ϵͳʱ�䣬���õĵط���ͬ��һ��Ҫע��
*
* GetRealTime()���ڶ�̬����ʱ���ᾭ���ĵط���������3�����������õĵط�
* GetRealTimeParser()����Parser::Parse()������õ����к�����
* GetRealTimeDecision()����Player::Decision()������õ����к�����
* GetRealTimeCommandSend()����CommandSend::Run()������õ����к�����
*/
/**
 * The followings four functions are used to get system time
 *
 * GetRealTime() won't be through dynamicDebug
 * GetRealTimeParser() used in Parser::Parse() and all the functions called by it
 * GetRealTimeDecision() used in Player::Decision() and all the functions called by it
 * GetRealTimeCommandSent() used in CommandSend::Run() and all the functions called by it
 */
//==============================================================================
timeval GetRealTime()
{
	timeval time_val;

#ifdef WIN32
    LARGE_INTEGER frq,count;
    QueryPerformanceFrequency(&frq);
    QueryPerformanceCounter(&count);
    time_val.tv_sec = (count.QuadPart / frq.QuadPart);
    time_val.tv_usec = (count.QuadPart % frq.QuadPart) * 1000000 / frq.QuadPart;
#else
    gettimeofday(&time_val, NULL);
#endif

    return time_val;
}


//==============================================================================
timeval GetRealTimeParser()
{
    if (PlayerParam::instance().DynamicDebugMode() == true)
    {
        return DynamicDebug::instance().GetTimeParser();
    }

    timeval time_val = GetRealTime();
    DynamicDebug::instance().AddTimeParser(time_val);
    return time_val;
}


//==============================================================================
timeval GetRealTimeDecision()
{
    if (PlayerParam::instance().DynamicDebugMode() == true)
    {
        return DynamicDebug::instance().GetTimeDecision();
    }

    timeval time_val = GetRealTime();
    DynamicDebug::instance().AddTimeDecision(time_val);
    return time_val;
}


//==============================================================================
timeval GetRealTimeCommandSend()
{
    if (PlayerParam::instance().DynamicDebugMode() == true)
    {
        return DynamicDebug::instance().GetTimeCommandSend();
    }

    timeval time_val = GetRealTime();
    DynamicDebug::instance().AddTimeCommandSend(time_val);
    return time_val;
}

//==============================================================================
RealTime RealTime::operator + (const RealTime &t) const
{
    if (GetUsec() + t.GetUsec() >= ONE_MILLION)
    {
        return RealTime(GetSec() + t.GetSec() + 1, GetUsec() + t.GetUsec() - ONE_MILLION);
    }
    else
    {
        return RealTime(GetSec() + t.GetSec(), GetUsec() + t.GetUsec());
    }
}


//==============================================================================
RealTime RealTime::operator + (int msec) const
{
    int usec = GetUsec() + msec * 1000;
    if (usec >= ONE_MILLION)
    {
        return RealTime(GetSec() + usec / ONE_MILLION, usec % ONE_MILLION );
    }
    else
    {
        return RealTime(GetSec(), usec);
    }
}


//==============================================================================
RealTime RealTime::operator - (int msec) const
{
    int usec = GetUsec() - msec * 1000;
    if(usec < 0)
    {
        usec = -usec;
        return RealTime(GetSec() - usec / ONE_MILLION - 1, ONE_MILLION - usec % ONE_MILLION );
    }
    else
    {
        return RealTime(GetSec(), usec);
    }
}


//==============================================================================
int RealTime::operator - (const RealTime &t) const
{
    return (GetSec() - t.GetSec()) * 1000 + int((GetUsec() - t.GetUsec()) / 1000.0);
}


//==============================================================================
long RealTime::Sub(const RealTime &t)
{
    return (GetSec() - t.GetSec()) * 1000000 + GetUsec() - t.GetUsec();
}


//==============================================================================
bool RealTime::operator < (const RealTime &t) const
{
    if (GetSec() < t.GetSec())
        return true;
    if (GetSec() == t.GetSec() && GetUsec() < t.GetUsec())
        return true;
    return false;
}


//==============================================================================
bool RealTime::operator > (const RealTime &t) const
{
    if (GetSec() > t.GetSec())
        return true;
    if (GetSec() == t.GetSec() && GetUsec() > t.GetUsec())
        return true;
    return false;
}


//==============================================================================
bool RealTime::operator == (const RealTime &t) const
{
    if(GetSec() == t.GetSec() && GetUsec() == t.GetUsec())
        return true;
    return false;
}


//==============================================================================
bool RealTime::operator != (const RealTime &t) const
{
    if(GetSec() == t.GetSec() && GetUsec() == t.GetUsec())
        return false;
    return true;
}


//==============================================================================
std::ostream & operator << (std::ostream &os, RealTime t)
{
    return os << t - RealTime::mStartTime;
}

//==============================================================================
Time Time::operator-(const int a) const
{
    int news = S() - a;
    if( news >= 0 )
    {
        return Time(T(), news);
    }
    return Time(T() + news, 0);
}


//==============================================================================
int Time::operator-(const Time &a) const
{
    if(mT == a.T())
    {
        return  mS - a.S();
    }
    else
    {
        return mT - a.T() + mS; //ʵ�ʿ��ܲ����,��׼
    }
}

//end of Utilities.cpp

