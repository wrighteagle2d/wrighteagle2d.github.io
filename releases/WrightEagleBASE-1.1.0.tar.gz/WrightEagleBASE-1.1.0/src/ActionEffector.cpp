/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "ActionEffector.h"
#include "Agent.h"
#include "UDPSocket.h"
#include "Observer.h"
#include "WorldState.h"
#include "NetworkTest.h"

bool AtomicAction::Execute(Agent & agent) const
{
	if (mSucceed || !mSucceed){ //�Ȳ���succeedΪfalse�����
		switch (mType){
		case CT_Turn: return agent.Turn(mTurnAngle);
		case CT_Dash: return agent.Dash(mDashPower, mDashDir);
		case CT_Kick: return agent.Kick(mKickVel.Mod(), mKickVel.Dir());
		default: return true;
		}
	}
	else return false;
}

ActionEffector::ActionEffector(Agent & agent):
	mAgent( agent ),
	mWorldState( agent.GetWorldState() ),
	mBallState( agent.GetWorldState().GetBall()),
    mSelfState( agent.GetSelf()),
	mTurn( agent ),
	mDash( agent ),
	mTurnNeck( agent ),
	mSay( agent ),
	mAttentionto( agent ),
	mKick( agent ),
	mTackle( agent ),
	mPointto( agent ),
	mCatch( agent ),
	mMove( agent ),
	mChangeView( agent ),
	mCompression( agent ),
	mSenseBody( agent ),
	mScore( agent ),
	mBye( agent ),
	mDone( agent ),
	mClang( agent ),
	mEar( agent ),
	mSynchSee( agent ),
	mChangePlayerType( agent )
{
	mTurnCount          = 0;
	mDashCount          = 0;
	mTurnNeckCount      = 0;
	mSayCount           = 0;
	mAttentiontoCount   = 0;
	mKickCount          = 0;
	mTackleCount        = 0;
	mPointtoCount       = 0;
	mCatchCount         = 0;
	mMoveCount          = 0;
	mChangeViewCount    = 0;
	mCompressionCount   = 0;
	mSenseBodyCount     = 0;
	mScoreCount         = 0;
	mByeCount           = 0;
	mDoneCount          = 0;
	mClangCount         = 0;
	mEarCount           = 0;
	mSynchSeeCount      = 0;
	mChangePlayerTypeCount = 0;

	mIsMutex        = false;

	mIsTurn         = false;
	mIsDash         = false;
	mIsTurnNeck     = false;
	mIsSay          = false;
	mIsAttentionto  = false;
	mIsKick         = false;
	mIsTackle       = false;
	mIsPointto      = false;
	mIsCatch        = false;
	mIsMove         = false;
	mIsChangeView   = false;
	mIsCompression  = false;
	mIsSenseBody    = false;
	mIsScore        = false;
	mIsBye          = false;
	mIsDone         = false;
	mIsClang        = false;
	mIsEar          = false;
	mIsSynchSee     = false;
	mIsChangePlayerType = false;
}

bool ActionEffector::SetTurnAction(AngleDeg turn_angle)
{
	if (mIsTurn == true || mIsMutex == true)
	{
		return false;
	}

	AngleDeg moment = GetVirtualTurnAngle(turn_angle, mSelfState.GetPlayerType(), mSelfState.GetVel().Mod());

//	if (moment < ServerParam::instance().minMoment() || moment > ServerParam::instance().maxMoment())
//	{
//		return false;
//	}

	moment = NormalizeMoment(moment);

	if (fabs(moment) < FLOAT_EPS){
		return false;
	}

	mTurn.Plan(moment);
	mTurn.Execute(mCommandQueue);
	++mTurnCount;
	mIsTurn = true;
	mIsMutex = true;
	return true;
}

bool ActionEffector::SetDashAction(double power, AngleDeg dir)
{
	if (mIsDash == true || mIsMutex == true)
	{
		return false;
	}

	power = NormalizeDashPower(power);
    dir = NormalizeDashAngle(dir);

    // ע�⣬��rcssserver13.1.0�汾�£�dashֻ��Ҫ������������������ɣ�
    // @ -power 0.0
    // @ +power 0.0
    // @ +power 90.0
    // @ +power -90.0
    //
    // from rcssserver13.1.0



	// @ -power 0.0
	// @ +power 0.0
	// @ +power 45.0
	// @ +power -45.0
	// @ +power 135.0
	// @ +power -135.0
	// from rcssserver14.0.0

    if (ServerParam::instance().dashAngleStep() < FLOAT_EPS )
    {
        // players can dash in any direction.
    }
    else
    {
        // The dash direction is discretized by server::dash_angle_step
        dir = ServerParam::instance().dashAngleStep() * Rint(dir / ServerParam::instance().dashAngleStep());
    }

	double max_stamina = mSelfState.GetStamina() + mSelfState.GetExtraStamina();
	if (power < 0.0)
	{
		if ((-2.0 * power) > max_stamina)
		{
			return false;
		}
	}
	else
	{
		if (power > max_stamina)
		{
			return false;
		}
	}

    power = mAgent.GetSelf().CorrectDashPowerForStamina(power); // ��֤�����������������

	mDash.Plan(power, dir);
	mDash.Execute(mCommandQueue);
	++mDashCount;
	mIsDash = true;
	mIsMutex = true;
	return true;
}

bool ActionEffector::SetTurnNeckAction(AngleDeg angle)
{
	if (mIsTurnNeck == true)
	{
		return false;
	}

	if (angle < ServerParam::instance().minNeckMoment() || angle > ServerParam::instance().maxNeckMoment())
	{
		return false;
	}

	mTurnNeck.Plan(angle);
	mTurnNeck.Execute(mCommandQueue);
	++mTurnNeckCount;
	mIsTurnNeck = true;
	return true;
}

bool ActionEffector::SetSayAction(std::string msg)
{
	if (mIsSay == true)
	{
		return false;
	}

    if (PlayerParam::instance().isCoach())
    {
        if (msg.length() > ServerParam::instance().freeformMsgSize())
        {
            return false;
        }
    }
    else
    {
        if (msg.length() > ServerParam::instance().sayMsgSize())
        {
            return false;
        }
    }

	mSay.Plan(msg);
	mSay.Execute(mCommandQueue);
	++mSayCount;
	mIsSay = true;
	return true;
}

bool ActionEffector::SetAttentiontoAction(Unum num)
{
	if (mIsAttentionto == true)
	{
		return false;
	}

	if (num == 0 || num == mAgent.GetSelfUnum() || num < -TEAMSIZE || num > TEAMSIZE)
	{
		return false;
	}

    if (mAgent.GetSelf().GetFocusOnUnum() == num)
    {
        mIsAttentionto = true; // �����ڲ���attentionto
        return false;
    }

	mAttentionto.Plan(true, num);
	mAttentionto.Execute(mCommandQueue);
	++mAttentiontoCount;
	mIsAttentionto = true;
	return true;
}

bool ActionEffector::SetAttentiontoOffAction()
{
	if (mIsAttentionto == true)
	{
		return false;
	}

    if (mAgent.GetSelf().GetFocusOnUnum() == 0)
    {
        mIsAttentionto = true; // �����ڲ���attentionto
        return false;
    }

	mAttentionto.Plan(false);
	mAttentionto.Execute(mCommandQueue);
	++mAttentiontoCount;
	mIsAttentionto = true;
	return true;
}

bool ActionEffector::SetKickAction(double power, AngleDeg angle)
{
	if (mIsKick == true || mIsMutex == true)
	{
		return false;
	}

	NormalizeKickPower(power);
	NormalizeMoment(angle);

	if (mWorldState.GetPlayMode() == PM_Before_Kick_Off ||
			mWorldState.GetPlayMode() == PM_Goal_Ours ||
			mWorldState.GetPlayMode() == PM_Goal_Opps ||
			mWorldState.GetPlayMode() == PM_Opp_Offside_Kick ||
			mWorldState.GetPlayMode() == PM_Our_Offside_Kick ||
			mWorldState.GetPlayMode() == PM_Our_Back_Pass_Kick ||
			mWorldState.GetPlayMode() == PM_Opp_Back_Pass_Kick ||
			mWorldState.GetPlayMode() == PM_Our_Free_Kick_Fault_Kick ||
			mWorldState.GetPlayMode() == PM_Opp_Free_Kick_Fault_Kick ||
			mWorldState.GetPlayMode() == PM_Our_CatchFault_Kick ||
			mWorldState.GetPlayMode() == PM_Opp_CatchFault_Kick ||
			mWorldState.GetPlayMode() == PM_Time_Over)
	{
		return false;
	}

	if (mSelfState.IsKickable() == false)
	{
		return false;
	}

    if (power < 1.0) // ���ⲻ��Ҫ��kick
    {
        return false;
    }

    if (power > ServerParam::instance().maxPower() - 1.0)
    {
        power = ServerParam::instance().maxPower();
    }

	mKick.Plan(power, angle);
	mKick.Execute(mCommandQueue);
	++mKickCount;
	mIsKick = true;
	mIsMutex = true;
	return true;
}

bool ActionEffector::SetTackleAction(AngleDeg angle, const bool foul)
{
	if (mIsTackle == true || mIsMutex == true)
	{
		return true;
	}

	if (angle < ServerParam::instance().minMoment() || angle > ServerParam::instance().maxMoment())
	{
		return false;
	}

	if (mSelfState.GetTackleBan() > 0)
	{
		return false;
	}

	double tackle_prob = ( foul ) ? mSelfState.GetTackleProbFoul() : mSelfState.GetTackleProb();
	if (tackle_prob < FLOAT_EPS &&
        mWorldState.GetPlayMode() != PM_Opp_Penalty_Taken) // ����Ա������ʱ��tackle��tackle
	{
		return false;
	}

	if (mWorldState.GetPlayMode() == PM_Before_Kick_Off ||
			mWorldState.GetPlayMode() == PM_Goal_Ours ||
			mWorldState.GetPlayMode() == PM_Goal_Opps ||
			mWorldState.GetPlayMode() == PM_Opp_Offside_Kick ||
			mWorldState.GetPlayMode() == PM_Our_Offside_Kick ||
			mWorldState.GetPlayMode() == PM_Our_Back_Pass_Kick ||
			mWorldState.GetPlayMode() == PM_Opp_Back_Pass_Kick ||
			mWorldState.GetPlayMode() == PM_Our_Free_Kick_Fault_Kick ||
			mWorldState.GetPlayMode() == PM_Opp_Free_Kick_Fault_Kick ||
			mWorldState.GetPlayMode() == PM_Our_CatchFault_Kick ||
			mWorldState.GetPlayMode() == PM_Opp_CatchFault_Kick ||
			mWorldState.GetPlayMode() == PM_Time_Over)
	{
		return false;
	}

	mTackle.Plan(angle);
	mTackle.Execute(mCommandQueue);
	++mTackleCount;
	mIsTackle = true;
	mIsMutex = true;
	return true;
}

bool ActionEffector::SetPointtoAction(double dist, AngleDeg angle)
{
	if (mIsPointto == true)
	{
		return false;
	}

	if (mSelfState.GetArmPointMovableBan() > 0)
	{
		return false;
	}

	mPointto.Plan(true, dist, angle);
	mPointto.Execute(mCommandQueue);
	++mPointtoCount;
	mIsPointto = true;
	return true;
}

bool ActionEffector::SetPointtoOffAction()
{
	if (mIsPointto == true)
	{
		return false;
	}

	if (mSelfState.GetArmPointMovableBan() > 0)
	{
		return false;
	}

	mPointto.Plan(false);
	mPointto.Execute(mCommandQueue);
	++mPointtoCount;
	mIsPointto = true;
	return true;
}

bool ActionEffector::SetCatchAction(AngleDeg angle)
{
    if (mIsCatch == true || mIsMutex == true)
    {
        return false;
    }

    if (angle < ServerParam::instance().minMoment() || angle > ServerParam::instance().maxMoment())
    {
        return false;
    }

//    if (mSelfState.IsGoalie() == false) //FIXME
//    {
//        return false;
//    }

    if (mSelfState.GetCatchBan() > 0)
    {
        return false;
    }

    if (mWorldState.GetPlayMode() != PM_Play_On &&
    		mWorldState.GetPlayMode() != PM_Our_Penalty_Setup &&
    		mWorldState.GetPlayMode() != PM_Opp_Penalty_Setup &&
    		mWorldState.GetPlayMode() != PM_Our_Penalty &&
    		mWorldState.GetPlayMode() != PM_Opp_Penalty_Ready &&
    		mWorldState.GetPlayMode() != PM_Our_Penalty_Taken &&
    		mWorldState.GetPlayMode() != PM_Opp_Penalty_Taken &&
    		mWorldState.GetPlayMode() != PM_Our_Penalty_Miss &&
    		mWorldState.GetPlayMode() != PM_Opp_Penalty_Miss &&
    		mWorldState.GetPlayMode() != PM_Our_Penalty_Score &&
    		mWorldState.GetPlayMode() != PM_Opp_Penalty_Score)
    {
        return false;
    }

    /*if (mSelfState.IsBallCatchable() == false)
    {
        return false;
    }*/

    mCatch.Plan(angle);
    mCatch.Execute(mCommandQueue);
    ++mCatchCount;
    mIsCatch = true;
    mIsMutex = true;
    return true;
}

bool ActionEffector::SetMoveAction(Vector pos)
{
	if (mIsMove == true || mIsMutex == true)
	{
		return false;
	}

	//goalie move, see SoccerServer player.cpp

	mMove.Plan(pos);
	mMove.Execute(mCommandQueue);
	++mMoveCount;
	mIsMove = true;
	mIsMutex = true;
	return true;
}

bool ActionEffector::SetChangeViewAction(ViewWidth view_width)
{
	if (view_width != VW_Narrow &&
			view_width != VW_Normal &&
			view_width != VW_Wide)
	{
		return false;
	}

	if (view_width == mSelfState.GetViewWidth())
	{
		return true;
	}

	mChangeView.Plan(view_width);
	mChangeView.Execute(mCommandQueue);
	++mChangeViewCount;
	mIsChangeView = true;
	return true;
}

bool ActionEffector::SetCompressionAction(int level)
{
	if (mIsCompression == true)
	{
		return false;
	}

	if (level > 9)
	{
		return false;
	}

	mCompression.Plan(level);
	mCompression.Execute(mCommandQueue);
	++mCompressionCount;
	mIsCompression = true;
	return true;
}

bool ActionEffector::SetSenseBodyAction()
{
	if (mIsSenseBody == true)
	{
		return false;
	}

	mSenseBody.Plan();
	mSenseBody.Execute(mCommandQueue);
	++mSenseBodyCount;
	mIsSenseBody = true;
	return true;
}

bool ActionEffector::SetScoreAction()
{
	if (mIsScore == true)
	{
		return false;
	}

	mScore.Plan();
	mScore.Execute(mCommandQueue);
	++mScoreCount;
	mIsScore = true;
	return true;
}

bool ActionEffector::SetByeAction()
{
	if (mIsBye == true)
	{
		return false;
	}

	mBye.Plan();
	mBye.Execute(mCommandQueue);
	++mByeCount;
	mIsBye = true;
	return true;
}

bool ActionEffector::SetDoneAction()
{
	if (mIsDone == true)
	{
		return false;
	}

	mDone.Plan();
	mDone.Execute(mCommandQueue);
	++mDoneCount;
	mIsDone = true;
	return true;
}

bool ActionEffector::SetClangAction(int min_ver, int max_ver)
{
	//    if (mIsClang == true)
	//    {
	//        return false;
	//    }

	mClang.Plan(min_ver, max_ver);
	mClang.Execute(mCommandQueue);
	++mClangCount;
	mIsClang = true;
	return true;
}

bool ActionEffector::SetEarOnAction(bool our_side, EarMode ear_mode)
{
	// ear����һ�����ڿ��Է����
	if (ear_mode != EM_Partial && ear_mode != EM_Complete)
	{
		return false;
	}

	mEar.Plan(true, our_side, ear_mode);
	mEar.Execute(mCommandQueue);
	++mEarCount;
	mIsEar = true;
	return true;
}

bool ActionEffector::SetEarOffAction(bool our_side, EarMode ear_mode)
{
	// ear����һ�����ڿ��Է����
	if (ear_mode != EM_Partial && ear_mode != EM_Complete && ear_mode != EM_All)
	{
		return false;
	}

	mEar.Plan(false, our_side, ear_mode);
	mEar.Execute(mCommandQueue);
	++mEarCount;
	mIsEar = true;
	return true;
}

bool ActionEffector::SetSynchSeeAction()
{
	//    if (mIsSynchSee == true)
	//    {
	//        return false;
	//    }

	mSynchSee.Plan();
	mSynchSee.Execute(mCommandQueue);
	++mSynchSeeCount;
	mIsSynchSee = true;
	return true;
}

bool ActionEffector::SetChangePlayerTypeAction(Unum num, int player_type)
{
	mChangePlayerType.Plan(num, player_type);
	mChangePlayerType.Execute(mCommandQueue);
	++mChangePlayerTypeCount;
	mIsChangePlayerType = true;
	return true;
}

/**
 * ͨ������kick�Ĳ���������kick�����λ�ú��ٶ�
 * Calculate ball position and velocity after a kick action.
 * \param kick_power.
 * \param kick_angle.
 * \param player_state state of the player who is performing kick.
 * \param ball_state ball state before the kick action is performed.
 * \param ball_pos will be set to ball position after kick.
 * \param ball_vel will be set to ball velocity after kick.
 * \param is_self if the action is performed by the agent this process represents.
 */
void ActionEffector::ComputeInfoAfterKick(const double kick_power, const double kick_angle,
		const PlayerState &player_state, const BallState &ball_state, Vector &ball_pos, Vector &ball_vel, bool is_self)
{
	double power = NormalizeKickPower(kick_power);
	double dir = NormalizeMoment(kick_angle);

	Vector ball_2_player = (ball_state.GetPos() - player_state.GetPos()).Rotate(-player_state.GetBodyDir());
    double eff_power = power *
        (is_self ? player_state.GetKickRate() : GetKickRate(ball_2_player, player_state.GetPlayerType()));
	Vector accel = Polar2Vector(eff_power, player_state.GetBodyDir() + dir);

	ball_vel = ball_state.GetVel() + accel;
	ball_pos = ball_state.GetPos() + ball_vel;
	ball_vel *= ServerParam::instance().ballDecay();
}

/**
 * ͨ������dash�Ĳ���������dash����Ա��λ�ú��ٶ�
 * Calculate player position and velocity after a dash action. Conflicts or forbidden areas are not
 * considered.
 * \param dash_power.
 * \param dash_dir.
 * \param player_state state of the player who is dashing.
 * \param player_pos will be set to player position after dash.
 * \param player_vel will be set to player velocity after dash.
 */
void ActionEffector::ComputeInfoAfterDash(const double dash_power, double dash_dir,
		const PlayerState &player_state, Vector &player_pos, Vector &player_vel)
{
	double dir_rate = ( std::fabs( dash_dir ) > 90.0
			? ServerParam::instance().backDashRate() - ( ( ServerParam::instance().backDashRate() - ServerParam::instance().sideDashRate() )
					* ( 1.0 - ( std::fabs( dash_dir ) - 90.0 ) / 90.0 ) )
					: ServerParam::instance().sideDashRate() + ( ( 1.0 - ServerParam::instance().sideDashRate() )
							* ( 1.0 - std::fabs( dash_dir ) / 90.0 ) )
	);

	if (dash_power < 0.0) {
		dash_dir += 180.0;
	}
    double eff_dash_power = fabs(dash_power) * player_state.GetEffort() * player_state.GetDashPowerRate() * dir_rate;

	Vector accel = Polar2Vector(eff_dash_power, GetNormalizeAngleDeg(player_state.GetBodyDir() + dash_dir));

	player_vel = player_state.GetVel() + accel;
	player_pos = player_state.GetPos() + player_vel;
	player_vel *= player_state.GetPlayerDecay();
}

/**
 * ͨ������move�Ĳ���������move����Ա��λ�ú��ٶ�
 * Calculate player position and velocity after a move action.
 * \param move_pos.
 * \param player_pos will be set to player position after move.
 * \param player_vel will be set to player velocity after move.
 */
void ActionEffector::ComputeInfoAfterMove(const Vector & move_pos, Vector &player_pos, Vector &player_vel)
{
	player_pos = move_pos;
	player_vel.SetValue(0, 0);
}

/**
 * ͨ������turn�Ĳ���������turn����Ա�����峯��Ͳ��ӳ���
 * Calculate player body direction after a turn action.
 * \param turn_angle.
 * \param player_state state of the player who is turning.
 * \param body_dir will be set to player's body direction after turn.
 */
void ActionEffector::ComputeInfoAfterTurn(const AngleDeg turn_angle,
		const PlayerState &player_state, AngleDeg &body_dir)
{
	double eff_moment = GetActualTurnAngle(turn_angle, player_state.GetPlayerType(), player_state.GetVel().Mod());
	body_dir = GetNormalizeAngleDeg(player_state.GetBodyDir() + eff_moment);
}

/**
 * ͨ������turn_neck�Ĳ���������turn_neck����Ա�Ĳ��ӳ���
 * Calculate player neck direction after a turn_neck action.
 * \param turn_neck_angle.
 * \param player_state state of the player who is turning.
 * \param neck_dir will be set to player's neck direction after turn_neck.
 */
void ActionEffector::ComputeInfoAfterTurnNeck(const AngleDeg turn_neck_angle,
		const PlayerState &player_state, AngleDeg &neck_dir)
{
	double eff_moment = NormalizeNeckMoment(turn_neck_angle);
	neck_dir = NormalizeNeckAngle(player_state.GetNeckDir() + eff_moment);
}

/**
 * ��������ڷ���server�������������WorldState�ĸ���
 * Check commands sent to server in last cycle. Help to update WorldState.
 * It predicts information by doing actions in commands queue,, assuming only this one agent influences
 * world state. And it will flush the commands queue.
 */
void ActionEffector::CheckCommandQueue(Observer *observer)
{
	if (!mCommandQueue.empty())
	{
		for (std::list<CommandInfo>::iterator it = mCommandQueue.begin(); it != mCommandQueue.end(); ++it)
		{
			switch (it->mType)
			{
			case CT_Kick:
				if (observer->Sense().GetKickCount() == mKickCount)
				{
					Vector ball_pos = Vector(0.0, 0.0);
					Vector ball_vel = Vector(0.0, 0.0);
					ComputeInfoAfterKick(it->mPower, it->mAngle, mSelfState, mBallState, ball_pos, ball_vel);

					observer->SetBallKickTime(observer->CurrentTime());
					observer->SetBallPosByKick(ball_pos);
					observer->SetBallVelByKick(ball_vel);
				}
				break;
			case CT_Dash:
				if (observer->Sense().GetDashCount() == mDashCount)
				{
					Vector player_pos = Vector(0.0, 0.0);
					Vector player_vel = Vector(0.0, 0.0);
					ComputeInfoAfterDash(it->mPower, it->mAngle, mSelfState, player_pos, player_vel);

					observer->SetPlayerDashTime(observer->CurrentTime());
					observer->SetPlayerPosByDash(player_pos);
					observer->SetPlayerVelByDash(player_vel);
				}
				break;
			case CT_Move:
				if (observer->Sense().GetMoveCount() == mMoveCount)
				{
					Vector player_pos = Vector(0.0, 0.0);
					Vector player_vel = Vector(0.0, 0.0);
					ComputeInfoAfterMove(it->mMovePos, player_pos, player_vel);

					observer->SetPlayerMoveTime(observer->CurrentTime());
					observer->SetPlayerPosByMove(player_pos);
					observer->SetPlayerVelByMove(player_vel);
				}
				break;
			case CT_Turn:
				if (observer->Sense().GetTurnCount() == mTurnCount)
				{
					AngleDeg body_dir = 0.0;
					ComputeInfoAfterTurn(it->mAngle, mSelfState, body_dir);

					observer->SetPlayerTurnTime(observer->CurrentTime());
					observer->SetPlayerBodyDirByTurn(body_dir);
				}
				break;
			case CT_TurnNeck:
				if (observer->Sense().GetTurnNeckCount() == mTurnNeckCount)
				{
					AngleDeg neck_dir = 0.0;
					ComputeInfoAfterTurnNeck(it->mAngle, mSelfState, neck_dir);

					observer->SetPlayerTurnNeckTime(observer->CurrentTime());
					observer->SetPlayerNeckDirByTurnNeck(neck_dir);
				}
			default:
				break;
			}
		}

		mCommandQueue.clear(); // ����������
	}
}

/**
 * ��������ڵ������Ƿ�©����ÿ���ڻ����Ϣ�󱻵���
 * Check commands sent to server in last cycle, see if there are any commands were lost, and print
 * "miss xxx" if there is one.
 * Called after all information has been fetched in every cycle.
 */
void ActionEffector::CheckCommands(Observer *observer)
{
	CheckCommandQueue(observer);

	/**
	* ����ͨ��sense��server�������������ݺ��Լ��ļ�¼���ݽ��бȽϣ��ж��Ƿ�©������
	* ����sense�е�˳������
	*/
	if (observer->Sense().GetKickCount() != mKickCount)
	{
		if (observer->Sense().GetKickCount() < mKickCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a kick" << std::endl;
		}
		mKickCount = observer->Sense().GetKickCount();
	}

	if (observer->Sense().GetDashCount() != mDashCount)
	{
		if (observer->Sense().GetDashCount() < mDashCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a dash" << std::endl;
		}
		mDashCount = observer->Sense().GetDashCount();
	}

	if (observer->Sense().GetTurnCount() != mTurnCount)
	{
		if (observer->Sense().GetTurnCount() < mTurnCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a turn" << std::endl;
		}
		mTurnCount = observer->Sense().GetTurnCount();
	}

	if (observer->Sense().GetSayCount() != mSayCount)
	{
		if (observer->Sense().GetSayCount() < mSayCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a say" << std::endl;
		}
		mSayCount = observer->Sense().GetSayCount();
	}

	if (observer->Sense().GetTurnNeckCount() != mTurnNeckCount)
	{
		if (observer->Sense().GetTurnNeckCount() < mTurnNeckCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a turn_neck" << std::endl;
		}
		mTurnNeckCount = observer->Sense().GetTurnNeckCount();
	}

	if (observer->Sense().GetCatchCount() != mCatchCount)
	{
		if (observer->Sense().GetCatchCount() < mCatchCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a catch" << std::endl;
		}
		mCatchCount = observer->Sense().GetCatchCount();
	}

	if (observer->Sense().GetMoveCount() != mMoveCount)
	{
		if (observer->Sense().GetMoveCount() < mMoveCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a move" << std::endl;
		}
		mMoveCount = observer->Sense().GetMoveCount();
	}

	if (observer->Sense().GetChangeViewCount() != mChangeViewCount)
	{
		if (observer->Sense().GetChangeViewCount() < mChangeViewCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a change_view" << std::endl;
		}
		mChangeViewCount = observer->Sense().GetChangeViewCount();
	}

	if (observer->Sense().GetArmCount() != mPointtoCount)
	{
		if (observer->Sense().GetArmCount() < mPointtoCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a pointto" << std::endl;
		}
		mPointtoCount = observer->Sense().GetArmCount();
	}

	if (observer->Sense().GetFocusCount() != mAttentiontoCount)
	{
		if (observer->Sense().GetFocusCount() < mAttentiontoCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a attentionto" << std::endl;
		}
		mAttentiontoCount = observer->Sense().GetFocusCount();
	}

	if (observer->Sense().GetTackleCount() != mTackleCount)
	{
		if (observer->Sense().GetTackleCount() < mTackleCount)
		{
			std::cout << observer->CurrentTime() << " " << PlayerParam::instance().teamName()
			<< " " << observer->MyUnum() << " miss a tackle" << std::endl;
		}
		mTackleCount = observer->Sense().GetTackleCount();
	}

	Reset();
}

void ActionEffector::Reset()
{
	mCommandQueue.clear();

	mIsMutex        = false;

	mIsTurn         = false;
	mIsDash         = false;
	mIsTurnNeck     = false;
	mIsSay          = false;
	mIsAttentionto  = false;
	mIsKick         = false;
	mIsTackle       = false;
	mIsPointto      = false;
	mIsCatch        = false;
	mIsMove         = false;
	mIsChangeView   = false;
	mIsCompression  = false;
	mIsSenseBody    = false;
	mIsScore        = false;
	mIsBye          = false;
	mIsDone         = false;
	mIsClang        = false;
	mIsEar          = false;
	mIsSynchSee     = false;
	mIsChangePlayerType = false;
}

void ActionEffector::ResetForScan()
{
	//��ջ�������
	//���turn neck����
	if (!mCommandQueue.empty())
	{
		for (std::list<CommandInfo>::iterator it = mCommandQueue.begin(); it != mCommandQueue.end();)
		{
			switch (it->mType)
			{
			case CT_Kick:
				mIsKick = false;
				--mKickCount;
				it = mCommandQueue.erase(it);
				break;
			case CT_Dash:
				mIsDash = false;
				--mDashCount;
				it = mCommandQueue.erase(it);
				break;
			case CT_Move:
				mIsMove = false;
				--mMoveCount;
				it = mCommandQueue.erase(it);
				break;
			case CT_Turn:
				mIsTurn = false;
				--mTurnCount;
				it = mCommandQueue.erase(it);
				break;
			case CT_TurnNeck:
				mIsTurnNeck = false;
				--mTurnNeckCount;
				it = mCommandQueue.erase(it);
			case CT_Tackle:
				mIsTackle = false;
				--mTackleCount;
				it = mCommandQueue.erase(it);
			default:
				++it;
				break;
			}
		}
		mIsMutex = false;
	}
}

ViewWidth ActionEffector::GetSelfViewWidthWithQueuedActions()
{
	if (IsChangeView()){
		ViewWidth view_width = mSelfState.GetViewWidth();
		for (std::list<CommandInfo>::iterator it = mCommandQueue.begin(); it != mCommandQueue.end(); ++it){
			if (it->mType == CT_ChangeView) {
				view_width = it->mViewWidth;
			}
		}
		return view_width;
	}
	else {
		return mSelfState.GetViewWidth();
	}
}

Vector ActionEffector::GetSelfPosWithQueuedActions()
{
	if (IsDash()){
		return mSelfState.GetPredictedPosWithDash(1, mDash.GetPower());
	}
	else if (IsMove()){
		Vector player_pos = Vector(0.0, 0.0);
		Vector player_vel = Vector(0.0, 0.0);
		ComputeInfoAfterMove(mMove.GetMovePos(), player_pos, player_vel);
		return player_pos;
	}
	else return mSelfState.GetPredictedPos();
}

Vector ActionEffector::GetSelfVelWithQueuedActions()
{
	if (IsDash()){
		return mSelfState.GetPredictedVelWithDash(1, mDash.GetPower());
	}
	else if (IsMove()){
		Vector player_pos = Vector(0.0, 0.0);
		Vector player_vel = Vector(0.0, 0.0);
		ComputeInfoAfterMove(mMove.GetMovePos(), player_pos, player_vel);
		return player_vel;
	}
	else return mSelfState.GetPredictedVel();
}

AngleDeg ActionEffector::GetSelfBodyDirWithQueuedActions()
{
	if (IsTurn()){
		AngleDeg body_dir = 0.0;
		ComputeInfoAfterTurn(mTurn.GetAngle(), mSelfState, body_dir);
		return body_dir;
	}
	else return mSelfState.GetBodyDir();
}

Vector ActionEffector::GetBallPosWithQueuedActions()
{
	if (IsKick()){
		Vector ball_pos = Vector(0.0, 0.0);
		Vector ball_vel = Vector(0.0, 0.0);
		ComputeInfoAfterKick(mKick.GetPower(), mKick.GetAngle(), mSelfState, mBallState, ball_pos, ball_vel);
		return ball_pos;
	}
	else return mBallState.GetPredictedPos();
}

Vector ActionEffector::GetBallVelWithQueuedActions()
{
	if (IsKick()){
		Vector ball_pos = Vector(0.0, 0.0);
		Vector ball_vel = Vector(0.0, 0.0);
		ComputeInfoAfterKick(mKick.GetPower(), mKick.GetAngle(), mSelfState, mBallState, ball_pos, ball_vel);
		return ball_vel;
	}
	else return mBallState.GetPredictedVel();
}

/**
 * ��server������������е�����
 * Send commands in queue to server.
 * \param msg if save_server_msg is on and a c-style string is passed to this method, it will record
 *            this string to msg-log as well.
 */
void ActionEffector::SendCommands(char *msg)
{
	static char command_msg[MAX_MESSAGE];
	command_msg[0] = '\0';

	for (std::list<CommandInfo>::iterator it = mCommandQueue.begin(); it != mCommandQueue.end(); ++it)
	{
		if (it->mType != CT_None && it->mTime == mWorldState.CurrentTime())
		{
			strcat(command_msg, it->mString.c_str());
            NetworkTest::instance().SetCommandSendCount((*it));
		}
	}

	if (command_msg[0] != '\0')
	{
		if (PlayerParam::instance().DynamicDebugMode() == true)
		{
			std::cerr << std::endl << command_msg; // ��̬����ģʽ��ֱ����������
		}
		else if (UDPSocket::instance().Send(command_msg) < 0) // ��������
		{
			PRINT_ERROR("UDPSocket error!");
		}
	}
	if (PlayerParam::instance().SaveServerMessage() == true && msg != 0) //˵��Ҫ��¼������Ϣ
	{
		strcat(msg, command_msg);
	}
}

// end of ActionEffector.cpp

