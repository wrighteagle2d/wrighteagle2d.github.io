/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/
#include <math.h>

#include "BehaviorDribble.h"
#include "WorldState.h"
#include "Kicker.h"
#include "Dasher.h"
#include "InterceptModel.h"

const BehaviorType BehaviorDribbleExecuter::BEHAVIOR_TYPE = BT_Dribble;

namespace {
bool ret = BehaviorExecutable::AutoRegister<BehaviorDribbleExecuter>();
}

BehaviorDribblePlanner::BehaviorDribblePlanner(Agent & agent): BehaviorPlannerBase<BehaviorAttackData>( agent )
{
}

BehaviorDribblePlanner::~BehaviorDribblePlanner()
{
}
/*
bool BehaviorDribblePlanner::Dribble(ActiveBehavior& act_bhv)
{
	if (mPositionInfo.GetClosestOpponentDistToBall() > 5)
	{					
		std::vector<Unum> _opp = mPositionInfo.GetCloseOpponentToBall();

		Vector v1, v2;

		bool complete = false;

		for (std::vector<Unum>::iterator it = _opp.begin(); it != _opp.end(); ++it)
		{
			if (mWorldState.GetOpponent(*it).GetPos().X() > mBallState.GetPos().X() && !complete)
			{
				complete = true;
				v1 = mWorldState.GetOpponent(*it).GetPos();
			}

			if (complete && mWorldState.GetOpponent(*it).GetPos().X() > mBallState.GetPos().X())
			{
				v2 = mWorldState.GetOpponent(*it).GetPos();
				break;
			}
		}

		act_bhv.mDetailType = BDT_Dribble;
		act_bhv.mKickSpeed = 0.1 * mPositionInfo.GetClosestOpponentDistToBall();
		act_bhv.mAngle = GetNormalizeAngleDeg(((v1 - mBallState.GetPos()).Dir() + (v2 - mBallState.GetPos()).Dir()) / 2);
		return true;
	}

	return false;
}
*/
void BehaviorDribblePlanner::Plan(std::list<ActiveBehavior> & behavior_list)
{
    ActiveBehavior act_bhv(mAgent, BT_Dribble, BDT_None);

	if ( !mSelfState.IsKickable() )//ball unkickable, return
	{
		return;
	}
	else //dribble
	{
		Unum _opp = mStrategy.GetFastestOpp();
		PlayerState oppState = mWorldState.GetOpponent( _opp );
		double oppTackle = oppState.GetTackleProb();
		bool oppKick = oppState.IsKickable();

		if ( oppKick || oppTackle > 0.65 )//in oppnent control, clear it
		{
			act_bhv = clearball();
		}
		else if ( oppTackle > 0.35 )
		{
			act_bhv = antitackle();
		}
		else
		{
			Vector target = GetDribbleTarget();
			act_bhv.mDetailType = BDT_Dribble_GoTo;
			act_bhv.mTarget = target;
			act_bhv.mEvaluation = 8.0;
			AtomicAction act;

			Dasher::instance().GoToPoint(mAgent, act, act_bhv.mTarget);
			Vector nextPos;
			//Vector last_vel;
			Vector nextBallPos = mBallState.GetPredictedPos(1);
			if ( act.mType == CT_Dash  )
			{
				nextPos = mSelfState.GetPredictedPosWithDash(1, act.mDashPower, act.mDashDir);
				//last_vel = mSelfState.GetPredictedVelWithDash(2, act.mDashPower, act.mDashDir);
			}
			else if ( act.mType == CT_Turn )
			{
				nextPos = mSelfState.GetPredictedPosWithTurn(act.mTurnAngle);
				//last_vel = mSelfState.GetPredictedVelWithTurn(act.mTurnAngle, 2);
			}
			static double KickDist = mSelfState.GetKickableMargin() + mSelfState.GetPlayerSize() + ServerParam::instance().ballSize();
			if ( nextPos.Dist(nextBallPos) > 0.95 * KickDist )
			{
				double dir_diff = ( mWorldState.GetBall().GetPos() - mSelfState.GetPos() ).Dir()
						- mSelfState.GetBodyDir();
				int p = ( dir_diff ) > 0 ? 1 : -1;
				act_bhv.mDetailType = BDT_Dribble;
				act_bhv.mTarget = nextPos + Polar2Vector( KickDist, p * 45.0 + mSelfState.GetBodyDir() );
				double outSpeed = mSelfState.GetVel().Mod();
//				double dist = 0;
//				while ( dist < KickDist * SQRT_2 + nextPos.Dist( mSelfState.GetPos() ) )
//				{
//					outSpeed /= 0.94;
//					dist += outSpeed;
//				}
				if ( act.mType == CT_Dash && fabs( act.mDashDir ) < FLOAT_EPS )
					outSpeed += mSelfState.GetAccelerationFront(act.mDashPower);
				act_bhv.mKickSpeed = outSpeed;
			}
		}


	}
	behavior_list.push_back(act_bhv);
}

/**
 * Get the dribble target.
 * @return a target.
 */
Vector BehaviorDribblePlanner::GetDribbleTarget()
{
	Unum i = mSelfState.GetUnum();

	Vector pos;
	Vector posGoal( ServerParam::PITCH_LENGTH/2.0,
					( mSelfState.GetPos().Y() / fabs( mSelfState.GetPos().Y() ) )
						* ServerParam::GOAL_WIDTH/2.0 );

	if ( i == mFormation.GetTeammateLeftDefender() ||
	  	i == mFormation.GetTeammateRightDefender() )
	{
	    if ( mSelfState.GetPos().Y() < 0 )
	        pos = Vector( 0 , -30 );
	    else pos = Vector( 0 , 30 );
	    if ( mSelfState.GetPos().X() < -25 ) return pos;
	    else
	    	if ( mSelfState.GetPos().Y() < 0 )
				pos = Vector( ServerParam::PITCH_LENGTH/2.0 , -27 );
			else pos = Vector( ServerParam::PITCH_LENGTH/2.0 , 27 );
			if ( mSelfState.GetPos().X() >  25 )
				pos = posGoal;
			return pos;
	}
	else if ( i == mFormation.GetTeammateLeftMidfielder() ||
			i == mFormation.GetTeammateRightMidfielder() ||
			i == mFormation.GetTeammateLeftForward() ||
			i == mFormation.GetTeammateRightForward() )
	{
		if ( mSelfState.GetPos().Y() < 0 )
			pos = Vector( ServerParam::PITCH_LENGTH/2.0 , -27 );
		else pos = Vector( ServerParam::PITCH_LENGTH/2.0 , 27 );
	    if ( mSelfState.GetPos().X() >  25 )
	    	pos = posGoal;
	    return pos;
	}

   	pos = posGoal;

	return pos;
}


ActiveBehavior BehaviorDribblePlanner::clearball()
{
	ActiveBehavior clearball_bhv(mAgent, BT_Dribble, BDT_ClearBall);

	return clearball_bhv;
}

ActiveBehavior BehaviorDribblePlanner::antitackle()
{
	ActiveBehavior antitackle_bhv(mAgent, BT_Dribble, BDT_Kick);

	return antitackle_bhv;
}

BehaviorDribbleExecuter::BehaviorDribbleExecuter(Agent& agent): BehaviorExecuterBase<BehaviorAttackData>(agent)
{
	Assert(ret);
}

BehaviorDribbleExecuter::~BehaviorDribbleExecuter(void)
{
}

bool BehaviorDribbleExecuter::Execute(const ActiveBehavior &act_bhv)
{
    switch(act_bhv.mDetailType)
    {
    case BDT_Kick:
    	return Kicker::instance().KickBall(mAgent, act_bhv.mAngle, act_bhv.mKickSpeed, KM_Quick);
    case BDT_ClearBall:
		return Kicker::instance().KickBall(mAgent, act_bhv.mAngle, ServerParam::instance().ballSpeedMax(), KM_Quick);
    case BDT_Dribble_GoTo:
    	return Dasher::instance().GoToPoint(mAgent, act_bhv.mTarget);
	case BDT_Dribble:
		return Kicker::instance().KickBall(mAgent, act_bhv.mTarget, act_bhv.mKickSpeed);
	case BDT_Dribble_Fast:
		return Kicker::instance().KickBall(mAgent, act_bhv.mTarget, act_bhv.mKickSpeed, KM_Quick);
    default:
        break;
    }

    return false;
}
