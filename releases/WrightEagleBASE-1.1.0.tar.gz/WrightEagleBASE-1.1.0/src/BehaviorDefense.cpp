/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "BehaviorDefense.h"
#include "WorldState.h"
#include "Agent.h"
#include "Formation.h"
#include "Dasher.h"
#include "Logger.h"
#include "Utilities.h"
#include "Kicker.h"

const BehaviorType BehaviorDefenseExecuter::BEHAVIOR_TYPE = BT_Defense;

namespace {
	bool ret = BehaviorExecutable::AutoRegister<BehaviorDefenseExecuter>();
}

BehaviorDefensePlanner::BehaviorDefensePlanner(Agent & agent): BehaviorPlannerBase <BehaviorDefenseData>( agent )
{

}

BehaviorDefensePlanner::~BehaviorDefensePlanner()
{
}

void BehaviorDefensePlanner::Plan(std::list<ActiveBehavior> & behavior_list)
{
    ActiveBehavior act_bhv(mAgent, BT_Defense, BDT_None);

    if (mSelfState.IsGoalie())
    {
		if (mWorldState.CurrentTime() - mWorldState.GetPlayModeTime() < 40 && mWorldState.GetPlayMode() == PM_Our_Goalie_Free_Kick)
		{
			act_bhv.mDetailType = BDT_Scan;
			behavior_list.push_back(act_bhv);
			return;
		}
		else if (mWorldState.GetPlayMode() == PM_Our_Goalie_Free_Kick)
		{
			act_bhv.mDetailType = BDT_Kick;
			act_bhv.mTarget = Vector(52.5, 0);
			act_bhv.mKickSpeed = 3;
			behavior_list.push_back(act_bhv);
			return;
		}

		if (mSelfState.IsBallCatchable())
		{
			act_bhv.mDetailType = BDT_Catch;
			behavior_list.push_back(act_bhv);
			return;
		}

		if (mStrategy.GetMyInterPos().X() < -36 && (mStrategy.GetMyInterCycle() < mStrategy.GetMinTmInterCycle() || mStrategy.GetMyInterCycle() < mStrategy.GetMinOppInterCycle()))
		{
			act_bhv.mTarget = mStrategy.GetMyInterPos();
			act_bhv.mDetailType = BDT_GoToPoint;
			behavior_list.push_back(act_bhv);
			return;
		}

        double left_ang = (Vector(-52.5, -7) - mStrategy.GetBallInterPos()).Dir();
        double right_ang = (Vector(-52.5, 7) - mStrategy.GetBallInterPos()).Dir();
        double ang_diff = Min(GetAngleDegDiffer(left_ang, right_ang), 360 - GetAngleDegDiffer(left_ang, right_ang));
        Ray r_div(mStrategy.GetMyInterPos(), left_ang - ang_diff / 2.0);
		if (!Line(Vector(-49, 0), Vector(-49, 1)).Intersection(r_div, act_bhv.mTarget))
		{
			Vector tar = Line(r_div).GetProjectPoint(mSelfState.GetPos());
			act_bhv.mTarget = (ServerParam::instance().ourPenaltyArea().IsWithin(tar))? tar:Vector(-51.5, tar.Y());
		}

		if (fabs(act_bhv.mTarget.Y()) > 7)
		{
			act_bhv.mTarget.SetY(Sign(act_bhv.mTarget.Y()) * 6.8);
		}
		
		if (mBallState.GetPos().X() > -10) act_bhv.mTarget = Vector(-47.5, 0);

        act_bhv.mDetailType = BDT_GoToPoint;
    }
	else if (!mSelfState.IsKickable())
	{
		if (mStrategy.GetMinTmInterCycle() > mStrategy.GetMyInterCycle())
		{
			act_bhv.mDetailType = BDT_GoToPoint;
			act_bhv.mTarget = mStrategy.GetBallInterPos();
		}
		else
		{
			act_bhv.mTarget = mAgent.GetFormation().GetTeammateFormationPointBaseBall(mSelfState.GetUnum(), mStrategy.GetBallInterPos());
			if (mSelfState.GetPos().Dist(act_bhv.mTarget) < 0.2)
			{
				act_bhv.mDetailType = BDT_TurnToBall;
			}
			else
			{
				act_bhv.mDetailType = BDT_GoToPoint;
			}
		}
	}
	else 
	{
		act_bhv.mTarget = Vector(52.5, 0);
		act_bhv.mKickSpeed = 3;
		act_bhv.mDetailType = BDT_Kick;
	}
	behavior_list.push_back(act_bhv);
}

BehaviorDefenseExecuter::BehaviorDefenseExecuter(Agent& agent): BehaviorExecuterBase<BehaviorDefenseData>(agent)
{
	Assert(ret);
}

BehaviorDefenseExecuter::~BehaviorDefenseExecuter(void)
{
}

bool BehaviorDefenseExecuter::Execute(const ActiveBehavior &act_bhv)
{
    switch(act_bhv.mDetailType)
    {
    case BDT_GoToPoint:
        if (mSelfState.GetPredictedPos(1).Dist(act_bhv.mTarget) > 0.2)
        {
            return Dasher::instance().GoToPoint(mAgent, act_bhv.mTarget);
        }
        break;
	case BDT_Catch:
		return mAgent.Catch(GetNormalizeAngleDeg((mBallState.GetPos() - mSelfState.GetPos()).Dir() - mSelfState.GetBodyDir()));
	case BDT_TurnToBall:
		return mAgent.Turn(GetNormalizeAngleDeg((mBallState.GetPos() - mSelfState.GetPredictedPos(1)).Dir() - mSelfState.GetBodyDir()));
	case BDT_Scan:
		return mAgent.Turn(60);
	case BDT_Kick:
		if (mSelfState.IsGoalie()) 
			return mAgent.Kick(100, (Vector(52.5, 0) - mSelfState.GetPos()).Dir() - mSelfState.GetBodyDir());
		return Kicker::instance().KickBall(mAgent, act_bhv.mTarget, act_bhv.mKickSpeed); 
    default:
        break;
	}

    return false;
}

