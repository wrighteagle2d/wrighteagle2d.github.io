/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __Logger_H__
#define __Logger_H__

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include <map>
#include "Types.h"
#include "Geometry.h"
#include "Thread.h"
#include "WorldState.h"

class Observer;
class BallState;
class PlayerState;
class InfoState;

/**
 * Sight log class
 */
class SightLogger
{
public:
	enum Color {
		Red,
		Blue,
		Green,
		Navy,
		Orange,
		Cyan,
		Purple,
		White,
		Black,
		Yellow,
		Olive
	};

	/** Constructor & destructor */
	SightLogger(Observer *observer, WorldState *world_state);
	~SightLogger();

	/** Header tools */
	void SetServerParamMsg(const char *msg);
	void SetPlayerParamMsg(const char *msg);
	void SetPlayerTypeMsg(const char *msg);

	/** Log sight */
	void LogSight();

	/** flush */
	void Flush();

	/** Basic drawing tools */
	void DecLock()   { mDecMutex.Lock(); }
	void DecUnLock() { mDecMutex.UnLock(); }
	void LogDec() { mTime = mpWorldState->CurrentTime(); }
	void AddPoint(Vector point, const char* comment = NULL, Color color = Red) { points.push_back(PointShape(point, color, comment)); }
	void AddLine(Vector origin, Vector target, Color color = Yellow) { lines.push_back(LineShape(origin, target, color)); }
	void AddCircle(Vector origin, double radius, Color color = White) { circles.push_back(CircleShape(origin, radius, color)); }

	/** Integrated drawing tools */
    void LogPlayerInfo(const PlayerState & player);
    void LogBallInfo(const BallState & ball);

private:
	std::ofstream os;
	ThreadMutex mSightMutex;
	ThreadMutex mDecMutex;

	Observer   *mpObserver;
	WorldState *mpWorldState;

	std::string mHeader;
	std::string mServerParamMsg;
	std::string mPlayerParamMsg;
	std::string mPlayerTypeMsg;
	int mLoggedPlayerTypeCount;
	bool mHeaderReady; //�Ƿ���Լ�¼�Ӿ���Ϣ��Ҫ�ȼ�¼��server_param�ȣ�
	bool mHeaderLogged;
	ServerPlayMode mServerPlayMode;
	bool mServerPlayMode_dirty;
	Time mTime;
	int mLeftScore; //�Լ�������ߵ�
	int mRightScore;
	int mLeftPenTaken;
	int mRightPenTaken;
	std::string mLeftName;
	std::string mRightName;
	bool mTeamState_dirty;

	BallState *mpBall;
	PlayerState *mpLeftTeam[TEAMSIZE + 1];
	PlayerState *mpRightTeam[TEAMSIZE + 1];

	struct ItemShape {
		Color line_color;

		const char *color(){
			switch (line_color){
			case Red: return "red";
			case Blue: return "blue";
			case Green: return "green";
			case Navy: return "navy";
			case Orange: return "orange";
			case Cyan: return "cyan";
			case Purple: return "purple";
			case White: return "white";
			case Black: return "black";
			case Yellow: return "yellow";
			case Olive: return "olive";
			}
			return "black";
		}

		ItemShape (Color color){
			line_color = color;
		}
	};

	struct PointShape: public ItemShape {
		double x, y;
		std::string comment;

		PointShape (Vector point, Color color, const char* cmt = NULL): ItemShape(color){
			x = point.X();
			y = point.Y();
			if (cmt)
			{
				comment.assign(cmt);
			}
		};

		friend std::ostream& operator<<(std::ostream &os, PointShape &point) {
			return os << "(point " << point.x << ' ' << point.y << ' ' << "\"" << point.color() << "\" "<<point.comment<<")";
		}
	};

	struct LineShape: public ItemShape {
		double x1, y1;
		double x2, y2;
		int width;

		LineShape (Vector from, Vector to, Color color): ItemShape(color){
			x1 = from.X();
			y1 = from.Y();
			x2 = to.X();
			y2 = to.Y();
		};

		friend std::ostream& operator<<(std::ostream &os, LineShape &line) {
			return os << "(line " << line.x1 << ' ' << line.y1 << ' ' << line.x2 << ' ' << line.y2 << " \"" << line.color() << "\")";
		}
	};

	struct CircleShape: public ItemShape {
		double x, y;
		double radius;

		CircleShape (Vector center, double r, Color color): ItemShape(color){
			x = center.X();
			y = center.Y();
			radius = r;
		};

		friend std::ostream& operator<<(std::ostream &os, CircleShape &circle) {
			return os << "(circle " << circle.x << ' ' << circle.y << ' ' << circle.radius << " \"" << circle.color() << "\")";
		}
	};

	std::vector<PointShape> points;
	std::vector<LineShape> lines;
	std::vector<CircleShape> circles;

};

/**
 * Text log class
 */
class TextLogger
{
	std::ofstream     os;
	std::stringstream mBuffer;

public:
	TextLogger(Observer* observer, const char* log_name);
	TextLogger();
	~TextLogger();
	void Flush();

	/**
	 * Operator <<
	 * Usage is the same as ostream.
	 */
	template<typename T>
	TextLogger& operator<<(const T& value)
	{
		if (PlayerParam::instance().SaveTextLog())
		{
			mBuffer << value;
		}
		return *this;
	}

	/**
	 * Copied from Mersad-5.9.5-RC2005. I dont know what these two specials
	 * are for. Will cause "undefined reference ..." if removed.
	 */
	TextLogger& operator<<(std::ostream& (*man)(std::ostream&))
	{
		if (PlayerParam::instance().SaveTextLog())
		{
			mBuffer << man;
		}
		return *this;
	}
	TextLogger& operator<<(std::ios_base& (*man)(std::ios_base&))
	{
		if (PlayerParam::instance().SaveTextLog())
		{
			mBuffer << man;
		}
		return *this;
	}

};


/**
 * Logger
 */
class Logger
{
	Observer   *mpObserver;
	WorldState *mpWorldState;

	SightLogger *mpSightLogger;
	std::map<std::string, TextLogger*> mTextLoggers;
	static TextLogger mTextLoggerNull;

	ThreadCondition mCondFlush;

	Logger(): mpObserver(0), mpWorldState(0), mpSightLogger(0) {}

public:
	static Logger& instance();

    /**
     * init��������������
     * Initialize.
     */
    void Initial(Observer *observer, WorldState *world_state );
    ~Logger();

    /**
     * ��ѭ������
     * Mainloop.
     */
    void LoggerLoop();

    /**
     * flush logs
     */
    void Flush();

    /**
     * set mCondFlush to let LoggerLoop flush logs.
     */
    void SetFlushCond();

    const Time & CurrentTime();

    /**
     * get subloggers
     */
    SightLogger* GetSightLogger();
    TextLogger& GetTextLogger(const char* logger_name);

    /**
     * utilitis - sight log & dec log
     */
    void InitSightLogger(ServerMsgType msg_type, const char* msg);
    void LogSight();
    void LogPoint(Vector target, SightLogger::Color color = SightLogger::Red, const char* comment = NULL);
    void LogLine(Vector begin, Vector end, SightLogger::Color color = SightLogger::Yellow, const char* comment = NULL);
    void LogCircle(Vector o, double r, SightLogger::Color color = SightLogger::Yellow);
    void LogRectangular(Rectangular rect, SightLogger::Color color = SightLogger::Yellow);
};

#endif
