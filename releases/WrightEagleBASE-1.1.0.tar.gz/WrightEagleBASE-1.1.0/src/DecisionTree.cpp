/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "DecisionTree.h"
#include "BehaviorAttack.h"
#include "BehaviorDefense.h"
#include "Agent.h"
#include "Strategy.h"
#include "TimeTest.h"
#include "BehaviorSetplay.h"
#include "BehaviorPenalty.h"

/**
 * Do the decision.
 * @param agent the agent itself.
 * @return true means the decision has been made.
 */
bool DecisionTree::Decision(Agent & agent)
{
	Assert(agent.GetSelf().IsAlive());

	ActiveBehavior beh = Search(agent, 1);

	if (beh.GetType() != BT_None) {
		agent.GetStrategy().SetActiveBehaviorInAct(beh.GetType());
		return beh.Execute();
	}
	return false;
}

/**
 * Search the decision tree, and finish the evaluation of conditions and actions.
 * @param agent the agent itslef.
 * @param step the depth of current node. step = 1 means the last ply, while step = max_step 
 * 	means the first ply.
 * @return an active behavior, the best result of the searching.
 */
ActiveBehavior DecisionTree::Search(Agent & agent, int step)
{
	if (step == 1){
		if (agent.GetSelf().IsTackling()) {
			return ActiveBehavior(agent, BT_None);
		}

		std::list<ActiveBehavior> active_behavior_list;
		MutexPlan<BehaviorPenaltyPlanner>(agent, active_behavior_list) || 
	    MutexPlan<BehaviorSetplayPlanner>(agent, active_behavior_list)||
		MutexPlan<BehaviorAttackPlanner>(agent, active_behavior_list) ||
		MutexPlan<BehaviorDefensePlanner>(agent, active_behavior_list);

		if (!active_behavior_list.empty()){
			return GetBestActiveBehavior(agent, active_behavior_list);
		}
		else {
			return ActiveBehavior(agent, BT_None);
		}
	}
	else {
		return ActiveBehavior(agent, BT_None);
	}
}

/**
 * Get the best active behavior from a active behavior list, and store the list for next cycle.
 * @param agent teh agent itself.
 * @param behavior_list the list of active behaviors to be sorted and stored.
 * @return an active behavior which is the best one of the whole list.
 */
ActiveBehavior DecisionTree::GetBestActiveBehavior(Agent & agent, std::list<ActiveBehavior> & behavior_list)
{
	agent.GetStrategy().SaveActiveBehaviorList(behavior_list); //behavior_list����洢�˱���������behavior���߳�������activebehavior������ͳһ����һ�£����ض�behavior������planʱ��

	behavior_list.sort(std::greater<ActiveBehavior>());
	return behavior_list.front();
}
