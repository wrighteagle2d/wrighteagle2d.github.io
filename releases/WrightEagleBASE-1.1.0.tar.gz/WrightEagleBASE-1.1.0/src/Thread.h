/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __Thread_H__
#define __Thread_H__


#include "Utilities.h"

#ifdef WIN32

//==============================================================================
inline void Create_Thread(LPTHREAD_START_ROUTINE function_thread, LPVOID param)
{
    HANDLE hParseThread;
    DWORD dwThreadId;
    hParseThread = CreateThread(NULL, 0, function_thread, param, 0, &dwThreadId);
}


//==============================================================================
inline void WaitFor(int ms)
{
    Sleep(ms);
}


//==============================================================================
class ThreadCondition
{
public:
    /**
     * ���캯������������
     */
    ThreadCondition();
    ~ThreadCondition();

    /**
     * �����ͻ��Ѻ���
     */
    bool Wait(int ms);
    void Set();

private:
    HANDLE mEvent;
};


//==============================================================================
class ThreadMutex
{
public:
    /**
     * ���캯������������
     */
    ThreadMutex();
    ~ThreadMutex();

    /**
     * �����ͽ�������
     */
    void Lock();
    void UnLock();

private:
    HANDLE mEvent;
};

#else

#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

//==============================================================================
inline void Create_Thread(void *(*function_thread)(void *), void* param)
{
	pthread_t parse; //�����߳�
	pthread_create(&parse, NULL, function_thread, param) ;
}


//==============================================================================
inline void WaitFor(int ms)
{
	usleep(ms * 1000);
}


//==============================================================================
class ThreadCondition
{
public:
    /**
     * ���캯������������
     */
    ThreadCondition();
    ~ThreadCondition() {}

    /**
     * �����ͻ��Ѻ���
     */
    bool Wait(int ms);
    void Set();

private:
    pthread_cond_t mCond;
    pthread_mutex_t mMutex;
};


//==============================================================================
class ThreadMutex
{
public:
    /**
     * ���캯������������
     */
    ThreadMutex();
    ~ThreadMutex() {}

    /**
     * �����ͽ�������
     */
    void Lock();
    void UnLock();

private:
    pthread_mutex_t mMutex;
};

#endif

#endif

