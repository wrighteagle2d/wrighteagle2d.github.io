#!/bin/sh

echo ""
echo "#######################################################################"
echo "#      WrightEagle 2D Soccer Simulation Team -- WrightEagleBASE       #"
echo "#                                                                     #"
echo "#                       Multi-Agent Systems Lab.                      #"
echo "#              School of Computer Science and Technology              #"
echo "#            University of Science and Technology of China            #"
echo "#                     Hefei, Anhui Province, China                    #"
echo "#                                                                     #"
echo "#                   Supervisor: Prof. Xiaoping Chen                   #"
echo "#      Team members: Ke Shi, Aijun Bai, Guanghui Lu, Yuhang Wang,     #"
echo "#                    Jing Wang, Yuanchong Zhu                         #"
echo "#                                                                     #"
echo "#                   WWW: http://wrighteagle.org/2D/                   #"
echo "#######################################################################"
echo ""

CLIENT="./Release/WrightEagleBASE"
TEAM_NAME="WrightEagleBASE"
HOST="localhost"
SLEEP_TIME=0

G_PARAM="-team_name $TEAM_NAME -host $HOST -goalie on"
N_PARAM="-team_name $TEAM_NAME -host $HOST"
C_PARAM="-team_name $TEAM_NAME -host $HOST -coach on"


echo ">>>>>>>>>>>>>>>>>>>>>> $TEAM_NAME Goalie: 1"
$CLIENT $G_PARAM &
sleep 2

i=2
while [ $i -le 11 ]; do
    echo ">>>>>>>>>>>>>>>>>>>>>> $TEAM_NAME Player: $i"
    $CLIENT $N_PARAM &
    sleep $SLEEP_TIME
    i=`expr $i + 1`
done
sleep 2

echo ">>>>>>>>>>>>>>>>>>>>>> $TEAM_NAME Coach"
$CLIENT $C_PARAM &

