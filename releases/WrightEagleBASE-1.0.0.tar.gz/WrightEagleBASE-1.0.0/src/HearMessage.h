/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __HEARINFO_H_
#define __HEARINFO_H_

#include "Geometry.h"
#include "BehaviorBase.h"

struct PassInfo
{
	Unum mPlayerUnum;
	Time mRecvTime;
	Vector mBallSpeed;
	Vector mGetPoint;
	bool   mIsMultiPass;
	Unum   mDangerOpp[4];
	int    mIntCycle;

	PassInfo():
		mPlayerUnum (0),
		mRecvTime (Time(-1, 0)),
		mBallSpeed (Vector(0, 0)),
		mGetPoint (Vector(0, 0)),
		mIsMultiPass (false),
		mIntCycle (-1)
	{
		memset(mDangerOpp, 0, sizeof(mDangerOpp));
	}
};

struct TacticsInfo
{
	BehaviorType mType;
	Time  mRecvTime;
	Vector mBallPos;
	Vector mBallSpeed;
	Vector mSelfPos;

	bool  mBallPosValid;
	bool  mBallSpeedValid;
	bool  mSelfPosValid;

	TacticsInfo():
		mType(BT_None),
		mRecvTime(Time(-1,0)),
		mBallPos(Vector(0,0)),
		mBallSpeed(Vector(0,0)),
		mSelfPos(Vector(0,0)),
		mBallPosValid(false),
		mBallSpeedValid(false),
		mSelfPosValid(false)
	{
	}
};

class HearMessage
{
	friend class CommunicateSystem;
	friend class WorldState;
	friend class Strategy;
public:
    HearMessage() : 
        mSender(0), 
        mReceiver(0)
    {
        for (int i = 0; i <= TEAMSIZE; ++i)
        {
            mTeammateStaminaCycle[i] = -3;
            mTeammateStamina[i] = 0;
        }
    }


public:
	const PassInfo& GetHearPassInfo() const { return mHearPassInfo;}
	const PassInfo& GetAskForBallInfo() const { return mAskForBallInfo;}
	Unum GetSender() const { return mSender;}
	Unum GetReceiver() const { return mReceiver;}
	const TacticsInfo& GetTacticsInfo() const { return mTacticsInfo;}

    const int & GetTeammateStaminaTime(const Unum & unum) const
    {
        Assert(unum >= 1 && unum <= TEAMSIZE);
        return mTeammateStaminaCycle[unum];
    }

    const int & GetTeammateStamina(const Unum & unum) const
    {
        Assert(unum >= 1 && unum <= TEAMSIZE);
        return mTeammateStamina[unum];
    }

private:
	Unum     mSender;
	Unum     mReceiver;
	TacticsInfo mTacticsInfo;
	PassInfo mHearPassInfo;
	PassInfo mAskForBallInfo;

    int mTeammateStaminaCycle[TEAMSIZE + 1];
	int mTeammateStamina[TEAMSIZE + 1];
};


#endif

