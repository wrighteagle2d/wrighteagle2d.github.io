/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "Tackler.h"
#include "WorldState.h"

/**
 * Constructor.
 */
Tackler::Tackler()
{
}


/**
 * Destructor.
 */
Tackler::~Tackler()
{
}


/**
 * Instance.
 */
Tackler & Tackler::instance()
{
    static Tackler tackler;
    return tackler;
}


/**
 * Update data used by tackle.
 * \param agent.
 */
void Tackler::UpdateTackleData(const Agent & agent)
{
    if (mAgentID == agent.GetAgentID())
    {
        return; /** no need to update */
    }

    mAgentID = agent.GetAgentID();

    const BallState &ball_state     = agent.GetWorldState().GetBall();
    const PlayerState &player_state = agent.GetSelf();
    Vector ball_2_player = (ball_state.GetPos() - player_state.GetPos()).Rotate(-player_state.GetBodyDir());

    Vector ball_vel;
    max_ball_speed_after_tackle = -1.0;
    memset(tackle_angle_for_ball_vel_angle_available, false, sizeof(tackle_angle_for_ball_vel_angle_available));

    double max, min, eff_power;
    max = ServerParam::instance().maxTacklePower();
    min = ServerParam::instance().maxBackTacklePower();

    double factor = 1.0 - 0.5 * (fabs(Deg2Rad(ball_2_player.Dir())) / M_PI);

    int index1, index2;
    for (AngleDeg angle = -180.0; angle <= 180.0; angle += 1.0){
        ball_vel = (ball_state.GetVelConf() > FLOAT_EPS) ? ball_state.GetVel() : Vector(0, 0);
        eff_power = (min + ((max - min) * (1.0 - fabs(Deg2Rad(angle)) / M_PI))) * ServerParam::instance().tacklePowerRate();
        eff_power *= factor;
        ball_vel += Polar2Vector(eff_power, angle + player_state.GetBodyDir());
        if (ball_vel.Mod() != 0)
            ball_vel = ball_vel.SetLength(Min(ball_vel.Mod(), ServerParam::instance().ballSpeedMax()));

        index1 = ang2idx(angle);
        index2 = ang2idx(ball_vel.Dir());

        ball_vel_after_tackle[index1] = ball_vel;

        if ( !tackle_angle_for_ball_vel_angle_available[index2]){
            tackle_angle_for_ball_vel_angle[index2] = angle;
            tackle_angle_for_ball_vel_angle_available[index2] = true;
        }
        else {
            if (ball_vel_after_tackle[ang2idx(tackle_angle_for_ball_vel_angle[index2])].Mod() < ball_vel.Mod() - FLOAT_EPS){ //�����������-FLOAT_EPS��������Ż��汾��δ�Ż��İ汾��һ��
                tackle_angle_for_ball_vel_angle[index2] = angle; //����ѡ�ٶȴ��
            }
        }

        if (ball_vel.Mod() > max_ball_speed_after_tackle){
            max_ball_speed_after_tackle = ball_vel.Mod();
        }

        if (ball_vel.Mod() * ServerParam::instance().ballDecay() < FLOAT_EPS)
        {
        	m_can_tackle_stop_ball = true;
        	m_tackle_stop_ball_angle = angle;
        }
    }
}


/**
 * Get ball velocity after tackle.
 * \param agent.
 * \param angle tackle angle.
 * \return ball velocity.
 */
Vector Tackler::BallVelAfterTackle(const Agent & agent, AngleDeg angle)
{
    UpdateTackleData(agent);
    return ball_vel_after_tackle[ang2idx(angle)];
}


/**
 * Get ball velocity after tackle to a certain direction.
 * \param agent.
 * \param angle_after_tackle direction you want the ball to go.
 * \param ball_vel will be set to ball velocity if valid.
 * \return true iff it is possible to tackle the ball to the given direction.
 */
bool Tackler::BallVelAfterTackleWithAngle(const Agent & agent, AngleDeg angle_after_tackle, Vector *ball_vel)
{
    UpdateTackleData(agent);
    int index = ang2idx(angle_after_tackle);
    if (tackle_angle_for_ball_vel_angle_available[index]){
        *ball_vel = ball_vel_after_tackle[ang2idx(tackle_angle_for_ball_vel_angle[index])];
        return true;
    }
    return false;
}


/**
 * If possible to tackle the ball to a certain direction.
 * \param angle_after_tackle direction you want the ball to go.
 * \return true iff it is possible to tackle the ball to the given direction.
 */
bool Tackler::BallVelAfterTackleWithAngleAvailable(const Agent & agent, AngleDeg angle_after_tackle)
{
    UpdateTackleData(agent);
    return tackle_angle_for_ball_vel_angle_available[ang2idx(angle_after_tackle)];
}


/**
 * Get tackle angle to tackle the ball to a certain direction.
 * \param angle_after_tackle direction you want the ball to go.
 * \param tackle_angle will be set to the angle to tackle at if valid.
 * \return true iff it is possible to tackle the ball to the given direction.
 */
bool Tackler::TackleAngleForBallVelAngle(const Agent & agent, AngleDeg angle_after_tackle, AngleDeg *tackle_angle)
{
    UpdateTackleData(agent);
    int index = ang2idx(angle_after_tackle);
    if (tackle_angle_for_ball_vel_angle_available[index]){
        *tackle_angle = tackle_angle_for_ball_vel_angle[index];
        return true;
    }
    return false;
}


/**
 * Maximum ball speed after tackle.
 * \param agent.
 * return maximum speed.
 */
double Tackler::MaxBallSpeedAfterTackle(const Agent & agent)
{
    UpdateTackleData(agent);
    return max_ball_speed_after_tackle;
}


/**
 * Tackle ball.
 * \param agent.
 * \param angle_after_tackle direction you want the ball to go.
 * \param p_tackle_angle will be set to the angle to tackle at if valid.
 * \return true iff it is possible to tackle the ball to the given direction.
 */
bool Tackler::TackleBall(Agent & agent, AngleDeg angle_after_tackle, AngleDeg *p_tackle_angle)
{
    UpdateTackleData(agent);
    AngleDeg tackle_angle;
    if (TackleAngleForBallVelAngle(agent, angle_after_tackle, &tackle_angle)){
        if (p_tackle_angle != NULL){
            *p_tackle_angle = tackle_angle;
        }
        agent.Tackle(tackle_angle);
        return true;
    }
    return false;
}


/**
 * If possible to stop ball via tackle.
 */
bool Tackler::CanTackleStopBall(Agent & agent)
{
	UpdateTackleData(agent);
	return m_can_tackle_stop_ball;
}


/**
 * Perform a tackle to stop ball.
 */
bool Tackler::TackleStopBall(Agent & agent)
{
	UpdateTackleData(agent);
	return m_can_tackle_stop_ball && TackleBall(agent, m_tackle_stop_ball_angle);
}

// end of Tackler.cpp
