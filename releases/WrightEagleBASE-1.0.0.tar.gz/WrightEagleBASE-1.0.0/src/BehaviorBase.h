/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef BEHAVIORBASE_H_
#define BEHAVIORBASE_H_

#include <list>
#include <map>
#include "Geometry.h"
#include "ActionEffector.h"
#include "Formation.h"

class WorldState;
class BallState;
class PlayerState;
class InfoState;
class PositionInfo;
class InterceptInfo;
class Strategy;
class Agent;

enum BehaviorType {
	BT_None,

    BT_Setplay,
    BT_Attack,
    BT_Defense,
	BT_Penalty,

	BT_Relax,//Use to communicate, stands for out of stamina
	BT_Max
};

enum BehaviorSetPlayType{
	TAT_Move,
	TAT_Scan,
	TAT_Turn,
	TAT_Face
};
enum BehaviorDetailType {
	BDT_None,

    BDT_Dribble,
    BDT_Dribble_Fast,
    BDT_Intercept,
    BDT_Pass,
	BDT_TurnToBall,
    BDT_Position_Normal,
    BDT_Position_Assort,
    BDT_Position_Rush,
    BDT_Kick,
    BDT_GoToPoint,
    BDT_Attack_Intercept,
	BDT_Catch,
	BDT_Scan,
	BDT_Shoot
};

class BehaviorExecutable;

class BehaviorFactory {
	BehaviorFactory();
	virtual ~BehaviorFactory();

public:
	typedef BehaviorExecutable * (*BehaviorCreator)(Agent & agent);
	static BehaviorFactory & instance();

	/**
	* Creat behavior
	* @param agent
	* @param type
	* @return
	*/
	BehaviorExecutable * CreateBehavior(Agent & agent, BehaviorType type);

	/**
	* Register behavior. When a behavior should be execute by its executer, register is necessary
	* @param type 
	* @param creator 
	* @return
	*/
	bool RegisterBehavior(BehaviorType type, BehaviorCreator creator);

private:
	BehaviorCreator mCreatorMap[BT_Max];
};

class ActiveBehavior 
{
	/** behavior type and agent pointer */
	BehaviorType mType;

	Agent * mpAgent;

public:

	ActiveBehavior(Agent & agent, BehaviorType type,
			BehaviorDetailType detail_type = BDT_None) :
		mType(type), mpAgent(&agent), mSuccessPoss(0.0), mSuccessEffect(0.0),
		mFailureEffect(0.0), mEvaluation(-1.0), mCostCycle(0),
		mKickCycle(0), mAngle(0), mTarget(Vector(0.0, 0.0)),
		mPower(0.0), mDistance(0.0), mKickSpeed(0.0), mDashSpeed(0.0),
		mPeakDist(0.0), mPeakPoint(Vector(0.0, 0.0)), mKeyUnum(0),
		mDetailType(detail_type),
        mBuffer(0.0){
	}

	void Clear() {
		mCostCycle = 0;
		mSuccessPoss = 0.0;
		mSuccessEffect = 0.0;
		mFailureEffect = 0.0;
		mEvaluation = 0.0;
		mActionPlan.mActionQueue.clear();
	}

	const BehaviorType & GetType() const {
		return mType;
	}
	void SetType(const BehaviorType &type) {
		mType = type;
	}

	Agent & GetAgent() const {
		return *mpAgent;
	}

	/** the possibility & evaluation model */
	double mSuccessPoss; // success possibility
	BehaviorSetPlayType mSetPlayType;
	double FailurePoss() const {
		return 1.0 - mSuccessPoss;
	} // fail possibility
	double mSuccessEffect; // success effect
	double mFailureEffect; // fail effect
	double mEvaluation; // totaly effect
	void UpdateEvaluation() {
		mEvaluation = mSuccessPoss * mSuccessEffect + FailurePoss()
				* mFailureEffect;
	}

	bool Execute(); //Depend on BehaviorType

	bool operator>(const ActiveBehavior & ab) const {
		return this->mEvaluation > ab.mEvaluation;
	}
	bool operator ==(const ActiveBehavior & ab) const {
		return this->mEvaluation == ab.mEvaluation;
	}
	bool operator <(const ActiveBehavior & ab) const {
		return this->mEvaluation < ab.mEvaluation;
	}

	//behavior detail
	int mCostCycle; 
	int mKickCycle; 
	AngleDeg mAngle; 
	Vector mTarget; 
	double mPower; 
	double mDistance; 
	double mKickSpeed; 
	double	mDashSpeed; 
	double mPeakDist; 
	Vector mPeakPoint; 

	KeyPlayerInfo mKeyTm; 
	KeyPlayerInfo mKeyOpp; 
	KeyPlayerInfo mKeyOppGB; 
	KeyPlayerInfo mKeyOppGT; 
	int mKeyUnum; 

	BehaviorDetailType mDetailType; 

	ActionPlan mActionPlan; 
	double mBuffer; 
};

class BehaviorAttackData {
public:
	BehaviorAttackData(Agent & agent);
	virtual ~BehaviorAttackData() {}

	Agent & mAgent;

	const WorldState & mWorldState;

	const BallState & mBallState;
	const PlayerState & mSelfState;

	PositionInfo & mPositionInfo;
	InterceptInfo & mInterceptInfo;

	Strategy & mStrategy;
    Formation & mFormation;
};

class BehaviorDefenseData: public BehaviorAttackData {
public:
	BehaviorDefenseData(Agent & agent);
	virtual ~BehaviorDefenseData() {}
};

template < class BehaviorDataType >
class BehaviorPlannerBase: public BehaviorDataType {
	BehaviorPlannerBase(const BehaviorPlannerBase &);

public:
	BehaviorPlannerBase(Agent & agent): BehaviorDataType(agent) {}
	virtual ~BehaviorPlannerBase() {}

	/**
	* Do decision. Find the best ActiveBehavior��push back to behavior_list
	*/
	virtual void Plan(std::list<ActiveBehavior> & behavior_list) = 0;

public:
	const std::list<ActiveBehavior> & GetActiveBehaviorList() {
		return mActiveBehaviorList;
	}

protected:
	std::list<ActiveBehavior> mActiveBehaviorList; // record the active behaviors for each high level behavior
};

class BehaviorExecutable {
	BehaviorExecutable(const BehaviorExecutable&);

public:
	BehaviorExecutable() {}
	virtual ~BehaviorExecutable() {}

	/**
	* Execute ActiveBehavior
	* @param act ActiveBehavior
	* @return
	*/
	virtual bool Execute(const ActiveBehavior & act_bhv) = 0;

	// behavior factory interfaces
	template <class BehaviorDerived >
	static BehaviorExecutable* Creator(Agent & agent) { return new BehaviorDerived(agent); }

	template<class BehaviorDerived>
	static bool AutoRegister() {
		return BehaviorFactory::instance().RegisterBehavior(
				BehaviorDerived::BEHAVIOR_TYPE, Creator<BehaviorDerived> );
	}
};

template < class BehaviorDataType >
class BehaviorExecuterBase: public BehaviorDataType, public BehaviorExecutable {
	BehaviorExecuterBase(const BehaviorExecuterBase &);

public:
	BehaviorExecuterBase(Agent & agent): BehaviorDataType(agent) {}
	virtual ~BehaviorExecuterBase() {}
};


typedef std::list<ActiveBehavior> ActiveBehaviorList;
typedef std::list<ActiveBehavior>::iterator ActiveBehaviorPtr;

#endif /* BEHAVIORBASE_H_ */
