/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "MotionModel.h"
#include "Utilities.h"
#include "ServerParam.h"
#include "Parser.h"

const double MotionModel::SPEED_STEP = ServerParam::instance().playerSpeedMax() / MotionModel::SPEED_SIZE;
const AngleDeg MotionModel::DIR_STEP = 180.0 / MotionModel::DIR_SIZE;
const double MotionModel::DIST_STEP = 1.0;

MotionModel::MotionModel()
{
	Assert(Parser::IsPlayerTypesReady()); //-- ���Ҫ�ȵ��յ��칹��Ϣ���ܳ�ʼ��

	mGBCD  = new Array<Array<double, DIR_SIZE + 1>, SPEED_SIZE + 1>[PlayerParam::instance().playerTypes()];
	mGBC   = new Array<Array<Array<int, 2>, DIR_SIZE + 1>, SPEED_SIZE + 1>[PlayerParam::instance().playerTypes()];
	mGBATV = new Array<Array<double, DIR_SIZE + 1>, SPEED_SIZE + 1>[PlayerParam::instance().playerTypes()];
	mGBATD = new Array<Array<double, DIR_SIZE + 1>, SPEED_SIZE + 1>[PlayerParam::instance().playerTypes()];
	mGBADD = new Array<Array<double, DIR_SIZE + 1>, SPEED_SIZE + 1>[PlayerParam::instance().playerTypes()];
    mGTangle = new Array<double, DIST_SIZE + 1>[PlayerParam::instance().playerTypes()];

	for (int id = 0; id < PlayerParam::instance().playerTypes(); ++id)
	{
		//�ٶ�ģ������ SPEED_SIZE ��ֵ, �ǶȲ������� DIR_SIZE ��
		for (int idxV = 0; idxV <= SPEED_SIZE; idxV++)
		{
			for (int idxAng = 0; idxAng <= DIR_SIZE; idxAng++)
			{
				double vmod = idxV * SPEED_STEP; //���巽���ϵĳ��ٶȣ�����
				double angle = (idxAng + 0.5) * DIR_STEP; //��ʼ�ǶȲ�
				double v = vmod * Cos(angle) * PlayerParam::instance().HeteroPlayer(id).effectiveSpeedMax();
				double dis = 0;
				mGBC[id][idxV][idxAng][0] = 0;
				mGBC[id][idxV][idxAng][1] = 0;
				//ת��
				while (angle >= DIR_STEP)
				{
					v *= PlayerParam::instance().HeteroPlayer(id).playerDecay(); //�õ�ʱ��v�Ǳ任��0-1��������idx�ģ�����������decay����turn
					vmod *= PlayerParam::instance().HeteroPlayer(id).playerDecay();
					angle -= 180.0 / ( 1.0 + PlayerParam::instance().HeteroPlayer(id).inertiaMoment() * fabs(vmod));
					dis += v;
					++mGBC[id][idxV][idxAng][1]; //���ת��������
					++mGBC[id][idxV][idxAng][0];
				}
				//��ʼ��
				double maxspeed = PlayerParam::instance().HeteroPlayer(id).effectiveSpeedMax() * 0.96;
				double max_decayed_speed = maxspeed * PlayerParam::instance().HeteroPlayer(id).playerDecay();
				mGBATV[id][idxV][idxAng] = v; //ת��֮����ٶ�
				mGBATD[id][idxV][idxAng] = dis; //ת�������ƶ��ľ���
				while (v < max_decayed_speed)
				{
					v += PlayerParam::instance().HeteroPlayer(id).dashPowerRate() * PlayerParam::instance().HeteroPlayer(id).effortMax() * 100;
					v = Min(PlayerParam::instance().HeteroPlayer(id).effectiveSpeedMax(), v);
					dis += v;
					v *= PlayerParam::instance().HeteroPlayer(id).playerDecay();
					++mGBC[id][idxV][idxAng][0]; //��ɼ��ٵ�����
				}
				dis -= v / PlayerParam::instance().HeteroPlayer(id).playerDecay() - maxspeed; //����ԣ��
				mGBADD[id][idxV][idxAng] = Max(dis, 0);
				mGBCD[id][idxV][idxAng] = mGBC[id][idxV][idxAng][0] * PlayerParam::instance().HeteroPlayer(id).effectiveSpeedMax() - mGBADD[id][idxV][idxAng];
			}
		}

	    double cyc;
	    mGTangle[id][0] = 0.0;
	    for (int idxD = 1; idxD < 45; ++idxD)
        {
            cyc = ServerParam::instance().GetBallCycle(ServerParam::instance().ballSpeedMax(), idxD);
            cyc = Max(0, cyc - mGBCD[id][2][20]) * PlayerParam::instance().HeteroPlayer(id).effectiveSpeedMax();
		    mGTangle[id][idxD] = ASin(cyc / (idxD + idxD));
	    }
	}
}

MotionModel::~MotionModel()
{
	delete[] mGBCD;
	delete[] mGBC;
	delete[] mGBATV;
	delete[] mGBATD;
	delete[] mGBADD;
    delete[] mGTangle;
}

MotionModel & MotionModel::instance()
{
	static MotionModel motion_model;
	return motion_model;
}
