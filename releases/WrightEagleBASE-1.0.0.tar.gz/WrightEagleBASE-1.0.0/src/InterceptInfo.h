/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __InterceptInfo_H__
#define __InterceptInfo_H__

#include "InfoState.h"

/**
 * Struct InterceptSolution
 */
struct InterceptSolution
{
	InterceptSolution ():
		tangc (0),
		interc (1)
	{

	}

	int tangc;     	//�е���Ŀ {0, 1, 2}
					//num of points of tangency {0, 1, 2}
	int interc;		//������Ŀ {1, 3}
					//num of points of intersection {1, 3}

	double tangp[2];	//���е�(0)�����е�(1)
						//exterior contact point(0), interior contact point(1)
	double tangv[2];	//���е��ٶ�(0)�����е��ٶ�v
						//velocity of exterior contact point(0), velocity of interior contact point(1)
	double interp[3];	//�����������
						//num of points of intersection <= 3
	double intert[3];	//���㴦��Ӧ��������
						//cycle need when event happen at a intersect point
};

enum InterceptRes { //���ؽ��
					//intercept result
	IR_None,

	IR_Failure, //intercept fail
	IR_Success	//intercept success
};

//���ݼ�ģ�����õ��Ľ�����Ϣ
//calculated by a simplified model
/**
 * Class PlayerInterceptInfo
 */
class PlayerInterceptInfo
{
private:
	InterceptSolution solution;
	friend class InterceptInfo;

public:
	PlayerInterceptInfo():
		mTime (Time(-3, 0)),
		mpPlayer (0),
		mIdleCycle (0),
		mMinCycle (1000),
		mInterPos (Vector(1000, 1000)),
		mIntervals (1),
		mDashPowerToUse (100),
		mRes (IR_Failure)
	{

	}

	Time mTime;		//����ʱ��
					//record last update time
	const PlayerState *mpPlayer;
	int mIdleCycle; //����ʼ�Ŀ������ڣ���Է����� tackle_ban
					//idle cycles before intercept happen.such as tackle_ban
	int mInterCycle[3]; //������Ľ��������Ӧ��������
						//cycle need corresponding to intercept area
	int mMinCycle;	//��С�������ڣ�����ǰ������ݼ�����ã�
					//min intercept cycle 
	Vector mInterPos;	//��С���ڶ�Ӧ�Ľ����
						//corresponding to min intercept cycle
	int mIntervals; //������� {1, 2}
					//num of intercept area
	double mDashPowerToUse; //���������������power�Ƚ�׼
							//get ball with the power is correct when ball isn't far
	InterceptRes mRes;	//����ɹ���ָ���ڳ���֮�ڽص���
						//intercept in the pitch rectangular

	friend std::ostream &operator<<(std::ostream &os, const PlayerInterceptInfo &it){
		if (it.solution.interc == 1){
			return os << "[" << it.mInterCycle[0] << ", $]";
		}
		else {
			return os << "[" << it.mInterCycle[0] << ", " << it.mInterCycle[1] << "] [" << it.mInterCycle[2] << ", $]";
		}
	}
};

/**
 * Struct OrderedIT
 * Used to save intercept information of a player
 */
struct OrderedIT {
	OrderedIT(): mpInterceptInfo(0), mUnum(0), mCycleDelay(0){}
	PlayerInterceptInfo *mpInterceptInfo;	//ָ��num��player������info,��ЧʱΪNULL
											//point to interceptInfo of player (num)
	Unum mUnum; //+ Ϊ���ѣ�- Ϊ����
				//mUnum > 0 -> teammate. mUnum < 0 -> opponent
	int mCycleDelay;   //cycle delay
	bool operator < (const OrderedIT& it) const {
		return (mpInterceptInfo->mMinCycle == it.mpInterceptInfo->mMinCycle)? mCycleDelay < it.mCycleDelay: mpInterceptInfo->mMinCycle < it.mpInterceptInfo->mMinCycle;
	}
};

/**
 * Class InterceptInfo
 * Mostly, the function operated as its name's meaning
 */
class InterceptInfo: public InfoStateBase
{
public:
    InterceptInfo(WorldState *pWorldState, InfoState *pInfoState);
    virtual ~InterceptInfo();

    PlayerInterceptInfo *GetPlayerInterceptInfo(Unum unum) const;
    const std::list<OrderedIT> & GetOIT() const { return mOIT; }
    bool IsPlayerBallInterceptable(Unum unum) const { return GetPlayerInterceptInfo(unum)? GetPlayerInterceptInfo(unum)->mRes == IR_Success: false; } //�����������ǰ���ص���

	static void CalcInterception(const Vector & ball_pos, const Vector & ball_vel, PlayerInterceptInfo *pInfo, bool can_inverse = true);

private:
	void UpdateRoutine();

	void SortInterceptInfo();
	PlayerInterceptInfo *VerifyIntInfo(Unum unum);

private:
    PlayerInterceptInfo mTeammateInterceptInfo[1 + TEAMSIZE];
    PlayerInterceptInfo mOpponentInterceptInfo[1 + TEAMSIZE];
    std::list<OrderedIT> mOIT;	//������������
								//linked list of intercept order

    class VirtualBall {
    public:
    	static const int MAX_STEP = 50;

    	VirtualBall(Vector pos, Vector vel){
    		mBallPos[0] = pos;
    		mBallVel[0] = vel;
    		mStep = 0;
    	};

    	const Vector & GetPredictPosition(int step){
#ifdef _Debug
    		Assert(step >= 0);
#else
    		step = Max(step, 0);
#endif

    		if (step <= mStep){
    			return mBallPos[step];
    		}
    		else {
    			step = Min(step, MAX_STEP);
    			for (int i = mStep + 1; i <= step; ++i){
    				mBallPos[i] = mBallPos[i-1] + mBallVel[i-1];
    				mBallVel[i] = mBallVel[i-1] * ServerParam::instance().ballDecay();
    			}
    			mStep = step;
    			return mBallPos[step];
    		}
    	}

    private:
    	Vector mBallPos[MAX_STEP + 1];
    	Vector mBallVel[MAX_STEP + 1];
    	int mStep;
    };
};

#endif
