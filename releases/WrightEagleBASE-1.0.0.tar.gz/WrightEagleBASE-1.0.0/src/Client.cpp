/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "Client.h"
#include "DynamicDebug.h"
#include "NoiseModel.h"
#include "Formation.h"
#include "Kicker.h"
#include "CommandSender.h"
#include "Parser.h"
#include "Thread.h"
#include "UDPSocket.h"
#include "WorldModel.h"
#include "Agent.h"
#include "Logger.h"
#include "MotionModel.h"
#include "CommunicateSystem.h"
#include "NetworkTest.h"
#include "Dasher.h"
#include "Tackler.h"
#include "PossibilityModel.h"
#include "TimeTest.h"
#include "InterceptModel.h"
#include "Plotter.h"

/**
* These are some interface functions for creating threads in Windows and Linux.
*/

namespace {
#ifdef WIN32
DWORD WINAPI CommandSenderThread(LPVOID lpParam)
{
	CommandSender *pCommandSender = (CommandSender *)lpParam;
	pCommandSender->CommandSendLoop();
	return 0;
}

DWORD WINAPI LoggerThread(LPVOID lpParam)
{
    Logger::instance().LoggerLoop();
    return 0;
}


DWORD WINAPI ParserThread(LPVOID lpParam)
{
	Parser *pParser = (Parser *)lpParam ;
	pParser->ParserLoop() ;
	return 0;
}

#else
void *CommandSenderThread(void *v)
{
	CommandSender *pCommandSender = (CommandSender *)v;
	pCommandSender->CommandSendLoop();
	return NULL;
}

void *LoggerThread(void *v)
{
	(void) v;
    Logger::instance().LoggerLoop();
    return NULL;
}

void *ParserThread(void *v)
{
	Parser *pParser = (Parser *)v ;
	pParser->ParserLoop() ;
	return NULL;
}
#endif
}

Client::Client() {
	/** Observer and World Model */
	mpAgent         = 0;
    mpObserver      = new Observer;
	mpWorldModel    = new WorldModel;

	/** Parser thread and CommandSend thread */
	mpParser        = new Parser(mpObserver);
	mpCommandSender = new CommandSender(mpObserver);

    // instance�������ﴴ���Խ�ʡ���������Ч�ʣ�����instance���ܷ��������Ҫʱ����

    /** Assistant instance */
	TimeTest::instance();
    NetworkTest::instance();
    DynamicDebug::instance();
    Logger::instance().Initial(mpObserver, &(mpWorldModel->World(false)));
    Plotter::instance();

    /** Param */
    ServerParam::instance();
    PlayerParam::instance();

	/** Base Model */
	NoiseModel::instance();
    // MotionModel::instance(); // �յ��칹��Ϣ�Ժ���ܳ�ʼ��
    InterceptModel::instance();

    /** Smart Action */
    Dasher::instance();
    Tackler::instance();
    Kicker::instance();

    /** Formation and Evaluation */
    TeammateFormation::instance();
    OpponentFormation::instance();
    // PossibilityModel::instance(); // �յ��칹��Ϣ�Ժ���ܳ�ʼ��

    /** Other Useful Instance */
    BehaviorFactory::instance();
    UDPSocket::instance();
    CommunicateSystem::instance();
}

Client::~Client() {
	delete mpCommandSender;
	delete mpParser;

	delete mpObserver;
	delete mpWorldModel;
	delete mpAgent;
}

/**
* Entrance function for the dynamic debug mode.
*/
void Client::RunDynamicDebug()
{
	static char msg[MAX_MESSAGE];
	DynamicDebug::instance().Initial(mpObserver); // ��̬���Եĳ�ʼ����ע��λ�ò����ƶ�

	DynamicDebug::instance().Run(msg); // ��ʼ����Ϣ
	mpParser->ParseInitializeMsg(msg);

	ConstructAgent();

	MessageType msg_type;

	bool first_parse = true;

	while (true)
	{
		msg_type = DynamicDebug::instance().Run(msg);

		switch (msg_type)
		{
		case MT_Parse:
			if (first_parse) {
				mpObserver->Reset();
				first_parse = false;
			}
			mpParser->Parse(msg);
			break;
		case MT_Run:
			Run();
			Logger::instance().Flush(); //flush log
			mpObserver->SetPlanned();
			break;
		case MT_Send:
			mpCommandSender->Run();
			first_parse = true;
			break;
		default:
			return;
		}
	}
}

/**
* Entrance function for the normal player mode.
*/
void Client::RunNormal()
{
	Create_Thread(&ParserThread, mpParser); // �����̣߳�����server��������Ϣ
	Create_Thread(&CommandSenderThread, mpCommandSender); // ���������̣߳���server������Ϣ
	Create_Thread(&LoggerThread, NULL);

	int past_cycle = 0;
	do
	{
		WaitFor(100); // wait for the parser thread to connect the server
		if (++past_cycle > 20)
		{
			std::cout << PlayerParam::instance().teamName() << ": Connect Server Error ..." << std::endl;
			return;
		}
	} while (mpParser->IsConnectServerOk() == false);

	ConstructAgent();

	SendOptionToServer();


    // ���յ�server�Ĳ�����Ϣ�������߼��㣬��������ȽϺ�
    if (PlayerParam::instance().KickerMode() == 1)
    {
        Kicker::instance().ComputeUtilityTable();
    }


	MainLoop();

	WaitFor(mpObserver->MyUnum() * 100);
    if (mpObserver->MyUnum() == 0)
    {
        std::cout << PlayerParam::instance().teamName() << " Coach: Bye ..." << std::endl;
    }
    else
    {
        std::cout << PlayerParam::instance().teamName() << " " << mpObserver->MyUnum() << ": Bye ..." << std::endl;
    }
}

/**
* Create an Agent, and initialize it.
*/
void Client::ConstructAgent()
{
	if (mpAgent == 0) mpAgent = new Agent(mpObserver->MyUnum(), mpWorldModel, false); //Ҫ֪��������ܳ�ʼ��
	mpCommandSender->RegisterAgent(mpAgent);
	CommunicateSystem::instance().Initial(mpObserver , mpAgent); //init communicate system
}

/**
* Main loop function for players in the normal player mode.
*/
void Client::MainLoop()
{
	while (mpObserver->WaitForNewInfo()) // �ȴ����Ӿ�
	{
        NetworkTest::instance().AddDecisionBegin();

        // ����������bye ...
        if (mpObserver->GetPlayMode() == PM_Time_Over)
        {
            mpAgent->CheckCommands(mpObserver);
            mpAgent->Bye();

            mpObserver->SetPlanned();
            mpObserver->SetCommandSend();
            Logger::instance().SetFlushCond();

            break;
        }

        DynamicDebug::instance().AddMessage("\0", MT_Run); // ��̬���Լ�¼Run��Ϣ
        Run();

		mpObserver->SetPlanned();
		mpObserver->SetCommandSend(); //���ѷ���������߳�
		Logger::instance().SetFlushCond(); // set flush cond and let the logger thread flush the logs to file.

        NetworkTest::instance().AddDecisionEnd(mpObserver->CurrentTime());
	}
}
