/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __Tackler_H__
#define __Tackler_H__

#include "Agent.h"

/**
 * Tackler
 */
class Tackler
{
    Tackler();

public:
    ~Tackler();

    static Tackler & instance();

    /**
     * Convert angle to index.
     * \param angle.
     * \return index.
     */
    inline int ang2idx(AngleDeg angle) { return int(Rint(angle + 180.0)); }

    /**
     * Update data used by tackle.
     */
    void UpdateTackleData(const Agent & agent);

    /**
     * Get ball velocity after tackle.
     */
    Vector BallVelAfterTackle(const Agent & agent, AngleDeg tackle_angle);

    /**
     * Get ball velocity after tackle to a certain direction.
     */
    bool BallVelAfterTackleWithAngle(const Agent & agent, AngleDeg angle_after_tackle, Vector *ball_vel);

    /**
     * If possible to tackle the ball to a certain direction.
     */
    bool BallVelAfterTackleWithAngleAvailable(const Agent & agent, AngleDeg angle_after_tackle);

    /**
     * Get tackle angle to tackle the ball to a certain direction.
     */
    bool TackleAngleForBallVelAngle(const Agent & agent, AngleDeg angle_after_tackle, AngleDeg *tackle_angle);

    /**
     * Maximum ball speed after tackle.
     */
    double MaxBallSpeedAfterTackle(const Agent & agent);

    /**
     * Tackle ball.
     */
    bool TackleBall(Agent & agent, AngleDeg angle_after_tackle, AngleDeg *p_tackle_angle = NULL);

    /**
     * If possible to stop ball via tackle.
     */
    bool CanTackleStopBall(Agent & agent);

    /**
     * Perform a tackle to stop ball.
     */
    bool TackleStopBall(Agent & agent);

private:
    /** ������ʡʱ��ļ�¼�� */
	AgentID mAgentID;

    Vector ball_vel_after_tackle[361]; // -180.0 -> 180.0
    AngleDeg tackle_angle_for_ball_vel_angle[361];
    bool tackle_angle_for_ball_vel_angle_available[361];
    double max_ball_speed_after_tackle;
    bool m_can_tackle_stop_ball;
    AngleDeg m_tackle_stop_ball_angle;
};


#endif

