/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __Formation_H__
#define __Formation_H__

#include "Types.h"
#include "Geometry.h"
#include <vector>

class Agent;
class WorldState;

#define FORMATION_LINE_NUM 3 // There are 3 formation lines
#define FORMATION_MAX_X (50.0)
#define FORMATION_MAX_Y (20.0)

/**
* ===============================================
*                         2
*                               3     4
*                         8
* Initial 4-3-3��   1           10    11
*                         9
*                               6     7
*                         5
* ===============================================
*/


struct RoleType
{
	/** x�����y��������� */
	/** Index of X direction and Y direction */
	int mIndexX; /** 0 - 3 */
	int mIndexY; /** 1 - 4*/

	LineType mLineType;
	PositionType mPositionType;

	RoleType()
	{
		mIndexX = 0;
		mIndexY = 0;
		mLineType = LT_Null;
		mPositionType = PT_Null;
	}

	PlayerRole ToPlayerRole() const {
		switch (mLineType){
		case LT_Defender:
			switch(mPositionType){
			case PT_Left:
			case PT_Right: return PR_BackSide;
			default: return PR_BackCenter;
			}
			break;
		case LT_Midfielder:
			switch(mPositionType){
			case PT_Left:
			case PT_Right: return PR_MidSide;
			default: return PR_MidCenter;
			}
			break;
		case LT_Forward:
			switch(mPositionType){
			case PT_Left:
			case PT_Right: return PR_ForwardSide;
			default: return PR_ForwardCenter;
			}
			break;
		default: return PR_Max;
		}
		return PR_Max;
	}
};

//������ʾ����Ϊ��Ԫ�⣬�����඼������instance��ʽ���� TeammateFormation �� OpponentFormation
//TeammateFormation and OpponentFormation can be called  as *.instance() by these friend classes only.
class FormationBase {
	friend class TeammateFormation;
	friend class OpponentFormation;
	friend class Formation;
	friend class Coach;
    friend class CoachTeamModel;
	friend class CommunicateSystem;
    friend class WorldStateUpdater;

public:
	FormationBase(Unum goalie_num, FormationType type);
	virtual ~FormationBase() {}

private:
    double GetHInerval(FormationType type, int index_H) const
    {
	    Assert(0<=index_H&&index_H<FORMATION_LINE_NUM -1);
	    return mHInterval[type][index_H];
    }

    double GetVInterval(FormationType type, int index_V) const
    {
	    Assert(0<=index_V&&index_V<FORMATION_LINE_NUM);
	    return mVInterval[type][index_V];
    }

    double GetHBallFactor(FormationType type) const
    {
        Assert(type >= 0 && type < FT_Max);
        return mHBallFactor[type];
    }

    double GetVBallFactor(FormationType type) const
    {
        Assert(type >= 0 && type < FT_Max);
        return mVBallFactor[type];
    }

    int GetLineArrange(FormationType type, int index_i) const
    {
        Assert(type >= 0 && type < FT_Max && index_i >= 0 && index_i <= FORMATION_LINE_NUM);
        return (index_i == 0) ? 1 : mLineArrange[type][index_i - 1]; // index_i == 0 is goalie
    }

    const RoleType & GetPlayerRoleType(FormationType type, Unum unum) const
	{
        Assert(unum>=1 && unum<=TEAMSIZE);
        return mPlayerRole[type][unum];
    }

    /** ͨ�������õ���Ա���� */
    /** Get player's number by index */
	Unum GetUnumFromIndex(FormationType type, int index_i, int index_j)
    {
        Assert(index_i >=0 && index_i < TEAMSIZE);
        Assert(index_j >=0 && index_j < TEAMSIZE);
        return mIndex2Unum[type][index_i][index_j];
    }

private:
	double      mHInterval[FT_Max][FORMATION_LINE_NUM - 1]; /** Distance between each formation line. [*][0] stands for the distance between backdefielder and midfielder��[*][1] stands for the distance between midfielder and striker */
	double      mVInterval[FT_Max][FORMATION_LINE_NUM]; /** Distance of players who are in a same formation line */

	double      mHBallFactor[FT_Max];
	double      mVBallFactor[FT_Max];
	Rectangular mActiveField[FT_Max][TEAMSIZE + 1]; /** Area of each player */

	int         mLineArrange[FT_Max][FORMATION_LINE_NUM]; /** Number of players in each formation line */
	RoleType    mPlayerRole[FT_Max][TEAMSIZE + 1]; /** [*][2] stands for player2's infomation of RoleType */
	Vector      mOffsetMatrix[FT_Max][TEAMSIZE + 1][TEAMSIZE + 1]; /** offset matrix */

    int         mIndex2Unum[FT_Max][TEAMSIZE][TEAMSIZE]; /** Get player number by index[FT_Max]��which formation line��goalie is 0��[TEAMSIZE]��player's num on a formation line dextrad increased��the leftmost is 1��[TEAMSIZE] */

private:
    const Unum & GetGoalieUnum() const { return mGoalieUnum; }
    void SetGoalieUnum(const Unum & unum) { mGoalieUnum = unum; }
    const FormationType & GetFormationType() const { return mFormationType; }
    void SetFormationType (const FormationType & type) { mFormationType = type; }

    Unum mGoalieUnum; 
    FormationType mFormationType;

private:
    Vector GetExpectedGoaliePos(const Vector & ball_pos, const double run, const Vector & goalie_pos, const int & cycle_delay);

// �������ĺ����ͻ����㣬�������﹩�ⲿ���ã���Ҫ����WorldState
private:
    const Vector & GetFormationCenter(const WorldState & world_state, bool is_teammate, double min_conf = 0.6);
	void SetFormationCenter(Unum num, Vector position);
    Vector GetFormationPoint(const WorldState &world_state, bool is_teammate, Unum unum, double min_conf = 0.6);

private:
    Vector mFormationCT;

private:
    const std::vector<Unum> & GetPassGraph(FormationType type, Unum unum) const
    {
        Assert(type >= 0 && type < FT_Max && unum >= 1 && unum <= TEAMSIZE);
        return mPassGraph[type][unum];
    }

    void SetPassGraph(FormationType type);

private:
    std::vector<Unum> mPassGraph[FT_Max][TEAMSIZE + 1];
};

/**
 * �Լ������Σ��ɳ�ʼ��ʱ���
 * My formation��get when initialization taken
 */
class TeammateFormation: public FormationBase {
	friend class Formation;
	friend class WorldStateUpdater;
	friend class Client;
	friend class Coach;
	friend class CoachTeamModel;
	friend class CommunicateSystem;

	TeammateFormation(Unum goalie_unum, FormationType type);

private:
	virtual ~TeammateFormation();

	static TeammateFormation & instance();

private:
    /** ��ʼ�����͵Ļ�����Ϣ�������ǹ��캯��Ĭ�ϵ��û��߽������� */
    /** Initialize formation information��from construct function or received from coach */
    void InitFormationInfo(const bool is_coach_say = false, const int coach_say_time = 0, const int line_arrange[] = 0, const int unum_arrange[] = 0);

	/** �������ø�������Ա��Ŀ����֤��ͬ���ߵ���Ա�������ڲ�ͬ�Ļ����ϣ����һ�����ʱ��ÿ����Ա�Ķ����ᳬ���������� */
	/** Set numbers of player on each formation line��ensure different formation line's player be run on different computer��when formation changed��changes of every player's formation line is less than 2*/
	void SetUnumArrange(FormationType type, int defender, int midfielder, int forward);

    /** �������ö��ѵ����� */
    /** Set teammate's formation type */
    void SetTeammateRole(FormationType type);

    /** �������ø������������,����֮ǰ��Ҫ���ȷ������Ա����ͽ�ɫ���� */
    /** Set distance between every two formation lines, Unum and role type of player should be set before this */
	void SetHInterval(FormationType type, double back_middle, double middle_front);

	/** �������ø������ڲ���Ա���������,����֮ǰ��Ҫ���ȷ������Ա����ͽ�ɫ���� */
	/** Set distance between every two players in a same formation line, Unum and role type of player should be set before this */
	void SetVInterval(FormationType type, double back, double middle, double front);

private:
    int mUnumArrange[FT_Max][TEAMSIZE]; /** from goalie to striker��[0] is goalie's number */
};

/**
 * �Է�����
 * Opponent's formation
 */
class OpponentFormation: public FormationBase {
	friend class Formation;
	friend class Client;
	friend class Coach;
    friend class CoachTeamModel;
	friend class CommunicateSystem;
    friend class WorldStateUpdater;

public:
	OpponentFormation(Unum goalie_unum, FormationType type);
    virtual ~OpponentFormation();

private:
	static OpponentFormation & instance();

public:
    void SetFormationRole(const FormationType & formation_type);
    void SetOffsetMatrix(const FormationType & formation_type);
    bool IsRoleValid() { return (mUsedTimes[mFormationType] > 0); }

private:
    std::vector<int> mLineMember[FT_Max][3]; // 3 means number of players on the same formation line with me��0 is backfielder��1 is midfielder��2 is striker
    unsigned long mUsedTimes[FT_Max]; // effective count
    int mHIntervalTimes[FT_Max][2]; // HInterval's effective count

public:
    static double mForwardMaxX; // forward max x
    static double mDefenderMinX;  // defender min x

public:
    enum
    {
        FRONT_CODE_SIZE = 10,
        BACK_CODE_SIZE = 10,
        FORMATION_CODE_SIZE = 21 // formation code length = 1 + 10 + 10
    };

    bool operator < (OpponentFormation& other)
    {
        return ((mFormationType == other.mFormationType) && (mUsedTimes[mFormationType] < other.mUsedTimes[other.mFormationType]));
    }

    bool operator == (OpponentFormation& other)
    {
        if (mFormationType == other.mFormationType &&
            mLineMember[mFormationType][0].size() == other.mLineMember[mFormationType][0].size() &&
            mLineMember[mFormationType][1].size() == other.mLineMember[mFormationType][1].size() &&
            mLineMember[mFormationType][2].size() == other.mLineMember[mFormationType][2].size())
	    {
		    for (int n = 0; n < 3; n++)
            {
                for (unsigned int i = 0; i < mLineMember[mFormationType][n].size(); i++)
                {
				    if (mLineMember[mFormationType][n][i] != other.mLineMember[mFormationType][n][i])
                    {
					    return false;
				    }
			    }
		    }
		    return true;
	    }
	    return false;
    }
};

/**
 * ͳһά���Լ������κͶԷ������Σ��������涼ʹ��������ṩ�Ľӿ�
 * Maintenance of our and opponent's formation��used when a behavior is planning.
 */
class Formation {
public:
	Formation (Agent & agent);
	virtual ~Formation() {}

//==============================================================================
    bool IsTeammateAttackFormation() const 
    {
        return (mpTeammateFormation->GetFormationType() == FT_Attack_Forward || mpTeammateFormation->GetFormationType() == FT_Attack_Midfield);
    }

    bool IsOpponentAttackFormation() const 
    {
        return (mpOpponentFormation->GetFormationType() == FT_Attack_Forward || mpOpponentFormation->GetFormationType() == FT_Attack_Midfield);
    }

    Unum GetTeammateUnumFromIndex(int index_i, int index_j) const
    {
	    return mpTeammateFormation->GetUnumFromIndex(mpTeammateFormation->GetFormationType(), index_i, index_j);
    }

    Unum GetTeammateUnumFromIndex(int index_i, int index_j, FormationType FType) const
    {
	    return mpTeammateFormation->GetUnumFromIndex(FType, index_i, index_j);
    }

    Unum GetOpponentUnumFromIndex(int index_i, int index_j) const
    {
	    return mpOpponentFormation->GetUnumFromIndex(mpOpponentFormation->GetFormationType(), index_i, index_j);
    }

    Unum GetOpponentUnumFromIndex(int index_i, int index_j, FormationType FType) const
    {
	    return mpOpponentFormation->GetUnumFromIndex(FType, index_i, index_j);
    }

    // �Լ������ͱ�֤ÿ����������2���ˣ����Լ�����Ľӿڣ������ͷ���   2009-05-04
    // Be sure that there are at least 2 player on each formation line��so the followings are just for convenience
    Unum GetTeammateLeftDefender() const
    {
        return GetTeammateUnumFromIndex(1, 1);
    }

    Unum GetTeammateRightDefender() const 
    {
        return GetTeammateUnumFromIndex(1, GetTeammateLineArrange(1));
    }

    Unum GetTeammateLeftMidfielder() const
    {
        return GetTeammateUnumFromIndex(2, 1);
    }

    Unum GetTeammateRightMidfielder() const 
    {
        return GetTeammateUnumFromIndex(2, GetTeammateLineArrange(2));
    }

    Unum GetTeammateLeftForward() const
    {
        return GetTeammateUnumFromIndex(3, 1);
    }

    Unum GetTeammateRightForward() const 
    {
        return GetTeammateUnumFromIndex(3, GetTeammateLineArrange(3));
    }

//==============================================================================
    int GetTeammateLineArrange(int index_i) const
    {
        return mpTeammateFormation->GetLineArrange(mpTeammateFormation->GetFormationType(), index_i);
    }

    int GetOpponentLineArrange(int index_i) const
    {
        return mpOpponentFormation->GetLineArrange(mpOpponentFormation->GetFormationType(), index_i);
    }

    double GetTeammateHInterval(int index_H) const
    {
	    return mpTeammateFormation->GetHInerval(mpTeammateFormation->GetFormationType(),index_H);
    }

    double GetTeammateVInterval(int index_V) const
    {
	    return mpTeammateFormation->GetVInterval(mpTeammateFormation->GetFormationType(),index_V);
    }

    double GetOpponentHInterval(int index_H) const
    {
	    return mpOpponentFormation->GetHInerval(mpOpponentFormation->GetFormationType(), index_H);
    }

    double GetOpponentVInterval(int index_V) const
    {
    	return mpOpponentFormation->GetVInterval(mpOpponentFormation->GetFormationType(), index_V);
    }

    double GetTeammateHBallFactor() const
    {
        return mpTeammateFormation->GetHBallFactor(mpTeammateFormation->GetFormationType());
    }

    double GetTeammateVBallFactor() const
    {
        return mpTeammateFormation->GetVBallFactor(mpTeammateFormation->GetFormationType());
    }

    double GetOpponentHBallFactor() const
    {
        return mpOpponentFormation->GetHBallFactor(mpOpponentFormation->GetFormationType());
    }

    double GetOpponentVBallFactor() const
    {
        return mpOpponentFormation->GetVBallFactor(mpOpponentFormation->GetFormationType());
    }

//==============================================================================
    const std::vector<Unum> & GetTeammatePassGraph(Unum unum) const
    {
        return mpTeammateFormation->GetPassGraph(mpTeammateFormation->GetFormationType(), unum);
    }

    const std::vector<Unum> & GetOpponentPassGraph(Unum unum) const
    {
        return mpOpponentFormation->GetPassGraph(mpOpponentFormation->GetFormationType(), unum);
    }
    
    const RoleType & GetTeammateRoleType(Unum unum) const
    {
        return mpTeammateFormation->GetPlayerRoleType(mpTeammateFormation->GetFormationType(), unum);
    }

	const RoleType & GetTeammateRoleType(Unum unum, FormationType FType) const
    {
        return mpTeammateFormation->GetPlayerRoleType(FType, unum);
    }

	const RoleType & GetOpponentRoleType(Unum unum) const
    {
        return mpOpponentFormation->GetPlayerRoleType(mpOpponentFormation->GetFormationType(), unum);
    }

    const RoleType & GetOpponentRoleType(Unum unum, FormationType FType) const
    {
        return mpOpponentFormation->GetPlayerRoleType(FType, unum);
    }

	const RoleType & GetPlayerRoleType(Unum unum) const
    {
        return (unum > 0) ? GetTeammateRoleType(unum) : GetOpponentRoleType(-unum);
    }

	const RoleType & GetPlayerRoleType(Unum unum, FormationType FType) const
    {
        return (unum > 0) ? GetTeammateRoleType(unum, FType) : GetOpponentRoleType(-unum, FType);
    }

    const RoleType & GetMyRole()  const;

//==============================================================================
    const FormationType & GetTeammateFormationType() const { return mpTeammateFormation->GetFormationType(); }
    void SetTeammateFormationType(const FormationType & type) { mpTeammateFormation->SetFormationType(type); }

    const Vector & GetTeammateFormationCenter(double min_conf = 0.6);
	void SetTeammateFormationCenter(Unum num, Vector position);
    Vector GetTeammateFormationPoint(Unum unum, double min_conf = 0.6);

    Vector GetTeammateExpectedGoaliePos(Vector bp, double run);
    Vector GetTeammateFormationPointBaseBall(Unum unum, const Vector & ball_pos);
    Vector GetTeammateFormationPoint(Unum unum, Unum focusTm, Vector focusPt);

//==============================================================================
    const FormationType & GetOpponentFormationType() const { return mpOpponentFormation->GetFormationType(); }
    void SetOpponentFormationType(const FormationType & type) { mpOpponentFormation->SetFormationType(type); }

    const Vector & GetOpponentFormationCenter(double min_conf = 0.6);
    void SetOpponentFormationCenter(Unum num, Vector position);
    Vector GetOpponentFormationPoint(Unum unum, double min_conf = 0.6);

    Vector GetOpponentExpectedGoaliePos(Vector bp, double run);
    Vector GetOpponentFormationPointBaseBall(Unum unum, const Vector & ball_pos);
    bool IsOpponentRoleValid()
    {
        return (static_cast<OpponentFormation *>(mpOpponentFormation)->IsRoleValid());
    }

    void UpdateOpponentRole(); // Calcuate opponent's formation before coach's sentence

//==============================================================================
private:
	const Agent & mAgent;
	FormationBase *mpTeammateFormation;
	FormationBase *mpOpponentFormation;
};


#endif

