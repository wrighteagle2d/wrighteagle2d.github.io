/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef MOTIONMODEL_H_
#define MOTIONMODEL_H_

#include "Types.h"
#include "Utilities.h"
#include "PlayerParam.h"

class MotionModel
{
	MotionModel();
public:
	~MotionModel();
	static MotionModel & instance();

	static const int SPEED_SIZE = 5;
	static const int DIR_SIZE = 20;
    static const int DIST_SIZE = 44;

	static const double SPEED_STEP;
	static const AngleDeg DIR_STEP;
    static const double DIST_STEP;

	/**
	 * �ӳ�ʼ״̬�ܶ������ٵ�����ۺϵ���ֱ��ȫ���ܵ����ڲʹ��ʱ�Ǵ��¸����ڿ�ʼ�ģ���������getPredictedPos(1)
	 * \param id hetero player type
	 * \param idxV quantized speed (0<=idxV<=5)
	 * \param idxAng quantized angle (0<=idxAng<=20)
	 */
	double GBCD(int id, int idxV, int idxAng) const
	{
		Assert(0<= id && id<PlayerParam::instance().playerTypes() && 0<=idxV && idxV<=SPEED_SIZE && 0<=idxAng && idxAng<=DIR_SIZE);
		return mGBCD[id][idxV][idxAng];
	}

    /**
     * �ӳ�ʼ״̬�ܶ������ٵ�����õ����ں�ת������
	 * \param id hetero player type
	 * \param idxV quantized speed (0<=idxV<=5)
	 * \param idxAng quantized angle (0<=idxAng<=20)
	 * \param flag 0-�ӳ�ʼ״̬�ܶ������ٵ�����õ�����, 1-ת������
     */
	int GBC(int id, int idxV, int idxAng, int flag) const
	{
		Assert(0<= id && id<PlayerParam::instance().playerTypes() && 0<=idxV && idxV<=SPEED_SIZE && 0<=idxAng && idxAng<=DIR_SIZE && 0<=flag && flag<2);
		return mGBC[id][idxV][idxAng][flag];
	}

	/**
	 * ת����ɺ���ٶȣ������������
	 * \param id hetero player type
	 * \param idxV quantized speed (0<=idxV<=5)
	 * \param idxAng quantized angle (0<=idxAng<=20)
	 */
	double GBATV(int id, int idxV, int idxAng) const
	{
		Assert(0<= id && id<PlayerParam::instance().playerTypes() && 0<=idxV && idxV<=SPEED_SIZE && 0<=idxAng && idxAng<=DIR_SIZE);
		return mGBATV[id][idxV][idxAng];
	}

	/**
	 * ת����ɺ�ǰ���ľ��룬�����������
	 * \param id hetero player type
	 * \param idxV quantized speed (0<=idxV<=5)
	 * \param idxAng quantized angle (0<=idxAng<=20)
	 */
	double GBATD(int id, int idxV, int idxAng) const
	{
		Assert(0<= id && id<PlayerParam::instance().playerTypes() && 0<=idxV && idxV<=SPEED_SIZE && 0<=idxAng && idxAng<=DIR_SIZE);
		return mGBATD[id][idxV][idxAng];
	}

	/**
	 * ������ɺ�ǰ���ľ���(Ŀ�귽����)
	 * \param id hetero player type
	 * \param idxV quantized speed (0<=idxV<=5)
	 * \param idxAng quantized angle (0<=idxAng<=20)
	 */
	double GBADD(int id, int idxV, int idxAng) const
	{
		Assert(0<= id && id<PlayerParam::instance().playerTypes() && 0<=idxV && idxV<=SPEED_SIZE && 0<=idxAng && idxAng<=DIR_SIZE);
		return mGBADD[id][idxV][idxAng];
	}

    /**
     * ������Ͷ�Ա���idx2�ף�idx2�״����Ƕ�֮��һ�����ܴ�Խ
	 * \param id hetero player type
	 * \param idxD quantized speed (0<=idxV<=44)
	 */
    double GTangle(int id, int idxD) const
    {
        Assert(0<= id && id<PlayerParam::instance().playerTypes() && 0<=idxD && idxD<=DIST_SIZE);
		return mGTangle[id][idxD];
    }

private:
	Array<Array<double, DIR_SIZE + 1>, SPEED_SIZE + 1> * mGBCD;
	Array<Array<Array<int, 2>, DIR_SIZE + 1>, SPEED_SIZE + 1> * mGBC;
	Array<Array<double, DIR_SIZE + 1>, SPEED_SIZE + 1> * mGBATV;
	Array<Array<double, DIR_SIZE + 1>, SPEED_SIZE + 1> * mGBATD;
	Array<Array<double, DIR_SIZE + 1>, SPEED_SIZE + 1> * mGBADD;
    Array<double, DIST_SIZE + 1> * mGTangle;
};

#endif /* MOTIONMODEL_H_ */
