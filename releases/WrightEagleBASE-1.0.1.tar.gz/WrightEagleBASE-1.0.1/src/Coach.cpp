/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include <list>
#include <string>
#include "Coach.h"
#include "DynamicDebug.h"
#include "Formation.h"
#include "CommandSender.h"
#include "Parser.h"
#include "Thread.h"
#include "UDPSocket.h"
#include "WorldModel.h"
#include "Agent.h"
#include "Logger.h"
#include "TimeTest.h"
#include "PlayerParam.h"
#include "../data/USTC_logo.xpm"

//==============================================================================
Coach::Coach()
{
	memset(mTeammatePlayerType, 0, sizeof(mTeammatePlayerType));

	mIsCycleInfoSent = false;
	mTimeInterval = 0;
	mIsPlayerTypesDone = false;
}

//==============================================================================
Coach::~Coach()
{
}

/*
 * Funciion for coach to send options to server such as player types
 * and other initial commands.
 */
void Coach::SendOptionToServer()
{
	while (!mpParser->IsEyeOnOk())
	{
		UDPSocket::instance().Send("(eye on)");
		WaitFor(200);
	}

    // team graphic
    if (PlayerParam::instance().UseTeamGraphic())
    {
#ifndef WIN32

        mTeamGraphic.createXpmTiles(USTC_logo_xpm);
        if (mpObserver->CurrentTime().T() == 0 && 
            mTeamGraphic.tiles().size() != mpParser->GetTeamGraphicOkSet().size())
        {
            SendTeamGraphic();
        }
        WaitFor(100);

#endif
    }

	for (int i = 1; i <= TEAMSIZE; ++i)
    {
        if (i != PlayerParam::instance().ourGoalieUnum() && mpObserver->Teammate_Coach(i).IsAlive()) // ֻ���ϳ��ķ�����Ա��Ա����
        {
            mpAgent->CheckCommands(mpObserver);
            mpAgent->ChangePlayerType(i, i);
            mpObserver->SetCommandSend();
            WaitFor(5);
        }
	}

    /** check whether each player's type is changed OK */
	WaitFor(200);
	for (int i = 1; i <= TEAMSIZE; ++i)
    {
        if (i != PlayerParam::instance().ourGoalieUnum() && mpObserver->Teammate_Coach(i).IsAlive())
        {
            while (!mpParser->IsChangePlayerTypeOk(i) && mpObserver->CurrentTime().T() < 1) // ֻ�ڱ�����ʼǰ����
            {
			    mpAgent->CheckCommands(mpObserver);
			    mpAgent->ChangePlayerType(i, i);
			    mpObserver->SetCommandSend();
                WaitFor(200);
		    }
        }
	}
}

/*
 * The main loop for coach.
 */
void Coach::Run()
{
    /** ���漸������˳���ܱ� */
	mpAgent->CheckCommands(mpObserver); // ��������ڷ����������
	mpWorldModel->Update(mpObserver);

	DoDecisionMaking();

	Logger::instance().LogSight();
}

/*
 * Funciton for the online coach to decide what to say to direct the match.
 */
void Coach::DoDecisionMaking()
{
    return;
}

/*
 * Send the team graphic to server.
 */
void Coach::SendTeamGraphic()
{
#ifndef WIN32

    int count = 0;
    for (TeamGraphic::Map::const_reverse_iterator tile = mTeamGraphic.tiles().rbegin(); tile != mTeamGraphic.tiles().rend(); ++tile)
    {
        WaitFor(2);
        if (mpParser->GetTeamGraphicOkSet().find(tile->first) == mpParser->GetTeamGraphicOkSet().end())
        {
            if (!DoTeamGraphic( tile->first.first, tile->first.second, mTeamGraphic))
            {
                break;
            }
            ++count;
        }
    }

    if (count > 0)
    {
        std::cout << 
            "#" << 
            PlayerParam::instance().teamName() << 
            " Coach: " << 
            "send team_graphic " << 
            count << 
            " tiles" << std::endl;
    }

#endif
}

/*
 * Create the team graphic by using a certain .xpm file point by point.
 * \param x the x position of the pixel point.
 * \param y the y position of the pixel point.
 * \param team_graphic the graphic to create.
 * \return if the graphic successfully created.
 */
bool Coach::DoTeamGraphic(const int x, const int y, const TeamGraphic & team_graphic)
{
#ifndef WIN32

    TeamGraphic::Index index(x, y);
    TeamGraphic::Map::const_iterator tile = team_graphic.tiles().find(index);

    if (tile == team_graphic.tiles().end())
    {
        std::cerr << 
            PlayerParam::instance().teamName() << 
            " Coach: " << 
            mpObserver->CurrentTime() << 
            " ***WARNING*** The xpm tile (" << 
            x << ',' << y << 
            ") does not found in the team graphic." << std::endl;
        
        return false;
    }

    std::ostringstream ostr;

    ostr << "(team_graphic (" << x << ' ' << y << ' ';
    tile->second->print( ostr );
    ostr << "))";

    if (UDPSocket::instance().Send( ostr.str().c_str() ) > 0)
    {
        return true;
    }

#endif

    return false;
}


//end of file Coach.cpp

