/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "Thread.h"


#ifdef WIN32

#include <windows.h>

//==============================================================================
ThreadCondition::ThreadCondition()
{
	mEvent = CreateEvent(NULL, false, false, NULL);
}


//==============================================================================
ThreadCondition::~ThreadCondition()
{
}


//==============================================================================
bool ThreadCondition::Wait(int ms)
{
	if (ms == 0)
	{
		ms = INFINITE;
	}

	ResetEvent(mEvent);
	DWORD ret = WaitForSingleObject(mEvent,ms);
	return (ret == WAIT_TIMEOUT);
}


//==============================================================================
void ThreadCondition::Set()
{
	SetEvent(mEvent);
}


//==============================================================================
ThreadMutex::ThreadMutex()
{
	mEvent = CreateMutex(NULL, false, NULL);
}


//==============================================================================
ThreadMutex::~ThreadMutex()
{
}


//==============================================================================
void ThreadMutex::Lock()
{
	WaitForSingleObject(mEvent, 50);
}


//==============================================================================
void ThreadMutex::UnLock()
{
	ReleaseMutex(mEvent);
}

#else

//==============================================================================
ThreadCondition::ThreadCondition()
{
	pthread_mutex_init(&mMutex, NULL);
	pthread_cond_init(&mCond, NULL);
}

//==============================================================================
bool ThreadCondition::Wait(int ms)
{
	while (pthread_mutex_lock(&mMutex))
	{
	}

	int ret = ETIMEDOUT;
	if (ms > 0)
	{
		timespec timeout;
		RealTime outtime = GetRealTime();
		outtime = outtime + ms;
		timeout.tv_sec = outtime.GetSec();
		timeout.tv_nsec = outtime.GetUsec() * 1000;
		while((ret = pthread_cond_timedwait(&mCond, &mMutex, &timeout)) == EINTR )
		{
		}
	}
	else
	{
		ret = pthread_cond_wait(&mCond, &mMutex);
	}

	while (pthread_mutex_unlock(&mMutex))
	{
	}
	return (ret == ETIMEDOUT);
}


//==============================================================================
void ThreadCondition::Set()
{
	while(pthread_mutex_lock(&mMutex))
	{
	}
	while(pthread_cond_signal(&mCond))
	{
	}
	while(pthread_mutex_unlock(&mMutex))
	{
	}
}


//==============================================================================
ThreadMutex::ThreadMutex()
{
	pthread_mutex_init (&mMutex,NULL);
}

//==============================================================================
void ThreadMutex::Lock()
{
	while (pthread_mutex_lock(&mMutex))
	{
	}
}


//==============================================================================
void ThreadMutex::UnLock()
{
	while (pthread_mutex_unlock(&mMutex))
	{
	}
}

#endif


//end of Thread.cpp

