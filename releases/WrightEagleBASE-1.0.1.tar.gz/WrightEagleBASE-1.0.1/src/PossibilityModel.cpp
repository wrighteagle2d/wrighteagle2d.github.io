/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "PossibilityModel.h"
#include "Dasher.h"
#include "ServerParam.h"
#include "PlayerState.h"
#include "Parser.h"

PossibilityModel::PossibilityModel()
{
    Assert(Parser::IsPlayerTypesReady()); // �յ��칹��Ϣ����ܳ�ʼ��

	mCycleDifferFix.SetOutMinMax(1.0, 2.6);
	mCycleDifferFix.Interpolate(3.6, 2.6, 18.0, 1.6, 36.0, 1.0);
	mPassOutsideFix.SetOutMinMax(0.8, 1.0);
	mPassOutsideFix.Interpolate(0.0, 0.8, 4.0, 0.98, 6.0, 1.0);
	mKickMaxRandFix.SetOutMinMax(0.7, 1.01);//max_rand�ķ�Χ��0��0.4
	mKickMaxRandFix.Interpolate(0.0, 1.01, 0.06, 1.0, 0.4, 0.7);
	mPassKickSpeedFix.SetOutMinMax(0.0, 3.0);//��0��15�׵Ĵ���ĳ����ٶȽ�������
	mPassKickSpeedFix.Interpolate(0.0, 0.0, 5.0, 2.0, 15.0, 3.0);
	mPassLowStaminaFix.SetOutMinMax(0.0, 10.0);
	mPassLowStaminaFix.Interpolate(2000.0, 0.0, 3000.0, 3.0, 4000.0, 10.0);
	mDirectPassPoss.SetOutMinMax(0.0, 1.0);
	mDirectPassPoss.Interpolate(8.0, 1.0, 16.0, 0.8, 36.0, 0.0);

    mKickablePoss.SetOutMinMax(0.0, 1.0);
	mKickablePoss.Interpolate(0.0, 0.5, 0.5, 0.26, 1.0, 0.0);
    mDribbleAngleDecay.SetOutMinMax(0.86, 1.0);
    mDribbleAngleDecay.Interpolate(90.0, 0.76, 45.0, 0.9, 0.0, 1.0);
    mFastDribblePossDecay.SetOutMinMax(0.8, 1.0);
    mFastDribblePossDecay.Interpolate(0.0, 1.0, 20.0, 0.96, 36.0, 0.86);
    mFastDribbleLastPoint.SetOutMinMax(0.0, 1.0);
    mFastDribbleLastPoint.Interpolate(5.0, 1.0, 16.0, 0.5, 36.0, 0.0);
    mFastDribbleBreakPoss.SetOutMinMax(0.0, 3.0);
    mFastDribbleBreakPoss.Interpolate(60.0, 0.1, 90.0, 1.0, 180.0, 3.0);
    mTurnDribbleAvoidRate.SetOutMinMax(0.0, 1.0);
    mTurnDribbleAvoidRate.Interpolate(2.6, 1.0, 20.0, 0.5, 60.0, 0.0);

    mOutOfPitchRate.SetOutMinMax(0.0, 1.0);
    mOutOfPitchRate.Interpolate(-1.0, 1.0, 0.0, 0.5, 2.0, 0.0);
    //mOutOfPitchRate.Show("mOutOfPitchRate", -1.0, 2.0);

    for (int i = 0; i < PlayerParam::instance().playerTypes(); ++i)
    {
        const double & speed_max = PlayerParam::instance().HeteroPlayer(i).effectiveSpeedMax();

        mTeammateInfluence[i].SetOutMinMax(0.0, 1.0);
        mTeammateInfluence[i].Interpolate(0.0, 1.0, 8.0 * speed_max, 0.28, 16.0 * speed_max, 0.1);
        mOpponentInfluence[i].SetOutMinMax(-1.0, 0.0);
        mOpponentInfluence[i].Interpolate(0.0, -1.0, 8.0 * speed_max, -0.28, 16.0 * speed_max, -0.1);
    }
}


PossibilityModel::~PossibilityModel() {
}

PossibilityModel & PossibilityModel::instance()
{
	static PossibilityModel possibility_model;
	return possibility_model;
}

/**
* ����Ա��ĳ�����������buf����ɹ���,���������
*
* @param dist ��Ҫ�˶��ľ���
* @param cycle_diff �򵽴�Ŀ�������� - ��Ա����Ŀ��������
* @param cycle_delay ����Աû����������
* @param safe_rate ���cycle_delay���趨���������ʣ���ʾ��cycle_delay�����ӳɹ��ʱ仯�������Խ�󽵵�Խ��
* @return �ɹ���
*/
/**
 * Caculate the possibility from intercept cycles.
 * This function is for dribble or pass.
 * @param dist the distance for ball to move.
 * @param cycle_diff the difference of cycles needed 
 * 	for ball to the target and the player to the target.
 * @param cycle_delay the cycle delay for player.
 * @param save_rate the rate to fix the cycle_delay, which 
 * 	shows the decrease rate of possibility for increase
 * 	of cycle_delay.
 * @return the possibility.
 */
double PossibilityModel::Cycle2Possibility(double dist, double cycle_diff, int cycle_delay, double safe_rate)
{
	double k	= mCycleDifferFix.GetOutput(dist);
	cycle_diff  *= k;
	cycle_delay = (int)ceil(cycle_delay * k);

	double poss     = 0.0;
	double rate     = 0.0;
	double cycle    = 0.0;
	for (int i = -cycle_delay; i <= cycle_delay; ++i) //�����Ѿ�����cycle_delay�ˣ�����CycleNeedToPoint����Ͳ���Ҫ�ٿ���cycle_delay
	{
		cycle = cycle_diff + i;
		rate = (i < 0) ? safe_rate : 1.0;

		if (cycle < -5)
		{
			poss += (0.04 - (1.0 + 1.0 / (cycle + 4.0)) * 0.04) * rate;
		}
		else if (cycle <= 5)
		{
			poss += ((0.16 * cycle - 0.0024 * cycle * cycle * cycle) * 0.92 + 0.5) * rate;
		}
		else
		{
			poss += (0.96 + (1.0 - 1.0 / (cycle - 4.0)) * 0.04) * rate;
		}
	}
	poss /= (cycle_delay * safe_rate + cycle_delay + 1);
	return poss;
}

/**
* ����cycle��������Աp���ܵ���target����ĸ���
*
* \param p
* \param target
* \param cycle
* \param distance ��cycleʱ�������о���,���������,����������˶����
* \return
*/
/**
 * Caculate the possibility for player to run to the target position
 * to kick the ball in a certain number of cycles.
 * @param p the player to caculate.
 * @param target the target position.
 * @param cycle the cycles to caculate.
 * @param distance the ball distance at the final cycle.
 * @param saferete.
 * @retrun the possibility.
 */
double PossibilityModel::CalcPlayerGoToPointPoss(const PlayerState & p, Vector target, double cycle, double distance, double saferate)
{
    double player_cycle = Dasher::instance().CalcPlayerGoToPointCycle(p, target);

	if (p.GetUnum() > 0){ //����
		return Cycle2Possibility(distance, cycle - player_cycle, p.GetPosDelay(), saferate);
	}
	else{
		int cd = p.GetPosDelay();
		if (cd > 2) saferate *= 1.5;
		return Cycle2Possibility(distance, cycle - player_cycle, cd, 1.0/saferate);
	}
}

/**
* �򵥼��㼸�����ں�����ĳλ��ʱ�����ųɹ���
*
* @param ballpt
* @param glpos
* @param precyc
* @return
*/
/**
 * Caculate the position after some certain cycles, for shoot possibility.
 * @param ballpt the ball position.
 * @param glpos the goal position.
 * @param precyc the cycles to predict.
 * @param ourside.
 * @return double the shoot success rate.
 */
double PossibilityModel::CalcShootSuccessRate(const Vector &ballpt, const Vector &glpos, double precyc, bool ourside)
{
	const double MAXDIS = ServerParam::instance().ballRunDistWithMaxSpeed();

	Vector rel_glpt = glpos - ballpt;
	double mid, left, right;
	mid = rel_glpt.Dir();
	Vector rel_target;

	if(ourside){
		right = fabs( mid - (ServerParam::instance().oppRightGoalPost() - ballpt).Dir());
		left =  fabs( mid - (ServerParam::instance().oppLeftGoalPost() - ballpt).Dir());
		if(fabs(right - left) < FLOAT_EPS){
			rel_target = ( ballpt.Y() > 0 ? ServerParam::instance().oppRightGoalPost(): ServerParam::instance().oppLeftGoalPost() ) - ballpt;
		}
		else{
			rel_target = ( right > left ? ServerParam::instance().oppRightGoalPost(): ServerParam::instance().oppLeftGoalPost() ) - ballpt;
		}
	}
	else{
		right = fabs( mid - (ServerParam::instance().ourRightGoalPost() - ballpt).Dir());
		left =  fabs( mid - (ServerParam::instance().ourLeftGoalPost() - ballpt).Dir());
		if(fabs(right - left) < FLOAT_EPS){
			rel_target = ( ballpt.Y() > 0 ? ServerParam::instance().ourRightGoalPost(): ServerParam::instance().ourLeftGoalPost() ) - ballpt;
		}
		else{
			rel_target = ( right > left ? ServerParam::instance().ourRightGoalPost(): ServerParam::instance().ourLeftGoalPost() ) - ballpt;
		}
	}

	double l[2], dis[2];
	double ang = GetAngleDegDiffer(rel_glpt.Dir(), rel_target.Dir());
	l[0] = rel_glpt.Mod() * Cos(ang);
	l[1] = rel_target.Mod();
	if(l[0] >= MAXDIS || l[1] >= MAXDIS) return 0.0;
	dis[0] = rel_glpt.Mod() * Sin(ang) - 1.0;
	dis[1] = rel_glpt.Dist(rel_target) - 1.0;
	int i;
	double c1,c2;
	double poss, maxposs = 0.0;
	for(i = 0 ; i < 2 ; i++){
		c1 = log(1.0 - l[i]/MAXDIS) / ServerParam::instance().logBallDecay();
		c2 = dis[i];
		poss = Cycle2Possibility(l[i], c1 - c2 - 0.5 + precyc);
		maxposs = Max(poss, maxposs);
	}
	return 1.0 - maxposs;
}

/**
 * Caculate the direct pass success rate.
 * @param ballpt the ball position.
 * @param tmpt the teammate position.
 * @param oppt the opponent position.
 * @param cyclefix.
 * @return the success rate.
 */
double PossibilityModel::CalcDirectPassSuccessRate(const Vector & ballpt, const Vector & tmpt, const Vector & oppt, double cyclefix)
{
	const double MAXDIS = (ServerParam::instance().ballSpeedMax() - 0.3) / (1 - ServerParam::instance().ballDecay());
	Vector rel_tm = tmpt - ballpt;
	Vector rel_op = oppt - ballpt;
	double l[2], dis[2];
	double ang = GetAngleDegDiffer(rel_op.Dir(), rel_tm.Dir());
	l[0] = rel_op.Mod() * Cos(ang);
	l[1] = rel_tm.Mod();
	if (l[0] >= MAXDIS || l[1] >= MAXDIS)
    {
		return 0.0;
    }

    dis[0] = rel_op.Mod() * Sin(ang);
	dis[1] = tmpt.Dist(oppt);
	int i;
	double c1, c2;
	double poss = 0.0;
	for (i = 0; i < 2; i++)
	{
		c1 = log(1.0 - l[i] / MAXDIS) / log(ServerParam::instance().ballDecay());
		c2 = dis[i] + 1.5 - cyclefix;
		poss = Max(poss, Cycle2Possibility(15, c1 - c2));
	}
	return 1.0 - poss;
}

