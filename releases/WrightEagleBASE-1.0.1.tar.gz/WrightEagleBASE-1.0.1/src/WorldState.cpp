/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include <cstdlib>
#include "WorldState.h"
#include "ActionEffector.h"
#include "Formation.h"
#include "Observer.h"
#include "Logger.h"
#include <fstream>

const double WorldStateUpdater::KICKABLE_BUFFER = 0.04;
const double WorldStateUpdater::CATCHABLE_BUFFER = 0.04;

/**
 * Construct Function
 */
WorldState::WorldState(HistoryState* history_state):
	mpHistory( history_state),
	mCurrentTime( Time(-3, 0)),
	mPlayMode( PM_No_Mode),
	mPlayModeTime( Time(-3,0)),
	mIsBallDropped( false),
	mTeammateGoalieUnum( 0),
	mOpponentGoalieUnum( 0),
	mSetPlayHearTime(-1 , 0),
	mSetPlayStaminaCycle(0),
	mSetPlayCapacityCycle(0),
	mTeammateScore( 0),
	mOpponentScore( 0),
	mIsCycleStopped( false)
{
	//Ϊ������Ա�������
	//distribute numbers among players
	for ( Unum i = 1; i <= TEAMSIZE; i++) {
		mTeammate[i].UpdateUnum(i);
		mOpponent[i].UpdateUnum(-i);

		mPlayerList.push_back(& mTeammate[i]);
		mPlayerList.push_back(& mOpponent[i]);
	}
}

/**
 * Get History WorldState
 * @param i 0 is the current one
 * @return
 */
WorldState * WorldState::GetHistory(int i) const
{
	Assert(i <=	HISTORYSIZE && i >= 0);

	if (i == 0)
	{
		return const_cast<WorldState *>(this);
	}

	return (mpHistory->GetHistory(i));
}

/**
 * Get history world time
 * @param cycle how long the history away from now
 * @return
 */
Time WorldState::GetTimeBeforeCurrent(int cycle) const
{
	Assert(cycle <= HISTORYSIZE && cycle >= 1);

	return mpHistory->GetHistory(cycle)->mCurrentTime;
}

void WorldState::UpdateFromObserver(Observer *observer)
{
	WorldStateUpdater(observer, this).Run();
}

/**
 * Create a world state seen by opponent
 * @param world_state pointer point to the created world state
 */
void WorldState::GetReverseFrom(WorldState *world_state)
{
	mCurrentTime = world_state->CurrentTime();
	mPlayMode    = world_state->GetPlayMode();
	mIsCycleStopped = world_state->mIsCycleStopped;
	mPlayModeTime = world_state->mPlayModeTime;

	mTeammateGoalieUnum = world_state->mOpponentGoalieUnum;
	mOpponentGoalieUnum = world_state->mTeammateGoalieUnum;

	mTeammateScore = world_state->mOpponentScore;
	mOpponentScore = world_state->mTeammateScore;

	Ball().GetReverseFrom(world_state->Ball());

	for (Unum i = 1; i <= TEAMSIZE; ++i){
		Opponent(i).GetReverseFrom(world_state->Teammate(i));
		Teammate(i).GetReverseFrom(world_state->Opponent(i));
	}
}

BallState & WorldStateUpdater::Ball()
{
	return mpWorldState->mBall;
}

PlayerState & WorldStateUpdater::Teammate(Unum i)
{
	return mpWorldState->Teammate(i);
}

PlayerState & WorldStateUpdater::Opponent(Unum i)
{
	return mpWorldState->Opponent(i);
}

PlayerState & WorldStateUpdater::SelfState()
{
	return Teammate(mSelfUnum);
}

const BallState & WorldStateUpdater::GetBall()
{
	return mpWorldState->mBall;
}

const PlayerState & WorldStateUpdater::GetTeammate(Unum i)
{
	return mpWorldState->Teammate(i);
}

const PlayerState & WorldStateUpdater::GetOpponent(Unum i)
{
	return mpWorldState->Opponent(i);
}

const PlayerState & WorldStateUpdater::GetSelf()
{
	return Teammate(mSelfUnum);
}

AngleDeg WorldStateUpdater::GetNeckGlobalDirFromSightDelay(int sight_delay)
{
	Assert(sight_delay >= 0 && sight_delay <= HISTORYSIZE);

	if (sight_delay == 0)
	{
		return GetSelf().GetNeckGlobalDir();
	}
	else
	{
		double neck_dir = mpWorldState->GetHistory(sight_delay)->GetTeammate(mSelfUnum).GetNeckDir();
		return GetSelf().GetBodyDir() + neck_dir;
	}
}

Vector WorldStateUpdater::GetSelfVelFromSightDelay(int sight_delay)
{
	Assert(sight_delay >= 0 && sight_delay <= HISTORYSIZE);

	if (sight_delay == 0)
	{
		return GetSelf().GetVel();
	}
	else
	{
		const PlayerState& player = mpWorldState->GetHistory(sight_delay)->GetTeammate(mSelfUnum);

		return player.GetVel().Rotate(-player.GetNeckGlobalDir()).Rotate(GetNeckGlobalDirFromSightDelay(sight_delay));
	}
}


Unum WorldStateUpdater::GetSelfUnum()
{
	return mSelfUnum;
}

char WorldStateUpdater::GetSelfSide()
{
	return mSelfSide;
}


/**
 * Update WorldState
 */
void WorldStateUpdater::Run()
{
	UpdateWorldState();
}

//==============================================================================
void WorldStateUpdater::UpdateActionInfo()
{
	const Vector & ball_pos = GetBall().GetPos();
	Vector ball_2_player = Vector(0.0, 0.0);
	double kickable_area = 0.0;
	double kick_rate = 0.0;
	double tackle_prob = 0.0;
	AngleDeg max_turn_angle = 0.0;

	for (int i = 1; i <= TEAMSIZE; ++i)
	{
        //TEAMMATE==============================================================
		if (mpWorldState->mTeammate[i].IsAlive() == true)
		{
			ball_2_player = (ball_pos - mpWorldState->mTeammate[i].GetPos()).Rotate(-mpWorldState->mTeammate[i].GetBodyDir());

			//BallKickable
            kickable_area = mpWorldState->mTeammate[i].GetKickableArea();
			if (ball_2_player.Mod() < kickable_area - KICKABLE_BUFFER &&
                !mpWorldState->mTeammate[i].IsTackling())
			{
				mpWorldState->mTeammate[i].UpdateKickable(true);

				kick_rate = GetKickRate(ball_2_player, mpWorldState->mTeammate[i].GetPlayerType());
				mpWorldState->mTeammate[i].UpdateKickRate(kick_rate);
			}
			else
			{
				mpWorldState->mTeammate[i].UpdateKickable(false);
				mpWorldState->mTeammate[i].UpdateKickRate(0.0);
			}

			//BallCatchable
			if (i == mpWorldState->GetTeammateGoalieUnum())
			{
                if ((mpWorldState->GetPlayMode() == PM_Play_On || mpWorldState->GetPlayMode() == PM_Opp_Penalty_Taken) &&
                    ServerParam::instance().ourPenaltyArea().IsWithin(ball_pos) &&
                    ServerParam::instance().ourPenaltyArea().IsWithin(mpWorldState->mTeammate[i].GetPos()) &&
                    ball_2_player.Mod() < ServerParam::instance().maxCatchableArea()  - CATCHABLE_BUFFER)
				{
					mpWorldState->mTeammate[i].UpdateBallCatchable(true);
				}
				else
				{
					mpWorldState->mTeammate[i].UpdateBallCatchable(false);
				}
			}

			//TackleProb
			tackle_prob = ComputeTackleProb(i);
			mpWorldState->mTeammate[i].UpdateTackleProb(tackle_prob);

			//MaxTurnAngle
			max_turn_angle = GetMaxTurnAngle(mpWorldState->mTeammate[i].GetPlayerType(), mpWorldState->mTeammate[i].GetVel().Mod());
			mpWorldState->mTeammate[i].UpdateMaxTurnAngle(max_turn_angle);
		}

        //OPPONENT==============================================================
		if (mpWorldState->mOpponent[i].IsAlive() == true)
		{
			ball_2_player = ball_pos - mpWorldState->mOpponent[i].GetPos();
			ball_2_player = ball_2_player.Rotate(-mpWorldState->mOpponent[i].GetBodyDir());

			//BallKickable
            kickable_area = mpWorldState->mOpponent[i].GetKickableArea();
			if (ball_2_player.Mod() < kickable_area + KICKABLE_BUFFER && // ���Ƕ����Ƿ���߽���һ�㣬��һ��buffer��WE2008��strategy���õ�buffer��0.2�������е��
                !mpWorldState->mOpponent[i].IsTackling())
			{
				mpWorldState->mOpponent[i].UpdateKickable(true);

				kick_rate = GetKickRate(ball_2_player, mpWorldState->mOpponent[i].GetPlayerType());
				mpWorldState->mOpponent[i].UpdateKickRate(kick_rate);
			}
			else
			{
				mpWorldState->mOpponent[i].UpdateKickable(false);
				mpWorldState->mOpponent[i].UpdateKickRate(0.0);
			}

			//BallCatchable
			if (i == mpWorldState->GetOpponentGoalieUnum())
			{
				if ((mpWorldState->GetPlayMode() == PM_Play_On || mpWorldState->GetPlayMode() == PM_Opp_Penalty_Taken) &&
                    ServerParam::instance().oppPenaltyArea().IsWithin(ball_pos) &&
                    ServerParam::instance().oppPenaltyArea().IsWithin(mpWorldState->mOpponent[i].GetPos()) &&
                    ball_2_player.Mod() < ServerParam::instance().maxCatchableArea()  - CATCHABLE_BUFFER)
				{
					mpWorldState->mOpponent[i].UpdateBallCatchable(true);
				}
				else
				{
					mpWorldState->mOpponent[i].UpdateBallCatchable(false);
				}
			}

			//TackleProb
			tackle_prob = ComputeTackleProb(-i);
			mpWorldState->mOpponent[i].UpdateTackleProb(tackle_prob);

			//MaxTurnAngle
			max_turn_angle = GetMaxTurnAngle(mpWorldState->mOpponent[i].GetPlayerType(), mpWorldState->mOpponent[i].GetVel().Mod());
			mpWorldState->mOpponent[i].UpdateMaxTurnAngle(max_turn_angle);
		}
	}
}

/**
 * ��observer�����������״̬
 */
/**
 * Update from observer
 */
void WorldStateUpdater::UpdateWorldState()
{
	/**���³��ϵ�״̬*/
	/**Update Field Information*/
	UpdateFieldInfo();

	if (PlayerParam::instance().isCoach()){
		if (mpObserver->OurSide() == 'l'){ //server����������Ϣ�������Լ�һ��
			Ball().UpdatePos(mpObserver->Ball_Coach().GetPos(), 0, 1.0);
			Ball().UpdateVel(mpObserver->Ball_Coach().GetVel(), 0, 1.0);

			for (int i = 1;i <= TEAMSIZE;i++)
			{
				Teammate(i).SetIsAlive(mpObserver->Teammate_Coach(i).IsAlive());
				Teammate(i).UpdatePlayerType(mpObserver->GetTeammateType(i));
				Teammate(i).UpdatePos(mpObserver->Teammate_Coach(i).GetPos(), 0, 1.0);
				Teammate(i).UpdateVel(mpObserver->Teammate_Coach(i).GetVel(), 0, 1.0);
				Teammate(i).UpdateBodyDir(mpObserver->Teammate_Coach(i).GetBodyDir(), 0, 1.0);
				Teammate(i).UpdateNeckDir(mpObserver->Teammate_Coach(i).GetNeckDir(), 0, 1.0);
				//TODO: arm, tackle �ȣ���ʱ���� -- TODO

				Opponent(i).SetIsAlive(mpObserver->Opponent_Coach(i).IsAlive());
				Opponent(i).UpdatePlayerType(mpObserver->GetOpponentType(i));
				Opponent(i).UpdatePos(mpObserver->Opponent_Coach(i).GetPos(), 0, 1.0);
				Opponent(i).UpdateVel(mpObserver->Opponent_Coach(i).GetVel(), 0, 1.0);
				Opponent(i).UpdateBodyDir(mpObserver->Opponent_Coach(i).GetBodyDir(), 0, 1.0);
				Opponent(i).UpdateNeckDir(mpObserver->Opponent_Coach(i).GetNeckDir(), 0, 1.0);
			}
		}
		else {	//server����������Ϣ�������Լ��෴����Ϊ���������Ǽ����Լ������
				//my side is always be on the left
			Ball().UpdatePos(mpObserver->Ball_Coach().GetPos() * -1.0, 0, 1.0);
			Ball().UpdateVel(mpObserver->Ball_Coach().GetVel() * -1.0, 0, 1.0);

			for (int i = 1;i <= TEAMSIZE;i++)
			{
				Teammate(i).SetIsAlive(mpObserver->Teammate_Coach(i).IsAlive());
				Teammate(i).UpdatePlayerType(mpObserver->GetTeammateType(i));
				Teammate(i).UpdatePos(mpObserver->Teammate_Coach(i).GetPos() * -1.0, 0, 1.0);
				Teammate(i).UpdateVel(mpObserver->Teammate_Coach(i).GetVel() * -1.0, 0, 1.0);
				Teammate(i).UpdateBodyDir(GetNormalizeAngleDeg(mpObserver->Teammate_Coach(i).GetBodyDir() + 180.0), 0, 1.0);
				Teammate(i).UpdateNeckDir(GetNormalizeAngleDeg(mpObserver->Teammate_Coach(i).GetNeckDir() + 180.0), 0, 1.0);
				//TODO: arm, tackle �ȣ���ʱ����

				Opponent(i).SetIsAlive(mpObserver->Opponent_Coach(i).IsAlive());
				Opponent(i).UpdatePlayerType(mpObserver->GetOpponentType(i));
				Opponent(i).UpdatePos(mpObserver->Opponent_Coach(i).GetPos() * -1.0, 0, 1.0);
				Opponent(i).UpdateVel(mpObserver->Opponent_Coach(i).GetVel() * -1.0, 0, 1.0);
				Opponent(i).UpdateBodyDir(GetNormalizeAngleDeg(mpObserver->Opponent_Coach(i).GetBodyDir() + 180.0), 0, 1.0);
				Opponent(i).UpdateNeckDir(GetNormalizeAngleDeg(mpObserver->Opponent_Coach(i).GetNeckDir() + 180.0), 0, 1.0);
			}
		}

		UpdateActionInfo();
	}
	else
	{
		//�������е�delay delay����1 conf����1
		//Update delay
		AutoDelay(1);

		//���������˵�player_type��is_goalie
		//udpate players type
		for (int i = 1;i <= TEAMSIZE;i++)
		{
			Teammate(i).UpdatePlayerType(mpObserver->GetTeammateType(i));
//			Opponent(i).UpdatePlayerType(mpObserver->GetOpponentType(i)); // ��UpdateFromAudio�и���,�ڴ˲�����

			Teammate(i).UpdateIsGoalie(false);
			Opponent(i).UpdateIsGoalie(false);
		}

		if (mpWorldState->GetTeammateGoalieUnum() > 0) Teammate(mpWorldState->GetTeammateGoalieUnum()).UpdateIsGoalie(true);
		if (mpWorldState->GetOpponentGoalieUnum() > 0) Opponent(mpWorldState->GetOpponentGoalieUnum()).UpdateIsGoalie(true);
//	int id =	TimeTest::instance().Begin("before");
		//�����Լ���������Ϣ
		//Update hear information
		UpdateFromAudio();

		//Ԥ��һ����
		//Estimate one cycle
		EstimateWorld();

		//�Ӵ����������Եĵײ����
		//Update from hear information
		UpdateFromHearInfo();

		if (mpObserver->IsNewSight())
		{
			UpdateSightDelay();
		}
/*	TimeTest::instance().End(id);
	id = TimeTest::instance().Begin("test");
	TimeTest::instance().End(id);
	id = TimeTest::instance().Begin("middle");*/
		//�����Լ�����Ϣ
		//Update self information
		UpdateSelfInfo();

		if (mpObserver->IsNewSight())
		{
			//�������пɼ��Ķ�Ա����Ϣ
			UpdateKnownPlayers();

			//��������δ֪�������Ա
			UpdateUnknownPlayers();

			//���������Ϣ
			UpdateBallInfo();

			EstimateToNow();
		}
/*	TimeTest::instance().End(id);

	id = TimeTest::instance().Begin("end");*/
		/**������ײ*/
		UpdateInfoWhenCollided();

		//������������Ա�����Ŷ� ������Ա������
		//Update confidence of players
		EvaluateConf();

		//����playmode����ȷ����λ��
		//Update information from play mode(position)
		UpdateInfoFromPlayMode();

		//����Action����Ϣ
		UpdateActionInfo();

		MaintainPlayerStamina();

		MaintainConsistency();
//	TimeTest::instance().End(id);
//
	}
}

void WorldStateUpdater::UpdateSightDelay()
{
	mSightDelay = mpObserver->CurrentTime() - mpObserver->LatestSightTime();
	mBallConf   = ComputeConf(PlayerParam::instance().ballConfDecay() , mSightDelay);
	mPlayerConf = ComputeConf(PlayerParam::instance().playerConfDecay() , mSightDelay);
}

void WorldStateUpdater::UpdateFromHearInfo()
{
	const PassInfo& pass_info = mpWorldState->GetHearPassInfo();
	const TacticsInfo& tac_info = mpWorldState->GetTacticsInfo();

	//TODO:BT_relax ������ʱδ��
	//TODO:nothing to do with BT_relax
	if (tac_info.mType != BT_Relax && tac_info.mRecvTime == mpObserver->CurrentTime())
	{
		Unum sender = mpObserver->Audio().GetHearUnum(); 
		if (Ball().GetGuessedTimes() > 0 ||Ball().GetPosConf() < PlayerParam::instance().minValidConf()  - FLOAT_EPS || (Teammate(sender).IsAlive() && Teammate(sender).GetPos().Dist2(Ball().GetPos()) < SelfState().GetPos().Dist2(Ball().GetPos()))) 
		{
			if (tac_info.mBallPosValid)
			{
				//1Ϊ����ֵ
				//1 is a experienced value
				double eps = 1 + PlayerParam::instance().GetEpsInSight((tac_info.mBallPos - Teammate(mpObserver->Audio().GetHearUnum()).GetPos()).Mod());
				Ball().UpdatePosEps(eps);
				Ball().UpdatePos(tac_info.mBallPos , 1 , PlayerParam::instance().ballConfDecay() - FLOAT_EPS);

				mIsHearBallPos = true;
			}

			if (tac_info.mBallSpeedValid)
			{
				Ball().UpdateVel(tac_info.mBallSpeed , 1 , PlayerParam::instance().ballConfDecay() - FLOAT_EPS);
				//��ʱ��0.32 ��Ϊһ��Ϊ������
				//0.32 experienced value
				Ball().UpdateVelEps(0.32);

				mIsHearBallVel = true;
			}
		}

		if (tac_info.mSelfPosValid)
		{
			Teammate(mpObserver->Audio().GetHearUnum()).UpdatePosEps(0.1);
                Teammate(mpObserver->Audio().GetHearUnum()).UpdatePos(tac_info.mSelfPos , 1 , PlayerParam::instance().playerConfDecay() - FLOAT_EPS);
            }
		}
	else if (tac_info.mType == BT_Relax && tac_info.mRecvTime == mpObserver->CurrentTime())
	{
		Teammate(mpObserver->Audio().GetHearUnum()).UpdateTired(true);
	}

	//TODO :�Ӿ��ʹ������������Ǹ�����ȷ�д�����
	if (pass_info.mRecvTime == mpObserver->CurrentTime())
	{
		if (!pass_info.mIsMultiPass)
		{
			//����1��Ϊ�������Ҫ ,����Ϣ���������
			//hear information is better for pass
			double eps = 0.3 + PlayerParam::instance().GetEpsInSight((pass_info.mGetPoint - Teammate(mpObserver->Audio().GetHearUnum()).GetPos()).Mod());
			Ball().UpdatePosEps(eps);
			Ball().UpdatePos(pass_info.mGetPoint , 1 , PlayerParam::instance().ballConfDecay() - FLOAT_EPS);
			Ball().UpdateVel(pass_info.mBallSpeed ,1 , PlayerParam::instance().ballConfDecay() - FLOAT_EPS);

			//��������������һ���ǽ������� , ��0.2��Ϊ���Ϻ���
			Ball().UpdateVelEps(0.32);

			mIsHearBallVel = true;
			mIsHearBallPos = true;
		}
	}
}

double WorldStateUpdater::ComputeConf(double decay , int cycle)
{
	if (cycle <= 0)
	{
		return 1;
	}

	double sum = 1;
	for (int i = 0;i < cycle;i++)
	{
		sum *= decay;
	}
	return sum;
}

void WorldStateUpdater::UpdateFromAudio()
{
    // update by our coach say
    if (mpObserver->Audio().IsOurCoachSayValid())
    {
        mpObserver->ResetOurCoachSayValid();	// �ָ�
												// recover

        if (mpObserver->Audio().GetOurCoachSayType() == AudioObserver::OCST_ChangeFormation)
        {
            // �������ڽ���ʱ�Ѿ�������
        }
        else if (mpObserver->Audio().GetOurCoachSayType() == AudioObserver::OCST_OpponentFormation)
        {
            // ���������ڽ���ʱ�Ѿ�������
        }
        else if (mpObserver->Audio().GetOurCoachSayType() == AudioObserver::OCST_SetplayCycle)
        {
			mpWorldState->mSetPlayHearTime  = mpObserver->Audio().GetHearSetplayTime();
			mpWorldState->mSetPlayStaminaCycle = mpObserver->Audio().GetSetplayStaminaCycle();
			mpWorldState->mSetPlayCapacityCycle = mpObserver->Audio().GetSetplayCapacityCycle();
        }
        else if (mpObserver->Audio().GetOurCoachSayType() == AudioObserver::OCST_PlayerType)
        {
            for (int i = 1; i <= TEAMSIZE; ++i)
            {
                if (mpObserver->Audio().GetOpponentType(i) > 0)
                {
                    Opponent(i).UpdatePlayerType(mpObserver->Audio().GetOpponentType(i));
                }
            }
        }
        else
        {
            PRINT_ERROR("error our coach say type");
        }
    }

    // update by teammate say
    if (mpObserver->Audio().IsTeammateSayValid())
	{
        mpObserver->ResetTeammateSayValid();

		int type = mpObserver->Audio().GetHearInfoType();
		Unum sender = mpObserver->Audio().GetHearUnum();

		//�������������Ϣ
		//update ball information by hear
		int cmp = type &  AudioObserver::HearInfo_Ball;
		if (cmp != 0)
		{
			if (Ball().GetGuessedTimes() > 0 ||Ball().GetPosConf() < PlayerParam::instance().minValidConf()  - FLOAT_EPS || (Teammate(sender).IsAlive() && Teammate(sender).GetPos().Dist2(Ball().GetPos()) < SelfState().GetPos().Dist2(Ball().GetPos()))) {
				if (mpObserver->Audio().GetBallPos().time() == mpObserver->CurrentTime())
				{
					Ball().UpdatePos(mpObserver->Audio().GetBallPos().value(), 1, PlayerParam::instance().ballConfDecay() - FLOAT_EPS);
					Ball().UpdateGuessedTimes(0);
					//0.3Ϊ����ֵ 0.75 * 4
					//experienced value 0.3
					double eps = 1.5 + PlayerParam::instance().GetEpsInSight((Ball().GetPos() - Teammate(sender).GetPos()).Mod());
					Ball().UpdatePosEps(eps);
				}

				if (mpObserver->Audio().GetBallVel().time() == mpObserver->CurrentTime())
				{
					Ball().UpdateVel(mpObserver->Audio().GetBallVel().value(), 1, PlayerParam::instance().ballConfDecay() - FLOAT_EPS);

					//ͳ�Ƶõ��������ٶ�һ��������1
					//by stat.
					Ball().UpdateVelEps(3);
				}
			}
		}

		//�����������ѵ���Ϣ
		//update teammates information by hear
		cmp = type & AudioObserver::HearInfo_Teammate;
		if (cmp != 0)
		{
			int teammate_count = mpObserver->Audio().GetTeammateCount();
			for (int i = 0;i < teammate_count;i++)
			{
				if (mpObserver->Audio().GetTeammate(i).time() == mpObserver->CurrentTime())
				{
					int unum = mpObserver->Audio().GetTeammate(i).value().mUnum;
					if (Teammate(unum).GetGuessedTimes() > 0 || Teammate(unum).GetPosConf() < PlayerParam::instance().playerConfDecay()  - FLOAT_EPS || (Teammate(sender).IsAlive() && Teammate(sender).GetPos().Dist2(Teammate(unum).GetPos()) < SelfState().GetPos().Dist2(Teammate(unum).GetPos()))) {
						Teammate(unum).UpdateGuessedTimes(0);
						Teammate(unum).SetIsAlive(true);
						const Vector & pos = mpObserver->Audio().GetTeammate(i).value().mPos;

						Teammate(unum).UpdatePos(pos, 1, PlayerParam::instance().playerConfDecay() - FLOAT_EPS);

						double eps = 0.1 + PlayerParam::instance().GetEpsInSight( (pos - Teammate(sender).GetPos()).Mod());
						Teammate(unum).UpdatePosEps(eps);
					}
				}
			}
		}

		//���������Ķ��ֵ���Ϣ
		//update opponents information by hear
		cmp = type & AudioObserver::HearInfo_Opponent;
		if (cmp != 0)
		{
			int Opponent_count = mpObserver->Audio().GetOpponentCount();
			for (int i = 0;i < Opponent_count;i++)
			{
				if (mpObserver->Audio().GetOpponent(i).time() == mpObserver->CurrentTime())
				{
					int unum = mpObserver->Audio().GetOpponent(i).value().mUnum;
					if (Opponent(unum).GetGuessedTimes() > 0 || Opponent(unum).GetPosConf() < PlayerParam::instance().playerConfDecay() - FLOAT_EPS || (Teammate(sender).IsAlive() && Teammate(sender).GetPos().Dist2(Opponent(unum).GetPos()) < SelfState().GetPos().Dist2(Opponent(unum).GetPos())))
					{
						Opponent(unum).UpdateGuessedTimes(0);
						Opponent(unum).SetIsAlive(true);
						const Vector & pos = mpObserver->Audio().GetOpponent(i).value().mPos;

						Opponent(unum).UpdatePos(pos, 1, PlayerParam::instance().playerConfDecay() - FLOAT_EPS);
						double eps = 0.1 + PlayerParam::instance().GetEpsInSight( (pos - Teammate(sender).GetPos()).Mod());
						Opponent(unum).UpdatePosEps(eps);
					}
				}
			}
		}
	}
}

void WorldStateUpdater::UpdateFieldInfo()
{
	mpWorldState->mCurrentTime = mpObserver->CurrentTime();
	mpWorldState->mIsBallDropped = mpObserver->IsBallDropped();
	mpWorldState->mKickOffMode  = mpObserver->GetKickOffMode();
	if (mpWorldState->mPlayMode != mpObserver->GetPlayMode())
    {
		mpWorldState->mLastPlayMode = mpWorldState->mPlayMode;
        mpWorldState->mPlayMode = mpObserver->GetPlayMode();
        mpWorldState->mPlayModeTime = mpObserver->CurrentTime();
    }

    OpponentFormation::instance().SetGoalieUnum(mpObserver->OppGoalieUnum()); // ����OpponentFormation������Ա����
    mpWorldState->mTeammateGoalieUnum = PlayerParam::instance().ourGoalieUnum();
	mpWorldState->mOpponentGoalieUnum = mpObserver->OppGoalieUnum();
//	mpWorldState->mSetPlayHearTime  = mpObserver->Audio().GetHearSetplayTime();
//	mpWorldState->mSetPlayStaminaCycle = mpObserver->Audio().GetSetplayStaminaCycle();
//	mpWorldState->mSetPlayCapacityCycle = mpObserver->Audio().GetSetplayCapacityCycle();
    mpWorldState->mTeammateScore = mpObserver->OurScore();
	mpWorldState->mOpponentScore = mpObserver->OppScore();

	if (mpWorldState->GetHistory(1) && mpWorldState->GetHistory(1)->CurrentTime().T() == mpWorldState->mCurrentTime.T())
	{
		mpWorldState->mIsCycleStopped = true;
	}
	else
	{
		mpWorldState->mIsCycleStopped = false;
	}
}

namespace
{
	double calcEps(double a, double b , double angle_deg)
	{
		return Sqrt(a * a + b * b - 2 * a * b * Cos(angle_deg));
	}
}



void WorldStateUpdater::UpdateSelfInfo()
{

	SelfState().SetIsAlive(true);
    SelfState().UpdateIsSensed(true);	// �����������Լ�
										// self

	//=============================�����Լ���sense========================
	UpdateSelfSense();
/*
	//==========================according to speed of this cycle estimate position of this cycle=======================
	if (mpObserver->GetPlayerMoveTime() != mpObserver->CurrentTime())
	{
		Vector vel = SelfState().GetVel();

		if (mpObserver->Sense().IsCollideWithBall() || mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithPost())
		{
			//when collided ,velocity should be changed to normal;
			vel /= -0.1;
		}

		Vector last_pos = mpWorldState->GetHistory(1)->Teammate(GetSelfUnum()).GetPos();
		SelfState().UpdatePos(last_pos + vel / ServerParam::instance().ballDecay() , SelfState().GetPosDelay() ,SelfState().GetPosConf());
	}
*/

	//����Ϊֹ�Լ�������ǶȺͲ��ӽǶȸ��¶���
	//���㹫ʽ��USTC_Material ������
	//playerVel = polar2vector(speedValue, neckGlobalAngle + speedAngle)
	Vector vec = Polar2Vector(mpObserver->Sense().GetSpeed(), mpObserver->Sense().GetSpeedDir() + GetSelf().GetNeckGlobalDir());
	SelfState().UpdateVel(vec);

	//���Լ����º���ٶ�Ԥ���Լ���λ��,��֮ǰ��Ԥ��׼.��08
	//update self position with the velocity updated, it's accurater than before
	if (!mpObserver->Sense().IsCollideWithBall() && !mpObserver->Sense().IsCollideWithPlayer() && mpObserver->GetPlayerMoveTime() != mpObserver->CurrentTime())
	{
		const Vector & pre_pos = mpWorldState->GetHistory(1)->GetTeammate(mSelfUnum).GetPos();
		double conf = mpWorldState->GetHistory(1)->GetTeammate(mSelfUnum).GetPosConf();

		if (conf > PlayerParam::instance().minValidConf())
		{

			Vector pos = pre_pos + vec / SelfState().GetPlayerDecay();
			SelfState().UpdatePos(pos , SelfState().GetPosDelay() , SelfState().GetPosConf());
		}
	}


	//�����Լ�λ����� ,Ŀǰ���������server����,���˲�֪.Ŀǰ���������dropball�Լ�playmodeģʽ�ı��ǽ�λ��eps�ӵ�����
	//estimate error of self position
	if (mpWorldState->GetPlayModeTime() == mpWorldState->CurrentTime() || mpWorldState->IsBallDropped())
	{
		SelfState().UpdatePosEps(10000);
	}

	//===============================�����Լ����Ӿ�======================
	//=============================Update Self sight===================
	if (mpObserver->IsNewSight())
	{
		//�����Լ���ͷ��������Ƕ�
		double neck_globe_angle = 0.0;


		if (ComputeSelfDir(neck_globe_angle))
		{
			//���㹫ʽ��USTC_Material ������
			//bodyGlobalAngle = neckGlobalAngle �C head_angle
			if (mSightDelay <= HISTORYSIZE)
			{
				const PlayerState& player = mpWorldState->GetHistory(mSightDelay)->GetTeammate(mSelfUnum);
				SelfState().UpdateBodyDir(neck_globe_angle - player.GetNeckDir() , mSightDelay , mPlayerConf);
			}
			else
			{
				PRINT_ERROR("mSightDelay too big!!" << mSightDelay);
				SelfState().UpdateBodyDir(neck_globe_angle - SelfState().GetNeckDir() , mSightDelay , mPlayerConf);
			}
		}

		if (mSightDelay == 0)
		{
			//�����Լ����ٶ� ���ҽ����������Ӿ��ӳ�ʱ.
			//fix speed, when no sight delay
			Vector vec = Polar2Vector(mpObserver->Sense().GetSpeed(), mpObserver->Sense().GetSpeedDir() + GetSelf().GetNeckGlobalDir());
			SelfState().UpdateVel(vec);
		}

		//�����Լ���λ��
		//update self position
		Vector pos;
		double eps = 0;
		if (ComputeSelfPos(pos , eps))
		{
			if (eps > SelfState().GetPosEps())
			{
				//����ͳ��ֵ,x,y����������ֵ����1���������� ���ȡ1
				// 1 determined by Stat.
				if (pos.Dist2(SelfState().GetPos()) < 1)
				{
					pos = SelfState().GetPos();
					eps = SelfState().GetPosEps();
				}

			}
			else if (eps == SelfState().GetPosEps())
			{
				if (pos.Dist2(SelfState().GetPos()) < 1)
				{
					pos = (pos + SelfState().GetPos()) / 2;
				}
			}

			SelfState().UpdatePos(pos, mSightDelay, mPlayerConf);
			SelfState().UpdatePosEps(eps);
		}
	}

}

void WorldStateUpdater::UpdateSelfSense()
{
	SelfState().UpdateNeckDir(PlayerParam::instance().ConvertAngle(mpObserver->Sense().GetNeckDir()));	//�����ʹû���Ӿ�ҲҪ����
																										//update even if no sight arrived

	SelfState().UpdateStamina(mpObserver->Sense().GetStamina());	//��������
																	//update stamina
	SelfState().UpdateEffort(mpObserver->Sense().GetEffort());		//����effort
																	//update effort
	SelfState().UpdateCapacity(mpObserver->Sense().GetCapacity());	//���¾���������
																	//update stamina capacity

	//update recovery
	double buff = Min(SelfState().GetRecovery() * SelfState().GetStaminaIncMax() , SelfState().GetCapacity());
	buff = ((int)(buff * 100)) / 100.0; //��������Ϊ0.01 ̫��ȷ�˻�Ӱ�����
										//precision should be set 0.01
	if (mpObserver->CurrentTime().T() > 0 && mpObserver->Sense().GetStamina() - buff  < ServerParam::instance().staminaMax() * ServerParam::instance().recoverDecThr())
	{
		double recovery = SelfState().GetRecovery() - ServerParam::instance().recoverDec();
		if (recovery < ServerParam::instance().recoverMin())
		{
			recovery = ServerParam::instance().recoverMin();
		}

		if (mpObserver->CurrentTime().T() % ServerParam::instance().halfTime() == 0 && ServerParam::instance().nrNormalHalfs() >= 0 && mpObserver->CurrentTime().T() < ServerParam::instance().halfTime() * ServerParam::instance().nrNormalHalfs())
		{
			recovery = 1.0;
		}

		SelfState().UpdateRecovery(recovery);
	}

	//�����Լ���tackleban
	//update self tackle ban
	SelfState().UpdateTackleBan(mpObserver->Sense().GetTackleExpires());

	//�����Լ���catchban ��ʱû��
	//update self catchban(void now)

	//�����Լ���armpoint
	//update self armpoint
	if (mpObserver->Sense().GetArmMovableBan() > 0)
	{
		SelfState().UpdateArmPoint(mpObserver->Sense().GetArmTargetDir(),0,1,mpObserver->Sense().GetArmTargetDist(),mpObserver->Sense().GetArmMovableBan(),mpObserver->Sense().GetArmExpires());
	}
	else
	{
		SelfState().UpdateArmPoint(mpObserver->Sense().GetArmTargetDir(),SelfState().GetArmPointDelay(),SelfState().GetArmPointConf(),mpObserver->Sense().GetArmTargetDist(),mpObserver->Sense().GetArmMovableBan(),mpObserver->Sense().GetArmExpires());
	}


	//�����Լ���FocusOn
	//update self focus on
	SelfState().UpdateFocusOn(mpObserver->Sense().GetFocusSide(), mpObserver->Sense().GetFocusUnum());

	//�����Լ����ӽ�
	//update self view width
	SelfState().UpdateViewWidth(mpObserver->Sense().GetViewWidth());

}

void WorldStateUpdater::UpdateKnownPlayers()
{
	//��ʱ�����ѵ�λ��Ϊ���µ�ʱ���ʾ����
	//if teammate's position's time is current time, then it means I saw him the current cycle

	//���¿����Ķ���
	//update seen teammates
	for (int i = 1;i <= TEAMSIZE;i++)
	{
		if (i == mSelfUnum)
		{
			continue;
		}

		if (mpObserver->Teammate(i).GetDir().time() == mpObserver->LatestSightTime())
		{
			UpdateSpecificPlayer(mpObserver->Teammate(i) , i , true);
		}
	}

	//���¿����Ķ���
	//update seen opponents
	for (int i = 1;i <= TEAMSIZE;i++)
	{
		if (mpObserver->Opponent(i).GetDir().time() == mpObserver->LatestSightTime())
		{
			UpdateSpecificPlayer(mpObserver->Opponent(i) , i , false);
		}
	}
}

void WorldStateUpdater::UpdateSpecificPlayer(const PlayerObserver &player, Unum unum, bool is_teammate)
{
	//���ݵײ��parser�����Ϣ ���µ��У�λ�ã��ٶȣ�����Ƕȣ�ͷ���Ƕȣ���ָ���Ƿ����
	//update position,velocity,body direction,head direction,point to,if tackling etc. according to parser
	//ԭ���ǣ�ֻ�н��������ʱ�Ÿ���
	//Updated only if sight is the newest

	if (is_teammate)
	{
		Teammate(unum).SetIsAlive(true);
		Teammate(unum).UpdateGuessedTimes(0);
		//λ�ø���
		//update position
		if (player.GetDir().time() == mpObserver->LatestSightTime())
		{
			Vector vec = Polar2Vector(PlayerParam::instance().ConvertSightDist(player.Dist()) , GetNeckGlobalDirFromSightDelay(mSightDelay) + player.Dir());
			vec = GetSelf().GetPos() + vec;
			Teammate(unum).UpdatePos(vec , mSightDelay , mPlayerConf);

			double eps = PlayerParam::instance().GetEpsInSight(player.Dist()) + SelfState().GetPosEps();
			Teammate(unum).UpdatePosEps(eps);
		}

		//�ٶȸ���
		//update velocity

		//*** ��ʽ = expressions ***

		if (player.GetDirChg().time() == mpObserver->LatestSightTime())
		{
			//��ʽ��relPos = polar2vector(1.0, ballAngle)
			Vector vec = Polar2Vector(1.0 , player.Dir());
			double distChg = player.DistChg();
			double dirChg  = player.DirChg();
			double dist    = player.Dist();
			//���㹫ʽ��USTC_Material ������
			//��ʽ��relVel = (distChg * relPos.x() - (dirChg * PI / 180 * ballDist * relPos.y()),distChg * rpos.y() + (dirChg * PI / 180 * ballDist * relPos.x())
			Vector relvel = Vector(distChg * vec.X() - (dirChg * M_PI / 180 * dist * vec.Y()) , distChg * vec.Y() + (dirChg * M_PI / 180 * dist * vec.X()));
			//��ʽ��ballVel = playerVel() + relVel.rotate(neckGlobalAngle)
			relvel = GetSelfVelFromSightDelay(mSightDelay) + relvel.Rotate(GetNeckGlobalDirFromSightDelay(mSightDelay));
			Teammate(unum).UpdateVel(relvel , mSightDelay , mPlayerConf);
		}
		else if(player.GetDir().time() == mpObserver->LatestSightTime())	//ֻ����λ�õ��ǿ������ٶȵ����
																			//see position no velocity
		{
		//	if (player.Dist() < ServerParam::instance().visibleDistance() * 2)
			int delay = mpWorldState->GetHistory(1 + mSightDelay)->Teammate(unum).GetPosDelay();
			if (delay  < HISTORYSIZE - 1 - mSightDelay)
			{
				Vector 	vel = Teammate(unum).GetPos() - mpWorldState->GetHistory(1 + mSightDelay + delay)->Teammate(unum).GetPos();
				vel /= (delay + 1);

				//use  speed of self sense instead of pos of self sight to reduce the error
				Vector self_vel = GetSelfVelFromSightDelay(mSightDelay);
				if (mpObserver->Sense().IsCollideWithBall() || mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithPost())
				{
					self_vel /= -0.1;
				}
				self_vel /= PlayerParam::instance().HeteroPlayer(SelfState().GetPlayerType()).playerDecay();
				Vector self_vel_pos = SelfState().GetPos() - mpWorldState->GetHistory(1 + mSightDelay)->Teammate(GetSelfUnum()).GetPos();
				vel += self_vel - self_vel_pos;

				double max_speed = PlayerParam::instance().HeteroPlayer(mpObserver->GetTeammateType(unum)).effectiveSpeedMax();
				//�����ٶȴ��²²⳯�� ���Ӿ�ʱ�Ḳ��
				//guess direction according to speed. The newest sight information may cover this
				if (vel.Mod() > max_speed * mpWorldState->GetTeammate(unum).GetPlayerDecay() * 0.8 && GetTeammate(unum).IsBodyDirMayChanged())
				{
//					Logger::instance().GetTextLogger("bodydir") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << unum << "\t" << vel.Dir() << "\t" << Teammate(unum).GetBodyDir() << "\n";
					Teammate(unum).UpdateBodyDir(vel.Dir() , GetTeammate(unum).GetBodyDirDelay() , GetTeammate(unum).GetBodyDirConf());
//					Teammate(unum).UpdateBodyDirMayChanged(false);
				}
				else if ( vel.Mod() > max_speed * mpWorldState->GetTeammate(unum).GetPlayerDecay())
				{
					Teammate(unum).UpdateBodyDirMayChanged(true);
				}


//				Logger::instance().GetTextLogger("bodydir") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << unum << "\t" << Teammate(unum).GetBodyDir() << "\n";
				if (vel.Mod() > max_speed)
				{
					vel = Polar2Vector(max_speed , vel.Dir());
				}

				vel *= PlayerParam::instance().HeteroPlayer(mpObserver->GetTeammateType(unum)).playerDecay();


				Teammate(unum).UpdateVel(vel ,mSightDelay , mPlayerConf);
			}
		}


		//����Ƕ�
		//body direction
		if (player.GetBodyDir().time() == mpObserver->LatestSightTime())
		{
			AngleDeg angle = player.BodyDir();
			angle = angle + GetNeckGlobalDirFromSightDelay(mSightDelay);
			Teammate(unum).UpdateBodyDir(angle , mSightDelay , mPlayerConf);
			Teammate(unum).UpdateBodyDirMayChanged(false);
		}

		//ͷ���Ƕ�
		//head direction
		if (player.GetHeadDir().time() == mpObserver->LatestSightTime())
		{
			AngleDeg angle = player.HeadDir() - player.BodyDir();
			Teammate(unum).UpdateNeckDir(angle , mSightDelay , mPlayerConf);
		}

		//��ָ��
		//point to
		if (player.GetIsPointing().time() == mpObserver->LatestSightTime())
		{
			if (player.IsPointing())
			{
				Teammate(unum).UpdateArmPoint(player.PointDir() + GetNeckGlobalDirFromSightDelay(mSightDelay) , mSightDelay , mPlayerConf);
			}
		}

		//�Ƿ����
		//if tackling
		if (player.GetIsTackling().time() == mpObserver->LatestSightTime())
		{
			if (player.IsTackling()) {
				if (Teammate(unum).GetTackleBan() == 0) {
					Teammate(unum).UpdateTackleBan(ServerParam::instance().tackleCycles() - 1);

				}
				//tackle�ٶ�һ��Ϊ��
				//if tackle happen then speed = 0
				Teammate(unum).UpdateVel(Vector(0,0) , mSightDelay , mPlayerConf);
			}
			else {
				Teammate(unum).UpdateTackleBan(0);
			}
		}

		//�Ƿ��������߹���
		//if kicked last cycle
		if (player.GetIsKicked().time() == mpObserver->LatestSightTime())
		{
			Teammate(unum).UpdateKicked(player.IsKicked());
		}
	}
	else
	{
		Opponent(unum).SetIsAlive(true);
		Opponent(unum).UpdateGuessedTimes(0);
		//λ�ø���
		//update position
		if (player.GetDir().time() == mpObserver->LatestSightTime())
		{
			Vector vec = Polar2Vector(PlayerParam::instance().ConvertSightDist(player.Dist()) , GetNeckGlobalDirFromSightDelay(mSightDelay) + player.Dir());
			vec = GetSelf().GetPos() + vec;
			Opponent(unum).UpdatePos(vec,mSightDelay , mPlayerConf);

			double eps = PlayerParam::instance().GetEpsInSight(player.Dist()) + SelfState().GetPosEps();
			Opponent(unum).UpdatePosEps(eps);
		}

		//�ٶȸ���
		//update velocity
		if (player.GetDirChg().time() == mpObserver->LatestSightTime())
		{
			//��ʽ��relPos = polar2vector(1.0, ballAngle)
			Vector vec = Polar2Vector(1.0 , player.Dir());
			double distChg = player.DistChg();
			double dirChg  = player.DirChg();
			double dist    = player.Dist();
			//���㹫ʽ��USTC_Material ������
			//��ʽ��relVel = (distChg * relPos.x() - (dirChg * PI / 180 * ballDist * relPos.y()),distChg * rpos.y() + (dirChg * PI / 180 * ballDist * relPos.x())
			Vector relvel = Vector(distChg * vec.X() - (dirChg * M_PI / 180 * dist * vec.Y()) , distChg * vec.Y() + (dirChg * M_PI / 180 * dist * vec.X()));

			//��ʽ��ballVel = playerVel() + relVel.rotate(neckGlobalAngle)
			relvel = GetSelfVelFromSightDelay(mSightDelay) + relvel.Rotate(GetNeckGlobalDirFromSightDelay(mSightDelay));
			Opponent(unum).UpdateVel(relvel , mSightDelay , mPlayerConf);
		}
		else if(player.GetDir().time() == mpObserver->LatestSightTime())	//ֻ�������λ�õ��ǿ������ٶȵ����
																			//see position no velocity
		{
			int delay = mpWorldState->GetHistory(1 + mSightDelay)->Opponent(unum).GetPosDelay();
			if (delay < HISTORYSIZE - 1 - mSightDelay)
			{
				Vector vel = Opponent(unum).GetPos() - mpWorldState->GetHistory(1 + mSightDelay + delay)->Opponent(unum).GetPos();
				vel /= (delay + 1);

				//use  speed of self sense instead of pos of self sight to reduce the error
				Vector self_vel = GetSelfVelFromSightDelay();
				if (mpObserver->Sense().IsCollideWithBall() || mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithPost())
				{
					self_vel /= -0.1;
				}
				self_vel /= PlayerParam::instance().HeteroPlayer(SelfState().GetPlayerType()).playerDecay();
				Vector self_vel_pos = SelfState().GetPos() - mpWorldState->GetHistory(1 + mSightDelay)->Teammate(GetSelfUnum()).GetPos();
				vel += self_vel - self_vel_pos;


				double max_speed = GetOpponent(unum).GetEffectiveSpeedMax();

				//�����ٶ�Ԥ��������峯��
				//estimate opponent's body direction according to his velocity
				if (vel.Mod() > max_speed * GetOpponent(unum).GetPlayerDecay()  * 0.8 && GetOpponent(unum).IsBodyDirMayChanged())
				{
//					Logger::instance().GetTextLogger("bodydir") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << unum + TEAMSIZE << "\t" << vel.Dir() << "\t" << Opponent(unum).GetBodyDir() << "\n";
					Opponent(unum).UpdateBodyDir(vel.Dir() , GetOpponent(unum).GetBodyDirDelay() , GetOpponent(unum).GetBodyDirConf());
//					Opponent(unum).UpdateBodyDirMayChanged(false);
				}
				else if (vel.Mod() <= max_speed * GetOpponent(unum).GetPlayerDecay())
				{
					Opponent(unum).UpdateBodyDirMayChanged(true);
				}

//				Logger::instance().GetTextLogger("bodydir") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << unum + TEAMSIZE << "\t" << Opponent(unum).GetBodyDir() << "\n";
				if (vel.Mod() > max_speed)
				{
					vel = Polar2Vector(max_speed , vel.Dir());
				}
				vel *= GetOpponent(unum).GetPlayerDecay();

				Opponent(unum).UpdateVel(vel , mSightDelay , mPlayerConf);
			}
		}


		//����Ƕ�
		//body direction
		if (player.GetBodyDir().time() == mpObserver->LatestSightTime())
		{
			AngleDeg angle = player.BodyDir();
			angle = angle + GetNeckGlobalDirFromSightDelay(mSightDelay);
			Opponent(unum).UpdateBodyDir(angle , mSightDelay , mPlayerConf);
			Opponent(unum).UpdateBodyDirMayChanged(false);
		}

		//ͷ���Ƕ�
		//head direction
		if (player.GetHeadDir().time() == mpObserver->LatestSightTime())
		{
			AngleDeg angle = player.HeadDir() - player.BodyDir();
			Opponent(unum).UpdateNeckDir(angle , mSightDelay , mPlayerConf);
		}

		//��ָ��
		//point to
		if (player.GetIsPointing().time() == mpObserver->LatestSightTime())
		{
			if (player.IsPointing())
			{
				Opponent(unum).UpdateArmPoint(player.PointDir() + GetNeckGlobalDirFromSightDelay(mSightDelay) , mSightDelay , mPlayerConf);
			}
		}

		//�Ƿ����
		//if tackling
		if (player.GetIsTackling().time() == mpObserver->LatestSightTime())
		{
			if (player.IsTackling())
			{
				if (Opponent(unum).GetTackleBan() == 0)
				{
					Opponent(unum).UpdateTackleBan(ServerParam::instance().tackleCycles() - 1);
				}
				//tackle�ٶ�һ��Ϊ��
				//speed = 0 if tackling
				Opponent(unum).UpdateVel(Vector(0,0) , mSightDelay , mPlayerConf);
			}
			else {
				Opponent(unum).UpdateTackleBan(0);
			}
		}

		//�Ƿ��������߹���
		//if kicked last cycle
		if (player.GetIsKicked().time() == mpObserver->LatestSightTime())
		{
			Opponent(unum).UpdateKicked(player.IsKicked());
		}
	}
}

/**
 * This function update some kick information about other players
 */
void WorldStateUpdater::UpdateOtherKick()
{
	mIsOtherKick = false;
	mOtherKickUnum = 0;
	mIsOtherMayKick = true;
	for (int i = 1;i < TEAMSIZE;i++)
	{
		if (i != mSelfUnum)
		{
			if (Teammate(i).IsKicked() || Teammate(i).GetTackleBan() == ServerParam::instance().tackleCycles() - 1)
			{
				mIsOtherKick = true;
				mOtherKickUnum = i;
				break;
			}
		}

		if (Opponent(i).IsKicked() || Opponent(i).GetTackleBan() == ServerParam::instance().tackleCycles() - 1)
		{
			mIsOtherKick = true;
			mOtherKickUnum = -i;
			break;
		}
	}

	double min_dist = 10000;
	int min_index;

	if (mpWorldState->GetBall().GetPosDelay() <= 1 && SelfState().IsKickable())
	{
		Vector ball_pos = mpWorldState->GetBall().GetPos();
		for (int i = 1;i <= TEAMSIZE;i++)
		{
			if (i != mSelfUnum)
			{
				if (Teammate(i).GetPos().Dist(ball_pos) < min_dist)
				{
					min_dist = Teammate(i).GetPos().Dist(ball_pos);
					min_index = i;
				}
			}

			if (Opponent(i).GetPos().Dist(ball_pos) < min_dist)
			{
				min_dist = Opponent(i).GetPos().Dist(ball_pos);
				min_index = i;
			}
		}

		if (min_dist > 2.5)
		{
			mIsOtherMayKick = false;
		}
	}
}
namespace {
	Vector LimitToField(Vector pos)
	{
		if (pos.X() > ServerParam::instance().PITCH_LENGTH / 2)
		{
			pos.SetX(ServerParam::instance().PITCH_LENGTH / 2);
		}
		else if (pos.X() < -ServerParam::instance().PITCH_LENGTH / 2)
		{
			pos.SetX(-ServerParam::instance().PITCH_LENGTH / 2);
		}

		if (pos.Y() > ServerParam::instance().PITCH_WIDTH / 2)
		{
			pos.SetY(ServerParam::instance().PITCH_WIDTH / 2);
		}
		else if (pos.Y() < -ServerParam::instance().PITCH_WIDTH / 2)
		{
			pos.SetY(-ServerParam::instance().PITCH_WIDTH / 2);
		}

		return pos;
	}
}


void WorldStateUpdater::UpdateBallInfo()
{
	//���±����Ƿ����.
	//update other players kick information
	UpdateOtherKick();


	//����λ��
	//���㹫ʽ��USTC_Material ������
	//��ʽ��ballPos = playerPos + polar2vector(ballDist , neckGlobalAngle + ballAngle)
	if (mpObserver->Ball().GetDist().time() == mpObserver->LatestSightTime())
	{
		double dist = PlayerParam::instance().ConvertSightDist(mpObserver->Ball().Dist());

		if (mpObserver->GetPlayMode() == PM_Opp_Kick_In
				|| mpObserver->GetPlayMode() == PM_Opp_Corner_Kick
				|| mpObserver->GetPlayMode() == PM_Opp_Free_Kick
				|| mpObserver->GetPlayMode() == PM_Opp_Goalie_Free_Kick
				|| mpObserver->GetPlayMode() == PM_Opp_Offside_Kick
				|| mpObserver->GetPlayMode() == PM_Opp_Free_Kick_Fault_Kick
			)
		{
			//�Է�������,������Ա���������ΪfreekickBuffer ,��ʱ��֪�������������� .
			//effect unknown
            dist = Max(dist, ServerParam::instance().offsideKickMargin() + FLOAT_EPS);
		}

		//������ײʱ�̶����������ƿ���˾���
		//if colliding happen, ball and player may be moved such a distance
		if (mpObserver->Sense().IsCollideWithBall())
		{
			dist = GetSelf().GetPlayerSize() + ServerParam::instance().ballSize();
		}
		Vector pos = GetSelf().GetPos() + Polar2Vector(dist , GetNeckGlobalDirFromSightDelay(mSightDelay) + mpObserver->Ball().Dir());

		//����eps ����������Ҫ ������ǲ�ʹ��, ��Ϊ��Ӱ�쵽�������ټ���
		//update error.
		double eps = PlayerParam::instance().GetEpsInSight(mpObserver->Ball().Dist());
		eps = calcEps(dist , dist + eps , 0.1) + SelfState().GetPosEps();
		if (dist >  ServerParam::instance().visibleDistance() * 2 && !(mSightDelay == 0 && mIsOtherKick && !mIsHearBallPos))
		{
			if (mSightDelay == 0 && eps > Ball().GetPosEps() && pos.Dist(Ball().GetPos()) < Ball().GetPosEps())
			{
				eps = Ball().GetPosEps();
				pos = Ball().GetPos();
			}
    		else if (mSightDelay == 0 && eps > Ball().GetPosEps() && pos.Dist(Ball().GetPos()) >=  Ball().GetPosEps() && !mIsOtherKick)
			{
				if (!mpWorldState->IsBallDropped() && mpWorldState->GetPlayMode() == PM_Play_On && mpWorldState->GetHistory(1)->GetBall().GetPosDelay() == 0)
				{
/*
	char filename[25] = {0};
	sprintf(filename , "ballinfo_%d.txt" , mSelfUnum);

	std::ofstream file(filename , std::ios::app);
	file << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << pos.X() << "\t" << pos.Y();*/

					Vector normal = (pos - Ball().GetPos()).Normalize();
					pos = Ball().GetPos() + normal * Ball().GetPosEps();
//	file << "\t" << pos.X() << "\t" << pos.Y() << std::endl;
//	file.close();
				}
			}

			else if (mSightDelay == 0 && eps == Ball().GetPosEps() && pos.Dist(Ball().GetPos()) < eps)
			{
				pos  = (pos + Ball().GetPos())/2;
			}
		}

		// limited to field ����λ��3�����⣬����������λ�ò�׼
		// useful only if is farther than 3 or the position of ball isn't accurate
		if (dist > ServerParam::instance().visibleDistance())
		{
			pos = LimitToField(pos);
		}

		Ball().UpdatePosEps(eps);
		Ball().UpdatePos(pos , mSightDelay , mBallConf);
		Ball().UpdateGuessedTimes(0);
	}

	//�����ٶ�
	//update velocity
	if (mpObserver->Ball().GetDistChg().time() == mpObserver->LatestSightTime())
	{
		//��ʽ��relPos = polar2vector(1.0, ballAngle)
		Vector relPos = Polar2Vector(1.0, mpObserver->Ball().Dir());

		double distChg = mpObserver->Ball().DistChg();
		double dirChg  = mpObserver->Ball().DirChg();
		double ballDist = mpObserver->Ball().Dist();

		//��ʽ��relVel = (distChg * relPos.x() - (dirChg * PI / 180 * ballDist * relPos.y()),distChg * rpos.y() + (dirChg * PI / 180 * ballDist * relPos.x())
		Vector relVel = Vector(distChg * relPos.X() - (dirChg * M_PI / 180 * ballDist * relPos.Y()) , distChg * relPos.Y() + (dirChg * M_PI / 180 * ballDist * relPos.X()));

		relVel = GetSelfVelFromSightDelay(mSightDelay) + relVel.Rotate(GetNeckGlobalDirFromSightDelay(mSightDelay));

		//compute vel eps;
		double eps = PlayerParam::instance().GetEpsInSight(mpObserver->Ball().Dist());
		Vector mod = Vector(0.02 * ballDist + fabs(distChg) / ballDist * eps + 0.02 * eps , 0.1 * M_PI / 180  * ballDist + fabs(dirChg) * M_PI / 180 * eps + eps * 0.1 * M_PI / 180);
		eps = mod.Mod();


		if ((!(mSightDelay == 0 && mIsOtherKick) )&& Ball().GetVelConf() > 0.9499)//0.95
		{
			Vector vel_estimate = Ball().GetVel();

			if (fabs(relVel.Mod() - vel_estimate.Mod()) <= ServerParam::instance().ballRand() * relVel.Mod() / ServerParam::instance().ballDecay() && fabs(relVel.Dir() - vel_estimate.Dir()) < 1 )
			{
				relVel = (relVel + vel_estimate) / 2;
			}
		}
		//��ʽ��ballVel = playerVel() + relVel.rotate(neckGlobalAngle)
		//Ball().UpdateVel(GetSelf().GetVel() + relVel.Rotate(GetSelf().GetNeckGlobalDir()));
		//
		if (!(mSightDelay == 0 && mIsOtherKick && !mIsHearBallVel))
		{
			if (mSightDelay == 0 && Ball().GetVelEps() <= 0.32 && eps > Ball().GetVelEps() && (relVel.Dist(Ball().GetVel()) < Ball().GetVelEps()))
			{
	/*
		char filename[25] = {0};
		sprintf(filename , "ballinfo_%d.txt" , mSelfUnum);

		std::ofstream file(filename , std::ios::app);
		file << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << relVel.X() << "\t" << relVel.Y() << "\t" << Ball().GetVel().X() << "\t" << Ball().GetVel().Y() << std::endl;

		file.close();
		*/
				relVel = Ball().GetVel();
				eps = Ball().GetVelEps();
			}
			else if (mSightDelay == 0 && Ball().GetVelEps() <= 0.32 && eps == Ball().GetVelEps() && (relVel.Dist(Ball().GetVel()) < Ball().GetVelEps()))
			{
				relVel = (relVel + Ball().GetVel()) / 2;
			}
		}

		Ball().UpdateVelEps(eps);
		Ball().UpdateVel(relVel , mSightDelay , mBallConf);
	}

	//����λ���������.
	//fix with position
	if (mpObserver->Ball().GetDist().time() == mpObserver->LatestSightTime())	//�������λ�����
																				//seen ball position
	{
	/*		if (//mpObserver->Ball().Dist() < ServerParam::instance().visibleDistance() * 2 &&
				(mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetPosDelay() == 0 ||
				 (mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetPos().Dist(SelfState().GetPos()) < ServerParam::instance().visibleDistance() - 0.15 && mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetPosDelay() < 2)))*/
		if (mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetPosDelay() < 2)	//�������һ���̶Ȳſ�����
																					//useful if distance satisfied
		{
			Vector vel = GetBall().GetPos() - mpWorldState->GetHistory(1 + mSightDelay)->Ball().GetPos() ;

			//use  speed of self sense instead of pos of self sight to reduce the error
			if (GetBall().GetPosEps() > ServerParam::instance().playerSize()  ||( !mpObserver->Sense().IsCollideWithBall() && !mpObserver->Sense().IsCollideWithPlayer() && !mpObserver->Sense().IsCollideWithPost()))
			{
				//��ײʱserverǿ���ƶ���,�����λ���������,���������0.3(player size)�����,08ҲӦ�������bug
				Vector self_vel = GetSelfVelFromSightDelay(mSightDelay);

				if (mpObserver->Sense().IsCollideWithBall() || mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithPost())
				{
					self_vel /= -0.1;
				}

				self_vel /= PlayerParam::instance().HeteroPlayer(SelfState().GetPlayerType()).playerDecay();
				Vector self_vel_pos = SelfState().GetPos() - mpWorldState->GetHistory(1 + mSightDelay)->Teammate(GetSelfUnum()).GetPos();
				vel += self_vel - self_vel_pos;
			}

			if (mpObserver->GetBallKickTime() != mpObserver->LatestSightTime() && !mpObserver->Sense().IsCollideWithBall())
			{
				if (mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetVelConf() > 0.9)
				{
					Vector old_vel = mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetVel();

					if (fabs(old_vel.X() - vel.X()) + fabs(old_vel.Y() - vel.Y()) < 0.30 && fabs(old_vel.Mod() / (vel.Mod() + FLOAT_EPS) - 1.0) < 0.16)
					{
						vel = (old_vel + vel) / 2;
					}
				}
			}
			else if (!mpObserver->Sense().IsCollideWithBall())
			{
				if (mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetVelConf() > 0.9)
				{
					if (mpObserver->GetBallKickTime() == mpObserver->LatestSightTime())
					{
						Vector old_vel = mpObserver->GetBallVelByKick() / ServerParam::instance().ballDecay();
						if (fabs(old_vel.X() - vel.X()) + fabs(old_vel.Y() - vel.Y()) < 0.30 && fabs(old_vel.Mod() / (vel.Mod() + FLOAT_EPS) - 1.0) < 0.16)
						{
							vel = (old_vel + vel) / 2;
						}
					}
				}
			}
			else if (mpObserver->Sense().IsCollideWithBall())
			{
				vel *= -0.1;
			}

			vel *= ServerParam::instance().ballDecay();

			if (vel.Mod() > ServerParam::instance().ballSpeedMax())
			{
				vel = Polar2Vector(ServerParam::instance().ballSpeedMax() , vel.Dir());
			}

			double eps1 = PlayerParam::instance().GetEpsInSight((mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetPos() - mpWorldState->GetHistory(1 + mSightDelay)->GetTeammate(mSelfUnum).GetPos()).Mod());
			double eps2 = PlayerParam::instance().GetEpsInSight(mpObserver->Ball().Dist());
			double eps = eps1 + eps2;


			if (mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithPost())
			{
				eps += ServerParam::instance().playerSize() * ServerParam::instance().ballDecay();
			}
			else if (mpObserver->Sense().IsCollideWithBall())
			{
				eps += ServerParam::instance().playerSize() * ServerParam::instance().ballDecay() * 0.1;
			}

			//û���Ӿ���һ������, �нǶ��Ӿ�����Ϊ����
			//update when no sight arrived. 
			if (mpObserver->Ball().Dist() < 2 * ServerParam::instance().visibleDistance())
			{
				if ( mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetPosDelay() == 0 || (mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetPos().Dist(SelfState().GetPos()) < ServerParam::instance().visibleDistance() - 0.15 && mpWorldState->GetHistory(1 + mSightDelay)->GetBall().GetPosDelay() == 1) || (!mIsHearBallVel && mIsOtherKick))
				{
					if (Ball().GetVelDelay() > mSightDelay + 1 || eps < Ball().GetVelEps() || (Ball().GetVelDelay() != 0 && vel.Dist(Ball().GetVel()) > Ball().GetVelEps() && mIsOtherMayKick))
					{
	/*	char filename[25] = {0};
		sprintf(filename , "ballinfo_%d.txt" , mSelfUnum);

		std::ofstream file(filename , std::ios::app);
		file << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << vel.X() << "\t" << vel.Y() << "\t" << Ball().GetVel().X() << "\t" << Ball().GetVel().Y() << std::endl;

		file.close();
	*/
						Ball().UpdateVelEps(eps);
						Ball().UpdateVel(vel , mSightDelay , mBallConf);
					}
				}
			}
			//���Խ���ǳ����� ��ע�͵�
			// be of no use
			else
			{
				if (Ball().GetVelDelay() > mSightDelay && !mIsHearBallVel && mIsOtherKick)
				{
	/*
		char filename[25] = {0};
		sprintf(filename , "ballinfo_%d.txt" , mSelfUnum);

		std::ofstream file(filename , std::ios::app);
		file << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << vel.X() << "\t" << vel.Y() << "\t" << Ball().GetVel().X() << "\t" << Ball().GetVel().Y() << "\t" << eps << "\t" << Ball().GetVelEps() << std::endl;

		file.close();
		*/
					Ball().UpdateVelEps(eps);
					Ball().UpdateVel(vel , mSightDelay , mBallConf);
				}
			}
		}
	}
}

void WorldStateUpdater::UpdateInfoWhenCollided()
{
	if (mpObserver->Sense().IsCollideWithBall() || mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithPost())
	{
		if (mpObserver->Sense().IsCollideWithBall())
		{
			SelfState().UpdateCollideWithBall(true);
		}
		else if (mpObserver->Sense().IsCollideWithPlayer())
		{
			SelfState().UpdateCollideWithPlayer(true);
		}
		else if (mpObserver->Sense().IsCollideWithPost())
		{
			SelfState().UpdateCollideWithPost(true);
		}
	}

	//���������ײ���ٶ���Ҫ���� ����δ���¿����ٶ�ʱʹ��
	//if colliding happen, speed should be fixed here
	if (mpObserver->Sense().IsCollideWithBall() && Ball().GetVelDelay() != 0)
	{
		Ball().UpdateVel(GetBall().GetVel() * -0.1 ,  GetBall().GetVelDelay() , GetBall().GetVelConf());
		Ball().UpdateVelEps(0.1 * Ball().GetVelEps());
	}

	if (mpObserver->Sense().IsCollideWithPlayer())
	{
		//�ҵ��������Ա
		//find the nearest player
		bool is_teammate = false;
		Unum tmmt = GetSeenClosestTeammate();	//���򷵻�0
												//0 if none
		Unum oppn = GetSeenClosestOpponent();	//���򷵻�0
												//0 if none

		if (tmmt * oppn == 0)
		{
			if (tmmt != 0)
			{
				is_teammate = true;
			}
			else if (oppn != 0)
			{
				is_teammate = false;
			}
			else
			{
				return;
			}
		}
		else
		{
			if (mpObserver->Teammate(tmmt).Dist() <= mpObserver->Opponent(oppn).Dist())
			{
				is_teammate = true;
			}
			else
			{
				is_teammate = false;
			}
		}


		if (is_teammate)
		{
			if (mpObserver->Teammate(tmmt).GetDirChg().time() != mpObserver->LatestSightTime())
			{
				Teammate(tmmt).UpdateVel(Teammate(tmmt).GetVel() * -0.1 , Teammate(tmmt).GetVelDelay() , Teammate(tmmt).GetVelConf());
			}
			Teammate(tmmt).UpdateCollideWithPlayer(true);
		}
		else
		{
			if (mpObserver->Opponent(oppn).GetDirChg().time() != mpObserver->LatestSightTime())
			{
				Opponent(oppn).UpdateVel(Opponent(oppn).GetVel() * -0.1 , Opponent(oppn).GetVelDelay() , Opponent(oppn).GetVelConf());
			}
			Opponent(oppn).UpdateCollideWithPlayer(true);
		}
	}
}

bool WorldStateUpdater::ComputeSelfDir(double& angle)
{
	//������Կ������ߣ�������������ʾ������
	//compute the visual line, if two then I'm out field
	int sample_line = SL_NONE; //mark
	int num = 0;
	double min = 10000; //��ʼֵ
						//initial
	for (int i = 0;i <  SL_MAX;i++)
	{
		if (mpObserver->SideLine((SideLineType)i).GetDir().time() == mpObserver->LatestSightTime())
		{
			//����ʹ�������һ����
			//the nearest line is necessary
			if (mpObserver->SideLine((SideLineType)i).Dist() < min)
			{
				sample_line = i;
				min = mpObserver->SideLine((SideLineType)i).Dist();
			}
			num++;
		}
	}

	//������
	//none seen
	if (num == 0)
	{
		return false;
	}

	//���㹫ʽ��USTC_Material ������

	//lineRelativeAngle = (line_dir < 0 ) ? (90 + line_dir ) : (line_dir �C 90)
	angle = mpObserver->SideLine((SideLineType)sample_line).Dir();

	angle = angle < 0 ? 90 + angle : angle - 90 ;

	//neckGlobalAngle = lineGlobalAngle �C lineRelativeAngle
	angle = (mpObserver->SideLine((SideLineType)sample_line)).GlobalPosition().Dir() - angle;

	//���ͬʱ���������߾ͱ�ʾ�ڳ��� ����180 ����ɲμ�Դ��MemPosition.c��Update_self_seen��������
	if (num >= 2)
	{
		angle = 180 + angle;
	}

	//��֤�Ƕ���180 �� -180 ֮��
	//ensure the angle's range
	if (angle > 180)
	{
		angle -= 360;
	}
	else if (angle < -180)
	{
		angle += 360;
	}

	return true;
}

bool WorldStateUpdater::ComputeSelfPos(Vector &vec ,double& eps)
{
	//Ѱ������ı�־
	//find the nearest flag
	int sample = FLAG_NONE; //�����־�ı�ʾ
							//the nearest flag, initial here
	double min = 2000.0;    //�����־�ľ��� ��ʼֵӦ�ò��ܱ������С�˰ɣ�
							//initial distance

	for (int i = 0;i < FLAG_MAX;i++)
	{
		if (mpObserver->Marker((MarkerType)i).GetDir().time() == mpObserver->LatestSightTime())
		{
			if (mpObserver->Marker((MarkerType)i).Dist() < min)
			{
				min = mpObserver->Marker((MarkerType)i).Dist();
				sample = i;
			}
		}
	}

	//û�п����� �򷵻�false
	//if no flag seen return false
	if (sample == FLAG_NONE)
	{
		return false;
	}

	//����������eps
	//fix and compute error
	min = PlayerParam::instance().ConvertMarkDist(min);
	eps = PlayerParam::instance().GetEpsInMark(min);

	eps = calcEps(min , min+eps , 1);

	if (GetSelf().GetBodyDirDelay() != mSightDelay)
	{
		//��ȥ��������Ƕ���û�и�����Ϊ�伫��׼
		//error max
		eps = 10000;
	}

	//���㹫ʽ��USTC_Material ������
	//playerPos = flagPos �C polar2vector(flagDist, neckGlobalAngle + flagDir)
	vec = mpObserver->Marker((MarkerType)sample).GlobalPosition() - Polar2Vector(min , GetNeckGlobalDirFromSightDelay(mSightDelay) + mpObserver->Marker((MarkerType)sample).Dir());

	return true;
}

bool WorldStateUpdater::ComputePlayerMaySeeOrNot(const PlayerState& state)
{
	double view_angle = 0;
	switch(GetSelf().GetViewWidth())
	{
	case VW_Narrow:
		view_angle = 60;
		break;
	case VW_Normal:
		view_angle = 120;
		break;
	case VW_Wide:
		view_angle = 180;
		break;
	default:
		view_angle = 120;
	}

	Vector dist_vec = state.GetPos() - GetSelf().GetPos();
	double angle = GetNormalizeAngleDeg(dist_vec.Dir());
	angle = ::fabs(::GetNormalizeAngleDeg(angle - GetNeckGlobalDirFromSightDelay(mSightDelay)));

	double anglebuf = ASin((state.GetPosDelay() * 0.6 + 0.05 * dist_vec.Mod() ) / dist_vec.Mod());

	angle -= anglebuf;

	if (angle < view_angle / 2)
	{
		return true;
	}

	if (dist_vec.Mod() < ServerParam::instance().visibleDistance() + ComputePlayerMaxDist(state))
	{
		return true;
	}

	double dist = ComputePlayerMaxDist(state) / dist_vec.Mod();
	if (dist < 1)
	{
		double delta_angle = ASin(ComputePlayerMaxDist(state) / dist_vec.Mod());
		angle -= delta_angle;

		if (angle < 0)
		{
			angle = 0;
		}
	}
	else
	{
		angle = 0;
	}

	if (angle < view_angle / 2)
	{
		return true;
	}

	return false;
}

//#define __UNKNOWN_TEST

#ifdef __UNKNOWN_TEST
#include <fstream>
#endif

void WorldStateUpdater::UpdateUnknownPlayers()
{
	if (!mpObserver->IsNewSight())
	{
		return;
	}

	bool is_special_mode = mpWorldState->GetPlayMode() == PM_Before_Kick_Off || mpWorldState->GetPlayMode() == PM_Goal_Ours || mpWorldState->GetPlayMode() == PM_Goal_Opps;


	////============================================���²�֪����Ա�����==========================================================
	////=========================================Update unknown player's number=================================================
	bool Unknown[TEAMSIZE * 2][TEAMSIZE * 2 + 1];	//��δ֪��Ա�ӽ�����֪��Ա�Ķ���.�������������Աi���j��δ֪��Ա������ͬ ��Unknown[j][i] = true;  ��ÿһ�� 0~TEAMSIZE-1Ϊ������Ա ����Ϊ�Է���Ա
													//array of known players who are near the unknown player.  example: teammate[i] is familiar with unknown[j] then Unknown[j][i] = true;  0~TEAMSIZE-1 are teammate,others are opponent
	int UnknownCount[TEAMSIZE * 2];					//���δ֪��Ա���ܵ�������Ա�ĸ���
													//mark unknown player count

	bool UnknownUpdate[TEAMSIZE*2];

	for (int i = 0; i < TEAMSIZE * 2; ++i){
		UnknownCount[i] = 0;
		UnknownUpdate[i] = false;
		for (int j = 0; j < TEAMSIZE * 2 + 1; ++j){
			Unknown[i][j] = false;
		}
	}

	//��ͬ��������
	int player_num = mpObserver->GetUnknownPlayerCount();
	char self_side = mpObserver->OurInitSide();

	//1.������pi,oj��������raidus_max(pi) > distance(pi,oj)ʱ����pi ��oj �������Է���ƥ���б���
	//1. when pi and oj satisfy raidus_max(pi) > distance(pi,oj), then pi and oj are matched
	for (int i = 0;i < player_num;i++)
	{
		Vector pos = Polar2Vector(PlayerParam::instance().ConvertSightDist(mpObserver->UnknownPlayer(i).Dist()) , GetNeckGlobalDirFromSightDelay(mSightDelay) + mpObserver->UnknownPlayer(i).Dir());
		pos = GetSelf().GetPos() + pos;

		if (is_special_mode && !ServerParam::instance().pitchRectanglar().IsWithin(pos))
		{
			continue;
		}

		//double disbuf = PlayerParam::instance().GetEpsInSight(mpObserver->UnknownPlayer(i).Dist()); // please look at line 3301 in MemPosition.C in WE2008a
		double disbuf = 0.1 * mpObserver->UnknownPlayer(i).Dist() + 0.66;
		if (mpObserver->UnknownPlayerBugInfo(i).mSide == mpObserver->UnknownPlayerBugInfo(i).mSupSide)
		{
			if (mpObserver->UnknownPlayerBugInfo(i).mLeastNum == mpObserver->UnknownPlayerBugInfo(i).mSupNum)
			{
				UnknownCount[i] = 1;
				int index = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ?  mpObserver->UnknownPlayerBugInfo(i).mLeastNum : mpObserver->UnknownPlayerBugInfo(i).mLeastNum  + TEAMSIZE;
				Unknown[i][index] = true;
				continue;
			}

			for (int j = mpObserver->UnknownPlayerBugInfo(i).mLeastNum;j <= mpObserver->UnknownPlayerBugInfo(i).mSupNum ;j++)
			{
					const PlayerState& player = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? GetTeammate(j) : GetOpponent(j);
					if (j == mSelfUnum && mpObserver->UnknownPlayerBugInfo(i).mSide == self_side)
					{
						continue;
					}
					double dist = (is_special_mode ? 0 : ComputePlayerMaxDist(player)) + disbuf;
					if (player.GetPosDelay() != 0&& ComputePlayerMaySeeOrNot(player) && (pos - player.GetPos()).Mod() <= dist)
					{
						//���ܳ�Ϊ�Ķ�Ա
						UnknownCount[i]++;
						int index = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? j : j + TEAMSIZE;
						Unknown[i][index] = true;
					}
				}
		}
		else
		{
			if (mpObserver->UnknownPlayerBugInfo(i).mSide != 'l')
			{
				PRINT_ERROR("mpObserver->UnknownPlayerBugInfo(i).mSide != 'l'");
			}

			for (int j = mpObserver->UnknownPlayerBugInfo(i).mLeastNum;j <= TEAMSIZE;j++)
			{
					const PlayerState& player = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? GetTeammate(j) : GetOpponent(j);
					if (j == mSelfUnum && mpObserver->UnknownPlayerBugInfo(i).mSide == self_side)
					{
						continue;
					}
					double dist = (is_special_mode ? 0 :ComputePlayerMaxDist(player) )+ disbuf;
					if (player.GetPosDelay() != 0&& ComputePlayerMaySeeOrNot(player) && (pos - player.GetPos()).Mod() <= dist)
					{
						//���ܳ�Ϊ�Ķ�Ա
						UnknownCount[i]++;
						int index = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? j : j + TEAMSIZE;
						Unknown[i][index] = true;
					}
			}

			for (int j = 1;j <= mpObserver->UnknownPlayerBugInfo(i).mSupNum ;j++)
			{
					const PlayerState& player = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? GetOpponent(j) : GetTeammate(j);
					if (j == mSelfUnum && mpObserver->UnknownPlayerBugInfo(i).mSide !=  self_side)
					{
						continue;
					}
					double dist = (is_special_mode ? 0 : ComputePlayerMaxDist(player) )+ disbuf;
					if (player.GetPosDelay() != 0&& ComputePlayerMaySeeOrNot(player) && (pos - player.GetPos()).Mod() <= dist)
					{
						//���ܳ�Ϊ�Ķ�Ա
						UnknownCount[i]++;
						int index = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? j + TEAMSIZE : j;
						Unknown[i][index] = true;
					}
			}
		}
	}

	//2.������δ֪��Աoj����oj ��ƥ���б�ֻ��1 ��Ԫ��ʱ���Ѹ�Ԫ�ض�Ӧ������Աpi ��oj ƥ�䣬��O �����Ƴ�oj����ͨ��pi ƥ���б���ѯ��
	//������������ƥ���δ֪��Ա����pi �����ǵ�ƥ���б����Ƴ���
	//2.when there is only one element in oj list, then the old player pi should match with oj. Remove oj from O,
	//then find another player that may match with oj in pi's matching list, then remove pi from pi's matching list
	for (int i = 0;i < player_num;i++)
	{
		bool is_update = false; //�ж���û�и���
		for (int j = 0;j < player_num;j++)
		{
			if (UnknownCount[j] == 1)
			{
				//����
				//update
				int k = 0;
				for (k = 1;k <= 2*TEAMSIZE;k++)
				{
					//�ж��Ƿ�����֪
					//judge if known
					if (Unknown[j][k])
					{
						if (k <= TEAMSIZE)
						{
#ifdef __UNKNOWN_TEST
test_num++;					//���¶���
file << mpObserver->LatestSightTime() << "unknown guess teammate: " << k << std::endl;
#endif
							UpdateSpecificUnknownPlayer(mpObserver->UnknownPlayer(j) , k , true);
						}
						else
						{
#ifdef __UNKNOWN_TEST
test_num++;							//���¶���
file << mpObserver->LatestSightTime() << "unknown guess opponent: " << k - TEAMSIZE << std::endl;
#endif
							UpdateSpecificUnknownPlayer(mpObserver->UnknownPlayer(j) , k - TEAMSIZE , false);
						}
						UnknownUpdate[j] = true;
						break;
					}
				}

				//û�������
				//continue
				if (k > 2*TEAMSIZE )
				{
					UnknownCount[j] = 0;
					std::cout << " error : ������ֵ�����!" << std::endl;
					continue;
				}

				//��ԭ�е�������ȥ�������
				//remove matched couple from origin array
				for (int m = 0;m < player_num;m++)
				{
					if (Unknown[m][k])
					{
						Unknown[m][k] = false;
						UnknownCount[m]--;
					}
/*
					//����server��bug�����صĺ����ǴӴ�С��˳���
					if (m < j)
					{
						int bound = TEAMSIZE;
						if (k > TEAMSIZE)
						{
							bound = TEAMSIZE * 2;
						}

						for (int n = k + 1;n <= bound;n++)
						{
							if (Unknown[m][n])
							{
								Unknown[m][n] = false;
								UnknownCount[m]--;
							}
						}
					}
					else if (m > j)
					{
						int bound = 1;
						if ( k > TEAMSIZE)
						{
							bound = TEAMSIZE + 1;
						}

						for (int n = bound;n < k;n++)
						{
							if (Unknown[m][n])
							{
								Unknown[m][n] = false;
								UnknownCount[m]--;
							}
						}
					}*/
				}
				is_update = true;

			}
		}

		//������û�и��� ʹ��distance(pi,oj)��С��ԭ�� ��֤����һ�� ���ò���̫�� �Ľ�һ�£�����������ѡ�����
		if (!is_update)
		{
			int min = 200 * TEAMSIZE;
			int index = -1;
			bool is_all_zero = true; //
			for (int j = 0;j < player_num;j++)
			{
				if (UnknownCount[j] > 0 && UnknownCount[j] < min)
				{
					min = UnknownCount[j];
					index = j;
				}

				if (is_all_zero && UnknownCount[j] > 0)
				{
					is_all_zero = false;
				}
			}

			//ȫΪ���ʾ�������
			//update complete
			if (is_all_zero)
			{
				break;
			}

			//Ѱ������ĸ���
			//find the newest update
			if (index != -1)
			{
				//Ѱ���������Ա
				//find the nearest player
				Vector pos = Polar2Vector(PlayerParam::instance().ConvertSightDist(mpObserver->UnknownPlayer(index).Dist()) , GetNeckGlobalDirFromSightDelay(mSightDelay) + mpObserver->UnknownPlayer(index).Dir()) + GetSelf().GetPos();
				double min_dist = 200000;
				int min_index = -1;
				for (int k = 1;k <= 2*TEAMSIZE;k++)
				{
					if (Unknown[index][k])
					{
						Vector compare_pos;
						if (k <= TEAMSIZE)
						{
							compare_pos = GetTeammate(k).GetPos();
						}
						else
						{
							compare_pos = GetOpponent(k - TEAMSIZE).GetPos();
						}

						if ( (pos - compare_pos).Mod() < min_dist)
						{
							min_dist = (pos - compare_pos).Mod();
							min_index = k;
						}
					}
				}

				if (min_index <= TEAMSIZE && min_index > 0)
				{
#ifdef __UNKNOWN_TEST
test_num++;					//���¶���
file << mpObserver->LatestSightTime() << "unknown guess teammate: " << min_index << std::endl;
#endif
					UpdateSpecificUnknownPlayer(mpObserver->UnknownPlayer(index) , min_index , true);
					UnknownUpdate[index] = true;
				}
				else if (min_index > TEAMSIZE && min_index <= TEAMSIZE * 2)
				{
#ifdef __UNKNOWN_TEST
test_num++;					//���¶���
file << mpObserver->LatestSightTime() << "unknown guess opponent: " << min_index - TEAMSIZE << std::endl;
#endif
					UpdateSpecificUnknownPlayer(mpObserver->UnknownPlayer(index) , min_index - TEAMSIZE , false);
					UnknownUpdate[index] = true;
				}
				else if (min_index == -1)	//��ʱӦ��û�ж�Ա��
											//no player
				{
					UnknownCount[index] = 0;
					continue;
				}

				//���ɵ�count��Ϊ��
				//set 0
				UnknownCount[index] = 0;

				//��ԭ�е�������ȥ�������
				//remove matched couple from origin array
				for (int m = 0;m < player_num;m++)
				{
					if (Unknown[m][min_index])
					{
						Unknown[m][min_index] = false;
						UnknownCount[m]--;
					}
/*
					//����server��bug�����صĺ����ǴӴ�С��˳���
					if (m < index)
					{
						int bound = TEAMSIZE;
						if (min_index > TEAMSIZE)
						{
							bound = TEAMSIZE * 2;
						}

						for (int n = min_index + 1;n <= bound;n++)
						{
							if (Unknown[m][n])
							{
								Unknown[m][n] = false;
								UnknownCount[m]--;
							}
						}
					}
					else if (m > index)
					{
						int bound = 1;
						if ( min_index > TEAMSIZE)
						{
							bound = TEAMSIZE + 1;
						}

						for (int n = bound;n < min_index;n++)
						{
							if (Unknown[m][n])
							{
								Unknown[m][n] = false;
								UnknownCount[m]--;
							}
						}
					}*/
				}

				is_update = true;
			}
		}

	}

	for (int i = 0;i < player_num;i++)
	{
		if (!UnknownUpdate[i])
		{
			Vector pos = Polar2Vector(PlayerParam::instance().ConvertSightDist(mpObserver->UnknownPlayer(i).Dist()) , GetNeckGlobalDirFromSightDelay(mSightDelay) + mpObserver->UnknownPlayer(i).Dir());
			pos = GetSelf().GetPos() + pos;

			if (!is_special_mode)
			{
				UnknownUpdate[i] = UpdateMostSimilarPlayer(pos ,i);
				continue;
			}

			//next just for special mode
			if (is_special_mode && !ServerParam::instance().pitchRectanglar().IsWithin(pos))
			{
				continue;
			}

			//��ʼʶ��ʱ������Ҫ6���ڲ��ܿ�ȫ���г���
			//6 cycles at least to see all the field
			if (mpObserver->UnknownPlayerBugInfo(i).mSide == mpObserver->UnknownPlayerBugInfo(i).mSupSide)
			{
				for (int j = mpObserver->UnknownPlayerBugInfo(i).mLeastNum;j <= mpObserver->UnknownPlayerBugInfo(i).mSupNum;j++)
				{
					const PlayerState& player = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? GetTeammate(j) : GetOpponent(j);

					if (j == mSelfUnum && mpObserver->UnknownPlayerBugInfo(i).mSide == self_side)
					{
						continue;
					}

					if (player.GetPosDelay() > 6)
					{
						this->UpdateSpecificUnknownPlayer(mpObserver->UnknownPlayer(i) , abs(player.GetUnum()) , player.GetUnum() > 0);
						UnknownUpdate[i] = true;
						break;
					}
				}
			}
			else
			{
				bool is_continue = true;
				for (int j = mpObserver->UnknownPlayerBugInfo(i).mLeastNum;j <= TEAMSIZE;j++)
				{
					const PlayerState& player = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? GetTeammate(j) : GetOpponent(j);

					if (j == mSelfUnum && mpObserver->UnknownPlayerBugInfo(i).mSide == self_side)
					{
						continue;
					}

					if (player.GetPosDelay() > 6)
					{
						this->UpdateSpecificUnknownPlayer(mpObserver->UnknownPlayer(i) , abs(player.GetUnum()) , player.GetUnum() > 0);
						UnknownUpdate[i] = true;
						is_continue = false;
						break;
					}
				}

				if (is_continue)
				{
					for (int j = 1;j <= mpObserver->UnknownPlayerBugInfo(i).mSupNum;j++)
					{
						const PlayerState& player = mpObserver->UnknownPlayerBugInfo(i).mSide == self_side ? GetOpponent(j) : GetTeammate(j);

						if (j == mSelfUnum && mpObserver->UnknownPlayerBugInfo(i).mSide != self_side)
						{
							continue;
						}

						if (player.GetPosDelay() > 6)
						{
							this->UpdateSpecificUnknownPlayer(mpObserver->UnknownPlayer(i) , abs(player.GetUnum()) , player.GetUnum() > 0);
							UnknownUpdate[i] = true;
							break;
						}
					}
				}
			}
		}

	}

}

bool  WorldStateUpdater::UpdateMostSimilarPlayer(Vector pos ,int index)
{
	bool is_known_side = mpObserver->UnknownPlayer(index).IsKnownSide();
	int least_num = mpObserver->UnknownPlayerBugInfo(index).mLeastNum;

	int min_index = 0;
	double min = 100000;


	if (is_known_side)
	{
		if (mpObserver->UnknownPlayer(index).Side() != mpObserver->UnknownPlayerBugInfo(index).mSide)
		{
			least_num = 1;
		}
		for (int i = least_num;i <= TEAMSIZE;i++)
		{
			const PlayerState& player = mpObserver->UnknownPlayer(index).Side() == mSelfSide ? mpWorldState->GetTeammate(i) : mpWorldState->GetOpponent(i);
			if (player.GetPosDelay() != 0 && (player.GetPos() - pos).Mod() < min)
			{
				min = (player.GetPos() - pos).Mod();
				min_index = player.GetUnum();
			}
		}
	}
	else
	{
		for (int i = 1;i <= TEAMSIZE;i++)
		{
			const PlayerState& player = mpObserver->UnknownPlayerBugInfo(index).mSide == mSelfSide ? mpWorldState->GetTeammate(i) : mpWorldState->GetOpponent(i);
			const PlayerState& opp_player = mpObserver->UnknownPlayerBugInfo(index).mSide == mSelfSide ? mpWorldState->GetOpponent(i) : mpWorldState->GetTeammate(i);
			if (i >= least_num)
			{
				if (player.GetPosDelay() != 0 && (player.GetPos() - pos).Mod() < min)
				{
					min = (player.GetPos() - pos).Mod();
					min_index = player.GetUnum();
				}
			}

			if (opp_player.GetPosDelay() != 0 && (opp_player.GetPos() - pos).Mod() < min)
			{
				min = (opp_player.GetPos() - pos).Mod();
				min_index = opp_player.GetUnum();
			}
		}
	}

	if (min_index != 0)
	{
		bool is_teammate = min_index > 0;
		this->UpdateSpecificUnknownPlayer(mpObserver->UnknownPlayer(index) , abs(min_index) , is_teammate);
		return true;
	}
	else
	{
		return false;
	}
}



double WorldStateUpdater::ComputePlayerMaxDist(const PlayerState &state)
{
	//���������ٶ�
	//compute max speed
	double max_speed = PlayerParam::instance().HeteroPlayer(state.GetPlayerType()).effectiveSpeedMax();

	return max_speed * state.GetPosDelay();
}

void WorldStateUpdater::UpdateSpecificUnknownPlayer(const UnknownPlayerObserver &player, Unum unum, bool is_teammate)
{
	if (is_teammate)
	{
		Teammate(unum).SetIsAlive(true);
		Teammate(unum).UpdateGuessedTimes(0);
		//λ�ø���
		//update position
		if (player.GetDir().time() == mpObserver->LatestSightTime())
		{
			Vector vec = Polar2Vector(PlayerParam::instance().ConvertSightDist(player.Dist()) , GetNeckGlobalDirFromSightDelay(mSightDelay) + player.Dir());
			vec = GetSelf().GetPos() + vec;
			Teammate(unum).UpdatePos(vec ,mSightDelay , mPlayerConf);

			double eps = PlayerParam::instance().GetEpsInSight(player.Dist()) + SelfState().GetPosEps();
			Teammate(unum).UpdatePosEps(eps);
		}

		//���½�����λ��
		//update position that near self
		int delay = mpWorldState->GetHistory(1 + mSightDelay)->Teammate(unum).GetPosDelay();
		if (delay < HISTORYSIZE - 1 - mSightDelay)
		{
			Vector 	vel = Teammate(unum).GetPos() - mpWorldState->GetHistory(1 + mSightDelay + delay)->Teammate(unum).GetPos();
			vel /= (delay + 1);

			//use  speed of self sense instead of pos of self sight to reduce the error
			Vector self_vel = GetSelfVelFromSightDelay(mSightDelay);
			if (mpObserver->Sense().IsCollideWithBall() || mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithPost())
			{
				self_vel /= -0.1;
			}
			self_vel /= PlayerParam::instance().HeteroPlayer(SelfState().GetPlayerType()).playerDecay();
			Vector self_vel_pos = SelfState().GetPos() - mpWorldState->GetHistory(1 + mSightDelay)->Teammate(GetSelfUnum()).GetPos();
			vel += self_vel - self_vel_pos;

			double max_speed = PlayerParam::instance().HeteroPlayer(mpObserver->GetTeammateType(unum)).effectiveSpeedMax();
			//�����ٶȴ��²²⳯�� ���Ӿ�ʱ�Ḳ��
			//guess body direction according to speed
			if (vel.Mod()  > max_speed * mpWorldState->GetTeammate(unum).GetPlayerDecay() * 0.8 &&  GetTeammate(unum).IsBodyDirMayChanged())
			{
//				Logger::instance().GetTextLogger("bodydir") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << unum<< "\t" << vel.Dir() << "\t" << GetTeammate(unum).GetBodyDir() << "\n";
				Teammate(unum).UpdateBodyDir(vel.Dir() , GetTeammate(unum).GetBodyDirDelay() , GetTeammate(unum).GetBodyDirConf());
//				Teammate(unum).UpdateBodyDirMayChanged(false);
			}
			else if (vel.Mod() <= max_speed * mpWorldState->GetTeammate(unum).GetPlayerDecay())
			{
				Teammate(unum).UpdateBodyDirMayChanged(true);
			}


//			Logger::instance().GetTextLogger("bodydir") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << unum<< "\t" << GetTeammate(unum).GetBodyDir() << "\n";
			if (vel.Mod() > max_speed)
			{
				vel = Polar2Vector(max_speed , vel.Dir());
			}

			vel *= PlayerParam::instance().HeteroPlayer(mpObserver->GetTeammateType(unum)).playerDecay();


			Teammate(unum).UpdateVel(vel ,mSightDelay , mPlayerConf);
		}

		//�Ƿ����
		//check takcling
		if (player.IsKnownSide())
		{
			if (player.GetIsTackling().time() == mpObserver->LatestSightTime())
			{
				if (player.IsTackling())
				{
					if (Teammate(unum).GetTackleBan() == 0)
					{
						Teammate(unum).UpdateTackleBan(ServerParam::instance().tackleCycles() - 1);

					}
					//tackle �ٶ�һ��Ϊ0
					Teammate(unum).UpdateVel(Vector(0,0), mSightDelay , mPlayerConf);
				}
				else {
					Teammate(unum).UpdateTackleBan(0);
				}
			}
			//�Ƿ��������߹���
			//if kicked last cycle
			if (player.GetIsKicked().time() == mpObserver->LatestSightTime())
			{
				Teammate(unum).UpdateKicked(player.IsKicked());
			}
		}

	}
	else
	{
		Opponent(unum).SetIsAlive(true);
		Opponent(unum).UpdateGuessedTimes(0);
		//λ�ø���
		//update position
		if (player.GetDir().time() == mpObserver->LatestSightTime())
		{
			Vector vec = Polar2Vector(PlayerParam::instance().ConvertSightDist(player.Dist()) , GetNeckGlobalDirFromSightDelay(mSightDelay) + player.Dir());
			vec = GetSelf().GetPos() + vec;
			Opponent(unum).UpdatePos(vec , mSightDelay , mPlayerConf);

			double eps = PlayerParam::instance().GetEpsInSight(player.Dist()) + SelfState().GetPosEps();
			Opponent(unum).UpdatePosEps(eps);
		}

		//�������ٶȸ���
		//update velocity that near self
		int delay = mpWorldState->GetHistory(1 + mSightDelay)->Opponent(unum).GetPosDelay();
		if (delay < HISTORYSIZE - 1 - mSightDelay)
		{
			Vector vel = Opponent(unum).GetPos() - mpWorldState->GetHistory(1 + mSightDelay + delay)->Opponent(unum).GetPos();
			vel /= (delay + 1);

			//use  speed of self sense instead of pos of self sight to reduce the error
			Vector self_vel = GetSelfVelFromSightDelay();
			if (mpObserver->Sense().IsCollideWithBall() || mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithPost())
			{
				self_vel /= -0.1;
			}
			self_vel /= PlayerParam::instance().HeteroPlayer(SelfState().GetPlayerType()).playerDecay();
			Vector self_vel_pos = SelfState().GetPos() - mpWorldState->GetHistory(1 + mSightDelay)->Teammate(GetSelfUnum()).GetPos();
			vel += self_vel - self_vel_pos;


			double max_speed = GetOpponent(unum).GetEffectiveSpeedMax();

			//�����ٶ�Ԥ��������峯��
			//guess body direction according to velocity
			if (vel.Mod()  > max_speed * GetOpponent(unum).GetPlayerDecay() * 0.8 &&  GetOpponent(unum).IsBodyDirMayChanged())
			{
//				Logger::instance().GetTextLogger("bodydir") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << unum + TEAMSIZE<< "\t" << vel.Dir() << "\t" << GetOpponent(unum).GetBodyDir() << "\n";
				Opponent(unum).UpdateBodyDir(vel.Dir() , GetOpponent(unum).GetBodyDirDelay() , GetOpponent(unum).GetBodyDirConf());
//				Opponent(unum).UpdateBodyDirMayChanged(false);
			}
			else if (vel.Mod() <= max_speed * GetOpponent(unum).GetPlayerDecay())
			{
				Opponent(unum).UpdateBodyDirMayChanged(true);
			}

//			Logger::instance().GetTextLogger("bodydir") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << unum + TEAMSIZE<< "\t" << GetOpponent(unum).GetBodyDir() << "\n";
			if (vel.Mod() > max_speed)
			{
				vel = Polar2Vector(max_speed , vel.Dir());
			}
			vel *= GetOpponent(unum).GetPlayerDecay();

			Opponent(unum).UpdateVel(vel , mSightDelay , mPlayerConf);
		}

		//�Ƿ����
		//tackle
		if (player.IsKnownSide())
		{
			if (player.GetIsTackling().time() == mpObserver->LatestSightTime())
			{
				if (player.IsTackling())
				{
					if (Opponent(unum).GetTackleBan() == 0)
					{
						Opponent(unum).UpdateTackleBan(ServerParam::instance().tackleCycles() - 1);
					}
					Opponent(unum).UpdateVel(Vector(0,0) , mSightDelay ,mPlayerConf);
				}
				else
				{
					Opponent(unum).UpdateTackleBan(0);
				}
			}
			//�Ƿ��������߹���
			//kicked
			if (player.GetIsKicked().time() == mpObserver->LatestSightTime())
			{
				Opponent(unum).UpdateKicked(player.IsKicked());
			}
		}

	}
}

void WorldStateUpdater::AutoDelay(int delay_add)
{
	//team��delayһ����
	//teammate
	for (Unum i = 1; i <= TEAMSIZE; i++)
	{
		mpWorldState->mTeammate[i].AutoUpdate(delay_add , PlayerParam::instance().playerConfDecay());
		mpWorldState->mOpponent[i].AutoUpdate(delay_add , PlayerParam::instance().playerConfDecay());
	}

	//��delayһ����
	//ball
	Ball().AutoUpdate(delay_add , PlayerParam::instance().ballConfDecay());

	//���⴦��
	//some other update
	SelfState().UpdateBodyDir(SelfState().GetBodyDir(), SelfState().GetBodyDirDelay(), 1.0);	//��Ϊ�Լ������巽��϶��������
																								//my body direction is known
	SelfState().UpdateVel(SelfState().GetVel(), SelfState().GetVelDelay(), 1.0);				//��Ϊ�Լ����ٶȿ϶��������
																								//my velocity is known
}

void WorldStateUpdater::EstimateToNow()
{
	if (mSightDelay > 0)
	{
		//������sense��ص���Ϣ ��Ҫ�� mSelfVel mNeckDir
		//keep information of sense such as mSelfVel, mNeckDir etc.
		const Vector & vel = SelfState().GetVel();

		SelfState().UpdateVel(mpWorldState->GetHistory(mSightDelay)->mTeammate[mSelfUnum].GetVel());
		int cycle = mSightDelay;
		for (int i = 0;i < cycle;i++)
		{
			EstimateWorld(true , cycle - i);
		}

		//�ָ��ֳ� ��ʱӦ�ÿ����� delay������Ϊ0
		//recover
		SelfState().UpdateVel(vel);

		//��ʱ������Ϣ�������� ���¸���������Ϣ �������������
		if (SelfState().GetPos().Dist(Ball().GetPos()) < ServerParam::instance().visibleDistance() * 2)
		{
			UpdateFromHearInfo();
		}
	}
}
void WorldStateUpdater::EstimateWorld(bool is_estimate_to_now ,int cycle)
{
	/**Ԥ���Լ�����Ϣ*/
	EstimateSelf(is_estimate_to_now , cycle);

	/**Ԥ�������Ϣ*/
	EstimateBall(is_estimate_to_now , cycle);

	/**Ԥ����Ա����Ϣ*/
	EstimatePlayers();
}

void WorldStateUpdater::EstimateSelf(bool is_estimate_to_now ,int cycle)
{
	(void)cycle;
	bool is_collided = mpObserver->Sense().IsCollideWithPlayer() || mpObserver->Sense().IsCollideWithBall() || mpObserver->Sense().IsCollideWithPost();
	if (mpObserver->GetPlayerDashTime() == mpObserver->CurrentTime())
	{
		if (is_collided)
		{
			//��ײ�����ڲ�����̫����,ֱ����Ϊ��׼.
			//error max when colliding
			SelfState().UpdatePosEps(10000);
		}

		if (!is_estimate_to_now)
		{
			if (!is_collided)
			{
				//server�ڲ�����randpΪVel.Mod()*playerRand()
				//max randp is Vel.Mod()*playerRand()
				double eps = (SelfState().GetPos() - mpObserver->GetPlayerPosByDash()).Mod() * ServerParam::instance().playerRand();
				SelfState().UpdatePosEps(SelfState().GetPosEps() + eps);
			}
			SelfState().UpdatePos(mpObserver->GetPlayerPosByDash(), SelfState().GetPosDelay(), SelfState().GetPosConf());
			SelfState().UpdateVel(mpObserver->GetPlayerVelByDash(), SelfState().GetVelDelay(), SelfState().GetVelConf());
		}
		else
		{
			const PlayerState& player = mpWorldState->GetHistory(1)->GetTeammate(mSelfUnum);
			Vector accel = mpObserver->GetPlayerPosByDash() - player.GetPos() - player.GetVel();
			Vector vel = SelfState().GetVel() + accel;

			if (!is_collided)
			{
				double eps = vel.Mod() * ServerParam::instance().playerRand();
				SelfState().UpdatePosEps(SelfState().GetPosEps() + eps);
			}

			Vector pos = SelfState().GetPos() + vel;
			vel *= SelfState().GetPlayerDecay();
			SelfState().UpdatePos(pos, SelfState().GetPosDelay(), SelfState().GetPosConf());
			SelfState().UpdateVel(vel,SelfState().GetVelDelay(), SelfState().GetVelConf());
		}
	}
	else
	{
		if (is_collided)
		{
			//��ײ�����ڲ�����̫����,ֱ����Ϊ��׼.
			//error max when colliding
			SelfState().UpdatePosEps(10000);
		}
		else
		{
			SelfState().UpdatePosEps(SelfState().GetPosEps() + SelfState().GetVel().Mod() * ServerParam::instance().playerRand());
		}
	   	ComputeNextCycle(SelfState(), PlayerParam::instance().HeteroPlayer(GetSelf().GetPlayerType()).playerDecay());
	}

	if (mpObserver->GetPlayerMoveTime() == mpObserver->CurrentTime())
	{
		SelfState().UpdatePos(mpObserver->GetPlayerPosByMove() , GetSelf().GetPosDelay() , GetSelf().GetPosConf());
		SelfState().UpdateVel(mpObserver->GetPlayerVelByMove() , GetSelf().GetVelDelay() , GetSelf().GetVelConf());
	}

	//Ԥ������Ƕ�
	//estimate body angle
	if (mpObserver->GetPlayerTurnTime() == mpObserver->CurrentTime())
	{
		if (!is_estimate_to_now)
		{
			SelfState().UpdateBodyDir(mpObserver->GetPlayerBodyDirByTurn() , GetSelf().GetBodyDirDelay() , GetSelf().GetBodyDirConf());
		}
		else
		{
			const PlayerState& player = mpWorldState->GetHistory(1)->GetTeammate(mSelfUnum);
			double eff_moment = mpObserver->GetPlayerBodyDirByTurn() - player.GetBodyDir();
			double body_dir = GetNormalizeAngleDeg(eff_moment + SelfState().GetBodyDir());
			SelfState().UpdateBodyDir(body_dir , GetSelf().GetBodyDirDelay() , GetSelf().GetBodyDirConf());
		}
	}

	//Ԥ��ͷ���Ƕ�
	//estimate head angle
	if (!is_estimate_to_now && mpObserver->GetPlayerTurnNeckTime() == mpObserver->CurrentTime())
	{
		SelfState().UpdateNeckDir(mpObserver->GetPlayerNeckDirByTurnNeck() , GetSelf().GetNeckDirDelay() , GetSelf().GetNeckDirConf());
	}
}

void WorldStateUpdater::EstimateBall(bool is_estimate_to_now , int cycle)
{
	if (!is_estimate_to_now &&  mpObserver->GetBallKickTime() == mpObserver->CurrentTime())
	{
		double eps = (2 * SelfState().GetKickRand() + mpObserver->GetBallVelByKick().Mod() / ServerParam::instance().ballDecay()) * ServerParam::instance().ballRand();
		Ball().UpdatePosEps(Ball().GetPosEps() + eps);
		Ball().UpdateVelEps(Ball().GetVelEps() + eps  * ServerParam::instance().ballDecay());
		Ball().UpdatePos(mpObserver->GetBallPosByKick() , GetBall().GetPosDelay() , GetBall().GetPosConf());
		Ball().UpdateVel(mpObserver->GetBallVelByKick() , GetBall().GetVelDelay() , GetBall().GetVelConf());

		Logger::instance().GetTextLogger("ball_info") << mpWorldState->CurrentTime().T() << "\t" << mpWorldState->CurrentTime().S() << "\t" << Ball().GetVel().X() << "\t" << Ball().GetVel().Y()  << "\t" << Ball().GetVelEps() << "\n"; 
	}
	else if(is_estimate_to_now && cycle == 1 && mpObserver->GetBallKickTime() == mpObserver->CurrentTime())
	{
		Vector pos = mpWorldState->GetHistory(1)->GetBall().GetPos();

		Vector vel = mpObserver->GetBallPosByKick() - pos;
		pos = vel + Ball().GetPos();
		vel  *= ServerParam::instance().ballDecay();

		Ball().UpdatePos(pos ,  GetBall().GetPosDelay() , GetBall().GetPosConf());
		Ball().UpdateVel(vel ,  GetBall().GetVelDelay() , GetBall().GetVelConf());
	}
	else
	{
		double eps = (Ball().GetVel().Mod() + Ball().GetVelEps()) * ServerParam::instance().ballRand() * ServerParam::instance().ballDecay();
		Ball().UpdateVelEps(Ball().GetVelEps() + eps);

		eps = (Ball().GetVel().Mod() + Ball().GetVelEps() ) * ServerParam::instance().ballRand();
		Ball().UpdatePosEps(Ball().GetPosEps() + eps + Ball().GetVelEps());

		ComputeNextCycle(Ball() , ServerParam::instance().ballDecay());
		Ball().UpdatePos(LimitToField(Ball().GetPos()) , Ball().GetPosDelay() ,Ball().GetPosConf()); //limit ball in  field
	}

}

void WorldStateUpdater::EstimatePlayers()
{
	//�����ٶȵ���һ����Ԥ���Ա������ǰһ���ڵ��ٶȼ�������
	for (Unum i = 1;i <= TEAMSIZE;i++)
	{
		if (i != mSelfUnum){

			if (Teammate(i).GetVelDelay() <= 1)
			{
				Teammate(i).UpdateVel(Teammate(i).GetVel() / Teammate(i).GetPlayerDecay() , Teammate(i).GetVelDelay() , Teammate(i).GetVelConf());
			}
			ComputeNextCycle(Teammate(i), PlayerParam::instance().HeteroPlayer(Teammate(i).GetPlayerType()).playerDecay());
		}

		if (Opponent(i).GetVelDelay() <= 1)
		{
			Opponent(i).UpdateVel(Opponent(i).GetVel() / Opponent(i).GetPlayerDecay(), Opponent(i).GetVelDelay() , Opponent(i).GetVelConf());
		}
		ComputeNextCycle(Opponent(i), PlayerParam::instance().HeteroPlayer(Opponent(i).GetPlayerType()).playerDecay());
	}
}

Unum WorldStateUpdater::GetSeenClosestTeammate()
{
	Unum num = 0;
	double min = 20000;
	for (int i = 1; i <= TEAMSIZE; i++)
	{
		if (i != mSelfUnum){
			if (mpObserver->Teammate(i).GetDist().time() == mpObserver->CurrentTime())
			{
				if (mpObserver->Teammate(i).Dist() < min)
				{
					min = mpObserver->Teammate(i).Dist();
					num = i;
				}
			}
		}
	}

	return num;
}

Unum WorldStateUpdater::GetSeenClosestOpponent()
{
	Unum num = 0;
	double min = 20000;
	for (int i = 1;i <=TEAMSIZE;i++)
	{
		if (mpObserver->Opponent(i).GetDist().time() == mpObserver->CurrentTime())
		{
			if (mpObserver->Opponent(i).Dist() < min)
			{
				min = mpObserver->Opponent(i).Dist();
				num = i;
			}
		}
	}

	return num;
}

bool WorldStateUpdater::ComputeNextCycle(MobileState& ms , double decay)
{
	ms.UpdatePos(ms.GetPos() + ms.GetVel(), ms.GetPosDelay(), ms.GetPosConf());
	ms.UpdateVel(ms.GetVel() * decay, ms.GetVelDelay(), ms.GetVelConf());

	return true;
}

void WorldStateUpdater::EvaluateConf()
{
	for (int i = 1;i <= TEAMSIZE;i++)
	{
		if (i != mSelfUnum) {
			EvaluatePlayer(Teammate(i) , true);
		}

		EvaluatePlayer(Opponent(i) , false);
	}
/*
	if (ComputeShouldSeeOrNot(GetBall().GetPos()) && GetBall().GetPosDelay() != 0 && mpObserver->IsNewSight())
	{
		Ball().UpdatePos(GetBall().GetPos(), GetBall().GetPosDelay(), 0);
	}
*/
	//����delay����Ա����
	int dead_level = 100;
	for (int i = 1;i <= TEAMSIZE;i++)
	{
		if (i != mSelfUnum && GetTeammate(i).IsAlive())
		{
			if (GetTeammate(i).GetPosDelay() > dead_level)
			{
				Teammate(i).SetIsAlive(false);
			}
		}

		if (GetOpponent(i).IsAlive())
		{
			if (GetOpponent(i).GetPosDelay() > dead_level)
			{
				Opponent(i).SetIsAlive(false);
			}
		}
	}

	//evaluate ball
	EvaluateBall();
}


void WorldStateUpdater::EvaluateBall()
{
	//if drop ball just forget
	//
	if (mpWorldState->IsBallDropped() && Ball().GetPosDelay() != 0)
	{
		EvaluateForgetBall();
		return;
	}

	if (!mpObserver->IsNewSight())
	{
		return;
	}

	if (Ball().GetPosDelay() != 0 && SelfState().GetPosDelay() == 0)
	{
		if (Ball().GetGuessedTimes() == 100) //guess too many times just forget
		{
			EvaluateForgetBall();
			return;
		}

		double neck_angle = SelfState().GetNeckGlobalDir();
		double view_angle = 0;
		switch(GetSelf().GetViewWidth())
		{
		case VW_Narrow:
			view_angle = 60;
			break;
		case VW_Normal:
			view_angle = 120;
			break;
		case VW_Wide:
			view_angle = 180;
			break;
		default:
			view_angle = 120;
		}

		view_angle /= 2;

		Vector rel_pos = (Ball().GetPos() - SelfState().GetPos()).Rotate(-neck_angle);
		double rel_dir = rel_pos.Dir();
		bool binviewangle = fabs(rel_dir) < view_angle;
		bool binfeeldistance = rel_pos.Mod() < ServerParam::instance().visibleDistance();
		if (rel_dir < 0)
		{
			view_angle = -view_angle;
		}

		//move ball edge of view position if it should not be forgotten
		Vector guess_pos;
		double dis = 0,min_cycle = -1;
		double one_minus_ball_decay = 1 - ServerParam::instance().ballDecay();
		double log_ball_decay = log(ServerParam::instance().ballDecay());
		double max_speed = ServerParam::instance().ballSpeedMax();
		if (binviewangle)
		{
			if (binfeeldistance)
			{
				dis = ServerParam::instance().visibleDistance();
				rel_dir = view_angle;
				guess_pos = Vector(Cos(view_angle) ,Sin(view_angle)) * dis;
				min_cycle = log(1 - guess_pos.Dist(rel_pos) * one_minus_ball_decay / max_speed) / log_ball_decay;
			}
			else
			{
				dis = rel_pos.Mod();
				rel_dir = view_angle;
				guess_pos = Vector(Cos(view_angle) ,Sin(view_angle)) * dis;
				min_cycle = log(1 - guess_pos.Dist(rel_pos) * one_minus_ball_decay / max_speed) / log_ball_decay;
			}
		}
		else
		{
			if (binfeeldistance)
			{
				dis = ServerParam::instance().visibleDistance();
				min_cycle = log(1 - (dis - rel_pos.Mod()) * one_minus_ball_decay / max_speed)  / log_ball_decay;
			}
			else
			{
				return;
			}
		}

		int cyc = Min((int)(min_cycle + 0.99) , Ball().GetPosDelay());
		if (Ball().GetGuessedTimes() > 0)
		{
			if (Ball().GetPosDelay() <= cyc + 1 || Ball().GetGuessedTimes() > 3)
			{
				EvaluateForgetBall();
				return;
			}
		}
		else if (Ball().GetPosDelay() < cyc)
		{
			EvaluateForgetBall();
			return;
		}

		Ball().UpdateGuessedTimes(Ball().GetGuessedTimes() + 1);

		//move ball
		double dist = dis;
		double abs_angle = neck_angle + rel_dir;
		Vector pos = SelfState().GetPos() + Polar2Vector(dist , abs_angle);
		Ball().UpdatePos(pos , Ball().GetPosDelay() , Ball().GetPosConf());
	}//if(Ball().GetPosDelay() != 0)
}

void WorldStateUpdater::EvaluateForgetBall()
{
	//Ball().UpdatePos(Ball().GetPos() , Ball().GetPosDelay() , 0);
	Ball().UpdatePos(Vector(0,0) , Ball().GetPosDelay() , 0); //as WE2008
	Ball().UpdateVel(Vector(0,0) , Ball().GetPosDelay() , 0); //as WE2008
	Ball().UpdateGuessedTimes(100);
}

void WorldStateUpdater::EvaluatePlayer(PlayerState& player , bool is_teammate)
{
	if (!mpObserver->IsNewSight())
	{
		return;
	}

	if (player.GetPosDelay() != 0 && player.IsAlive() && SelfState().GetPosDelay() == 0)
	{
		if (player.GetGuessedTimes() == 100)
		{
			EvaluateForgetPlayer(player);
		}

		double neck_angle = SelfState().GetNeckGlobalDir();
		double view_angle = 0;
		switch(GetSelf().GetViewWidth())
		{
		case VW_Narrow:
			view_angle = 60;
			break;
		case VW_Normal:
			view_angle = 120;
			break;
		case VW_Wide:
			view_angle = 180;
			break;
		default:
			view_angle = 120;
		}

		view_angle /= 2;

		Vector rel_pos = (player.GetPos() - SelfState().GetPos()).Rotate(-neck_angle);
		double rel_dir = rel_pos.Dir();
		bool binviewangle = fabs(rel_dir) < view_angle;
		bool binfeeldistance = rel_pos.Mod() < ServerParam::instance().visibleDistance();
		if (rel_dir < 0)
		{
			view_angle = -view_angle;
		}

		//move player to  edge of view position if it should not be forgotten
		Vector guess_pos;
		double dis = 0,min_cycle = -1;
		if (binviewangle)
		{
			if (binfeeldistance)
			{
				dis = ServerParam::instance().visibleDistance();
				rel_dir = view_angle;
				guess_pos = Vector(Cos(view_angle) ,Sin(view_angle)) * dis;
				min_cycle = CalcPlayerGotoPoint(player , guess_pos.Dist(rel_pos));
			}
			else
			{
				dis = rel_pos.Mod();
				rel_dir = view_angle;
				guess_pos = Vector(Cos(view_angle) ,Sin(view_angle)) * dis;
				min_cycle = CalcPlayerGotoPoint(player , guess_pos.Dist(rel_pos));

				Vector guess_pos2 = Vector(Cos(view_angle) , -Sin(view_angle)) * dis;
				double min_cycle2 = CalcPlayerGotoPoint(player , guess_pos2.Dist(rel_pos));
				//special tackle
				if ((!is_teammate && abs(player.GetUnum()) == GetClosestOpponent()) || (is_teammate && abs(player.GetUnum()) == mpWorldState->GetTeammateGoalieUnum() ) || (!is_teammate && abs(player.GetUnum()) == mpWorldState->GetOpponentGoalieUnum()))
				{
//std::cout << "opponent goalie Unum : " << mpWorldState->GetOpponentGoalieUnum() << std::endl;
					if ((int)(min_cycle2 + 0.99) <= player.GetPosDelay())
					{
						if (!is_teammate && abs(player.GetUnum()) == mpWorldState->GetOpponentGoalieUnum() && Ball().GetPosDelay() < 10)
						{
							const Vector & ball_pos = Ball().GetPos();
							double ang2goalmid = (ServerParam::instance().oppGoal() - ball_pos).Dir();
							double ang2goal    = (guess_pos.Rotate(SelfState().GetNeckGlobalDir()) + SelfState().GetPos() - ball_pos).Dir();
							double ang2goal2   = (guess_pos2.Rotate(SelfState().GetNeckGlobalDir()) + SelfState().GetPos() - ball_pos).Dir();
							if (GetAngleDegDiffer(ang2goalmid ,ang2goal2) < GetAngleDegDiffer(ang2goalmid ,ang2goal))
							{
								rel_dir = -view_angle;
								min_cycle = min_cycle2;
							}
						}
						else
						{
							Vector goalPt;
							if (GetClosestPlayerToBall() > 0 && !(is_teammate && abs(player.GetUnum()) == mpWorldState->GetTeammateGoalieUnum()))
							{
								Vector pos = ServerParam::instance().oppGoal();
								goalPt = pos.Rotate(-SelfState().GetNeckGlobalDir());
							}
							else
							{
								goalPt = (Ball().GetPos() + Ball().GetVel() - SelfState().GetPos()).Rotate(-SelfState().GetNeckGlobalDir());
							}

							if (guess_pos2.Dist2(goalPt) < guess_pos.Dist2(goalPt))
							{
								rel_dir = -view_angle;
								min_cycle = min_cycle2;
							}
						}
					}
				}
				else
				{
					if ((int)(min_cycle2 + 0.99) <= player.GetPosDelay() && player.GetGuessedTimes() == 0)
					{
                        Vector relFPT;
                        if (is_teammate)
                        {
                            relFPT = (TeammateFormation::instance().GetFormationPoint(*mpWorldState , true ,player.GetUnum()) - SelfState().GetPos()).Rotate(-SelfState().GetNeckGlobalDir());
						}
                        else if (!is_teammate && OpponentFormation::instance().IsRoleValid())
						{
							relFPT = (OpponentFormation::instance().GetFormationPoint(*mpWorldState , false , -player.GetUnum()) - SelfState().GetPos()).Rotate(-SelfState().GetNeckGlobalDir());
						}
						else
						{
							relFPT = (Ball().GetPos() + Ball().GetVel() - SelfState().GetPos()).Rotate(-SelfState().GetNeckGlobalDir());
						}

						if(guess_pos2.Dist2(relFPT) < guess_pos.Dist2(relFPT))
						{
							rel_dir = -view_angle;
							min_cycle = min_cycle2;
						}
					}
				}

			}
		}
		else
		{
			if (binfeeldistance)
			{
				dis = ServerParam::instance().visibleDistance();
				min_cycle = CalcPlayerGotoPoint(player , fabs(dis - rel_pos.Mod()));
			}
			else
			{
				return;
			}
		}

	//��ʱ���ж���Ա��������,�����08��һ��
		int cyc = Min((int)(min_cycle + 0.99) , player.GetPosDelay());
		if (player.GetGuessedTimes() > 0)
		{
			if (player.GetPosDelay() <= cyc || player.GetGuessedTimes() > 5)
			{
				EvaluateForgetPlayer(player);
				return;
			}
		}
		else if (player.GetPosDelay() < cyc)
		{
			EvaluateForgetPlayer(player);
			return;
		}

		player.UpdateGuessedTimes(player.GetGuessedTimes() + 1);

		//move player
		double dist = dis;
		double abs_angle = neck_angle + rel_dir;
		Vector pos = SelfState().GetPos() + Polar2Vector(dist , abs_angle);

		player.UpdatePos(pos , player.GetPosDelay() ,player.GetPosConf());
	}
}

void WorldStateUpdater::EvaluateForgetPlayer(PlayerState& player)
{
	//i think it will cause trouble with UpdateUnknownPlayer ,it need test.
	player.SetIsAlive(false);
	player.UpdatePos(Vector(0,0) , player.GetPosDelay() , 0);
	player.UpdateVel(Vector(0,0) , player.GetVelDelay() , 0);
	player.UpdateBodyDir(0 , player.GetBodyDirDelay() , 0);
	player.UpdateNeckDir(0 , player.GetNeckDirDelay() , 0);
	player.UpdateGuessedTimes(100);
}

double  WorldStateUpdater::CalcPlayerGotoPoint(PlayerState& player , double dist)
{
	//very simple ,different from WE2008 ,it will be changed if not so good
	double max_speed = player.GetEffectiveSpeedMax() ;

	return dist / max_speed ;
}

Unum  WorldStateUpdater::GetClosestOpponent()
{
	double min_dist = 200000;
	int  min_index = -1;
	for (int i = 1;i <= TEAMSIZE;i++)
	{
		if(GetOpponent(i).IsAlive())
		{
			if ((GetOpponent(i).GetPos() - SelfState().GetPos()).Mod() < min_dist)
			{
				min_dist = (GetOpponent(i).GetPos() - SelfState().GetPos()).Mod();
				min_index = i;
			}
		}
	}
	return min_index;
}

Unum WorldStateUpdater::GetClosestPlayerToBall()
{
	double min_dist = 20000;
	int min_index = 0;
	for (int i = 1;i <= TEAMSIZE;i++)
	{
		if (GetTeammate(i).IsAlive())
		{
			if ((GetTeammate(i).GetPos() - Ball().GetPos()).Mod() < min_dist)
			{
				min_dist = (GetTeammate(i).GetPos() - Ball().GetPos()).Mod();
				min_index = i;
			}
		}
		if (GetOpponent(i).IsAlive())
		{
			if ((GetOpponent(i).GetPos() - Ball().GetPos()).Mod() < min_dist)
			{
				min_dist = (GetOpponent(i).GetPos() - Ball().GetPos()).Mod();
				min_index = - i;
			}
		}
	}


	return min_index;
}

bool WorldStateUpdater::ComputeShouldSeeOrNot(Vector pos)
{
	double view_angle = 0;
	switch(GetSelf().GetViewWidth())
	{
	case VW_Narrow:
		view_angle = 60;
		break;
	case VW_Normal:
		view_angle = 120;
		break;
	case VW_Wide:
		view_angle = 180;
		break;
	default:
		view_angle = 120;
	}
	
	//���λ������Լ��ļн�
	//get position's angle relative to self angle
	Vector dist_vec = pos - GetSelf().GetPos();
	double angle = GetNormalizeAngleDeg(dist_vec.Dir());
	angle = ::fabs(::GetNormalizeAngleDeg(angle - GetSelf().GetNeckGlobalDir()));
	double anglebuf = ASin((1 * 0.6 + 0.05 * dist_vec.Mod() ) / dist_vec.Mod());
	angle += anglebuf; //different from ComputePlayerMaySeeOrNot

	//��ȫ�ӽ��ڿɼ�
	//visible
	double distbuf = 0.05 * ServerParam::instance().visibleDistance();
	if (dist_vec.Mod() <= ServerParam::instance().visibleDistance() - distbuf)
	{
		return true;
	}

	//�Ƕ����ӽ���
	//angle is within my view width
	if (angle > view_angle / 2)
	{
		return false;
	}

	return true;

}
void WorldStateUpdater::UpdateInfoFromPlayMode()
{
	if (mpObserver->GetPlayMode() == PM_Before_Kick_Off) //ע����ʱ��֪��PM_AfterGoal_Right�Ĳ��� ��ʱ�����ǺǺ�
	{
/*		for (int i = 1;i <= TEAMSIZE ;i++)
		{
			//��ע�͵�����Ϊ�˷���bug
			if (i == mSelfUnum)
			{
				continue;
			}

			if ((mSelfSide == 'l' && mpObserver->CurrentTime().T() < ServerParam::instance().halfTime()) || (mSelfSide == 'r' && mpObserver->CurrentTime().T() >= ServerParam::instance().halfTime()))
			{
				Teammate(i).UpdatePos(TeammateFormation::instance().GetInitialPosition(i , PM_Our_Mode));
			}
			else
			{
				Teammate(i).UpdatePos(TeammateFormation::instance().GetInitialPosition(i , PM_Opp_Mode));
			}
			Teammate(i).UpdateVel(Vector(0,0));
		}

		Ball().UpdatePos(Vector(0,0));*/
	}
/*
	if (mpObserver->GetPlayMode() == PM_Goal_Opps)
	{
		for (int i = 1;i <= TEAMSIZE;i++)
		{
			if (i == mSelfUnum)
			{
				continue;
			}
			Teammate(i).SetIsAlive(true);
			Teammate(i).UpdatePos(TeammateFormation::instance().GetInitialPosition(i , PM_Our_Mode));
			Teammate(i).UpdateVel(Vector(0,0));
			Ball().UpdatePos(Vector(0,0));
		}
	}

	if (mpObserver->GetPlayMode() == PM_Goal_Ours)
	{
		for (int i = 1;i <= TEAMSIZE;i++)
		{
			if (i == mSelfUnum)
			{
				continue;
			}
			Teammate(i).SetIsAlive(true);
			Teammate(i).UpdatePos(TeammateFormation::instance().GetInitialPosition(i , PM_Opp_Mode));
			Teammate(i).UpdateVel(Vector(0,0));
			Ball().UpdatePos(Vector(0,0));
		}
	}
*/
    if ((mpObserver->GetPlayMode() == PM_Our_Penalty_Setup) ||
        (mpObserver->GetPlayMode() == PM_Opp_Penalty_Setup))
    {
        Ball().UpdatePos(Vector(ServerParam::instance().PITCH_LENGTH / 2.0 - ServerParam::instance().penDistX(), 0.0));
    }

    if ((mpObserver->GetPlayMode() == PM_Our_Goalie_Free_Kick))
    {
        Ball().UpdateVel(Vector(0,0));
        if (mSelfUnum == mpWorldState->GetTeammateGoalieUnum())
        {
            const PlayerState & self_state = mpWorldState->GetTeammate(mSelfUnum);
            const double dist = self_state.GetPlayerSize() + ServerParam::instance().ballSize();
            Ball().UpdatePos(self_state.GetPos() + Vector(dist, 0.0).Rotate(self_state.GetBodyDir()));
        }
    }

	//������Ϣֻ��playMode�ı�ʱ����
	//update when play mode changed
	if (mpWorldState->GetPlayModeTime() == mpWorldState->CurrentTime())
	{
		double x ,y;
		switch(mpWorldState->GetPlayMode())
		{
			case PM_Our_Kick_Off:
			case PM_Opp_Kick_Off:
				//Ball().UpdatePos(Vector(0,0));
				Ball().UpdateVel(Vector(0,0));
				break;
			case PM_Our_Corner_Kick:
				x = 1.0 * ServerParam::instance().PITCH_LENGTH * 0.5;
				y = Sign(mpWorldState->GetHistory(1)->GetBall().GetPos().Y()) * ServerParam::instance().PITCH_WIDTH * 0.5;
				Ball().UpdatePos(Vector(x , y));
				Ball().UpdateVel(Vector(0,0));
				break;
			case PM_Opp_Corner_Kick:
				x = -1.0 * ServerParam::instance().PITCH_LENGTH * 0.5;
				y = Sign(mpWorldState->GetHistory(1)->GetBall().GetPos().Y()) * ServerParam::instance().PITCH_WIDTH * 0.5;
				Ball().UpdatePos(Vector(x ,y));
				Ball().UpdateVel(Vector(0,0));
				break;
			case PM_Our_Goal_Kick:
				x = -1.0 * (ServerParam::instance().PITCH_LENGTH * 0.5 - ServerParam::instance().GOAL_AREA_LENGTH);
				y = Sign(mpWorldState->GetHistory(1)->GetBall().GetPos().Y()) * ServerParam::instance().GOAL_AREA_WIDTH * 0.5;
				Ball().UpdatePos(Vector(x ,y));
				Ball().UpdateVel(Vector(0,0));
				break;
			case PM_Opp_Goal_Kick:
				x = 1.0 * (ServerParam::instance().PITCH_LENGTH * 0.5 - ServerParam::instance().GOAL_AREA_LENGTH);
				y = Sign(mpWorldState->GetHistory(1)->GetBall().GetPos().Y()) * ServerParam::instance().GOAL_AREA_WIDTH * 0.5;
				Ball().UpdatePos(Vector(x ,y));
				Ball().UpdateVel(Vector(0,0));
				break;
			case PM_Our_Back_Pass_Kick:
			case PM_Opp_Back_Pass_Kick:
				//TODO:we2008�㷨ʹ�õ��˽����,����WE2009�д˽����֧��ʹ�ý�����Ϣ,��˶Դ����˼�.
				Ball().UpdateVel(Vector(0,0));
				break;
			case PM_Our_Offside_Kick:
			case PM_Opp_Offside_Kick:
				Ball().UpdateVel(Vector(0,0));
				break;
			default:
				break;
		}
	}
}

void WorldStateUpdater::MaintainPlayerStamina()
{
	for (unsigned int i = 0; i < mpWorldState->GetPlayerList().size(); ++i) {
		PlayerState * player = mpWorldState->GetPlayerList()[i];

        // ����������Ա��mMinStamina
		// update all players' mMinStamina
        player->UpdateMinStamina(PlayerParam::instance().MinStamina());
        if (player->GetUnum() == mSelfUnum &&	// ��ʱֻ�����Լ�
												// only for self
            mpWorldState->CurrentTime().T() <= ServerParam::instance().halfTime() * ServerParam::instance().nrNormalHalfs()) // ����ʱ��
        {
            const int reserve_cycle = ServerParam::instance().halfTime() - mpWorldState->CurrentTime().T() % ServerParam::instance().halfTime(); // ����볡��ʣ��������
            const int cycle_buffer = (int)((player->GetStamina() + player->GetExtraStamina()) / ServerParam::instance().maxPower());
            if (reserve_cycle <= cycle_buffer)	// ������Ϊÿ���볡������������ڿ��Բ���������
												// no consideration about stamina when the last few cycles of a half of the game
            {
                player->UpdateMinStamina(0.0);
            }
        }

		const PlayerState * last_cycle_player = & mpWorldState->GetHistory(1)->GetPlayer(player->GetUnum());
		if (player->GetUnum() == mSelfUnum) continue;
		if (player->IsAlive() && last_cycle_player->IsAlive()) {
			double power = 0.0; //��Ϊû��dash
								//no dash

			if (player->GetVelDelay() == 0 && last_cycle_player->GetVelDelay() == 0) {	//һ��ȷ����dash -- ��ʱ�����ǲ�dash
																						//a dash action
				double acc = (player->GetVel() - last_cycle_player->GetVel() * player->GetDecay()).Mod();
				power = acc / (player->GetDashPowerRate() * last_cycle_player->GetEffort());
			}

			double stamina = last_cycle_player->GetStamina();
			double recovery = last_cycle_player->GetRecovery();
			double effort = last_cycle_player->GetEffort();

			stamina -= (power > 0.0)? power: -2.0 * power;
			if( stamina  <= ServerParam::instance().recoverDecStamina() && recovery > ServerParam::instance().recoverMin() )
				recovery -= ServerParam::instance().recoverDec();
			if( stamina  <= ServerParam::instance().effortDecStamina() && effort > last_cycle_player->GetEffortMin() )
				effort -= ServerParam::instance().effortDec();
			if( stamina  >= ServerParam::instance().effortIncStamina() && effort < 1.0 ) {
				effort += ServerParam::instance().effortInc();
				if ( effort > 1.0 ) {
					effort = 1.0;
				}
			}
			stamina  += recovery * last_cycle_player->GetStaminaIncMax();
			if ( stamina  > ServerParam::instance().staminaMax() ) {
				stamina  = ServerParam::instance().staminaMax();
			}
			// tracer stamina may error, give the min stamina
			if (stamina < ServerParam::instance().recoverDecStamina() + 100) {
				stamina = ServerParam::instance().recoverDecStamina() + 100;
			}

			player->UpdateStamina(stamina);
			player->UpdateEffort(effort);
			player->UpdateRecovery(recovery);
		}
		else {
			player->UpdateStamina(ServerParam::instance().staminaMax());
			player->UpdateEffort(player->GetEffortMax());
			player->UpdateRecovery(1.0);
		}
	}
}

void WorldStateUpdater::MaintainConsistency()
{
	for (unsigned int i = 0; i < mpWorldState->GetPlayerList().size(); ++i) {
		PlayerState * player = mpWorldState->GetPlayerList()[i];
		if (player->GetUnum() == mSelfUnum) continue;
		if (player->IsAlive()) {
			if (player->IsGoalie() || player->GetPlayerType() != 0) {
				Vector vel = player->GetVel();
				if (vel.Mod() > player->GetEffectiveSpeedMax() * player->GetDecay()) {
					vel = vel.Normalize() * player->GetEffectiveSpeedMax() * player->GetDecay();
					player->UpdateVel(vel, player->GetVelDelay(), player->GetVelConf());
				}
			}
		}
	}

    Vector vel = Ball().GetVel();
	if (vel.Mod() > ServerParam::instance().ballSpeedMax() * ServerParam::instance().ballDecay()) {
		vel = vel.Normalize() * ServerParam::instance().ballSpeedMax() * ServerParam::instance().ballDecay();
		Ball().UpdateVel(vel, Ball().GetVelDelay(), Ball().GetVelConf());
	}
}

double WorldStateUpdater::ComputeTackleProb(const Unum & unum)
{
    const PlayerState & player = mpWorldState->GetPlayer(unum);
    if (mpWorldState->GetPlayMode() == PM_Before_Kick_Off ||
        player.IsAlive() == false ||
        player.IsTackling() == true)
    {
        return 0.0;
    }

    const Vector & ball_pos = mpWorldState->GetBall().GetPos();
    const Vector & player_pos = player.GetPos();
    Vector ball_2_player = ball_pos - player_pos;
    if (ball_2_player.Mod() > ServerParam::instance().maxTackleDist())
    {
        return 0.0;
    }

    const Vector & v = player.GetVel();
    double bodyang = player.GetBodyDir();
    if (player.GetBodyDirConf() > 0.9)
    {
        bodyang = player.GetBodyDir();
	}
    else if (v.Mod() > 0.2)
    {
		bodyang = v.Dir();
	}
    else
    {
        Vector posdiff = player.GetPos() - mpWorldState->GetHistory(1)->GetPlayer(unum).GetPos();
		if (posdiff.Mod() > 0.12)
        {
			bodyang = posdiff.Dir();
		}
	}

    ball_2_player = ball_2_player.Rotate(-bodyang);
	return GetTackleProb(ball_2_player);
}

void HistoryState::UpdateHistory(const WorldState &world)
{
	mNum = mNum % HISTORYSIZE;
	mRecord[mNum] = world;

	mNum++;
}

WorldState *HistoryState::GetHistory(int num)
{
	Assert(num > 0);

	num = (num % HISTORYSIZE);
	num = (mNum + HISTORYSIZE - num) % HISTORYSIZE;

	return &mRecord[num];
}
//end of WorldState.cpp
