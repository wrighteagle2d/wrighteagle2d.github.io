/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "Formation.h"
#include "Agent.h"
#include "PlayerParam.h"

FormationBase::FormationBase(Unum goalie_num, FormationType type):
	mGoalieUnum(goalie_num),
    mFormationType(type)
{
    memset(mHInterval, 0, sizeof(mHInterval));
    memset(mVInterval, 0, sizeof(mVInterval));

    memset(mHBallFactor, 0, sizeof(mHBallFactor));
    memset(mVBallFactor, 0, sizeof(mVBallFactor));
    memset(mActiveField, 0, sizeof(mActiveField));

    memset(mLineArrange, 0, sizeof(mLineArrange));

    memset(mIndex2Unum, 0, sizeof(mIndex2Unum));
}


Vector FormationBase::GetExpectedGoaliePos(const Vector & ball_pos, const double run, const Vector & goalie_pos, const int & cycle_delay)
{
    Vector p[2];
    p[0] = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, -ServerParam::instance().goalWidth() / 2.0 + 0.1); // top
    p[1] = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, ServerParam::instance().goalWidth() / 2.0 - 0.1); // down

    double tmp, distg;
    distg = ball_pos.Dist(goalie_pos);
	AngleDeg mid;
	mid = GetNormalizeAngleDeg(((p[1]- ball_pos).Dir() + (p[0]- ball_pos).Dir()) / 2);
	tmp = ball_pos.Dist(Vector(ServerParam::instance().PITCH_LENGTH / 2.0, 0.0)) - 2.0;
	Vector tgPos, jgPos;
	tgPos = ball_pos + Polar2Vector(distg, mid); 
	if (tgPos.Dist(ball_pos) > tmp)
    {
        tgPos = ball_pos + (tgPos - ball_pos).SetLength(tmp); 
    }
    if (goalie_pos.Dist(tgPos) < run + cycle_delay * 0.8)
    {
        jgPos = tgPos; 
    }
    else
    {
        jgPos = goalie_pos + Polar2Vector(run + cycle_delay * 0.8, (tgPos - goalie_pos).Dir());
    }
	return jgPos;
}


const Vector & FormationBase::GetFormationCenter(const WorldState & world_state, bool is_teammate, double min_conf)
{
    double conf = 0.0;
	double total_conf = 0.0;
	Vector center = Vector(0.0, 0.0);

	for (Unum i = 1; i <= TEAMSIZE; ++i)
    {
        if (is_teammate)
        {
		    if (i == world_state.GetTeammateGoalieUnum())
            {
                continue;
		    }
		    conf = world_state.GetTeammate(i).GetPosConf();
		    if (conf > min_conf)
            {
                center += ( world_state.GetTeammate(i).GetPos() + mOffsetMatrix[mFormationType][i][0]) * conf;
			    total_conf += conf;
		    }
        }
        else
        {
            if (i == world_state.GetOpponentGoalieUnum())
            {
                continue;
		    }
            conf = world_state.GetOpponent(i).GetPosConf();
		    if (conf > min_conf)
            {
                center += ( world_state.GetOpponent(i).GetPos() + mOffsetMatrix[mFormationType][i][0]) * conf;
			    total_conf += conf;
		    }
        }
	}

    mFormationCT = center / total_conf;
	return mFormationCT;
}


void FormationBase::SetFormationCenter(Unum num, Vector position)
{
    Assert(num >= 1 && num <= TEAMSIZE);
	position = mActiveField[mFormationType][num].AdjustToWithin(position);
	mFormationCT = position + mOffsetMatrix[mFormationType][num][0];
}


Vector FormationBase::GetFormationPoint(const WorldState & world_state, bool is_teammate, Unum unum, double min_conf)
{
    Assert(unum >= 1 && unum <= TEAMSIZE);
    if (is_teammate)
    {
        if (unum == world_state.GetTeammateGoalieUnum())
        {
            return Vector(-45.0, 0.0);
        }
        else
        {
            return GetFormationCenter(world_state, is_teammate, min_conf) + mOffsetMatrix[mFormationType][0][unum];
        }
    }
    else
    {
        if (unum == world_state.GetOpponentGoalieUnum())
        {
            return Vector(45.0, 0.0);
        }
        else
        {
            return GetFormationCenter(world_state, is_teammate, min_conf) - mOffsetMatrix[mFormationType][0][unum];
        }
    }
}


void FormationBase::SetPassGraph(FormationType type)
{
    for (int i = 1; i <= TEAMSIZE; ++i)
    {
        mPassGraph[type][i].clear();

        for (int j = 1; j <= TEAMSIZE; ++j)
        {
            if (i == j || i == mGoalieUnum || j == mGoalieUnum)
            {
                continue;
            }
            if (abs(mPlayerRole[type][i].mIndexX - mPlayerRole[type][j].mIndexX) <= 1 &&
                abs(mPlayerRole[type][i].mIndexY - mPlayerRole[type][j].mIndexY) <= 1)
            {
                mPassGraph[type][i].push_back(j);
            }
        }
    }


    Unum unum = 0;
    std::vector<Unum>::iterator it;
    if (mLineArrange[type][0] == 4 && mLineArrange[type][1] == 3 && mLineArrange[type][2] == 3) 
    {
        unum = mIndex2Unum[type][1][4];
        mPassGraph[type][unum].push_back(mIndex2Unum[type][2][2]);

        unum = mIndex2Unum[type][2][3];
        for (it = mPassGraph[type][unum].begin(); it != mPassGraph[type][unum].end(); ++it)
        {
            if (*it == mIndex2Unum[type][1][2])
            {
                mPassGraph[type][unum].erase(it);
                break;
            }
        }

        unum = mIndex2Unum[type][1][2];
        for (it = mPassGraph[type][unum].begin(); it != mPassGraph[type][unum].end(); ++it)
        {
            if (*it == mIndex2Unum[type][2][3])
            {
                mPassGraph[type][unum].erase(it);
                break;
            }
        }

        unum = mIndex2Unum[type][2][2];
        mPassGraph[type][unum].push_back(mIndex2Unum[type][1][4]);
    }
    else if (mLineArrange[type][0] == 4 && mLineArrange[type][1] == 4 && mLineArrange[type][2] == 2) 
    {
        unum = mIndex2Unum[type][2][1];
        for (it = mPassGraph[type][unum].begin(); it != mPassGraph[type][unum].end(); ++it)
        {
            if (*it == mIndex2Unum[type][3][2])
            {
                mPassGraph[type][unum].erase(it);
                break;
            }
        }

        unum = mIndex2Unum[type][3][1];
        mPassGraph[type][unum].push_back(mIndex2Unum[type][2][3]);

        unum = mIndex2Unum[type][2][4];
        mPassGraph[type][unum].push_back(mIndex2Unum[type][3][2]);

        unum = mIndex2Unum[type][3][2];
        for (it = mPassGraph[type][unum].begin(); it != mPassGraph[type][unum].end(); ++it)
        {
            if (*it == mIndex2Unum[type][2][1])
            {
                mPassGraph[type][unum].erase(it);
                break;
            }
        }
        mPassGraph[type][unum].push_back(mIndex2Unum[type][2][4]);

        unum = mIndex2Unum[type][2][3];
        mPassGraph[type][unum].push_back(mIndex2Unum[type][3][1]);
    }
    else 
    {
    }
}


TeammateFormation::TeammateFormation(Unum goalie_unum, FormationType type): FormationBase(goalie_unum, type)
{
    InitFormationInfo();
}


TeammateFormation::~TeammateFormation()
{
}


TeammateFormation & TeammateFormation::instance()
{
	static TeammateFormation teammate_formation(PlayerParam::instance().ourGoalieUnum(), FT_Attack_Forward);
	return teammate_formation;
}


void TeammateFormation::InitFormationInfo(const bool is_coach_say, const int coach_say_time, const int line_arrange[], const int unum_arrange[])
{
    SetUnumArrange(FT_Attack_Forward, 4, 3, 3);
    SetUnumArrange(FT_Defend_Back, 4, 3, 3);
    SetUnumArrange(FT_Attack_Midfield, 4, 4, 2);
    SetUnumArrange(FT_Defend_Midfield, 4, 4, 2);

    if (is_coach_say && line_arrange[0] == 4 && line_arrange[1] == 3 && line_arrange[2] == 3)
    {
        for (int ft = 0; ft < FT_Max; ++ft)
        {
            if (mLineArrange[ft][0] == 4 && mLineArrange[ft][1] == 3 && mLineArrange[ft][2] == 3) 
            {
                for (int i = 0; i < TEAMSIZE; ++i)
                {
                    mUnumArrange[ft][i] = unum_arrange[i];
                }
            }
            else if (mLineArrange[ft][0] == 4 && mLineArrange[ft][1] == 4 && mLineArrange[ft][2] == 2) 
            {
                for (int i = 0; i < 5; ++i)
                {
                    mUnumArrange[ft][i] = unum_arrange[i];
                }


                mUnumArrange[ft][5] = unum_arrange[5];
                mUnumArrange[ft][6] = (coach_say_time % 2 == 0) ? unum_arrange[6] : unum_arrange[9];
                mUnumArrange[ft][7] = (coach_say_time % 2 == 0) ? unum_arrange[9] : unum_arrange[6];
                mUnumArrange[ft][8] = unum_arrange[7];


                mUnumArrange[ft][9] = unum_arrange[8];
                mUnumArrange[ft][10] = unum_arrange[10];
            }
        }
    }


    SetTeammateRole(FT_Attack_Forward);
    SetHInterval(FT_Attack_Forward, 13.5, 10.5);
    SetVInterval(FT_Attack_Forward, 9.0, 13.0, 16.0);

    SetTeammateRole(FT_Defend_Back);
    SetHInterval(FT_Defend_Back, 9.5, 13.5);
    SetVInterval(FT_Defend_Back, 9.0, 10.0, 16.0);

    SetTeammateRole(FT_Attack_Midfield);
    SetHInterval(FT_Attack_Midfield, 13.5, 10.5);
    SetVInterval(FT_Attack_Midfield, 9.0, 16.0, 50.0);

    SetTeammateRole(FT_Defend_Midfield);
    SetHInterval(FT_Defend_Midfield, 9.5, 13.5);
    SetVInterval(FT_Defend_Midfield, 9.0, 13.0, 50.0);
}


void TeammateFormation::SetUnumArrange(FormationType type, int defender, int midfielder, int forward)
{
	int line_max = 6; 
	if (defender > line_max || midfielder > line_max || forward > line_max)
	{
		PRINT_ERROR("too many players in one line");
		return;
	}

	if (defender + midfielder + forward + 1 != TEAMSIZE)
	{
		PRINT_ERROR("too many players for a team");
		return;
	}

	for (int i = 0; i < TEAMSIZE; ++i) 
	{
		mUnumArrange[type][i] = 0;
	}


    mUnumArrange[type][0] = mGoalieUnum;
    std::vector<Unum> unum_vector; 
    for (int i = 1; i <= TEAMSIZE; ++i)
    {
        if (i != mGoalieUnum)
        {
            unum_vector.push_back(i);
        }
    }


    unsigned index = 0;
	mUnumArrange[type][1]                     = unum_vector[index++];
	mUnumArrange[type][defender + 1]          = unum_vector[index++];
	mUnumArrange[type][TEAMSIZE - forward]    = unum_vector[index++];
	mUnumArrange[type][defender]              = unum_vector[index++];
	mUnumArrange[type][defender + midfielder] = unum_vector[index++];
	mUnumArrange[type][TEAMSIZE - 1]          = unum_vector[index++];


	for (int i = 0; i < TEAMSIZE; ++i)
	{
        if (index < unum_vector.size() && mUnumArrange[type][i] == 0)
		{
			mUnumArrange[type][i] = unum_vector[index++];
		}
	}

	mLineArrange[type][0] = defender;
	mLineArrange[type][1] = midfielder;
	mLineArrange[type][2] = forward;
}


void TeammateFormation::SetTeammateRole(FormationType type)
{
	const Unum our_goalie_unum = mGoalieUnum;

	mPlayerRole[type][our_goalie_unum].mIndexX = 0;
	mPlayerRole[type][our_goalie_unum].mIndexY = 1;
	mPlayerRole[type][our_goalie_unum].mLineType = LT_Goalie;
	mPlayerRole[type][our_goalie_unum].mPositionType = PT_Middle;
	mIndex2Unum[type][0][1] = our_goalie_unum;

	int index_x = 1;
	int index_y = 1;

	for (int i = 0; i < TEAMSIZE; ++i)
	{
		if (mUnumArrange[type][i] == mGoalieUnum)
		{
			continue; 
		}

		mPlayerRole[type][mUnumArrange[type][i]].mIndexX = index_x;
		mPlayerRole[type][mUnumArrange[type][i]].mIndexY = index_y;
		mPlayerRole[type][mUnumArrange[type][i]].mLineType = LineType(index_x + 1);


        const int & index = mUnumArrange[type][i];
        const double midoffset = index_y - ( mLineArrange[type][index_x - 1] + 1) * 0.5;
		if (fabs(midoffset) < FLOAT_EPS)
        {
			mPlayerRole[type][index].mPositionType = PT_Middle;
		}
        else if (fabs(midoffset - 0.5) < FLOAT_EPS)
        {
			mPlayerRole[type][index].mPositionType = PT_RightMiddle;
		}
        else if (fabs(midoffset + 0.5) < FLOAT_EPS)
        {
			mPlayerRole[type][index].mPositionType = PT_LeftMiddle;
		}
        else if (fabs(midoffset - 1.25) < 0.25 + FLOAT_EPS)
        { 
			mPlayerRole[type][index].mPositionType = PT_Right;
		}
        else if (fabs(midoffset + 1.25) < 0.25 + FLOAT_EPS)
        { 
			mPlayerRole[type][index].mPositionType = PT_Left;
		}
        else if (midoffset > 2.0 - FLOAT_EPS)
        {
			mPlayerRole[type][index].mPositionType = PT_RightRight;
		}
        else
        {
			mPlayerRole[type][index].mPositionType = PT_LeftLeft;
		}

		mIndex2Unum[type][index_x][index_y] = mUnumArrange[type][i];

		
		++index_y;
		if (index_y > mLineArrange[type][index_x - 1])
		{
			++index_x;
			index_y = 1;
		}
	}

    SetPassGraph(type);
}


void TeammateFormation::SetHInterval(FormationType type, double back_middle, double middle_front)
{
	mHInterval[type][0] = back_middle;
	mHInterval[type][1] = middle_front;

	mHBallFactor[type] = (FORMATION_MAX_X - (back_middle + middle_front) / 2.0) / ServerParam::instance().PITCH_LENGTH * 2.0;
	mHBallFactor[type] = Max(0.0, mHBallFactor[type]);

	RoleType role_i, role_j;
	for (int i = 1; i <= TEAMSIZE; ++i)
	{
		if (i == mGoalieUnum)
		{
			continue;
		}

		role_i = mPlayerRole[type][i];
		if (role_i.mIndexX == 1) 
		{
			mActiveField[type][i].SetLeft(-FORMATION_MAX_X);
			mActiveField[type][i].SetRight(FORMATION_MAX_X - mHInterval[type][0] - mHInterval[type][1]);
			mOffsetMatrix[type][0][i].SetX(-mHInterval[type][0]);
			mOffsetMatrix[type][i][0].SetX(mHInterval[type][0]);
		}
		else if (role_i.mIndexX == 2) 
		{
			mActiveField[type][i].SetLeft(-FORMATION_MAX_X + mHInterval[type][0]);
			mActiveField[type][i].SetRight(FORMATION_MAX_X - mHInterval[type][1]);
			mOffsetMatrix[type][0][i].SetX(0.0);
			mOffsetMatrix[type][i][0].SetX(0.0);
		}
		else if (role_i.mIndexX == 3) 
		{
			mActiveField[type][i].SetLeft(-FORMATION_MAX_X + mHInterval[type][0] + mHInterval[type][1]);
			mActiveField[type][i].SetRight(FORMATION_MAX_X);
			mOffsetMatrix[type][0][i].SetX(mHInterval[type][1]);
			mOffsetMatrix[type][i][0].SetX(-mHInterval[type][1]);
		}

		for (int j = 1; j <= TEAMSIZE; ++j)
		{
			if (j == mGoalieUnum)
			{
				continue;
			}

			role_j = mPlayerRole[type][j];

			if (role_i.mIndexX == 1)
			{
				if (role_j.mIndexX == 1)
				{
					mOffsetMatrix[type][i][j].SetX(0.0);
				}
				else if (role_j.mIndexX == 2)
				{
					mOffsetMatrix[type][i][j].SetX(mHInterval[type][0]);
				}
				else if (role_j.mIndexX == 3)
				{
					mOffsetMatrix[type][i][j].SetX(mHInterval[type][0] + mHInterval[type][1]);
				}
			}
			else if (role_i.mIndexX == 2)
			{
				if (role_j.mIndexX == 1)
				{
					mOffsetMatrix[type][i][j].SetX(-mHInterval[type][0]);
				}
				else if (role_j.mIndexX == 2)
				{
					mOffsetMatrix[type][i][j].SetX(0.0);
				}
				else if (role_j.mIndexX == 3)
				{
					mOffsetMatrix[type][i][j].SetX(mHInterval[type][1]);
				}
			}
			else if (role_i.mIndexX == 3)
			{
				if (role_j.mIndexX == 1)
				{
					mOffsetMatrix[type][i][j].SetX(-mHInterval[type][0] - mHInterval[type][1]);

				}
				else if (role_j.mIndexX == 2)
				{
					mOffsetMatrix[type][i][j].SetX(-mHInterval[type][1]);
				}
				else if (role_j.mIndexX == 3)
				{
					mOffsetMatrix[type][i][j].SetX(0.0);
				}
			}
		}
	}
}


void TeammateFormation::SetVInterval(FormationType type, double back,
		double middle, double front) {
	mVInterval[type][0] = back;
	mVInterval[type][1] = middle;
	mVInterval[type][2] = front;

	double max_wide = Max(back * (mLineArrange[type][0] - 1), middle * (mLineArrange[type][1] - 1));
	max_wide = Max(max_wide, front * (mLineArrange[type][2] - 1));
	mVBallFactor[type] = (FORMATION_MAX_Y - max_wide / 2.0 ) / ServerParam::instance().PITCH_WIDTH * 2.0;
	mVBallFactor[type] = Max(0.0, mVBallFactor[type]);

	RoleType role_i, role_j;
	for (int i = 1; i <= TEAMSIZE; ++i)
	{
		if (i == mGoalieUnum)
		{
			continue;
		}

		role_i = mPlayerRole[type][i];
		mActiveField[type][i].SetTop(-FORMATION_MAX_Y + (role_i.mIndexY - 1) * mVInterval[type][role_i.mIndexX - 1]);
		mActiveField[type][i].SetBottom(FORMATION_MAX_Y - (mLineArrange[type][role_i.mIndexX - 1] - role_i.mIndexY) * mVInterval[type][role_i.mIndexX - 1]);
		double iy = (role_i.mIndexY - (mLineArrange[type][role_i.mIndexX - 1] + 1) / 2.0) * mVInterval[type][role_i.mIndexX - 1];
		mOffsetMatrix[type][0][i].SetY(iy);
		mOffsetMatrix[type][i][0].SetY(-iy);

		for (int j = 1; j <= TEAMSIZE; ++j)
		{
			if (j == mGoalieUnum)
			{
				continue;
			}

			role_j = mPlayerRole[type][j];
			double jy = (role_j.mIndexY - (mLineArrange[type][role_j.mIndexX - 1] + 1) / 2.0) * mVInterval[type][role_j.mIndexX - 1];
			mOffsetMatrix[type][i][j].SetY(jy - iy);
		}
	}
}


OpponentFormation::OpponentFormation(Unum goalie_unum, FormationType type): FormationBase(goalie_unum, type)
{
    for (int i = 0; i < FT_Max; ++i)
    {
        mUsedTimes[i] = 0;
	    mHIntervalTimes[i][0] = 0;
        mHIntervalTimes[i][1] = 0;
    }
}

OpponentFormation::~OpponentFormation()
{
}

OpponentFormation & OpponentFormation::instance()
{
	static OpponentFormation opponent_formation(0, FT_Attack_Forward); 
	return opponent_formation;
}


double OpponentFormation::mForwardMaxX = -100000;
double OpponentFormation::mDefenderMinX = 100000;


void OpponentFormation::SetFormationRole(const FormationType & formation_type)
{
	mLineArrange[formation_type][0] = mLineMember[formation_type][0].size();
	mLineArrange[formation_type][1] = mLineMember[formation_type][1].size();
	mLineArrange[formation_type][2] = mLineMember[formation_type][2].size();


	int xidx;
	int yidx;
	int n;
	for(n=1;n<=11;n++) mPlayerRole[formation_type][n].mLineType = LT_Null;
	for(xidx = 1; xidx <= 3 ; xidx++)
    {
		for(yidx = 1;yidx <= mLineArrange[formation_type][xidx-1]; yidx++)
        {
			n = mLineMember[formation_type][xidx-1][yidx-1]; 
			if(n == mGoalieUnum)
            {
                mIndex2Unum[formation_type][0][1] = n;
				mPlayerRole[formation_type][mGoalieUnum].mIndexX = 0;
				mPlayerRole[formation_type][mGoalieUnum].mIndexY = 1;
				mPlayerRole[formation_type][mGoalieUnum].mLineType = LT_Goalie;
			}
            else
            {
                mIndex2Unum[formation_type][xidx][yidx] = n;
				mPlayerRole[formation_type][n].mIndexX = xidx;
				mPlayerRole[formation_type][n].mIndexY = yidx;
				mPlayerRole[formation_type][n].mLineType = LineType(xidx + 1);
				double midoffset = yidx - ( mLineArrange[formation_type][xidx - 1] + 1) * 0.5;
				if(fabs(midoffset) < FLOAT_EPS)
                {
					mPlayerRole[formation_type][n].mPositionType = PT_Middle;
				}
                else if(fabs(midoffset - 0.5) < FLOAT_EPS)
                {
					mPlayerRole[formation_type][n].mPositionType = PT_RightMiddle;
				}
                else if(fabs(midoffset + 0.5) < FLOAT_EPS)
                {
					mPlayerRole[formation_type][n].mPositionType = PT_LeftMiddle;
				}
                else if(fabs(midoffset - 1.25) < 0.25 + FLOAT_EPS)
                { 
					mPlayerRole[formation_type][n].mPositionType = PT_Right;
				}
                else if(fabs(midoffset + 1.25) < 0.25 + FLOAT_EPS)
                { 
					mPlayerRole[formation_type][n].mPositionType = PT_Left;
				}
                else if(midoffset > 2.0 - FLOAT_EPS)
                {
					mPlayerRole[formation_type][n].mPositionType = PT_RightRight;
				}
                else
                {
					mPlayerRole[formation_type][n].mPositionType = PT_LeftLeft;
				}
			}
		}
	}

    SetPassGraph(formation_type);
}


void OpponentFormation::SetOffsetMatrix(const FormationType & formation_type)
{
	if(mHIntervalTimes[formation_type][0] == 0 || mHIntervalTimes[formation_type][1] ==0 ) return;
	RoleType iRole,jRole;
	const double MAXX = 50.0;
	const double MINX = -50.0;
	const double MAXY = 23.0;
	const double MINY = -23.0;

    mHBallFactor[formation_type] = ( MAXX - ( mHInterval[formation_type][0] + mHInterval[formation_type][1] ) * 0.5 ) / ServerParam::instance().PITCH_LENGTH * 2;
	mHBallFactor[formation_type] = Max(0,mHBallFactor[formation_type]);

	double maxwide = Max(mVInterval[formation_type][0] * ( mLineArrange[formation_type][0] - 1 ) , mVInterval[formation_type][1] * ( mLineArrange[formation_type][1] - 1 ));
	maxwide = Max(maxwide, mVInterval[formation_type][2] * (mLineArrange[formation_type][2] - 1) );
    mVBallFactor[formation_type] = ( MAXY - maxwide * 0.5 ) / ServerParam::instance().PITCH_WIDTH * 2;
	mVBallFactor[formation_type] = Max(0,mVBallFactor[formation_type]);


	for(int i=1;i<=11;i++){
		if(i == mGoalieUnum) continue;
		iRole = mPlayerRole[formation_type][i];
		if(iRole.mLineType == LT_Null) continue;
		if(iRole.mIndexX == 1){
			mActiveField[formation_type][i].SetLeft(MINX);
			mActiveField[formation_type][i].SetRight(MAXX - mHInterval[formation_type][1] - mHInterval[formation_type][0]);
		}else if(iRole.mIndexX == 2){
			mActiveField[formation_type][i].SetLeft(MINX + mHInterval[formation_type][0]);
			mActiveField[formation_type][i].SetRight(MAXX - mHInterval[formation_type][1]);
		}else if(iRole.mIndexX == 3){
			mActiveField[formation_type][i].SetLeft(MINX + mHInterval[formation_type][0] + mHInterval[formation_type][1]);
			mActiveField[formation_type][i].SetRight(MAXX);
		}
		mActiveField[formation_type][i].SetBottom( MAXY - (mLineArrange[formation_type][iRole.mIndexX - 1] - iRole.mIndexY) * mVInterval[formation_type][iRole.mIndexX - 1] );
		mActiveField[formation_type][i].SetTop( MINY + iRole.mIndexY * mVInterval[formation_type][iRole.mIndexX - 1] );

		if(iRole.mIndexX == 1){
			mOffsetMatrix[formation_type][0][i].SetX(-mHInterval[formation_type][0]);
			mOffsetMatrix[formation_type][i][0].SetX( mHInterval[formation_type][0]);
		}else if(iRole.mIndexX == 2){
			mOffsetMatrix[formation_type][0][i].SetX( 0);
			mOffsetMatrix[formation_type][i][0].SetX( 0);
		}else if(iRole.mIndexX == 3){
			mOffsetMatrix[formation_type][0][i].SetX( mHInterval[formation_type][1]);
			mOffsetMatrix[formation_type][i][0].SetX( -mHInterval[formation_type][1]);
		}

		double iy = ( iRole.mIndexY - mLineArrange[formation_type][iRole.mIndexX - 1] * 0.5 ) * mVInterval[formation_type][iRole.mIndexX - 1];
		mOffsetMatrix[formation_type][0][i].SetY( iy);
		mOffsetMatrix[formation_type][i][0].SetY( -iy);

		for(int j=1;j<11;j++){
			if(j == mGoalieUnum || i == j) continue;
			jRole = mPlayerRole[formation_type][j];
			if(jRole.mLineType == LT_Null) continue;

			if(iRole.mIndexX == 1){
				if(jRole.mIndexX == 1){
					mOffsetMatrix[formation_type][i][j].SetX(0.0);
				}else if(jRole.mIndexX == 2){
					mOffsetMatrix[formation_type][i][j].SetX(mHInterval[formation_type][0]);
				}else if(jRole.mIndexX == 3){
					mOffsetMatrix[formation_type][i][j].SetX(mHInterval[formation_type][0] + mHInterval[formation_type][1]);
				}
			}else if(iRole.mIndexX == 2){
				if(jRole.mIndexX == 1){
					mOffsetMatrix[formation_type][i][j].SetX(-mHInterval[formation_type][0]);
				}else if(jRole.mIndexX == 2){
					mOffsetMatrix[formation_type][i][j].SetX(0);
				}else if(jRole.mIndexX == 3){
					mOffsetMatrix[formation_type][i][j].SetX(mHInterval[formation_type][1]);
				}
			}else if(iRole.mIndexX == 3){
				if(jRole.mIndexX == 1){
					mOffsetMatrix[formation_type][i][j].SetX(-mHInterval[formation_type][0] - mHInterval[formation_type][1]);
				}else if(jRole.mIndexX == 2){
					mOffsetMatrix[formation_type][i][j].SetX(-mHInterval[formation_type][1]);
				}else if(jRole.mIndexX == 3){
					mOffsetMatrix[formation_type][i][j].SetX(0.0);
				}
			}
			double jy = ( jRole.mIndexY - (mLineArrange[formation_type][jRole.mIndexX - 1] + 1) * 0.5 ) * mVInterval[formation_type][jRole.mIndexX - 1];
			mOffsetMatrix[formation_type][i][j].SetY(jy - iy);
		}
	}
}


//==============================================================================
Formation::Formation(Agent & agent) : mAgent(agent)
{
	if (mAgent.IsReverse()) {
		mpTeammateFormation = &OpponentFormation::instance();
		mpOpponentFormation = &TeammateFormation::instance();
	} else {
		mpTeammateFormation = &TeammateFormation::instance();
		mpOpponentFormation = &OpponentFormation::instance();
	}
}

const RoleType & Formation::GetMyRole() const
{
    return GetTeammateRoleType(mAgent.GetSelfUnum());
}


const Vector & Formation::GetTeammateFormationCenter(double min_conf)
{
    return mpTeammateFormation->GetFormationCenter(mAgent.GetWorldState(), true, min_conf);
}


void Formation::SetTeammateFormationCenter(Unum num, Vector position)
{
    mpTeammateFormation->SetFormationCenter(num, position);
}


Vector Formation::GetTeammateFormationPoint(Unum unum, double min_conf)
{
    return mpTeammateFormation->GetFormationPoint(mAgent.GetWorldState(), true, unum, min_conf);
}


Vector Formation::GetTeammateExpectedGoaliePos(Vector bp, double run)
{
    const WorldState & world_state = mAgent.GetWorldState();

    Vector gPos;
    int Uncyc;
    if (world_state.GetTeammateGoalieUnum() == 0 ||
        world_state.GetTeammate(world_state.GetTeammateGoalieUnum()).GetPosConf() < FLOAT_EPS)
    { 
        gPos = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, 0.0); 

        Vector p[2];
        double dist[2];
        p[0] = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, -ServerParam::instance().goalWidth() / 2.0 + 0.1); // top
        p[1] = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, ServerParam::instance().goalWidth() / 2.0 - 0.1); // down
        dist[0] = bp.Dist(p[0]);
        dist[1] = bp.Dist(p[1]);
		Uncyc = (int)(Min(dist[0], dist[1]) / 5.0);
    }
    else
    {
        gPos = world_state.GetTeammate(world_state.GetTeammateGoalieUnum()).GetPos();
        Uncyc = world_state.GetTeammate(world_state.GetTeammateGoalieUnum()).GetPosDelay();
	}

    return mpTeammateFormation->GetExpectedGoaliePos(bp, run, gPos, Uncyc);
}


Vector Formation::GetTeammateFormationPointBaseBall(Unum unum, const Vector & ball_pos)
{
    Assert(unum >= 1 && unum <= TEAMSIZE);

    Vector point;
    if (unum == mAgent.GetWorldState().GetTeammateGoalieUnum())
    {
		return Vector(-45.0, 0.0);
	}

    point.SetX(ball_pos.X() * mpTeammateFormation->mHBallFactor[mpTeammateFormation->GetFormationType()] +
        mpTeammateFormation->mOffsetMatrix[mpTeammateFormation->GetFormationType()][0][unum].X());
    point.SetY(ball_pos.Y() * mpTeammateFormation->mVBallFactor[mpTeammateFormation->GetFormationType()] +
        mpTeammateFormation->mOffsetMatrix[mpTeammateFormation->GetFormationType()][0][unum].Y());
    return point;
}


Vector Formation::GetTeammateFormationPoint(Unum unum, Unum focusTm, Vector focusPt)
{
    Assert(unum >= 1 && unum <= TEAMSIZE);
    if (unum == mAgent.GetWorldState().GetTeammateGoalieUnum())
    {
		return Vector(-45.0, 0.0);
	}

    if (focusTm == mAgent.GetWorldState().GetTeammateGoalieUnum())
    {
        int back_center = mpTeammateFormation->GetLineArrange(mpTeammateFormation->GetFormationType(), 1) / 2 + 1; 
        focusTm = mpTeammateFormation->GetUnumFromIndex(mpTeammateFormation->GetFormationType(), 1, back_center);
        focusPt.SetX(focusPt.X() + 9.0);
    }
    else if (focusTm <= Unum_Unknown || mAgent.GetWorldState().CurrentTime().T() < 1)
    {
	    return GetTeammateFormationPoint(unum);
    }

    focusPt = mpTeammateFormation->mActiveField[mpTeammateFormation->GetFormationType()][focusTm].AdjustToWithin(focusPt);
    if (focusTm == unum)
    {
        return focusPt;
    }
    return focusPt + mpTeammateFormation->mOffsetMatrix[mpTeammateFormation->GetFormationType()][focusTm][unum];
}


const Vector & Formation::GetOpponentFormationCenter(double min_conf)
{
    return mpOpponentFormation->GetFormationCenter(mAgent.GetWorldState(), false, min_conf);
}


void Formation::SetOpponentFormationCenter(Unum num, Vector position)
{
    mpOpponentFormation->SetFormationCenter(num, position);
}


Vector Formation::GetOpponentFormationPoint(Unum unum, double min_conf)
{
    return mpOpponentFormation->GetFormationPoint(mAgent.GetWorldState(), false, unum, min_conf);
}


Vector Formation::GetOpponentExpectedGoaliePos(Vector bp, double run)
{
    const WorldState & world_state = mAgent.GetWorldState();

    Vector gPos;
    int Uncyc;
    if (world_state.GetOpponentGoalieUnum() == 0 ||
        world_state.GetOpponent(world_state.GetOpponentGoalieUnum()).GetPosConf() < FLOAT_EPS)
    { 
        gPos = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, 0.0); 

        Vector p[2];
        double dist[2];
        p[0] = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, -ServerParam::instance().goalWidth() / 2.0 + 0.1); // top
        p[1] = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, ServerParam::instance().goalWidth() / 2.0 - 0.1); // down
        dist[0] = bp.Dist(p[0]);
        dist[1] = bp.Dist(p[1]);
		Uncyc = (int)(Min(dist[0], dist[1]) / 5.0);
    }
    else
    {
        gPos = world_state.GetOpponent(world_state.GetOpponentGoalieUnum()).GetPos();
        Uncyc = world_state.GetOpponent(world_state.GetOpponentGoalieUnum()).GetPosDelay();
	}

    return mpOpponentFormation->GetExpectedGoaliePos(bp, run, gPos, Uncyc);
}


Vector Formation::GetOpponentFormationPointBaseBall(Unum unum, const Vector & ball_pos)
{
    const FormationType & type = mpOpponentFormation->GetFormationType();
    double x = ball_pos.X() * mpOpponentFormation->mHBallFactor[type] - mpOpponentFormation->mOffsetMatrix[type][0][unum].X();
    if (mAgent.GetWorldState().GetPlayMode() == PM_Our_Kick_Off && x > 0)
    {
        x = 0.0;
    }
    double y = ball_pos.Y() * mpOpponentFormation->mVBallFactor[type] - mpOpponentFormation->mOffsetMatrix[type][0][unum].Y();
    return Vector(x, y);
}


void Formation::UpdateOpponentRole()
{
    const WorldState & world_state = mAgent.GetWorldState();
    const InfoState & info_state = mAgent.GetInfoState();
    const std::list<KeyPlayerInfo> & opp_list = info_state.GetPositionInfo().GetXSortOpponent();
    if (opp_list.size() < TEAMSIZE || world_state.GetPlayMode() != PM_Play_On || world_state.CurrentTime() % 10 != 0)
    {
        return;
    }

    int i;
    for (i = 0; i < FT_Max; ++i)
    {
        if (static_cast<OpponentFormation *>(mpOpponentFormation)->mUsedTimes[i] == 0)
        {
            break;
        }
    }
    if (i == FT_Max)
    {
        return;
    }

    const FormationType & type = mpTeammateFormation->GetFormationType();
    const int & forward_num = mpTeammateFormation->GetLineArrange(type, 3);
    const int & midfielder_num = mpTeammateFormation->GetLineArrange(type, 2);
    const int & defender_num = mpTeammateFormation->GetLineArrange(type, 1);

    int count = 0;
	KeyPlayerInfo kp;
	std::vector<KeyPlayerInfo> forward, midfielder, defender;
    for (std::list<KeyPlayerInfo>::const_iterator it = opp_list.begin(); it != opp_list.end(); ++it)
    {
        kp.mUnum = it->mUnum;
        kp.mValue = -world_state.GetOpponent(kp.mUnum).GetPos().Y();
		if (count < forward_num)
        {
			forward.push_back(kp);
		}
		else if (count < forward_num + midfielder_num)
        {
			midfielder.push_back(kp);
		}
		else if (count < forward_num + midfielder_num + defender_num)
        {
			defender.push_back(kp);
		}
		++count;
	}
    std::sort(forward.begin(), forward.end());
    std::sort(midfielder.begin(), midfielder.end());
    std::sort(defender.begin(), defender.end());

    for (int i = 1; i <= TEAMSIZE; ++i)
    {
        if (i == mpTeammateFormation->GetGoalieUnum())
        {
            continue;
        }

        const RoleType & role = mpTeammateFormation->mPlayerRole[type][i];
        switch (role.mLineType)
        {
        case LT_Forward:
            Assert(role.mIndexY - 1 >= 0 && role.mIndexY - 1 < (int)forward.size());
            for (int j = 0; j < FT_Max; ++j)
            {
                if (static_cast<OpponentFormation *>(mpOpponentFormation)->mUsedTimes[j] == 0)
                {
                    mpOpponentFormation->mPlayerRole[j][forward[role.mIndexY - 1].mUnum] = role;
                }
            }
            break;
        case LT_Midfielder:
            Assert(role.mIndexY - 1 >= 0 && role.mIndexY - 1 < (int)midfielder.size());
            for (int j = 0; j < FT_Max; ++j)
            {
                if (static_cast<OpponentFormation *>(mpOpponentFormation)->mUsedTimes[j] == 0)
                {
                    mpOpponentFormation->mPlayerRole[j][midfielder[role.mIndexY - 1].mUnum] = role;
                }
            }
            break;
        case LT_Defender:
            Assert(role.mIndexY - 1 >= 0 && role.mIndexY - 1 < (int)defender.size());
            for (int j = 0; j < FT_Max; ++j)
            {
                if (static_cast<OpponentFormation *>(mpOpponentFormation)->mUsedTimes[j] == 0)
                {
                    mpOpponentFormation->mPlayerRole[j][defender[role.mIndexY - 1].mUnum] = role;
                }
            }
            break;
        default:
            PRINT_ERROR("lien type error");
            break;
		}
	}
}
