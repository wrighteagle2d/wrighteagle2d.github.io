/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "BehaviorAttack.h"
#include "WorldState.h"
#include "Kicker.h"
#include "Dasher.h"
#include "InterceptModel.h"

const BehaviorType BehaviorAttackExecuter::BEHAVIOR_TYPE = BT_Attack;

namespace {
bool ret = BehaviorExecutable::AutoRegister<BehaviorAttackExecuter>();
}

BehaviorAttackPlanner::BehaviorAttackPlanner(Agent & agent): BehaviorPlannerBase<BehaviorAttackData>( agent )
{
}

BehaviorAttackPlanner::~BehaviorAttackPlanner()
{
}

bool BehaviorAttackPlanner::Dribble(ActiveBehavior& act_bhv)
{
	if (mPositionInfo.GetClosestOpponentDistToBall() > 5)
	{					
		std::vector<Unum> _opp = mPositionInfo.GetCloseOpponentToBall();

		Vector v1, v2;

		bool complete = false;

		for (std::vector<Unum>::iterator it = _opp.begin(); it != _opp.end(); ++it)
		{
			if (mWorldState.GetOpponent(*it).GetPos().X() > mBallState.GetPos().X() && !complete)
			{
				complete = true;
				v1 = mWorldState.GetOpponent(*it).GetPos();
			}

			if (complete && mWorldState.GetOpponent(*it).GetPos().X() > mBallState.GetPos().X())
			{
				v2 = mWorldState.GetOpponent(*it).GetPos();
				break;
			}
		}

		act_bhv.mDetailType = BDT_Dribble;
		act_bhv.mKickSpeed = 0.1 * mPositionInfo.GetClosestOpponentDistToBall();
		act_bhv.mAngle = GetNormalizeAngleDeg(((v1 - mBallState.GetPos()).Dir() + (v2 - mBallState.GetPos()).Dir()) / 2);
		return true;
	}

	return false;
}

bool BehaviorAttackPlanner::Pass(ActiveBehavior& act_bhv)
{
	if (mPositionInfo.GetClosestOpponentDistToBall() <= 5 && mBallState.GetPos().X() < 28)
	{
		for (int i = 1; i <= TEAMSIZE; ++i)
		{
			double min = 100;
			Unum def_teammate = 0;
			if (mFormation.GetTeammateRoleType(i).ToPlayerRole() == PR_ForwardCenter)
			{
				Vector rel_pos = (mWorldState.GetOpponent(mPositionInfo.GetClosestOpponentToTeammate(i)).GetPos() - mSelfState.GetPos()).Rotate(-(mWorldState.GetTeammate(i).GetPos() - mSelfState.GetPos()).Dir());
				double gth = InterceptModel::instance().CalcGoingThroughSpeed(
					rel_pos,
					(mWorldState.GetTeammate(i).GetPos() - mSelfState.GetPos()).Mod(),
					mWorldState.GetOpponent(mPositionInfo.GetClosestOpponentToTeammate(i)).GetPlayerSpeedMax(),
					mWorldState.GetOpponent(mPositionInfo.GetClosestOpponentToTeammate(i)).GetKickableArea(),
					1.5);
				if (gth < min && gth > ServerParam::instance().ballSpeedMax())
				{
					min = gth;
					def_teammate = i;
				}
			}
			act_bhv.mKeyUnum = def_teammate;
			act_bhv.mKickSpeed = min;
		}
		if (act_bhv.mKeyUnum != 0)
		{
			act_bhv.mKickSpeed *= 1.5;
			if (act_bhv.mKickSpeed > ServerParam::instance().ballSpeedMax())
			{
				act_bhv.mKickSpeed = ServerParam::instance().ballSpeedMax();
			}
			return true;
		}
	}

	return false;
}

void BehaviorAttackPlanner::Plan(std::list<ActiveBehavior> & behavior_list)
{
    ActiveBehavior act_bhv(mAgent, BT_Attack, BDT_None);

	if (mStrategy.GetBallInterPos().X() < 0 || !mSelfState.IsKickable())
	{
		return;
	}
	else
	{
		if (!Dribble(act_bhv))
		{
			if (!Pass(act_bhv))
			{
				if (mBallState.GetPos().X() < 30)
				{
					std::vector<Unum> _opp = mPositionInfo.GetCloseOpponentToBall();

					Vector v1, v2;

					bool complete = false;

					for (std::vector<Unum>::iterator it = _opp.begin(); it != _opp.end(); ++it)
					{
						if (mWorldState.GetOpponent(*it).GetPos().X() > mBallState.GetPos().X() && !complete)
						{
							complete = true;
							v1 = mWorldState.GetOpponent(*it).GetPos();
						}

						if (complete && mWorldState.GetOpponent(*it).GetPos().X() > mBallState.GetPos().X())
						{
							v2 = mWorldState.GetOpponent(*it).GetPos();
							break;
						}
					}

					act_bhv.mDetailType = BDT_Kick;
					act_bhv.mAngle = GetNormalizeAngleDeg(((v1 - mBallState.GetPos()).Dir() + (v2 - mBallState.GetPos()).Dir()) / 2);
					act_bhv.mPower = 100;
				}
				else
				{
					act_bhv.mDetailType = BDT_Shoot;
					act_bhv.mTarget = Vector(ServerParam::instance().PITCH_LENGTH / 2.0, ((mWorldState.CurrentTime().T() % 2 == 0)? ServerParam::instance().goalWidth() / 2.0:-ServerParam::instance().goalWidth() / 2.0));
					act_bhv.mKickSpeed = ServerParam::instance().ballSpeedMax();
				}
			}
		}
		behavior_list.push_back(act_bhv);
	}
}

BehaviorAttackExecuter::BehaviorAttackExecuter(Agent& agent): BehaviorExecuterBase<BehaviorAttackData>(agent)
{
	Assert(ret);
}

BehaviorAttackExecuter::~BehaviorAttackExecuter(void)
{
}

bool BehaviorAttackExecuter::Execute(const ActiveBehavior &act_bhv)
{
    switch(act_bhv.mDetailType)
    {
    case BDT_Kick:
		{
			if (mSelfState.IsGoalie()) return mAgent.Kick(100, (Vector(52.5, 0) - mSelfState.GetPos()).Dir() - mSelfState.GetBodyDir());

			return Kicker::instance().KickBall(mAgent, act_bhv.mTarget, ServerParam::instance().ballSpeedMax());
		}
    case BDT_Attack_Intercept:
        return Dasher::instance().GoToPoint(mAgent, act_bhv.mTarget);
	case BDT_Dribble:
		return Kicker::instance().KickBall(mAgent, act_bhv.mAngle, act_bhv.mKickSpeed);
	case BDT_Pass:
		return Kicker::instance().KickBall(mAgent, mWorldState.GetTeammate(act_bhv.mKeyUnum).GetPos(), act_bhv.mKickSpeed);
	case BDT_Shoot:
		return Kicker::instance().KickBall(mAgent, act_bhv.mTarget, act_bhv.mKickSpeed);
    default:
        break;
    }

    return false;
}
