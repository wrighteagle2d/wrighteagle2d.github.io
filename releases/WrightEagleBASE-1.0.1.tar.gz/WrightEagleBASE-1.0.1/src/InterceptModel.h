/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef INTERCEPTMODEL_H_
#define INTERCEPTMODEL_H_

#include "Geometry.h"

class PlayerState;
class WorldState;
struct InterceptSolution;

/**
 * Class InterceptModel
 * A simpilied intercept model
 * Used to calculate intercept information
 */
class InterceptModel {
	InterceptModel();
public:
	virtual ~InterceptModel();
	static InterceptModel &instance();

	static const double CP_impossible_speed;

	/**
	 * ����ĺ�������������������ģ��
	 */
	/**
	 * The following functions are used to calculate out a intercept solution with a idealized model
	 */
	void CalcInterception(const Vector & ball_pos, const Vector & ball_vel, const PlayerState * player, InterceptSolution * sol);
	int CalcTangPoint(double x0, double y0, double vp, double ka, double cd, InterceptSolution * sol);
	double CalcInterPoint(double x_init, double x0, double y0, double vb, double vp, double ka, double cd);

	/**
	 * ����ĺ�����peakpt�ʹ�Խ�ٶ����
	 */
	/**
	 * The following functions calculate a peak point and going through speed
	 */
	//����� fix ����Ա���ܶ��ӳ٣����������ӳٺͷ�Ӧ�ӳ٣�����Ĭ��ȥ1.5������
	double CalcPeakPoint(Vector relpos, double vp, double ka, double cd, double fix = 1.5);
	double CalcSpottingSpeed(Vector relpos, double dis, double vp, double ka, double cd, double fix = 1.5);
	double CalcGoingThroughSpeed(Vector relpos, double x, double vp, double ka, double cd, double *peakdist = 0, double fix = 1.5);
    double CalcGoingThroughSpeed(const PlayerState & player, const Ray & ballcourse, double distance, double *peakdist = 0, double fix = 1.5);

private:
	/**
	 * ���������������
	 * @param x0
	 * @param y0
	 * @param v0
	 * @param vp
	 * @param ka
	 * @param cd
	 */
	void PlotInterceptCurve(double x0, double y0, double v0, double vp, double ka, double cd, double max_x);
};

#endif /* INTERCEPTMODEL_H_ */
