/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __Utilities_H__
#define __Utilities_H__


#ifdef WIN32
#include <Winsock2.h>
#else
#include <sys/time.h>
#endif

#include <cstdlib>
#include <iostream>
#include <cmath>
#include "Types.h"
/**
 * Change radian to angle
 * @param radian
 * @return angle
 */
inline AngleDeg Rad2Deg(AngleRad x)
{
	return x * 180.0 / M_PI;
}

/**
 * Change angle to radian
 * @param angle
 * @return radian
 */
inline AngleRad Deg2Rad(AngleDeg x)
{
	return x * M_PI / 180.0;
}

/**
 * cosine
 * @param angle
 * @return
 */
inline double Cos(AngleDeg x)
{
	return cos(Deg2Rad(x));
}

/**
 * sine
 * @param angle
 * @return
 */
inline double Sin(AngleDeg x)
{
	return sin(Deg2Rad(x));
}

/** tangent */
inline double Tan(AngleDeg x)
{
	return tan(Deg2Rad(x));
}

/** arccos */
inline AngleDeg ACos(double x)
{
	return ((x) >= 1.0 - 0.000006 ? 0.0 : ((x) <= -1.0 + 0.000006 ? 180.0 : (Rad2Deg(acos(x)))));
}

/** arcsin */
inline AngleDeg ASin(double x)
{
	return ((x) >= 1.0 - 0.000006 ? 90.0 : ((x) <= -1.0 + 0.000006 ? -90.0 : (Rad2Deg(asin(x)))));
}

/** 
 * arctan 
 * @param x : if tan(A) = x then return A
 */
inline AngleDeg ATan(double x)
{
	return (Rad2Deg(atan(x)));
}

/**
 * arctan
 * @param y, x : if tan(A) = x/y then return A
 */
inline AngleDeg ATan2(double y, double x)
{
	return ((fabs(x) < 0.000006 && fabs(y) < 0.000006) ? 0 : (Rad2Deg(atan2(y, x))));
}

/**
 * normalize a angle to min_ang~min_ang + 180
 * @param ang angle to be normalized
 * @param min_ang
 * @return
 */
inline AngleDeg GetNormalizeAngleDeg(AngleDeg ang, const AngleDeg min_ang = -180.0)
{
	if (ang < min_ang) {
		do {
			ang += 360.0;
		} while (ang < min_ang);
	}
	else {
		const AngleDeg max_ang = 360.0 + min_ang;

		while (ang >= max_ang){
			ang -= 360.0;
		}
	}

	return ang;
}

/**
 * Same as GetNormalizeAngleDeg() unless the first parameter is a reference
 */
inline void NormalizeAngleDeg(AngleDeg & ang, AngleDeg min_ang = -180.0)
{
	ang = GetNormalizeAngleDeg(ang, min_ang);
}

/**
 * normalize a radian to min_ang~min_ang + PI
 * @param ang radian to be normalized
 * @param min_ang
 * @return
 */
inline AngleRad GetNormalizeAngleRad(AngleRad ang, AngleRad min_ang = -M_PI)
{
	while (ang > 2.0 * M_PI + min_ang)
	{
		ang -= 2.0 * M_PI;
	}
	while (ang < min_ang)
	{
		ang += 2.0 * M_PI;
	}
	return ang;
}

/**
 * Same as GetNormalizeAngleRad() unless the first parameter is a reference
 */
inline void NormalizeAngleRad(AngleRad & ang, AngleRad min_ang = -M_PI)
{
	ang = GetNormalizeAngleRad(ang, min_ang);
}

/**
 * calculate difference between ang1 and ang2
 * @return a, 0 <= a <= 180
 */
inline AngleDeg GetAngleDegDiffer(AngleDeg ang1, AngleDeg ang2)
{
	return fabs(GetNormalizeAngleDeg(ang1 - ang2));
}

/**
 * calculate difference between ang1 and ang2
 * @return a, 0 <= a <= PI
 */
inline AngleRad GetAngleRadDiffer(AngleRad ang1, AngleRad ang2)
{
	return fabs(GetNormalizeAngleRad(ang1 - ang2));
}

/**
* ���ؽǶ�gamma�Ƿ�λ����alpha��˳ʱ�뷽����ת��beta��Χ�ɵ�����������
* @param alpha
* @param gamma
* @param beta
* @return
*/
/**
 * Compute if gamma is in the sector which has a ray on alpha direction and another ray on beta direction
 * The sector from alpha to beta is clockwise 
 */
inline bool IsAngleDegInBetween(AngleDeg alpha, AngleDeg gamma, AngleDeg beta)
{
	return GetNormalizeAngleDeg(gamma, alpha) <= GetNormalizeAngleDeg(beta, alpha);
}

/**
* ����gamma�Ƿ���alpha����
* @param alpha
* @param gamma
* @param beta
* @return true�������
*/
/**
 * return if gamma is nearer to alpha than beta
 * @return true if gamma is nearer
 */
inline bool IsAngleDegCloseToLeft(AngleDeg alpha, AngleDeg gamma, AngleDeg beta)
{
	return GetAngleDegDiffer(gamma, alpha) < GetAngleDegDiffer(gamma, beta);
}

/**
 * Sum of infinite geometry series
 * \param first_term
 * \param r common ratio
 */
inline double SumInfGeomSeries(double first_term, double r)
{
	return first_term / (1.0 - r);
}


//==============================================================================
/**
* �����ĸ��������ǵõ�ϵͳʱ�䣬���õĵط���ͬ��һ��Ҫע��
*
* GetRealTime()���ڶ�̬����ʱ���ᾭ���ĵط���������3�����������õĵط�
* GetRealTimeParser()����Parser::Parse()������õ����к�����
* GetRealTimeDecision()����Player::Decision()������õ����к�����
* GetRealTimeCommandSend()����CommandSend::Run()������õ����к�����
*/
/**
 * The followings four functions are used to get system time
 *
 * GetRealTime() won't be through dynamicDebug
 * GetRealTimeParser() used in Parser::Parse() and all the functions called by it
 * GetRealTimeDecision() used in Player::Decision() and all the functions called by it
 * GetRealTimeCommandSent() used in CommandSend::Run() and all the functions called by it
 */
timeval GetRealTime();
timeval GetRealTimeParser();
timeval GetRealTimeDecision();
timeval GetRealTimeCommandSend();

//==============================================================================
/** Real Time */
class RealTime
{
public:
	explicit RealTime(long tv_sec = 0, long tv_usec = 0) {
		mTime.tv_sec = tv_sec;
		mTime.tv_usec = tv_usec;
	}

	RealTime(const timeval &t): mTime(t) { }

	timeval GetTime() const { return mTime; }
	long GetSec() const { return mTime.tv_sec; }
	long GetUsec() const { return mTime.tv_usec; }

	const RealTime & operator = (const timeval &t) { mTime = t; return *this; }
	RealTime operator + (const RealTime &t) const;
	RealTime operator + (int msec) const;
	RealTime operator - (int msec) const;
	int operator - (const RealTime &t) const;
	long Sub( const RealTime &t);

	bool operator < (const RealTime &t) const;
	bool operator > (const RealTime &t) const;
	bool operator == (const RealTime &t) const;
	bool operator != (const RealTime &t) const;

	friend std::ostream & operator << (std::ostream &os, RealTime t);

private:
	timeval mTime;

	static timeval mStartTime;
	static const long ONE_MILLION;
};


//==============================================================================
/** Game Time */
class Time
{
public:
	explicit Time(int t = -3, int s = 0): mT(t), mS(s) {}

	int T() const { return mT; }
	int S() const { return mS; }
	void SetT(int t) { mT = t; }
	void SetS(int s) { mS = s; }

	const Time & operator=(const int a) { mT = a;  mS = 0; return *this; }
	Time operator+(const int a) const { return Time(mT + a, 0); }
	Time operator-(const int a) const;
	int operator-(const Time &a) const;

	void operator+=(const int a) { *this = *this + a; }
	void operator-=(const int a) { *this = *this - a; }
	void operator-=(const Time &a) { *this = *this - a; }
	const Time & operator++() { *this += 1; return *this; }
	const Time & operator--() { *this -= 1; return *this; }
	int operator%(const int a) const { return (mT + mS) % a; }

	bool operator==(const Time &a) const { return (mS == a.S()) && (mT == a.T()); }
	/*bool operator==(const int a) const { return mT == a; }*/
	bool operator!=(const Time &a) const { return (mS != a.S()) || (mT != a.T()); }
	/*bool operator!=(const int a) const { return mT != a; }*/
	bool operator<(const Time &a) const { return (mT < a.T()) || (mT == a.T() && mS < a.S()); }
	/*bool operator<(const int a) const { return mT < a; }*/
	bool operator<=(const Time &a) const { return (mT < a.T()) || ( mT == a.T() && mS <= a.S()); }
	/*bool operator<=(const int a) const { return mT <= a; }*/
	bool operator>(const Time &a) const { return (mT > a.T()) || (mT == a.T() && mS > a.S()); }
	/*bool operator>(const int a) const { return mT > a; }*/
	bool operator>=(const Time &a) const { return (mT > a.T()) || (mT == a.T() && mS >= a.S()); }
	/*bool operator>=(const int a) const { return mT >= a; }*/
	bool operator!() const { return (mS == 0) && (mT == 0); }
	friend std::ostream & operator<<(std::ostream & os, const Time& t) { return os << '(' << t.T() << ':' << t.S() << ')'; }

private:
	int mT;
	int mS;
};


/**
* bellow is parse utilities
*/
namespace parser {
inline double get_double(char **str_ptr){
	while (!isdigit(**str_ptr) && **str_ptr != '-' && **str_ptr != '+' && **str_ptr != '.') (*str_ptr)++;
	return strtod(*str_ptr, str_ptr);
}

//==============================================================================
inline double get_double(char *str){
	while (!isdigit(*str) && *str != '-' && *str != '+' && *str != '.') str++;
	return strtod(str, (char **) NULL);
}

//==============================================================================
inline int get_int(char **str_ptr){
	while (!isdigit(**str_ptr) && **str_ptr != '-' && **str_ptr != '+' && **str_ptr != '.') (*str_ptr)++;
	return static_cast<int>(strtol(*str_ptr, str_ptr, 10));
}

//==============================================================================
inline int get_int(char *str){
	while (!isdigit(*str) && *str != '-' && *str != '+' && *str != '.') str++;
	return static_cast<int>(strtol(str, (char **) NULL, 10));
}

//==============================================================================
inline void get_word(char **str_ptr){
	while ( !isalpha(**str_ptr) ) (*str_ptr)++;
}

//==============================================================================
inline void get_next_word(char **str_ptr){
	while ( isalpha(**str_ptr) ) (*str_ptr)++;
	get_word(str_ptr);
}
}

namespace sight {
inline AngleDeg ViewAngle(ViewWidth view_width)
{
	switch(view_width){
	case VW_Narrow: return 60.0;
	case VW_Normal: return 120.0;
	case VW_Wide: return 180.0;
	default: Assert(0); return 90.0;
	}
}

inline int SightDelay(ViewWidth view_width)
{
	switch(view_width) {
	case VW_Narrow: return 1;
	case VW_Normal: return 2;
	case VW_Wide: return 3;
	default: Assert(0); return 1;
	}
}
}

inline double Quantize( const double v, const double q )
{
    return Rint( v / q ) * q;
}

inline double rand01()
{
	return ((double)rand()) / RAND_MAX;
}

//===========The Followings are Some Template===================================
//==============================================================================
template <class Data> class TimedData
{
public:
	TimedData(Time time = Time(-3, 0))               { mTime = time; }
	TimedData(const Data &data, Time time)  { mData = data; mTime = time; }

	const Data & GetData() const        { return mData; }
	const Time & GetTime() const        { return mTime; }
	void SetData(const Data &data)      { mData = data; }
	void SetTime(const Time time)       { mTime = time; }

	void operator = (const Data &data)  { mData = data; }
	TimedData operator + (TimedData d)  { return TimedData(mData + d, mTime); }
	TimedData operator - (TimedData d)  { return TimedData(mData - d, mTime); }
	TimedData operator / (TimedData d)  { return TimedData(mData / d, mTime); }
	TimedData operator * (TimedData d)  { return TimedData(mData * d, mTime); }

private:
	Data mData;
	Time mTime;
};


//==============================================================================
template <class T, int size> class TimedDataArray
{
public:
	inline bool IsValidIdx(int idx1, int idx2)
	{
		if (idx1 < 0 || idx1 >= size || idx2 < 0 || idx2 >= size || idx1 == idx2)
		{
			return false;
		}
		return true;
	}

	inline int Index(int idx1, int idx2)
	{
		if (IsValidIdx(idx1, idx2) == false)
		{
			return size * (size -1) /2;
		}

		if (idx1 > idx2)
		{
			std::swap(idx1, idx2);
		}
		return (2 * size - 1  - idx1) * idx1 / 2 + idx2 - idx1 - 1;
	}

	inline bool IsDataKnown(int idx1, int idx2, Time time) { return mData[Index(idx1, idx2)].GetTime() == time; }
	inline const TimedData<T> & GetElement(int idx1, int idx2) { return mData[Index(idx1, idx2)]; }
	inline const T & GetData(int idx1, int idx2) { return mData[Index(idx1, idx2)].GetData(); }

	inline void Reset() { memset(mData, 0, sizeof(mData)); }
	inline void SetTime(int idx1, int idx2, Time time) { mData[Index(idx1, idx2)].SetTime(time); }
	inline void SetData(int idx1, int idx2, const T &data, Time time)
	{
		mData[Index(idx1, idx2)].SetData(data);
		mData[Index(idx1, idx2)].SetTime(time);
	}

private:
	TimedData<T> mData[size * (size - 1) / 2 + 1];
};


//==============================================================================
template <class Data> class DoubleLinkedSoftListNode
{
public:
	DoubleLinkedSoftListNode() { next = -1; prev = -1; }
	int next;
	int prev;
	Data data;
};


//==============================================================================
template <class Data, int size> class DoubleLinkedSoftList
{
protected:
	DoubleLinkedSoftListNode<Data> Nodes[size + 1];
	int num_nodes;
	int head;
	int tail;

public:
	DoubleLinkedSoftList()
	{
		head = size;
		tail = size;
		num_nodes = 0;
	}

	virtual ~DoubleLinkedSoftList()
	{
	}

	int ListSize()      { return num_nodes; }
	int ActualHead()    { return Nodes[head].next; }
	int Head()          { return head; }
	int Tail()          { return tail; }
	int Prev(int p)     { Assert(p >= 0 && p <= size); return Nodes[p].prev; }
	int Next(int p)     { Assert(p >= 0 && p <= size); return Nodes[p].next; }

	bool IsEmpty()      { return Nodes[head].next == -1; }
	bool IsHead(int p)  { Assert(p >= 0 && p <= size); return head == p; }
	bool IsTail(int p)  { Assert(p >= 0 && p <= size); return tail == p; }
	bool IsValid(int p) { return (p >= 0 && p <= size); }

	Data & GetData(int p)                               { Assert(p >= 0 && p <= size); return Nodes[p].data; }
	void SetData(const Data& data, int p)               { Assert(p >= 0 && p <= size); Nodes[p].data = data; }
	DoubleLinkedSoftListNode<Data> & GetHead()          { Assert(head >= 0 && head <= size); return Nodes[head]; }
	DoubleLinkedSoftListNode<Data> & GetElement(int p)  { Assert(p >= 0 && p <= size); return Nodes[p]; }

	bool Insert(int p, int insert_node)
	{
        if (!IsValid(p) || !IsValid(insert_node) || p == insert_node)
        {
            return false;
        }
		if (Nodes[p].prev == -1 && p != head)
        {
            return false;
        }

		if (p == tail)
		{
			tail = insert_node;
			Nodes[p].next = insert_node;
			Nodes[insert_node].prev = p;
			Nodes[insert_node].next = -1;
		}
		else
		{
			Nodes[Nodes[p].next].prev = insert_node;
			Nodes[insert_node].next = Nodes[p].next;
			Nodes[insert_node].prev = p;
			Nodes[p].next = insert_node;
		}
		num_nodes ++;
		return true;
	}

	bool Delete(int p)
	{
        if (!IsValid(p) || Nodes[p].prev == -1)
        {
            return false;
        }

		if (p == tail)
		{
			tail = Nodes[p].prev;
			Nodes[p].prev =Nodes[tail].next = -1;//old tail.next = -1 all the time,no need to reset.
		}
		else if (p == head)
		{
			return false;
		}
		else
		{
			Nodes[Nodes[p].prev].next = Nodes[p].next;
			Nodes[Nodes[p].next].prev = Nodes[p].prev;
			Nodes[p].next = Nodes[p].prev = -1;//flag it to be a blank node.
		}
		num_nodes --;
		return true;
	}

	int CircularNext(int p)
	{
        if (p < 0 || p > size || IsEmpty())
        {
            return -1;
        }
		if (p == tail)
        {
            return Nodes[head].next;
        }
        return Nodes[p].next;
	}

	int CircularPrev(int p)
	{
        if (p < 0 || p > size || IsEmpty() || p == head)
        {
            return -1;
        }
		if (Nodes[p].prev == head)
        {
            return tail;
        }
		return Nodes[p].prev;
	}

	virtual void Cleanup()
	{
		for(int i=0;i<=size;i++)
		{
			Nodes[i].prev=-1;
			Nodes[i].next=-1;
		}
		num_nodes = 0;
		tail = head;
	}

	int AddData(int p,const Data& data)
	{
		int i;
		//����Ĵ�����Ҫ��Ϊ��Ѱ�ҿ��нڵ�ʱ��ʡʱ��,�ڴ�������,��ĵط�Ӧ��ֱ�ӽ���forѭ�����ң�������ĵط�Ҳ�ò���.
		//������һ���˿���2�����϶β���,�����㹻��.
		if(Nodes[data.mIdx].next ==-1 && Nodes[data.mIdx].prev==-1)
		{
			i=data.mIdx;
		}
		else
		{
			for(i=0;i<size;i++)
			{
				if(Nodes[i].next==-1 && Nodes[i].prev==-1)
					break;
			}
		}
		if(i == size) return -1;//error Խ��
		Nodes[i].data=data;
		Insert(p,i);
		return i;
	}
};


//==============================================================================
template<class Data, int size> class OrderedSoftQueue : public DoubleLinkedSoftList<Data, size>{
public:
	OrderedSoftQueue()  { this->num_nodes = 0;}
	void Cleanup()      { DoubleLinkedSoftList<Data, size>::Cleanup(); }

	/** ר��������Angle���м���ģ��������Ҳ�ò���,��ʹ��Ӧע�⡣������������Ƿŵ�����ȽϺ��� */
	int GetMostSimilarNode(AngleDeg angle)
	{
		if(this->num_nodes < 1) return -1;
		bool bChangeDir = false;//�Ƿ񻻹������ķ�����
		int n = 0;
		int q = this->Nodes[this->head].next,min_q = -1;
		int diff,mindiff = 1000;
		while(n++ < this->num_nodes)
		{
			diff = int(fabs(this->GetData(q).mValue - angle)); //TODO: array subscript is below array bounds
			diff = diff % 360;
			if(diff > 180) diff -= 360;
			diff = diff > 0?diff:-diff;
			if(diff <= mindiff)
			{
				mindiff = diff;
				min_q = q;
				q =  bChangeDir ? DoubleLinkedSoftList<Data, size>::CircularPrev(q) : DoubleLinkedSoftList<Data, size>::CircularNext(q);
			}
			else
			{
				if(bChangeDir)
				{
					return min_q;
				}
				else
				{
					q = CircularPrev(this->Nodes[this->head].next);
					bChangeDir = true;
				}
			}
		}
		return min_q;
	}

	bool Enqueue(const Data& data)
	{
        if (this->num_nodes >= size || this->num_nodes < 0)
        {
            return false;
        }

        this->Nodes[this->num_nodes].data = data;
		int q = this->head;
		while(IsValid(this->Nodes[q].next))
		{
			if (this->Nodes[this->num_nodes].data < this->Nodes[this->Nodes[q].next].data)
				break;
			q = this->Nodes[q].next;
		}
		return Insert(q, this->num_nodes);
	}
};


/** Key Player Information */
class KeyPlayerInfo
{
public:
	Unum    mUnum;
	double  mValue;

	KeyPlayerInfo():
		mUnum ( 0 ),
		mValue ( 0.0 )
	{
	};

	bool operator < (const KeyPlayerInfo &other) const  { return mValue < other.mValue; }
	bool operator > (const KeyPlayerInfo &other) const  { return mValue > other.mValue; }
	bool operator == (const KeyPlayerInfo &other) const { return fabs(mValue - other.mValue) < FLOAT_EPS; }
};

template<typename _Tp, std::size_t _Nm>
class Array
{
	_Tp _M_instance[_Nm ? _Nm : 1];

public:
	// Element access.
	_Tp &
	operator[](const std::size_t & __n)
	{ Assert(__n < _Nm); return _M_instance[__n]; }

	const _Tp &
	operator[](const std::size_t & __n) const
    { Assert(__n < _Nm); return _M_instance[__n]; }
};

class Updatable {
public:
	Updatable(): mUpdateTime(Time(-3, 0)) {}

	virtual ~Updatable(){}

	void UpdateAtTime(const Time & time) {
		if (mUpdateTime != time){
			UpdateRoutine();

			mUpdateTime = time;
		}
	}

private:
	virtual void UpdateRoutine() = 0;

private:
	Time mUpdateTime;
};

#endif
