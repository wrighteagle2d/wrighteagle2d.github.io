/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include <cstdlib>
#include "Agent.h"
#include "WorldModel.h"

/**
 * Constructor.
 */
Agent::Agent(Unum unum, WorldModel *world_model, bool reverse):
	mSelfUnum( abs(unum) ),
	mReverse( reverse ),
	mpWorldModel( world_model ),
	mpWorldState( &(world_model->World(reverse)) ),
	mpInfoState( new InfoState( mpWorldState)),
	mIsNewSight (false),
	mpStrategy(0),
    mpActionEffector(0),
    mpFormation(0)
{
	Assert((mSelfUnum >= 1 && mSelfUnum <= TEAMSIZE && !PlayerParam::instance().isCoach()) || (mSelfUnum == 0 && PlayerParam::instance().isCoach()));
}

/**
 * Destructor.
 */
Agent::~Agent()
{
	delete mpInfoState;
    delete mpFormation;
	delete mpActionEffector;
	delete mpStrategy;
}

/**
 * Interface to create an agent which represents a team mate.
 * \param unum positive number represents the uniform number of the team mate.
 * \return an agent created by "new" operator, which should be manually deleted when there will be no
 *         use any more.
 */
Agent * Agent::CreateTeammateAgent(Unum unum) ///�������
{
    Assert(abs(unum) != mSelfUnum);
    Assert(unum != 0);
    Agent *new_agent = new Agent(unum, mpWorldModel, mReverse); //reverse���Բ���

    return new_agent;
}

/**
 * Interface to create an agent which represents an opponent.
 * \param unum positive number represents the uniform number of the opponent.
 * \return an agent created by "new" operator, which should be manually deleted when there will be no
 *         use any more.
 */
Agent * Agent::CreateOpponentAgent(Unum unum) ///�������
{
	return new Agent(unum, mpWorldModel, !mReverse); //reverse�����෴
}

