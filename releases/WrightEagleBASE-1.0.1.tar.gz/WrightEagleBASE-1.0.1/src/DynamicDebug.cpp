/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include <cstring>
#include "DynamicDebug.h"

//==============================================================================
DynamicDebug::DynamicDebug()
{
	mpObserver          = NULL;
	mInitialOK          = false;

	mpIndex             = NULL;
	mpParserTime        = NULL;
	mpDecisionTime      = NULL;
	mpCommandSendTime   = NULL;
	mpCurrentIndex      = NULL;

	mpFile              = NULL;
	mpFileStream        = NULL;
	mpStreamBuffer      = std::cin.rdbuf(); // ����std::cin����������Ҫ�ض���

	mRunning            = false;
	mShowMessage        = false;
	mRuntoCycle         = Time(-3, 0);
}

//==============================================================================
DynamicDebug::~DynamicDebug()
{
	Flush();

	if (mpIndex != NULL)
	{
		delete[] mpIndex;
	}

	if (mpParserTime != NULL)
	{
		delete[] mpParserTime;
	}

	if (mpDecisionTime != NULL)
	{
		delete[] mpDecisionTime;
	}

	if (mpCommandSendTime != NULL)
	{
		delete[] mpCommandSendTime;
	}
}


//==============================================================================
DynamicDebug & DynamicDebug::instance()
{
	static DynamicDebug dynamic_debug;
	return dynamic_debug;
}


//==============================================================================
void DynamicDebug::Initial(Observer *pObserver)
{
	if (mInitialOK == true)
	{
		return;
	}

	if (pObserver == NULL)
	{
		PRINT_ERROR("Observer Null Pointer");
		return;
	}

	mpObserver = pObserver;

	if (PlayerParam::instance().DynamicDebugMode() == true) // ��̬����
	{
		mpFileStream = new std::ifstream("dynamicdebug.txt");
		if (mpFileStream)
		{
			std::cin.rdbuf(mpFileStream->rdbuf());
		}
	}
	else // ��������ʱ
	{
		if (PlayerParam::instance().SaveServerMessage() == true) // ��Ҫ����server��Ϣ
		{
			char file_name[64];
			sprintf(file_name, "Logfiles/%s-%d-msg.log", PlayerParam::instance().teamName().c_str(), mpObserver->MyUnum());
			mpFile = fopen(file_name, "wb");
			if (mpFile){
				if (setvbuf(mpFile, NULL, _IOFBF, 1024 * 8192) != 0)
				{
					PRINT_ERROR("set buffer for file \"" << file_name << "\" error");
				}
			}
			else {
				PRINT_ERROR("open file \"" << file_name << "\" error");
			}
		}

		if (mpFile != NULL)
		{
			fseek(mpFile, sizeof(mFileHead), SEEK_SET); // ����mFileHead�ĵط����������
			mFileHead.mIndexTableSize = 0;
			mIndexTable.reserve(8192);
			mMessageTable.reserve(8192);
		}
	}
	mInitialOK = true;
}


/**
* Log the server message.
* @param msg the server message logged.
* @param msg_type the type of message to be added.
*/
void DynamicDebug::AddMessage(const char *msg, MessageType msg_type)
{
    if (PlayerParam::instance().SaveServerMessage() && 
        !PlayerParam::instance().DynamicDebugMode())
    {
	    if (!mInitialOK)
	    {
		    return; // û�г�ʼ�����߲��ü�¼server��Ϣ������
	    }

	    mFileMutex.Lock(); // �п��ܶ���߳�ͬʱ��д�ļ�������Ҫ��֤����

	    MessageIndexTableUnit index_table_unit;
	    index_table_unit.mServerTime = mpObserver->CurrentTime();
	    index_table_unit.mDataSize = strlen(msg);

	    switch (msg_type)
	    {
	    case MT_Parse:
		    index_table_unit.mTimeOffset = mParserTimeTable.size();
		    break;
	    case MT_Run:
		    index_table_unit.mTimeOffset = mDecisionTimeTable.size();
		    break;
	    case MT_Send:
		    index_table_unit.mTimeOffset = mCommandSendTimeTable.size();
		    break;
	    default:
		    break;
	    }

	    mMessageTable.push_back( Message(msg_type, msg));
	    mIndexTable.push_back(index_table_unit);
	    mFileHead.mMaxCycle = Max(mFileHead.mMaxCycle, index_table_unit.mServerTime);

	    mFileMutex.UnLock();
    }
}


/**
* Add the time parser.
* @param time the time.
*/
void DynamicDebug::AddTimeParser(timeval &time)
{
	if (PlayerParam::instance().SaveServerMessage() && 
        !PlayerParam::instance().DynamicDebugMode())
    {
		mParserTimeTable.push_back(time);
	}
}


/**
* Add the time when the decision is done.
* @param time the time evaluation.
*/
void DynamicDebug::AddTimeDecision(timeval &time)
{
	if (PlayerParam::instance().SaveServerMessage() && 
        !PlayerParam::instance().DynamicDebugMode())
    {
		mDecisionTimeTable.push_back(time);
	}
}


/**
* Add the time when the command is sent.
* @param time the time evaluation.
*/
void DynamicDebug::AddTimeCommandSend(timeval &time)
{
	if (PlayerParam::instance().SaveServerMessage() && 
        !PlayerParam::instance().DynamicDebugMode())
    {
		mCommandSendTimeTable.push_back(time);
	}
}


/**
* Run with a certain piece of message.
* @param msg the message to run.
* @return the message type.
*/
MessageType DynamicDebug::Run(char *msg)
{
	std::cerr << std::endl << mpObserver->CurrentTime(); // �����ǰ����

	if (mRunning == true)
	{
		if (mRuntoCycle >= Time(0, 0))
		{
			if(mRuntoCycle <= mpObserver->CurrentTime())
			{
				mRunning = false;
				mRuntoCycle = 0;
			}
		}

		if (mRunning){
			return GetMessage(msg);
		}
	}

	std::string read_msg;
	while (std::cin)
	{
        if (std::cin.eof())
        {
            std::cin.rdbuf(mpStreamBuffer);
        }

		std::cerr << std::endl << ">>> ";
		std::cin >> read_msg;

		if (*read_msg.c_str() == '\0')
		{
			std::cin.rdbuf(mpStreamBuffer); // �����ļ�ĩβ�����'\0'�������ض���
			continue;
		}

		if (read_msg == "load")
		{
			std::string file_name;
			std::cin >> file_name;
			mpFile = fopen(file_name.c_str(), "rb");
			if (mpFile == NULL)
			{
				std::cerr << "Can't open dynamicdebug file, exit..." << std::endl;
				continue;
			}

			if (fread(&mFileHead, sizeof(mFileHead), 1, mpFile) < 1)
            {
                Assert(0);
            }

			if (strcmp(mFileHead.mHeadFlag, "DD") != 0)
			{
				std::cerr<<"Not a dynamicdebug logfile!"<<std::endl;
				return MT_Null;
			}

			long size;

			size = mFileHead.mIndexTableSize;
			mpIndex = new MessageIndexTableUnit[size];
			fseek(mpFile, mFileHead.mIndexTableOffset, SEEK_SET);
			if (size > 0 && fread(mpIndex, size * sizeof(MessageIndexTableUnit), 1, mpFile) < 1)
            {
                Assert(0);
            }

			size = mFileHead.mParserTableSize;
			mpParserTime = new timeval[size];
			fseek(mpFile, mFileHead.mParserTableOffset, SEEK_SET);
			if (size > 0 && fread(mpParserTime, size * sizeof(timeval), 1, mpFile) < 1)
            {
                Assert(0);
            }

			size = mFileHead.mDecisionTableSize;
			mpDecisionTime = new timeval[size];
			fseek(mpFile, mFileHead.mDecisionTableOffset, SEEK_SET);
			if (size > 0 && fread(mpDecisionTime, size * sizeof(timeval), 1, mpFile) < 1)
            {
                Assert(0);
            }

			size = mFileHead.mCommandSendTableSize;
			mpCommandSendTime = new timeval[size];
			fseek(mpFile, mFileHead.mCommandSendTableOffset, SEEK_SET);
			if (size > 0 && fread(mpCommandSendTime, size * sizeof(timeval), 1, mpFile) < 1)
            {
                Assert(0);
            }

			fseek(mpFile, sizeof(mFileHead), SEEK_SET);
			mpCurrentIndex = mpIndex; // load�󣬵�һ��Ϊ��ʼ����Ϣ���Ƚ��г�ʼ��

			std::cerr << "Load finished." << std::endl;
			fseek(mpFile, mpCurrentIndex->mDataOffset, SEEK_SET);
			if (fread(msg, 1, 1, mpFile) < 1)
            {
                Assert(0);
            }
            if (mpCurrentIndex->mDataSize > 0 && fread(msg, mpCurrentIndex->mDataSize, 1, mpFile) < 1)
            {
                Assert(0);
            }
			msg[mpCurrentIndex->mDataSize] = '\0';
			return MT_Parse;
		}
		else if (read_msg == "step" || read_msg == "s")
		{
			if (mpCurrentIndex == NULL)
			{
				std::cerr << "no file loaded!";
				continue;
			}
			return GetMessage(msg);
		}
		else if (read_msg == "goto" || read_msg == "g")
		{
			if (mpCurrentIndex == NULL)
			{
				std::cerr << "no file loaded!";
				continue;
			}

			int cycle;
			std::cin >> cycle;
			if (FindCycle(cycle) == true)
			{
				std::cerr << "goto finished ..." << std::endl;
			}
			else
			{
				std::cerr << "no such cycle ..." << std::endl;
			}
			continue;
		}
		else if (read_msg == "runto" || read_msg == "rt")
		{
			if (mpCurrentIndex == NULL)
			{
				std::cerr << "no file loaded!";
				continue;
			}

			std::string str;
			std::cin >> str;

			char a;
			int t; // time
			int s; // stop time
			if (sscanf(str.c_str(), "%d%c%d", &t, &a, &s) != 3)
			{
				s = 0;
			}

			mRuntoCycle = Time(t, s);

			if (mRuntoCycle == mpObserver->CurrentTime())
			{
				std::cerr << "already here ...";
				continue;
			}
			else if (mRuntoCycle < mpObserver->CurrentTime())
			{
				std::cerr << "can not run to previous cycle";
				continue;
			}
			else
			{
				mRunning = true;
				return GetMessage(msg);
			}
		}
		else if (read_msg == "run" || read_msg == "r")
		{
			mRuntoCycle = -1;
			mRunning = true;
			return GetMessage(msg);
		}
		else if (read_msg == "msg" || read_msg == "m")
		{
			mShowMessage = !mShowMessage;
			std::cerr << "Set ShowMessage: " << mShowMessage << std::endl;
			continue;
		}
		else if (read_msg == "quit" || read_msg == "q")
		{
			std::cerr << "Bye ..." << std::endl;
			return MT_Null;
		}
		else
		{
			std::cerr << "Error command, only the following commands are aviliable: " << std::endl;
			std::cerr << "\tload"<< std::endl;
			std::cerr << "\tstep(s)" <<std::endl;
			std::cerr << "\trunto(rt)" <<std::endl;
			std::cerr << "\tgoto(g)" <<std::endl;
			std::cerr << "\trun(r)" << std::endl;
			std::cerr << "\tmsg(m)" << std::endl;
			std::cerr << "\ttype(t)" << std::endl;
			std::cerr << "\tquit(q)" << std::endl;
			continue;
		}
	}

	return MT_Null;
}


/**
* Get the Message.
* @param msg the message to get.
* @return the message type.
*/
MessageType DynamicDebug::GetMessage(char *msg)
{
	if (mpCurrentIndex == NULL)
	{
		return MT_Null;
	}

	if (mpCurrentIndex->mServerTime >= mFileHead.mMaxCycle)
	{
		std::cerr << "End ..." << std::endl;
		return MT_Null;
	}
	else
	{
		++mpCurrentIndex;
	}

	fseek(mpFile, mpCurrentIndex->mDataOffset, SEEK_SET);
	if (fread(msg, 1, 1, mpFile) < 1) // ��ȡ��Ϣ����
    {
        Assert(0);
    }
	MessageType msg_type = (MessageType)msg[0];

    if (mpCurrentIndex->mDataSize > 0 && fread(msg, mpCurrentIndex->mDataSize, 1, mpFile) < 1) // ��ȡ��Ϣ����
    {
        Assert(0);
    }
	msg[mpCurrentIndex->mDataSize] = '\0';

	if (mShowMessage == true)
	{
		std::cerr << msg << std::endl;
	}

	return msg_type;
}


/**
* Find a certain cycle.
* @param cycle the cycle to find.
* @return true if the certain cycle found.
*/
bool DynamicDebug::FindCycle(int cycle)
{
	Time cycle_time(cycle, 0);
	if (cycle_time == mpObserver->CurrentTime())
	{
		return true;
	}

	int  begin = 0;
	int end = mFileHead.mIndexTableSize - 1;
	int mid;
	while (begin < end)
	{
		mid = (begin + end) / 2;
		if (mpIndex[mid].mServerTime == cycle_time)
		{
			mpCurrentIndex = &mpIndex[mid];
			return true;
		}
		else if (mpIndex[mid].mServerTime < cycle_time)
		{
			begin = mid;
		}
		else
		{
			end = mid;
		}
	}
	return false;
}


/**
* Get the time of parser.
* @return the time of parser.
*/
timeval DynamicDebug::GetTimeParser()
{
	timeval time_val = mpParserTime[mpCurrentIndex->mTimeOffset++];
	return time_val;
}


/**
* Get the time of decision.
* @return the time of decision.
*/
timeval DynamicDebug::GetTimeDecision()
{
	timeval time_val = mpDecisionTime[mpCurrentIndex->mTimeOffset++];
	return time_val;
}


/**
* Get the time of sending the command.
* @return the time of sending the command.
*/
timeval DynamicDebug::GetTimeCommandSend()
{
	timeval time_val = mpCommandSendTime[mpCurrentIndex->mTimeOffset++];
	return time_val;
}



/**
* Save the server message.
*/
void DynamicDebug::Flush()
{
    if (PlayerParam::instance().SaveServerMessage() && 
        !PlayerParam::instance().DynamicDebugMode())
    {
	    if (mpFile != NULL)
	    {
		    long i = 0; // ѭ������
		    mFileHead.mHeadFlag[0] = 'D';
		    mFileHead.mHeadFlag[1] = 'D';

		    // ��ֵ4�����Ĵ�С�����潫Ҫд���ļ���
		    mFileHead.mIndexTableSize = mIndexTable.size();
		    mFileHead.mParserTableSize = mParserTimeTable.size();
		    mFileHead.mDecisionTableSize = mDecisionTimeTable.size();
		    mFileHead.mCommandSendTableSize = mCommandSendTimeTable.size();

		    //message
		    long size = mFileHead.mIndexTableSize;
		    for (i = 0; i < size; ++i) {
			    mIndexTable[i].mDataOffset = ftell(mpFile);
			    fwrite(& mMessageTable[i].mType, 1, 1, mpFile); // ��д����Ϣ����
			    fwrite(mMessageTable[i].mString.c_str(), mIndexTable[i].mDataSize, 1, mpFile);
		    }

		    // index table
		    mFileHead.mIndexTableOffset = ftell(mpFile);
		    mpIndex = new MessageIndexTableUnit[size];
		    for (i = 0; i < size; ++i)
		    {
			    memcpy(&mpIndex[i], &mIndexTable[i], sizeof(MessageIndexTableUnit));
		    }
		    fwrite(mpIndex, size * sizeof(MessageIndexTableUnit), 1, mpFile);

		    // observer time
		    mFileHead.mParserTableOffset = ftell(mpFile);
		    size = mFileHead.mParserTableSize;
		    mpParserTime = new timeval[size];
		    for (i = 0; i < size; ++i)
		    {
			    mpParserTime[i] = mParserTimeTable[i];
		    }
		    fwrite(mpParserTime, size * sizeof(timeval), 1, mpFile);

		    // decision time
		    mFileHead.mDecisionTableOffset = ftell(mpFile);
		    size = mFileHead.mDecisionTableSize;
		    mpDecisionTime = new timeval[size];
		    for (i = 0; i < size; ++i)
		    {
			    mpDecisionTime[i] = mDecisionTimeTable[i];
		    }
		    fwrite(mpDecisionTime, size * sizeof(timeval), 1, mpFile);

		    // commandsend time
		    mFileHead.mCommandSendTableOffset = ftell(mpFile);
		    size = mFileHead.mCommandSendTableSize;
		    mpCommandSendTime = new timeval[size];
		    for (i = 0; i < size; ++i)
		    {
			    mpCommandSendTime[i] = mCommandSendTimeTable[i];
		    }
		    fwrite(mpCommandSendTime, size * sizeof(timeval), 1, mpFile);

		    fseek(mpFile, 0, SEEK_SET);
		    fwrite(&mFileHead, sizeof(mFileHead), 1, mpFile);
	    }

	    if (mpFile != NULL)
	    {
		    fclose(mpFile);
	    }
    }
}


//end of file DynamicDebug.cpp

