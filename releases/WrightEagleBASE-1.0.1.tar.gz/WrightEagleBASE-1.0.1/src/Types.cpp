/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include <cmath>
#include "Types.h"

const Unum Unum_Unknown = 0;

const char *ServerPlayModeString[] =
{
		"",
		"before_kick_off",
		"time_over",
		"play_on",
		"kick_off_l",
		"kick_off_r",
		"kick_in_l",
		"kick_in_r",
		"free_kick_l",
		"free_kick_r",
		"corner_kick_l",
		"corner_kick_r",
		"goal_kick_l",
		"goal_kick_r",
		"goal_l",
		"goal_r",
		"drop_ball",
		"offside_l",
		"offside_r",
		"penalty_kick_l",
		"penalty_kick_r",
		"first_half_over",
		"pause",
		"human_judge",
		"foul_charge_l",
		"foul_charge_r",
		"foul_push_l",
		"foul_push_r",
		"foul_multiple_attack_l",
		"foul_multiple_attack_r",
		"foul_ballout_l",
		"foul_ballout_r",
		"back_pass_l",
		"back_pass_r",
		"free_kick_fault_l",
		"free_kick_fault_r",
		"catch_fault_l",
		"catch_fault_r",
		"indirect_free_kick_l",
		"indirect_free_kick_r",
		"penalty_setup_l",
		"penalty_setup_r",
		"penalty_ready_l",
		"penalty_ready_r",
		"penalty_taken_l",
		"penalty_taken_r",
		"penalty_miss_l",
		"penalty_miss_r",
		"penalty_score_l",
		"penalty_score_r",
		"goalie_catch_ball_l",
		"goalie_catch_ball_r",
		"time_up",
		"half_time",
		"time_extended",
		"penalty_onfield_l",
		"penalty_onfield_r",
		"penalty_foul_l",
		"penalty_foul_r",
		"penalty_winner_l",
		"penalty_winner_r",
		"foul_l",
		"foul_r"
};

/**
 * ǿ����ɶδ����Ա㱻�����ܼ�¼��log��coredump
 * Create a segmentation fault for recording log and coredump file.
 */
int abort_with_SIGSEGV(const char *expr, const char *file, int line, const char *function)
{
	fprintf(stderr, "%s in %s:%d aborted at %s\n", function, file, line, expr);
	int *p = 0;
	*p = 1; //segfault here
	return *p;
}

//end of Types.cpp

