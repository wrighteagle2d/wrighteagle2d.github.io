/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "Plotter.h"
#include "PlayerParam.h"

Plotter::Plotter():
	mIsDisplayOk(false),
	mIsGnuplotOk(false),
	mpGnupolot(0)
{
	Init();
}

Plotter::~Plotter() {
	Close();
}

Plotter & Plotter::instance()
{
	static Plotter plotter;
	return plotter;
}

void Plotter::Init()
{
#ifndef WIN32
	mIsDisplayOk = getenv("DISPLAY") != NULL;

	if (PlayerParam::instance().UsePlotter()) {
		mpGnupolot = popen("gnuplot", "w");
	}

	if (mpGnupolot){
		if (mIsDisplayOk) {
			GnuplotExecute("set terminal x11");
		}
	}
#endif
}

void Plotter::Close()
{
#ifndef WIN32
	for (std::list<std::string>::iterator it = mTmpFile.begin(); it != mTmpFile.end(); ++it) {
		std::remove(it->c_str());
	}

    if (mpGnupolot && pclose(mpGnupolot) == -1) {
        fprintf(stderr, "problem closing communication to gnuplot\n") ;
        return ;
    }
#endif
}

void Plotter::GnuplotExecute(const char *  cmd, ...)
{
#ifndef WIN32
	if (!mpGnupolot) return;

    va_list ap ;
    char    local_cmd[GP_CMD_SIZE];

    va_start(ap, cmd);
    vsprintf(local_cmd, cmd, ap);
    va_end(ap);

    strcat(local_cmd, "\n");

    fputs(local_cmd, mpGnupolot) ;
    fflush(mpGnupolot) ;
    return ;
#endif
}

void Plotter::SetStyle(char * plot_style)
{
    if (strcmp(plot_style, "lines") &&
        strcmp(plot_style, "points") &&
        strcmp(plot_style, "linespoints") &&
        strcmp(plot_style, "impulses") &&
        strcmp(plot_style, "dots") &&
        strcmp(plot_style, "steps") &&
        strcmp(plot_style, "errorbars") &&
        strcmp(plot_style, "boxes") &&
        strcmp(plot_style, "boxerrorbars")) {
        fprintf(stderr, "warning: unknown requested style: using points\n") ;
        strcpy(mPlotStyle, "points") ;
    }
    else {
        strcpy(mPlotStyle, plot_style) ;
    }
}

void Plotter::SetXLabel(char * label)
{
    char    cmd[GP_CMD_SIZE];
    sprintf(cmd, "set xlabel \"%s\"", label);
    GnuplotExecute(cmd);
}

void Plotter::SetYLabel(char * label)
{
    char    cmd[GP_CMD_SIZE];
    sprintf(cmd, "set ylabel \"%s\"", label);
    GnuplotExecute(cmd);
}

void Plotter::Reset()
{
	GnuplotExecute("reset");
}

void Plotter::PlotX(double * d, int n, char * title)
{
#ifndef WIN32
	if (!mpGnupolot) return;

	//create a tmp file
	char    name[128];
	sprintf(name, "/tmp/plotx-XXXXXX");

	int tmpfd;
    if ((tmpfd = mkstemp(name)) == -1) {
        fprintf(stderr,"cannot create temporary file: exiting plot") ;
        return ;
    }

    mTmpFile.push_back(std::string(name));

	//write data
    char    line[GP_CMD_SIZE];
    for (int i=0 ; i<n ; i++) {
        sprintf(line, "%g\n", d[i]);
        if (write(tmpfd, line, strlen(line)) < 1)
        {
            Assert(0);
        }
    }
    close(tmpfd) ;

	//plot this file
    if (title == NULL) {
    	sprintf(line, "%s \"%s\" with %s", "plot", name, mPlotStyle) ;
    } else {
    	sprintf(line, "%s \"%s\" title \"%s\" with %s", "plot", name,
    			title, mPlotStyle) ;
    }
    GnuplotExecute(line);
#endif
}

void Plotter::PlotXY(double * x, double * y, int n, char * title)
{
#ifndef WIN32
	if (!mpGnupolot) return;

	//create a tmp file
	char    name[128];
	sprintf(name, "/tmp/plotxy-XXXXXX");

	int tmpfd;
    if ((tmpfd = mkstemp(name)) == -1) {
        fprintf(stderr,"cannot create temporary file: exiting plot") ;
        return ;
    }

    mTmpFile.push_back(std::string(name));

	//write data
    char    line[GP_CMD_SIZE];
    for (int i=0 ; i<n ; i++) {
        sprintf(line, "%g %g\n", x[i], y[i]);
        if (write(tmpfd, line, strlen(line)) < 1)
        {
            Assert(0);
        }
    }
    close(tmpfd) ;

	//plot this file
    if (title == NULL) {
    	sprintf(line, "%s \"%s\" with %s", "plot", name, mPlotStyle) ;
    } else {
    	sprintf(line, "%s \"%s\" title \"%s\" with %s", "plot", name,
    			title, mPlotStyle) ;
    }
    GnuplotExecute(line);
#endif
}

void Plotter::PlotToFile(char * file_name)
{
	GnuplotExecute("set terminal png");
	GnuplotExecute("set output Logfiles/\"%s\"", file_name);
}

void Plotter::PlotToDisplay()
{
	GnuplotExecute("set termianl x11");
}
