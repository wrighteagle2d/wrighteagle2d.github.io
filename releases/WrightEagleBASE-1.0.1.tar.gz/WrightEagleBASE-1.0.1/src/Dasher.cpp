/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#include "Dasher.h"
#include "Logger.h"
#include "Agent.h"
#include "Geometry.h"
#include "Kicker.h"
#include "MotionModel.h"

double Dasher::GETBALL_BUFFER = 0.06;

//==============================================================================
Dasher::Dasher()
{
}


//==============================================================================
Dasher::~Dasher()
{
}


//==============================================================================
Dasher & Dasher::instance()
{
	static Dasher dasher;
	return dasher;
}


/** �����ķ�ʽ�ܵ�Ŀ���
* Run to the destination point with the fastest method.
* \param agent the agent itself.
* \param act an atomic action caculated to go to pos for this cycle.
* \param pos the destination point.
* \param buffer point buffer, means the real destinantion is a cycle with the certer 
* 		of pos and radius of buffer.
* \param power the intend power to use.
* \param can_inverse true means can run in the inverse direction of the agent's body.
* \param turn_first true means that the agent should turn first to adjust the direction.
*/
void Dasher::GoToPoint(Agent & agent, AtomicAction & act, Vector target, double buffer, double power, bool can_inverse, bool turn_first)
{
	act.Clear();

	target = FixRoute(agent, target);

	const Vector & my_pre_pos = agent.Self().GetPredictedPos(1);
	double dist = my_pre_pos.Dist(target);

	if (dist < buffer){
		act.mSucceed = true;
		return;
	}
	AngleDeg dirdiff = GetNormalizeAngleDeg((target - my_pre_pos).Dir() - agent.GetSelf().GetBodyDir());

	if (fabs(dirdiff) < 90.0){
		can_inverse = false; //����Ҫ������
	}

	bool inverse = false;
	if (can_inverse){
		int cycle = CycleNeedToPointWithCertainPosture(agent.Self(), target, true);
		if (cycle < 9 && cycle < CycleNeedToPointWithCertainPosture(agent.Self(), target, false)){
			inverse = true;
		}
	}

	GoToPointWithCertainPosture(agent, act, target, buffer, power, inverse, turn_first);
}

/** ��ȷ�������ƣ�ָ�����ܺ����ܣ����ܵ�Ŀ���
* Run to the destination point with a certain posture, forward or backword.
* \param agent the agent itself.
* \param act an atomic action caculated to go to pos for this cycle.
* \param pos the destination point.
* \param buffer point buffer, means the real destinantion is a cycle with the center
* 		of pos and radius of buffer.
* \param power the intend power to use.
* \param inverse true means run backward.
* \param turn_first true means that the agent should turn first to adjust the direction.
*/
void Dasher::GoToPointWithCertainPosture(Agent & agent, AtomicAction & act, Vector target, double buffer, double power, const bool inverse, bool turn_first)
{
	Assert(!Isnan(target.X()) && !Isnan(target.Y()));

	act.Clear();

	const Vector & my_pre_pos = agent.Self().GetPredictedPos(1);
	double dist = my_pre_pos.Dist(target);
	AngleDeg dirdiff = inverse? GetNormalizeAngleDeg((my_pre_pos - target).Dir() - agent.GetSelf().GetBodyDir()): GetNormalizeAngleDeg((target - my_pre_pos).Dir() - agent.GetSelf().GetBodyDir()); //��Ҫת���ĽǶ�

	double bufang;

	buffer = Max(0.05, buffer); //TODO: wait test

	if (buffer > FLOAT_EPS){
		bufang = ASin(buffer / dist / 2) * 2;
		bufang = Max(10.0, bufang);
	}
	else {
		bufang = 0.0;
	}

	if (fabs(dirdiff) > bufang){
		TurnDashPlaning(agent, act, target, buffer, power, inverse, turn_first);
	}
	else {
		power = inverse? -fabs(power): fabs(power);
		power = agent.GetSelf().CorrectDashPowerForStamina(power);
		if (fabs(power) > FLOAT_EPS){
			act.mType = CT_Dash;
			act.mDashPower = AdjustPowerForDash(agent.Self(), target, buffer, power);
			act.mDashPower = agent.GetSelf().CorrectDashPowerForStamina(act.mDashPower);
			if (fabs(act.mDashPower) > FLOAT_EPS){
				act.mSucceed = true;
			}
			else {
				act.mType = CT_None; //powerΪ��ʱ�Ͳ�Ҫִ���ˣ�û����
				TurnDashPlaning(agent, act, target, buffer, power, inverse, turn_first);//�ٴο���ת��������©��һ�ߺõ�ת���Ļ���
			}
		}
	}
}

/**
* ����ת����ֱ��dash
* Planing to turn or to dash.
* @param agent the agent itself.
* @param act an atomic action to return the caculated decision.
* @param target the target position to go to.
* @param buffer
* @param power the intend power for dash.
* @param inverse true means running backwards.
* @param turn_first true means turn first manually.
*/
void Dasher::TurnDashPlaning(Agent & agent, AtomicAction & act, Vector target, double buffer, double power, bool inverse, bool turn_first)
{
	act.Clear();

	power = inverse? -fabs(power): fabs(power);
	power = agent.GetSelf().CorrectDashPowerForStamina(power);

	PlayerState & self = agent.Self();
	const Vector & my_pre_pos = self.GetPredictedPos(1);
	double target_dist = my_pre_pos.Dist(target);
	AngleDeg target_ang = inverse? GetNormalizeAngleDeg((my_pre_pos - target).Dir() - agent.GetSelf().GetBodyDir()): GetNormalizeAngleDeg((target - my_pre_pos).Dir() - agent.GetSelf().GetBodyDir()); //��Ҫת���ĽǶ�

	//DT_none
	//����ת������,����1dash + 1turn����
	double bufang;
	if(buffer > FLOAT_EPS){
		bufang = ASin(buffer / target_dist / 2) * 2;
		bufang = Max(10.0, bufang);
	}
	else{
		bufang = 0.0;
	}

	const double & effort = self.GetEffort();
	const double & accrate = self.GetDashPowerRate();
	const double & inertia_moment = self.GetInertiaMoment();
	const double & decay = self.GetPlayerDecay();
	const double & speedmax = self.GetEffectiveSpeedMax();
	const Vector & vel = self.GetVel();

	const double & facing = self.GetBodyDir();
	double speed = vel.Mod();


	double diffang = fabs(target_ang);
    double oneturnang = self.GetMaxTurnAngle();
	if(buffer < FLOAT_EPS && target_dist > 2.6){
		oneturnang += 2.6;
	}

	if(turn_first || diffang <= oneturnang || speed < 0.04){ //���������Ĵ��ڣ��ڷ����巽��Ҳ���ٶȣ���Ҳ����������̫Сʱ����ֱ��ת,0.04��һ���Ա����ֵ
		act.mType = CT_Turn;
		act.mTurnAngle = target_ang;
		act.mSucceed = true;
		return;
	}
	else {
		//����1 dash + 1turn;
		//���涼����dash��ʲô�ٶ����
		double mspd1 = (180.0/ ( diffang + 10 ) - 1.0 ) / inertia_moment; //10��buf����Ȼ���׵��������û�ת������
		double dash2spd = Min(mspd1 / decay, speedmax) / (1 + ServerParam::instance().playerRand());

		if( fabs(GetNormalizeAngleDeg(vel.Dir() - facing)) > 90.0){
			speed = -speed;
		}

		double spd_inf = Max(speed - accrate * ServerParam::instance().maxDashPower(), -dash2spd);
		double spd_sup = Min(speed + accrate * ServerParam::instance().maxDashPower(), dash2spd);
		Ray cur_r(self.GetPos(), facing);
		Vector pt_inf = cur_r.GetPoint(spd_inf * (1.0 + decay));
		Vector pt_sup = cur_r.GetPoint(spd_sup * (1.0 + decay));
		Vector pt;//Ҫȡ�õ�
		bool bnegtive;//Ҫ�ܵĵ��ǲ���������
		Line pdl = Line(cur_r).GetPerpendicular(target);//����
		if(pdl.IsPointInSameSide(pt_inf, pt_sup)){
			if(fabs(GetNormalizeAngleDeg(facing-target_ang)) < 90.0){
				pt = pt_sup;
				bnegtive = (spd_sup<0);
			}
			else{
				pt = pt_inf;
				bnegtive = (spd_inf<0);
			}
		}
		else{
			double dist;
			bnegtive = !cur_r.Intersection(pdl, dist); //����
			pt = cur_r.GetPoint(dist);
		}
		double dis = pt.Dist(target);//�������ں���point�ľ���,����compare with 2 turn
		double twoturnang = oneturnang + 180.0 / (1.0 + inertia_moment * fabs(speed) * decay);
		if(twoturnang > diffang){
			const Vector & pt2 = self.GetPredictedPos(2);
			double dis2 = pt2.Dist(target);
			if(dis2 < dis || diffang > 102.6){ //һ��ת̫�����Ҳ����ֱ��2turn
				act.mType = CT_Turn;
				act.mTurnAngle = target_ang;
				act.mSucceed = true;
				return;
			}
		}
		double spd_need;
		if(bnegtive){
			spd_need = -(pt - self.GetPos()).Mod() / (1.0 + decay);
		}
		else{
			spd_need = (pt - self.GetPos()).Mod() / (1.0 + decay);
		}
		//������dash��dash����ת������...,���ž�������
		double turnang_after_dash = 180.0 / (1.0 + inertia_moment * fabs(spd_need) * decay) - 5.0;
		if(GetAngleDegDiffer((target - pt).Dir(), facing) > turnang_after_dash ){
			act.mType = CT_Turn;
			act.mTurnAngle = target_ang;
			act.mSucceed = true;
			return;
		}
		double power = ( spd_need - speed ) / accrate / effort;
		//I over
		act.mType = CT_Dash;
		act.mDashPower = AdjustPowerForDash(self, pt, FLOAT_EPS, power);
		act.mDashPower = agent.GetSelf().CorrectDashPowerForStamina(act.mDashPower);
		if(fabs(act.mDashPower) > FLOAT_EPS)
		{
			act.mSucceed = true;
		}
		else {
			act.mType = CT_Turn; //powerΪ��ʱ�Ͳ�Ҫִ���ˣ�û����
			act.mTurnAngle = 0.0;
			act.mSucceed = true;
		}
	}
}

/** �����ķ�ʽ�ܵ�Ŀ���
* Run to the destination point with the fastest method.
* \param agent the agent itself.
* \param pos the destination point.
* \param buffer point buffer, means the real destinantion is a cycle with the certer 
* 		of pos and radius of buffer.
* \param power the intend power to use.
* \param can_inverse true means can run in the inverse direction of the agent's body.
* \param turn_first true means that the agent should turn first to adjust the direction.
* \return true if the action excuted successfully.
*/
bool Dasher::GoToPoint(Agent & agent, Vector pos, double buffer, double power, bool can_inverse, bool turn_first)
{
	AtomicAction act;

	GoToPoint(agent, act, pos, buffer, power, can_inverse, turn_first);
	return act.Execute(agent);
}

/**
* ��Ҫ��Ϊ�˵���power�ã�Ϊ�˱���power������ܹ���
* Ŀ��㡣ԭ����Ϊ�˸��߲�Э����powerֻ���ܼ�С����
* ������Ϊ�˲���Ҫ��dash��powerҲ�ɿ���Ϊ�㡣Ҳ��
* dash��ִ��
* power ���������������
* This funcition is mainly used to adjust ( usually decrease ) the dash power 
* to avoid run over the target position by using a big power. The final power 
* could be 0 to avoid an unnecessary dash.
* The sign of power is given outside the function.
* @param player the player to caculate.
* @param target the target position to go to.
* @param buffer
* @param power orignal power given.
* @return power adjusted.
*/
double Dasher::AdjustPowerForDash(const PlayerState & player, Vector target, double buffer, double power)
{
	const double & speedmax = player.GetEffectiveSpeedMax();
	const double & effort = player.GetEffort();
	const double & accrate = player.GetDashPowerRate();
	const Vector & pos = player.GetPos();
	const Vector & vel = player.GetVel();

	const double & facing = player.GetBodyDir();

	if (pos.Dist(target) > speedmax + buffer){ //��ô�ܵĶ������ܹ�
		return power;
	}

	if((pos + vel).Dist(target) < buffer) { //����Ҳ�ܵ�����Ͳ�������
		return 0.0;
	}

	Line dash_line(Ray(pos, player.GetBodyDir()));
	Vector projective_target = dash_line.GetProjectPoint(target);
	Vector acc = projective_target - pos - vel;
	double dash_power = acc.Mod() / (effort * accrate);
	if (GetAngleDegDiffer(acc.Dir(), facing) > 90.0){
		dash_power = -dash_power;
	}

	if (power > 0){
		return MinMax(ServerParam::instance().minDashPower(), dash_power, power);
	}
	else {
		return MinMax(power, dash_power, ServerParam::instance().maxDashPower());
	}
}

/**
* ����player�ܵ�target�������С��������������dash
* Ŀǰ�ǰ����ϵ�dashģ�����
*/
/**
* player �ܵ� target ���������С������
* This function returns the minimum cycles for a player to go to a target position.
* @param player the player to caculate.
* @param target the target position to go to.
* @param can_inverse true means consider running backwards.
* @param buffer
* @return an integer to show the minimum cycles caculated.
*/
int Dasher::CycleNeedToPoint(const PlayerState & player, Vector target, bool can_inverse, double *buf)
{
	const Vector & pos = player.GetPos();
	const Vector & vel = player.GetVel();

	const double dir = (target - pos).Dir();

	double facing;
	if (player.IsBodyDirValid()) {
		facing = player.GetBodyDir();
	}
	else if (vel.Mod() > 0.26){
		facing = vel.Dir();
	}
	else {
		facing = dir; //��Ϊ����ת��
	}

	double diffang = fabs(GetNormalizeAngleDeg(dir - facing));

	if (diffang < 90.0){
		can_inverse = false; //û�б�Ҫ������
	}

	if (can_inverse){
		if (buf != 0) {
			double tmp;

			int cycle1 = CycleNeedToPointWithCertainPosture(player, target, true, buf);
			int cycle2 = CycleNeedToPointWithCertainPosture(player, target, false, &tmp);

			if (cycle2 <= cycle1) {
				*buf = tmp;
			}

			return Min(cycle1, cycle2);
		}
		else {
			int cycle1 = CycleNeedToPointWithCertainPosture(player, target, true);
			int cycle2 = CycleNeedToPointWithCertainPosture(player, target, false);
			return Min(cycle1, cycle2);
		}
	}
	else {
		return CycleNeedToPointWithCertainPosture(player, target, false, buf);
	}
}

/**
* player ��ȷ�������ƣ�ָ�����ܺ����ܣ����ܵ� target ����Ҫ��������
* This function returns the minimum cycles for a player to go to a target position with 
* a certain posture, forward or backward.
* @param player the player to caculate.
* @param target the target position to go to.
* @param inverse true means running backwards.
* @param buffer 
* @return an integer to show the minimum cycles caculated.
*/
int Dasher::CycleNeedToPointWithCertainPosture(const PlayerState & player, Vector target, const bool inverse, double *buf)
{
	Assert(!Isnan(target.X()) && !Isnan(target.Y()));

	int cycle = 0; //�õ�����

	const double & decay = player.GetPlayerDecay();
	const double & speedmax = player.GetEffectiveSpeedMax();
	const double & stamina = player.GetStamina();
	const double & stamina_inc_max = player.GetStaminaIncMax();
	const double & dash_max = ServerParam::instance().maxDashPower();
	const Vector & pos = player.GetPos();
	const Vector & vel = player.GetVel();

	const double accrate = player.GetDashPowerRate() * player.GetEffort();
	double speed = vel.Mod();

	const Vector predict_pos_1 = pos + vel;
	const Vector predict_pos_2 = predict_pos_1 + vel * decay;
	const double dir = (target - pos).Dir();
	double dis = (target - predict_pos_1).Mod();

	const double kick_area = player.IsGoalie()? ServerParam::instance().catchAreaLength(): (player.GetKickableArea() - GETBALL_BUFFER);

	if (dis <= kick_area){
		dis = pos.Dist(target);
		if (buf) *buf = 0;
		return 1;
	}

	double facing;
	if (player.IsBodyDirValid()) {
		facing = player.GetBodyDir();
	}
	else if (speed > 0.26){
		facing = vel.Dir();
	}
	else {
		facing = dir; //��Ϊ����ת��
	}

	double diffang = fabs(GetNormalizeAngleDeg(dir - facing));
	const double oneturnang = player.GetMaxTurnAngle();
	const double stamina_recovery_thr = ServerParam::instance().recoverDecThr() * ServerParam::instance().staminaMax();

	double angbuf = FLOAT_EPS;
	angbuf = ASin(kick_area / dis);
	angbuf = Max(angbuf , 15.0);

	if (inverse) {
		diffang = 180.0 - diffang;
		facing = GetNormalizeAngleDeg(180.0 + facing);
	}

	//I �����׶�
	if(diffang <= angbuf){ //����Ҫת��
		target = (target - pos).Rotate(-facing);
		dis = fabs(target.X());
		double y = fabs(target.Y());
		if(y < kick_area){
			dis -= sqrt(kick_area * kick_area - y * y);
		}
		speed *= Cos(vel.Dir() - facing); //���巽���ϵ�ͶӰ
	}
	else if(diffang <= oneturnang){
		cycle += 1;
		target -= predict_pos_1;
		speed *= Cos(vel.Dir() - dir); //ȡ��Ŀ�귽���ͶӰ
		speed *= decay;//����ͶӰ.��ֱ����1�����ں�˥����10+������,������1turnʱ�ɼ��뿼��������
		dis = target.Mod();
		dis -= kick_area;
	}
	else{ //��Ϊת�����£���ϸ�£�
		cycle += 2;
		target -= predict_pos_2;
		speed *= Cos(vel.Dir() - dir); //ȡ��Ŀ�귽���ͶӰ
		speed *= decay * decay;//����ͶӰ.��ֱ����1�����ں�˥����10+������,������1turnʱ�ɼ��뿼��������
		dis = target.Mod();
		dis -= kick_area;
	}

	if (dis <= 0){
		if(buf != NULL){
			*buf = -dis / ( speed / decay);
			*buf = Min(*buf , 0.99);
		}
		return Max(cycle, 0);
	}

	//II ���� & ���������׶�
	const double stamina_used_per_cycle = inverse? dash_max * 2.0: dash_max;
	const int full_cyc = int((stamina - stamina_recovery_thr) / (stamina_used_per_cycle - stamina_inc_max)); //�������׶�
	int acc_cyc = 0;//���ٽ׶�
	const double speedmax_thr = speedmax * decay * 0.98;
	const double accmax = accrate * dash_max;

	while(acc_cyc < full_cyc && speed < speedmax_thr){
		speed += accmax;
		if(speed > speedmax){
			speed = speedmax;
		}
		dis -= speed;
		if(dis <= 0){//��û���ٵ������ܵ���...
			cycle += acc_cyc + 1;
			if(buf != NULL){
				*buf = -dis /( speed / decay );
				*buf = Min(*buf , 0.99);
			}
			return Max(cycle, 0);
		}
		speed *= decay;
		++ acc_cyc;
	}

	cycle += acc_cyc;

	//III �������ٽ׶�
	int aver_cyc = full_cyc - acc_cyc;
	double aver_cyc_dis = aver_cyc * speedmax;
	if(aver_cyc_dis >= dis){
		if(buf != NULL){
			double realcyc = cycle + dis / speedmax;
			cycle = int( ceil(realcyc) );
			*buf = cycle - realcyc;
			return Max(cycle, 0);

		}
		else{
			cycle = int(ceil( cycle + dis / speedmax));
			return Max(cycle, 0);
		}
	}
	else{
		cycle += aver_cyc;
		dis -= aver_cyc_dis;
	}

	//IV û��(0����)���ٽ׶�
	double acc_tired = stamina_inc_max * accrate;
	double speed_tired = acc_tired / (1 - decay);
	double speed_tired_thr = speed_tired * decay;
	speed *= decay;
	while(dis > 0 && fabs(speed - speed_tired_thr) > 0.004){
		speed += acc_tired;
		dis -= speed;
		speed *= decay;
		++cycle;
	}

	if(dis <= 0){
		if(buf != NULL){
			*buf = -dis / ( speed / decay);
			*buf = Min(*buf , 0.99);
		}
		return Max(cycle, 0);
	}

	//V û��(0����)���ٽ׶�

    if( buf != NULL){
        double realcyc = cycle + dis / speed_tired;
        cycle = int( ceil( realcyc ) );
        *buf = cycle - realcyc;
        return Max(cycle, 0);
    }
    else{
    	cycle = cycle + int(ceil ( dis / speed_tired));
    	return Max(cycle, 0);
    }
}

/*
 * Caculate the minimum cycles for a player dashing to a point considering that the dash method
 * is forward/backward and then sideward or sideward and then forward/backward.
 * @param player the player to caculate.
 * @param expected_cycle the expected cycles for the player to dash to the point.
 * @param target the target position to go to.
 * @param dash_dir the direction of dash.
 * @param dash_type the type of dash.
 * @param change_cycle the cycle change caculated.
 * @param buf cycle allowance.
 * @param dashpower an array of 4 units, stores 4 dash power for 
 * 	1.dash to get the ball
 * 	2.dash to collide with ball
 * 	3.dash to avoid collision
 * 	4.dash to miss ball.
 * @return an integer to show the cycles needed.
 */
int Dasher::CycleNeedToDashToPoint(const PlayerState & player, int expected_cycle, const Vector target, AngleDeg & dash_dir, DashType & dash_type, int & change_cycle, double buf[2], int * dashpower)
{
	int cycle = 0; //�õ�����

	const double & decay = player.GetPlayerDecay();
	const double & stamina_inc_max = player.GetStaminaIncMax();
	const Vector & pos = player.GetPos();
	const Vector & vel = player.GetVel();

	double stamina = player.GetStamina();

	const double accrate = player.GetDashPowerRate() * player.GetEffort();
	const double speed = vel.Mod();

	const double dir = (target - pos).Dir();

	double facing;
	if (player.IsBodyDirValid()) {
		facing = player.GetBodyDir();
	}
	else if (speed > 0.26){
		facing = vel.Dir();
	}
	else {
		facing = dir; //��Ϊ����ת��
	}

	const double kick_area = player.IsGoalie()? ServerParam::instance().catchAreaLength(): (player.GetKickableArea() - GETBALL_BUFFER);
	const double stamina_recovery_thr = ServerParam::instance().recoverDecThr() * ServerParam::instance().staminaMax();

	bool inverse; //���ܽ׶ε��Ƿ�Ҫ������
	const Vector predict_pos_1 = pos + vel;
	Vector prepoint = ( target - predict_pos_1).Rotate( -facing);
	if(prepoint.X() < 0){
		inverse = true;//������
	}
	else{
		inverse = false;//����
	}

	const Vector rel_target = ( target - pos ).Rotate( -facing);
	const double forward_dist = fabs(rel_target.X());
	const double sideward_dist = fabs(rel_target.Y());

	dash_type = DT_None;
	dash_dir = 0.0;
	change_cycle = 1000;

	//���y
	if(sideward_dist > kick_area){
		double side_facing;
		if (rel_target.Y() > 0) {
			dash_dir = 90.0;
			side_facing = facing + 90.0;
		}
		else {
			dash_dir = -90.0;
			side_facing = facing - 90.0;
		}

		/**
		 * �滮��dashʱҪ�������巽���ϳ��ٶȵ�Ӱ�죬��Ϊ����ٶȿ��ܱȽϴ�
		 * */
		/*const*/ double forward_speed = speed * Cos(vel.Dir() - facing); //���巽���ϵ�ͶӰ, +/-
		if (inverse) {
			forward_speed *= -1.0; //�õ�Ŀ�귽���ͶӰ
		}
		const double offset_1 = forward_speed; //���ٶ���ɵ����巽���ϵ�һ����ƫ��
		const double max_offset = forward_speed / (1.0 - player.GetDecay()); //���ٶ���ɵ����巽���ϵ����ƫ��

		const double forward_dist_final = fabs(forward_dist - max_offset);
		const double forward_dist_1     = fabs(forward_dist - offset_1);

		if (forward_dist_final < kick_area){ //ֱ�Ӳ�dash�϶����õ�
			double sideward_speed = speed * Cos(vel.Dir() - side_facing); //����෽���ϵ�ͶӰ
			int cycle2 = CycleNeedToDashForDist(sideward_dist,  expected_cycle, sideward_speed, decay, accrate * ServerParam::instance().sideDashRate(), forward_dist_final, kick_area, stamina, stamina_recovery_thr, 1, stamina_inc_max, buf, dashpower);
			dash_type = DT_Sideward;
			change_cycle = Max(cycle + cycle2, 0);
			return change_cycle;
		}
		else if (forward_dist_1 < kick_area) { //�п��ܲ�dashһ�����ھ��õ���
			double sideward_speed = speed * Cos(vel.Dir() - side_facing); //����෽���ϵ�ͶӰ
			int cycle2 = CycleNeedToDashForDist(sideward_dist,  expected_cycle, sideward_speed, decay, accrate * ServerParam::instance().sideDashRate(), forward_dist_1, kick_area, stamina, stamina_recovery_thr, 1, stamina_inc_max, buf, dashpower);
			if (cycle2 == 1) {
				dash_type = DT_Sideward;
				change_cycle = Max(cycle + cycle2, 0);
				return change_cycle;
			}
		}

		{
			//Ҫ�������׶�dash
			//I. ����dash�ٲ�dash
			double forward_speed = speed * Cos(vel.Dir() - facing); //���巽���ϵ�ͶӰ
			if (inverse) {
				forward_speed *= -1.0; //�õ�Ŀ�귽���ͶӰ
			}
			int forward_cycle = CycleNeedToDashForDist(forward_dist, expected_cycle, forward_speed, decay, accrate, 0.0, kick_area, stamina, stamina_recovery_thr, inverse? 2: 1, stamina_inc_max, buf, dashpower);
			if (forward_cycle > expected_cycle){ //���������Ѿ�û������
				return 1000;
			}
			else {
				if (inverse) {
					dashpower[0] *= -1;
					dashpower[1] *= -1;
					dashpower[2] *= -1;
					dashpower[3] *= -1;
				}

				double sideward_dist1 = sideward_dist;
				double sideward_speed = speed * Cos(vel.Dir() - side_facing); //����෽���ϵ�ͶӰ
				for (int i = 0; i < forward_cycle; ++i) {
					sideward_dist1 -= sideward_speed;
					sideward_speed *= decay; //���ܽ׶εĳ��ٶ�
				}

				if (sideward_dist1 < FLOAT_EPS) {
					Assert(0);
				}

				double buf3[2];
				int sideward_cycle = CycleNeedToDashForDist(sideward_dist1, expected_cycle - forward_cycle, sideward_speed, decay, accrate * ServerParam::instance().sideDashRate(), 0.0, kick_area, stamina, stamina_recovery_thr, 1, stamina_inc_max, buf3, 0);
				if (sideward_cycle > expected_cycle - forward_cycle) {
					return 1000;
				}

				//II.�Ȳ�dash����dash
				double sideward_speed2 = speed * Cos(vel.Dir() - side_facing); //����෽���ϵ�ͶӰ

				double buf2[2];
				int dashpower2[4];
				int sideward_cycle2 = CycleNeedToDashForDist(sideward_dist, expected_cycle, sideward_speed2, decay, accrate * ServerParam::instance().sideDashRate(), 0.0, kick_area, stamina, stamina_recovery_thr, 1, stamina_inc_max, buf2, dashpower2);
				double forward_speed2 = forward_speed; //���巽���ϵ�ͶӰ
				double forward_dist2 = forward_dist;
				for (int i = 0; i < sideward_cycle2; ++i) {
					forward_dist2 -= forward_speed2; //�滮��dashʱҪ�������巽���ϳ��ٶȵ�Ӱ�죬��Ϊ����ٶȿ��ܱȽϴ�
					forward_speed2 *= decay; //���ܽ׶εĳ��ٶ�
				}

				if (forward_dist2 < FLOAT_EPS) {
					Assert(0);
				}

				double buf4[2];
				int forward_cycle2 = CycleNeedToDashForDist(forward_dist2,  expected_cycle - sideward_cycle2, forward_speed2, decay, accrate, 0.0, kick_area, stamina, stamina_recovery_thr, inverse? 2: 1, stamina_inc_max, buf4, 0);
				if (forward_cycle + sideward_cycle > sideward_cycle2 + forward_cycle2 && buf4[0] > GETBALL_BUFFER){
					buf[0] = buf2[0];
					buf[1] = buf2[1];
					dashpower[0] = dashpower2[0];
					dashpower[1] = dashpower2[1];
					dashpower[2] = dashpower2[2];
					dashpower[3] = dashpower2[3];
					dash_type = DT_Sideforward;
					change_cycle = Max(sideward_cycle2 + cycle, 0);
					return Max(sideward_cycle2 + forward_cycle2 + cycle, 0);
				}
				else if (buf3[0] > GETBALL_BUFFER){
					dash_type = DT_Forsideward;
					change_cycle = Max(forward_cycle + cycle, 0);
					dash_dir = 0.0;
					return Max(forward_cycle + sideward_cycle + cycle, 0);
				}
			}
		}
		return 1000;
	}

	int cycle1 = 1000;
	double buf2[2];
	int dashpower2[4];

	/*const*/ double forward_speed = speed * Cos(vel.Dir() - facing); //���巽���ϵ�ͶӰ, +/-
	if (inverse) {
		forward_speed *= -1.0; //�õ�Ŀ�귽���ͶӰ
	}
	const double max_offset = forward_speed / (1.0 - player.GetDecay()); //���ٶ���ɵ����巽���ϵ����ƫ��

	const double forward_dist_final = fabs(forward_dist - max_offset);

	if (forward_dist_final < kick_area) { //�����dashҲ�У����ۺ�����һ��
		double side_facing;
		if (rel_target.Y() > 0) {
			dash_dir = 90.0;
			side_facing = facing + 90.0;
		}
		else {
			dash_dir = -90.0;
			side_facing = facing - 90.0;
		}
		double sideward_speed = speed * Cos(vel.Dir() - side_facing); //����෽���ϵ�ͶӰ
		cycle1 = CycleNeedToDashForDist(sideward_dist,  expected_cycle, sideward_speed, decay, accrate * ServerParam::instance().sideDashRate(), forward_dist, kick_area, stamina, stamina_recovery_thr, 1, stamina_inc_max, buf2, dashpower2);
	}

	int cycle2 = CycleNeedToDashForDist(forward_dist,  expected_cycle, forward_speed, decay, accrate, sideward_dist, kick_area, stamina, stamina_recovery_thr, inverse? 2: 1, stamina_inc_max, buf, dashpower);

	if (inverse) {
		dashpower[0] *= -1;
		dashpower[1] *= -1;
		dashpower[2] *= -1;
		dashpower[3] *= -1;
	}

	if (cycle1 < 1000) {
		if ((cycle2 < 1000 && cycle1 <= cycle2 && (buf2[1] > buf[1] && abs(dashpower2[0] + dashpower2[3]) < abs(dashpower[0] + dashpower[3])) ) || cycle2 >= 1000) { //��dash����
			buf[0] = buf2[0];
			buf[1] = buf2[1];
			dashpower[0] = dashpower2[0];
			dashpower[1] = dashpower2[1];
			dashpower[2] = dashpower2[2];
			dashpower[3] = dashpower2[3];
			dash_type = DT_Sideward;
			change_cycle = Max(cycle + cycle1, 0);
			return change_cycle;
		}
	}

	dash_dir = 0.0;
	dash_type = DT_Forward;
	change_cycle = Max(cycle + cycle2, 0);
	return change_cycle;
}

//=============================================================================
/**
* ��������ײ
* Collide with the ball.
* @param agnet the agent itself.
* @return an atomic action to collide with the ball.
*/
AtomicAction Dasher::GetCollideBallAction(const Agent &agent)
{
	AtomicAction soc;
	soc.mSucceed = false;

	if (agent.GetSelf().GetPos().Dist(agent.GetWorldState().GetBall().GetPos()) > agent.GetWorldState().GetBall().GetVel().Mod() + agent.GetSelf().GetEffectiveSpeedMax())
	{
		return soc;
	}

	if (agent.GetWorldState().GetBall().GetPosDelay() != 0){
		return soc;
	}

	const Vector & posBallPred  = agent.GetWorldState().GetBall().GetPredictedPos();
	// first try turn
	double turn_angle = (ServerParam::instance().oppGoal() - agent.GetSelf().GetPos()).Dir() - agent.GetSelf().GetBodyDir();
	int turn_step;
    if (turn_angle > agent.GetSelf().GetMaxTurnAngle()) {
        turn_angle = agent.GetSelf().GetMaxTurnAngle();
		turn_step = 2;
	}
	else{
		turn_step = 1;
	}

	Vector posAgentPred = agent.GetSelf().GetPredictedPosWithTurn(turn_angle, turn_step);
	if( posAgentPred.Dist( posBallPred ) <
			ServerParam::instance().ballSize() + agent.GetSelf().GetPlayerSize())
	{
		soc.mType = CT_Turn;
		soc.mTurnAngle = turn_angle;
		soc.mSucceed = true;
		return soc;
	}

	// then try dash
	double dash_power;
	GetPowerForForwardDash(agent, &dash_power, posBallPred - agent.GetSelf().GetPos(), agent.GetSelf().GetBodyDir(), agent.GetSelf().GetEffort(), 1);
	posAgentPred = agent.GetSelf().GetPredictedPosWithTurn(0, 1, dash_power, false);
	if( posAgentPred.Dist( posBallPred ) < ServerParam::instance().ballSize() + agent.GetSelf().GetPlayerSize())
	{
		soc.mType = CT_Dash;
		//soc.VelDash = Polar2Vector(dash_power,_pMem->MyBodyAng());//wait_bird_del
		soc.mDashPower = (int)dash_power;
		soc.mSucceed = true;
		return soc;
	}

	soc.mSucceed = false;
	return soc;
}


//=============================================================================
/**
* ������ת���ض�����
* Turn body to a certain direction.
* @param agent the agent itself.
* @param ang the angle to turn to.
* @return an atomic action to turn the body.
*/
AtomicAction Dasher::GetTurnBodyToAngleAction(const Agent & agent, AngleDeg ang)
{
	AtomicAction action;
    action.mType = CT_Turn;

    double angle_turn = GetNormalizeAngleDeg(ang - agent.GetSelf().GetBodyDir());
    if (fabs(angle_turn) < agent.GetSelf().GetMaxTurnAngle())
    {
        action.mSucceed = true;
        action.mTurnAngle = angle_turn;
    }
    else
    {
        action.mSucceed = false;
        action.mTurnAngle = Sign(angle_turn) * agent.GetSelf().GetMaxTurnAngle();
    }
    return action;
}


/*! This method determines the optimal dash power to mantain an optimal speed
When the current speed is too high and the distance is very small, a
negative dash is performed. Otherwise the difference with the maximal speed
is determined and the dash power rate is set to compensate for this
difference.
\param posRelTo relative point to which we want to dash
\param angBody body angle of the agent
\param vel current velocity of the agent
\param dEffort current effort of the player
\param iCycles desired number of cycles to reach this point
\return dash power that should be sent with dash command */
bool Dasher::GetPowerForForwardDash(const Agent &agent, double* dash_power, Vector posRelTo, double angBody, double dEffort, int iCycles )
{
	// the distance desired is the x-direction to the relative position we
	// we want to move to. If point lies far away, we dash maximal. Furthermore
	// we subtract the x contribution of the velocity because it is not necessary
	// to dash maximal.
	if (!dash_power) {
		return false;
	}
	double dDist = posRelTo.Rotate(-angBody).X(); // get distance in direction

	if( iCycles <= 0 ) iCycles = 1;
	double dAcc  = dDist * (1 - agent.GetSelf().GetPlayerDecay()) / (1 - pow(agent.GetSelf().GetPlayerDecay(), iCycles));//get the first Geom
	// get speed to travel now
	if( dAcc > agent.GetSelf().GetEffectiveSpeedMax() )             // if too far away
	{
		dAcc = agent.GetSelf().GetEffectiveSpeedMax();                // set maximum speed
	}
	//dAcc -= vel.rotate(-angBody).x;             // subtract current velocity

	// acceleration = dash_power * dash_power_rate * effort ->
	// dash_power = acceleration / (dash_power_rate * effort )
	double dDashPower = dAcc / (agent.GetSelf().GetDashPowerRate() * dEffort );
	if( dDashPower > ServerParam::instance().maxDashPower()){
		*dash_power = ServerParam::instance().maxDashPower();
		return false;
	}
	else if( dDashPower < ServerParam::instance().minDashPower() ){
		*dash_power = ServerParam::instance().minDashPower();
		return false;
	}
	else{
		*dash_power = dDashPower;
		return true;
	}
}

/**��freeʱ,����int_cycleʱ����λ�õ�ִ�ж���,int_cycle��-1,���Լ������������÷�
*
* \param &act
* \param /
* \return ʵ���ܵ�������,���ļ���Ϊ�ǲ���
*/

/**
* Caculate the get ball cycles and actions.
* @param agent the agent itself.
* @param act the atomic action to execute this cycle to get the ball.
* @param int_cycle the beginning cycle to do the action, while -1 means now.
* @param can_inverse true means allow runnning backwards to get the ball.
* @param turn_first true means the agent turn first to get the ball.
* @return a double to show the cycles needed and if it less than 0, that is to say impossible.
*/
double Dasher::GetBall(Agent & agent, AtomicAction & act, int int_cycle , bool can_inverse, bool turn_first)
{
	Assert(int_cycle == -1 || int_cycle >= 0);

    const Strategy & strategy = agent.GetStrategy();

    act.Clear();

	double realcycle = -100.0;//ʵ���ܵ����ڲ�

	const PlayerState & self = agent.GetSelf();
	const BallState   & ball = agent.GetWorldState().GetBall();

	if(self.GetPosConf() < FLOAT_EPS || ball.GetPosConf() < FLOAT_EPS){
		return -100.0;
	}

	if (self.IsKickable() && (int_cycle == -1 || int_cycle == 0)) {
		act.mType = CT_None;
		act.mSucceed = true;
		return 0.0;
	}

	if (int_cycle == 0 && !self.IsKickable()) {
		act.mType = CT_None;
		act.mSucceed = false;
		return -100.0;
	}

	/*if (!agent.GetInfoState().GetInterceptInfo().IsPlayerBallInterceptable(self.GetUnum())) return -100.0;*/

	if (ball.GetVel().Mod() < 0.1 && agent.GetInfoState().GetPositionInfo().GetBallDistToTeammate(self.GetUnum()) > 10.0) {
		GoToPoint(agent, act, ball.GetPredictedPos(), self.GetKickableArea() - GETBALL_BUFFER, ServerParam::instance().maxDashPower(), false);
		if (act.mSucceed) {
			return CycleNeedToPoint(self, ball.GetPredictedPos(), false);
		}
	}

	act.mType = CT_None;
	act.mSucceed = true;

	if(int_cycle == -1){
		int_cycle = strategy.GetMyInterCycle();
		if (int_cycle == 0) {
			act.mType = CT_None;
			act.mSucceed = true;
			return 0.0;
		}
	}

	const Vector & target = ball.GetPredictedPos(int_cycle);
	const Vector & myp = self.GetPredictedPos();
	bool inverse = false;

	//����Ѿ�����Ҫ�ܵ����ص�

    double buf = ball.GetPosDelay() * 0.1 + target.Dist(ball.GetPos()) * 0.126 + self.GetVel().Mod() * 0.126;
    if(int_cycle > 3){//Զ�˵�Ҳû��,����ת�����õķ��򣬻��ռ��Ӿ�
        buf *= 0.5;
        buf = MinMax(GETBALL_BUFFER, buf, 0.26);
    }
    else{
        buf = MinMax(GETBALL_BUFFER, buf, 0.5);
    }

	if (myp.Dist(target) < self.GetKickableArea() - buf)
	{
		if ( int_cycle > 3 ){
			//ʲô������,�����Ӿ�����ת��ת
			act.mType = CT_None;
			act.mSucceed = true;
		}
		else{//ת����_pStrategy->aim_angle
			//������dash//act = turnBodyToAngleMulti( _pStrategy->aim_angle, target );
			AngleDeg angNeedTurn = GetNormalizeAngleDeg(strategy.GetTeammateAimAngle(self.GetUnum()) - self.GetBodyDir());
			act.mSucceed = false;

			//if(fabs(angNeedTurn) > 8.0 && self.GetVel().Mod() > 0.08){//û�ٶ��������˲�֪��
			act = GetTurnBodyToAngleAction(agent, strategy.GetTeammateAimAngle(self.GetUnum()));
			act.mSucceed = true;
			if (!ServerParam::instance().oppPenaltyArea().IsWithin(target)) {//��ת�����ܷ�ͣס��,��������ֱ�����ž�����
				AtomicAction a = Kicker::instance().GetStopBallAction(agent, true);
				act.mSucceed = a.mSucceed;
			}
			//}

			if(act.mSucceed){
				////ת����_pStrategy->aim_angle
			}
			else if(CalcDashGetBallInfo(agent, int_cycle)){
				const DashGetBallInfo & dash_get_ball_info = GetDashGetBallInfo(int_cycle);
				if (fabs(dash_get_ball_info.mDashDir) < FLOAT_EPS) { //���������ܹ���
					inverse = dash_get_ball_info.mIsInverse;
					if(can_inverse || !inverse){
						double dash_power;
						if(dash_get_ball_info.mChangeCycle <= 1){
							if(abs(dash_get_ball_info.mDashPower[1]) <= 100 && ball.GetVel().Mod() > 0.6 &&
									GetAngleDegDiffer(ball.GetVel().Dir(), strategy.GetTeammateAimAngle(self.GetUnum())) > 60 )
							{
								if(inverse){//��������ͣ������ǰ��,��������,������ʱ2,3�����Ҫ�õ�dashpower
									dash_power = (dash_get_ball_info.mDashPower[2] + dash_get_ball_info.mDashPower[3])/2;
								}
								else{//��������ͣ������ǰ��,��������,������ʱ0,1�����Ҫ�õ�dashpower
									dash_power = (dash_get_ball_info.mDashPower[0] + dash_get_ball_info.mDashPower[1])/2;
								}

							}
							else{
								dash_power = (dash_get_ball_info.mDashPower[0] + dash_get_ball_info.mDashPower[3])/2;
							}
						}
						else{
							if(dash_get_ball_info.mIsInverse){
								dash_power = -100;
							}
							else{
								dash_power = 100;
							}
						}
						dash_power = self.CorrectDashPowerForStamina(dash_power);

						dash_power = MinMax(ServerParam::instance().minDashPower(), dash_power, ServerParam::instance().maxDashPower());

						if(int_cycle == 1){
							act.mDashPower = dash_power;
							act.mType = CT_Dash;
							act.mSucceed = true;
							return 0.0;
						}
					}
				}
				else {
					double dash_power;
					if(dash_get_ball_info.mChangeCycle <= 1){
						dash_power = (dash_get_ball_info.mDashPower[0] + dash_get_ball_info.mDashPower[3])/2;
					}
					else {
						dash_power = ServerParam::instance().maxDashPower();
					}

					dash_power = self.CorrectDashPowerForStamina(dash_power);
					dash_power = MinMax(ServerParam::instance().minDashPower(), dash_power, ServerParam::instance().maxDashPower());
					if(int_cycle == 1){
						act.mDashPower = dash_power;
						act.mDashDir = dash_get_ball_info.mDashDir;
						act.mType = CT_Dash;
						act.mSucceed = true;
						return 0.0;
					}
				}
			}
			else{
				act.mType = CT_Turn;
				act.mTurnAngle = (angNeedTurn > 0 ? 1.0:-1.0);
			}
			act.mSucceed = true;
		}
		return 0.0;
	}

	double buffer = self.GetKickableArea() - GETBALL_BUFFER;
	if( int_cycle <= 9 ){//�������ص����
		//��ֱ�����в���
		if(CalcDashGetBallInfo(agent, int_cycle)){
			const DashGetBallInfo & dash_get_ball_info = GetDashGetBallInfo(int_cycle);
			if (fabs(dash_get_ball_info.mDashDir) < FLOAT_EPS) { //���������ܹ���
				inverse = dash_get_ball_info.mIsInverse;
				if(can_inverse || !inverse){
					double dash_power;
					if(dash_get_ball_info.mChangeCycle <= 1){
						if(abs(dash_get_ball_info.mDashPower[1]) <= 100 && ball.GetVel().Mod() > 0.6)
						{
							AngleDeg ang_diff = fabs(self.GetBodyDir() - (ball.GetPredictedPos() - self.GetPredictedPos()).Dir());
							double temp_power = (dash_get_ball_info.mDashPower[1] + dash_get_ball_info.mDashPower[2])/2;
							if(self.GetPredictedPosWithDash(1, temp_power).Dist(ball.GetPredictedPos()) > 0.3
									&& int_cycle == 1 && ang_diff >= 30.0){
								dash_power = temp_power;
							}
							//��������Ϊ2ʱ��ǰ���ٵ�����ҪСһЩ��������һ����ת��ʱ��һ����ǰ�ļ��ٶȾͻ����Ա�Ƶ���ǰ��ȥ��
							else if(GetAngleDegDiffer(ball.GetVel().Dir(), strategy.GetTeammateAimAngle(self.GetUnum())) > 60 || int_cycle == 2)
							{
								dash_power = (dash_get_ball_info.mDashPower[0] + dash_get_ball_info.mDashPower[1])/2;
							}
							else {
								dash_power = (dash_get_ball_info.mDashPower[0] + dash_get_ball_info.mDashPower[2])/2;
							}
						}
						else{
							dash_power = (dash_get_ball_info.mDashPower[0] + dash_get_ball_info.mDashPower[3])/2;
						}
					}
					else{
						if(dash_get_ball_info.mIsInverse){
							dash_power = -100;
						}
						else{
							dash_power = 100;
						}
					}
					dash_power = self.CorrectDashPowerForStamina(dash_power);
					dash_power = MinMax(ServerParam::instance().minDashPower(), dash_power, ServerParam::instance().maxDashPower());
					act.mDashPower = (int)dash_power;
					act.mType = CT_Dash;
					act.mSucceed = true;
					double RealIntCyc = dash_get_ball_info.mIntCycle;
					//Y������ʱֱ��ԣ����С�����ﵥ������һ�£�ʹ����ֵ���ֳ��������
					int cycbuf = (int)(dash_get_ball_info.mBallCycle - dash_get_ball_info.mIntCycle);
					double minbuf = -FLOAT_EPS;

					Vector relballRuningPt = (self.GetPos() - ball.GetPos()).Rotate(-ball.GetVel().Dir());
					if (relballRuningPt.X() > 0 || fabs(relballRuningPt.Y()) > 1.2) {
						//�����׷��ʱ��Ҫת��תȥ����ʱ��
						if(cycbuf > 3){
							minbuf = 0.26;
						}
						else if(cycbuf >= 2){
							minbuf = 0.16;
						}
						else if(cycbuf >= 1){
							minbuf = 0.116;
						}
					}

					if(GetAngleDegDiffer(ball.GetVel().Dir(), strategy.GetTeammateAimAngle(self.GetUnum())) < 60.0 && strategy.GetSituation() != ST_Defense){
						//����ã�����������,���ֺõ����巽��
						minbuf *= 0.5;
					}

					if(dash_get_ball_info.mYBuf < minbuf){
						RealIntCyc += 0.9 - dash_get_ball_info.mYBuf;
						if(can_inverse && (GetAngleDegDiffer((target - myp).Dir(), self.GetBodyDir()) > 90)
								&& (GetAngleDegDiffer(strategy.GetTeammateAimAngle(self.GetUnum()), (target - myp).Dir()) > 90))
						{
							realcycle = RealCycleNeedToPointWithCertainPosture(self, target, true);
							if(realcycle < int_cycle){
								double realcycle2 = RealCycleNeedToPointWithCertainPosture(self, target, false);
								if (realcycle < realcycle2 - FLOAT_EPS) {
									inverse = true;
								}
								else {
									realcycle = realcycle2;
								}
							}
							else {
								realcycle = RealCycleNeedToPointWithCertainPosture(self, target, false);
							}
						}
						else {
							realcycle = RealCycleNeedToPointWithCertainPosture(self, target, false);
						}

						if(can_inverse)	{
							GoToPointWithCertainPosture(agent, act, target, buffer, ServerParam::instance().maxDashPower(), inverse, turn_first);
						}
						else{
							GoToPointWithCertainPosture(agent, act, target, buffer, ServerParam::instance().maxDashPower(), false, turn_first);
						}
						act.mSucceed = true;
					}

					if (act.mType == CT_Dash && fabs(act.mDashPower) < FLOAT_EPS) {
						act = GetTurnBodyToAngleAction(agent, strategy.GetTeammateAimAngle(self.GetUnum()));
						act.mSucceed = true;
					}
					return RealIntCyc;
				}
			}
			else {
				double dash_power;
				if(dash_get_ball_info.mChangeCycle <= 1){
					dash_power = (dash_get_ball_info.mDashPower[0] + dash_get_ball_info.mDashPower[3])/2;
				}
				else {
					dash_power = ServerParam::instance().maxDashPower();
				}
				dash_power = self.CorrectDashPowerForStamina(dash_power);
				dash_power = MinMax(ServerParam::instance().minDashPower(), dash_power, ServerParam::instance().maxDashPower());
				act.mDashPower = (int)dash_power;
				act.mDashDir = dash_get_ball_info.mDashDir;
				act.mType = CT_Dash;
				act.mSucceed = true;
				return dash_get_ball_info.mIntCycle;
			}
		}

		//����Ҫ��Ҫ������
		if(can_inverse && (GetAngleDegDiffer((target - myp).Dir(), self.GetBodyDir()) > 90)
				&& (GetAngleDegDiffer(strategy.GetTeammateAimAngle(self.GetUnum()), (target - myp).Dir()) > 90))
		{
			realcycle = RealCycleNeedToPointWithCertainPosture(self, target, true);
			if(realcycle < int_cycle){
				double realcycle2 = RealCycleNeedToPointWithCertainPosture(self, target, false);
				if (realcycle < realcycle2 - FLOAT_EPS) { //���Է��֣���realcyc - realcyc2 == 0 ʱ�� debug�汾�� realcycle < realcycle2 Ϊ�٣�release�汾�� realcycle < realcycle2 Ϊ��
					inverse = true;
				}
				else {
					realcycle = realcycle2;
				}
			}
			else {
				realcycle = RealCycleNeedToPointWithCertainPosture(self, target, false);
			}
		}
		else {
			realcycle = RealCycleNeedToPointWithCertainPosture(self, target, false);
		}

		if(can_inverse)	{
			GoToPointWithCertainPosture(agent, act, target, buffer, ServerParam::instance().maxDashPower(), inverse, turn_first);
		}
		else{
			GoToPointWithCertainPosture(agent, act, target, buffer, ServerParam::instance().maxDashPower(), false, turn_first);
		}

		return realcycle;
	}
	else{
		GoToPoint(agent, act, target, buffer, ServerParam::instance().maxDashPower(), false); //�������ܣ�Ҫ��ʡ����
		realcycle = RealCycleNeedToPoint(self, target, false);
		return realcycle;
	}

	return -100.0;
}

/**
* Caculate the get ball action and execute it.
* @param agent the agent itself.
* @param int_cycle the beginning cycle to do the action, while -1 means now.
* @param can_inverse true means allow runnning backwards to get the ball.
* @param turn_first true means the agent turn first to get the ball.
* @return true means the action executed successfully.
*/
bool Dasher::GetBall(Agent & agent, int int_cycle , bool can_inverse, bool turn_first)
{
	AtomicAction act;
	GetBall(agent, act, int_cycle, can_inverse, turn_first);
	if (act.mSucceed) {
		return act.Execute(agent);
	}
	return false;
}

/**
* ��ϸ����ֱ���Ƿ�����õ���
* Caculate in detail if the agent can get the ball only by dashing.
* @param agent the agent itself.
* @param cycle cycles forward to caculate.
* @return true means the agent can get the ball.
*/
bool Dasher::CalcDashGetBallInfo(Agent & agent, int cycle)
{
	if(cycle > 10) return false;
	Assert(cycle >= 1);

	const PlayerState & self = agent.GetSelf();
	if (!self.IsSensed()){
		return false; //ֱ�ӷ��ز�Ӱ���Ѵ洢������
	}

	if (agent.GetAgentID() != mDashGetInfoAgentID){
		mDashGetInfoAgentID = agent.GetAgentID();

		const BallState & ball = agent.GetWorldState().GetBall();
		double real_cycle, buf[2];
		int dash_power[4];

		for(int i = 1; i <= 10; i++)
		{
			DashGetBallInfo & dash_get_ball_info = mDashGetBallInfo[i - 1];

			dash_get_ball_info.mBallCycle = i;
			dash_get_ball_info.mIntPpos = ball.GetPredictedPos(i);
			dash_get_ball_info.mIsSuccess = false;

			real_cycle = CycleNeedToDashToPoint(self, i, dash_get_ball_info.mIntPpos, dash_get_ball_info.mDashDir, dash_get_ball_info.mDashType, dash_get_ball_info.mChangeCycle, buf, dash_power);

			if(real_cycle <= i && buf[1] > GETBALL_BUFFER)
			{
				dash_get_ball_info.mIsSuccess = true;
				if (fabs(dash_get_ball_info.mDashDir) < FLOAT_EPS) { //����
					if (dash_get_ball_info.mDashType == DT_Forward) { //ȫ������
						dash_get_ball_info.mIntCycle = real_cycle - buf[0];
					}
					else {
						dash_get_ball_info.mIntCycle = real_cycle;
					}

					dash_get_ball_info.mYBuf = buf[1];
					if(dash_get_ball_info.mChangeCycle <= 1) {
						dash_get_ball_info.mIsInverse = ( (dash_power[3] + dash_power[0]) < 0 );
					}
					else {
						dash_get_ball_info.mIsInverse = ( dash_power[3] < dash_power[0] );//�Ƿ�����
					}
					memcpy(dash_get_ball_info.mDashPower,dash_power,sizeof(dash_power));
				}
				else {
					//���ת�����ã��Ͳ���dash
					int with_turn_cycle = CycleNeedToPointWithCertainPosture(self, dash_get_ball_info.mIntPpos, true);

					if (dash_get_ball_info.mDashType == DT_Sideward) { //ȫ�̲���
						dash_get_ball_info.mIntCycle = real_cycle - buf[0];
					}
					else {
						dash_get_ball_info.mIntCycle = real_cycle;
					}

					if (with_turn_cycle > i) { //���ת�����ò�����
						dash_get_ball_info.mYBuf = buf[1];
						dash_get_ball_info.mIsInverse = false;
						memcpy(dash_get_ball_info.mDashPower,dash_power,sizeof(dash_power));
					}
					else { //����ת��
						dash_get_ball_info.mIsSuccess = false; //������dash
					}
				}
			}
		}
	}
	return GetDashGetBallInfo(cycle).mIsSuccess;
}


/**
* ������Ա��ĳ����ʼ��,���ٵ����������ӳ�
* Caculate the delay cycles for a player to accel to his max speed.
* @param player the player to caculate.
* @param angle the max speed angle to predict.
* @return an double to show the cycles caculated.
*/
double Dasher::CalcPlayerCycleFix(const PlayerState &player, AngleDeg angle)
{
    const Vector & vel = player.GetVel();
    double vmod = vel.Mod() / player.GetEffectiveSpeedMax() / player.GetPlayerDecay();
	int vidx,aidx;
	vidx = int( vmod / 0.2);
	vidx = MinMax(0, vidx, 5);
	if (!vidx)
    {
        if(player.GetBodyDirConf() == 0)
        {
			return 0.5;//û������Ϣ����Ϊ�������0.5
		}
        angle = GetAngleDegDiffer(player.GetBodyDir(), angle);
	}
    else
    {
		angle = GetAngleDegDiffer(vel.Dir(),angle);
	}
	aidx = int(angle / 9.0);
    return MotionModel::instance().GBCD(player.GetPlayerType(), vidx, aidx);
}


/**
* ����ĳ��Ա�ܵ�ĳ����������ڣ���pre(1)λ���㣬Ȼ��+1
* Caculate the cycles needed for a player to go to the point.
* @param player the player to caculate.
* @param target the target position to go to.
* @return an double to show the cycles caculated.
*/
double Dasher::CalcPlayerGoToPointCycle(const PlayerState & player, const Vector & target)
{
	Assert(!Isnan(target.X()) && !Isnan(target.Y()));

	Vector relpos = target - player.GetPredictedPos();
	AngleDeg angle = relpos.Dir();
	double player_cycle =  relpos.Mod() - ( player.IsGoalie() ? ServerParam::instance().maxCatchableArea() : ( player.GetKickableArea() - GETBALL_BUFFER) );

	if(player_cycle < 0) return 1.0 + player.GetTackleBan();

	double fix = 0;
	const Vector & vel = player.GetVel();
	double vmod = vel.Mod() / player.GetEffectiveSpeedMax() / player.GetDecay();

	int vidx, aidx;
	vidx = int(vmod / 0.2);
	vidx = MinMax(0, vidx, 5);

    if(!vidx && player.GetBodyDirConf() <= FLOAT_EPS){
		if(player.GetUnum() > 0){
			fix = 0.5;//û������Ϣ����Ϊ�������0.5
		}
		else{
			fix = 0.0;
		}
		player_cycle = player_cycle / player.GetEffectiveSpeedMax() + fix + 1;
	}
	else {
        if(player.GetBodyDirConf() >= 1.0 - FLOAT_EPS || !vidx){
			angle = GetAngleDegDiffer(player.GetBodyDir(), angle);
		}
		else{
			angle = GetAngleDegDiffer(vel.Dir(), angle);
		}

		if(angle > 90.0 && ( player_cycle < (player.GetUnum() < 0 ? 3 : 5)|| player.IsGoalie()) ){//��Ϊ�ᵹ����
			angle = 180.0 - angle;
			player_cycle += vmod * player.GetDecay();
			vidx = 0;
		}

		if(angle < ASin((player.GetKickableArea() - GETBALL_BUFFER) / relpos.Mod())){
			aidx = 0;
		}
		else{
			aidx = int(angle / 9.0);
		}

		fix = MotionModel::instance().GBCD(player.GetPlayerType(), vidx, aidx);

		int cyc = MotionModel::instance().GBC(player.GetPlayerType(), vidx, aidx, 0);
		if(player_cycle + fix< cyc){//�ܲ����ͼ��ٹ���
			double dis = player_cycle;
			player_cycle = MotionModel::instance().GBC(player.GetPlayerType(), vidx, aidx, 1);
			if(dis < 0.5){//�ر����ʱ������ת������̫��
				player_cycle = Min(player_cycle, 2.0);
			}
			vmod = MotionModel::instance().GBATV(player.GetPlayerType(), vidx, aidx);
            const double & acc = player.GetAccelerationFrontMax();

			while(dis > 0){
				++player_cycle;
				vmod += acc;
				dis -= vmod;
				vmod *= player.GetDecay();
			}
			player_cycle += dis / player.GetEffectiveSpeedMax() + ((aidx == 0 && vidx == 0) ? 0.8 : 1 );//fixһ�£���ԣ�����ǽ�ȥ,1��pre��cyc ,������ʱ��Ϊ�����Ѿ�������
		}
		else{
			if(vidx == 0 && player.GetUnum() < 0 ){
				player_cycle = player_cycle / player.GetEffectiveSpeedMax() + fix + 0.8;//�п�������ת���������ķ���
			}
			else{
				player_cycle = player_cycle / player.GetEffectiveSpeedMax() + fix + 1;
			}
		}
	}
	return player_cycle + player.GetTackleBan();
}


//==============================================================================
/*
* Caculate in detail how far a player can rich considering the player's kick area
* supposing that in the first cycle the player do a kick. This function is for dribble.
* @param player_state the player state for the player.
* @param dir the dash direction.
* @param maxdis the maximum distance to caculate.
* @param maxcyc the maximum cycles to caculate.
* @param dis the pointer for an array of double to record the distance for each cycle. 
* 		The kick cycle or turn cycle are considered dis[0].
* @return an integer show the cycles. dis[cyc]=maxdis.
*/
int Dasher::CalcDashDist(const PlayerState & player_state, const double & dir, const double & maxdis, const int & maxcyc, double * dis)
{
    const double & effort = player_state.GetEffort();
    const double & decay = player_state.GetPlayerDecay();
    const double & speedmax = player_state.GetEffectiveSpeedMax();
    const double & stamina = player_state.GetStamina();
    const double & accrate = player_state.GetDashPowerRate();
    const Vector & vspeed = player_state.GetVel();
	double speed = player_state.GetVel().Mod();
    double _cos = Cos(vspeed.Dir() - dir);
	int cycle = 1;//�õ�����
    double facing = player_state.GetBodyDir();
	double diffang = fabs(GetNormalizeAngleDeg(dir - facing));

    dis[0] = speed * _cos; //dis[0] kick
    speed *= decay;
    const double oneturnang = player_state.GetMaxEffectiveTurn(speed); // WE2008������Ҳ��bug��Ӧ����˥������ٶ���ת���Ƕ�   2009-04-24
    if (diffang < FLOAT_EPS)
    {
        cycle = 1; //dis[1] dash
    }
    else if (diffang < oneturnang)
    {
        dis[1] = dis[0] + speed * _cos; //dis[1]turn
        speed *= decay;
        cycle = 2; //dis[2] dash
    }
    else
    {
        dis[1] = dis[0]; //ͣס
        dis[2] = dis[0]; //ת��
        speed = 0.0;
        cycle = 3; //dis[3] dash
    }

	//II����&���������׶�
    double min_stamina = player_state.GetMinStamina();
    int full_cyc=int((stamina - min_stamina) / (100.0 - player_state.GetStaminaIncMax()) + cycle);//�������׶�
	double speedmax_thr = speedmax * decay * 0.98;
	double accmax = accrate * 100.0 * effort;
	while (cycle < full_cyc && speed < speedmax_thr)
    {
		speed += accmax;
		if (speed > speedmax)
        {
			speed = speedmax;
		}
		dis[cycle] = dis[cycle - 1] + speed;
		if(dis[cycle] > maxdis || cycle > maxcyc)
        {
			return cycle - 1;//��û���ٵ������ܵ���...
		}
		++cycle;
		speed *= decay;
	}

	//III �������ٽ׶�
	while (cycle < full_cyc)
    {
		dis[cycle] = dis[cycle - 1] + speedmax;
		if (dis[cycle] > maxdis || cycle > maxcyc)
        {
			return cycle-1;//����Ǹ�������
		}
		++cycle;
	}

	//IV û��(0����)���ٽ׶�
    double acc_tired = player_state.GetStaminaIncMax() * accrate * effort;
	double speed_tired = acc_tired / (1-decay);
	double speed_tired_thr = speed_tired * decay;
	speed *= decay;
	while(fabs(speed - speed_tired_thr) > 0.004)
    {
		speed += acc_tired;
		dis[cycle] = dis[cycle - 1] + speed;
		speed *= decay;
		if (dis[cycle] > maxdis || cycle > maxcyc)
        {
			return cycle-1;
		}
		++cycle;
	}
	//V û��(0����)���ٽ׶�
	do
    {
		dis[cycle]=dis[cycle-1]+speed_tired;
	}
    while (dis[cycle++] < maxdis && cycle < maxcyc);
	return cycle-2;
}


//==============================================================================
/*
* Caculate how far a player can rich by dashing with a power above 0.
* @param player_state the player state for the player.
* @param max_cycle the maximum cycles to caculate.
* @param distance an array of double to store the distance of each cycle.
* @param speed an array of double to store the speed of each cycle.
* @param stamina an array of double to store the stamina of the player of each cycyle.
* @param is_first_kick true means in the first cycle the player does a kick.
*/
void Dasher::CalcFrontDashDist(const PlayerState & player_state, const int & max_cycle, double * distance, double * speed, double * stamina, bool is_first_kick)
{
    if (max_cycle < 0)
    {
        return;
    }

    const double & accel_rate = player_state.GetAccelerationFrontRate();
    const double & player_decay = player_state.GetPlayerDecay();
    const double & player_speed_max = player_state.GetEffectiveSpeedMax();
    const double & stamina_inc = player_state.GetStaminaIncMax();
    const double & min_stamina = player_state.GetMinStamina();
    const double & init_stamina = player_state.GetStamina();
    const double init_speed = player_state.GetVel().Rotate(-player_state.GetBodyDir()).X();

	double t = 0.0;
    if (is_first_kick)
    {
        distance[0] = init_speed;
        speed[0] = init_speed * player_decay;
        stamina[0] = init_stamina;
	}
    else
    {
        t = MinMax(stamina_inc, player_state.GetStamina() - min_stamina, ServerParam::instance().maxDashPower());//dash power
        stamina[0] = init_stamina - t + stamina_inc;
		t = t * accel_rate;
		speed[0] = Min(init_speed + t, player_speed_max);
		distance[0] = speed[0];
		speed[0] *= player_decay;
	}

	int cycle = 0; // �õ�����
	while (cycle++ < max_cycle)
    {
        t = MinMax(stamina_inc, stamina[cycle - 1] - min_stamina, ServerParam::instance().maxDashPower());//dash power
		stamina[cycle] = stamina[cycle - 1] - t + stamina_inc;
		t = t * accel_rate;
		speed[cycle] = Min(speed[cycle - 1] + t, player_speed_max);
		distance[cycle] = distance[cycle - 1] + speed[cycle];
		speed[cycle] *= player_decay;
	}
}

/*
* Caculate the relative position of ball and the speed for ball to kick to.
* @param ball_state the ball state.
* @param player_state the player state.
* @param max_cycle the max_cycle to consider.
* @param denstiny the destination position ( relative coordination ).
* @param ball_path an array to store the ball path ( relative coordination ) every cycle.
* @param ballOutSpeed0 the fist speed for ball.
*/
void Dasher::CalcBallPath(const BallState & ball_state, const PlayerState & player_state, const int & max_cycle, Vector & destiny, Vector * ball_path, Vector & ballOutSpeed0)
{
    if (max_cycle < 0 )
    {
		return;
	}
	const double & decay = ServerParam::instance().ballDecay();
    const double & pdecay = player_state.GetPlayerDecay();
    const double & body_dir = player_state.GetBodyDir();
    Vector bp = (ball_state.GetPos() - player_state.GetPos()).Rotate(-body_dir);
	destiny = destiny - bp;
    double dBallSpeed = ServerParam::instance().GetBallSpeed(max_cycle + 1, destiny.Mod());
    dBallSpeed = MinMax(0.0, dBallSpeed, ServerParam::instance().ballSpeedMax());

	Vector dBallVel = destiny / destiny.Mod() * dBallSpeed ;
	ballOutSpeed0 = dBallVel.Rotate(body_dir); // ת��Ϊ��������

    double distance_y = player_state.GetVel().Rotate(-body_dir).Y(); // ת��Ϊ��Ե�y�ٶ�
	ball_path[0] = bp + dBallVel;
    ball_path[0].SetY(ball_path[0].Y() - distance_y);
	distance_y *= pdecay;
	dBallVel *= decay;
	for( int i = 1; i <= max_cycle; i ++ )
	{
		ball_path[i] = ball_path[i - 1] + dBallVel;
        ball_path[i].SetY(ball_path[i].Y() - distance_y);
		distance_y *= pdecay;
		dBallVel *= decay;
	}
}


/*
* Caculate the distance for a player to run to a certain direction per cycle.
* @param player_state the player state.
* @param dir the target direction.
* @param dis an array to record the distance per cycle.
* @param maxdis the maximum distance to caculate.
* @param maxcyc the maximum cycles to caculate.
* @param adjust_finish the time for turning to the right direction finished.
* @param in_future true means to caculate a player's future state.
* @return an integer to return the number of cycyles caculated.
*/
int Dasher::CalcRunDistance(const PlayerState & player_state, double dir, double *dis, double maxdis, int maxcyc, int & adjust_finish, bool in_future)
{
	const double & effort = player_state.GetEffort();
	const double & decay = player_state.GetPlayerDecay();
	const double & stamina = player_state.GetStamina();
	const double & accrate = player_state.GetDashPowerRate();
	const double & speedmax = player_state.GetEffectiveSpeedMax();

	double speed = (in_future)?  speedmax * player_state.GetDecay(): ((player_state.GetVelConf() > FLOAT_EPS)? player_state.GetVel().Mod(): 0.0);
	double facing = (in_future)? dis[0]: ((player_state.IsBodyDirValid())? player_state.GetBodyDir(): dir);
	Vector vspeed = (in_future)? Polar2Vector(speed, facing): ((player_state.GetVelConf() > FLOAT_EPS)? player_state.GetVel(): Vector(0.0, 0.0));
    double oneturnang = (in_future)? GetMaxTurnAngle(player_state.GetPlayerType(), speedmax* player_state.GetDecay()): player_state.GetMaxTurnAngle();

    double _cos = Cos(GetAngleDegDiffer(vspeed.Dir(), dir)); //Ŀ�귽���ϵ�ͶӰ
    double diffang = fabs(GetNormalizeAngleDeg(dir-facing));
	double bufang = ATan((player_state.GetKickableArea()) / maxdis);

	int  cycle = 1;//�õ�����
	int  precycle = 0; //��¼ת������������������,ֻ��ͣס��ʱ����Ҫ����Dashͣס����Ҫ��������

	speed *= _cos;

	//��Ӧ&ת���Ľ׶�
	dis[0] = 0.0;
	bufang = Min(bufang, oneturnang);

	if(diffang >= bufang)//�����Ҫת��
	{
		if(diffang <= oneturnang)
		{
			dis[cycle++] = speed;
			speed *= decay;
			adjust_finish = 1;
		}else{
			//160��ת���������������ˣ�ֱ��ͣסת��ȥ����
			dis[cycle++] = 0.0;//ͣס
			precycle ++;
			dis[cycle++] = 0.0;//ת��
			speed = 0;
			adjust_finish = 2;
		}
	}
	else {
		adjust_finish = 0;
	}

	//����&���������׶�
	int full_cyc = int((stamina - ServerParam::instance().effortDecStamina()) / (ServerParam::instance().maxDashPower() - player_state.GetStaminaIncMax()) + cycle - precycle);
	//full_cyc ��ʾ���������½���1200֮ǰ�����Լ��ٶ������ڡ���Ϊǰ�涼����ת���� cycle - precycle ���������������Ի����һ�� cycle - precycle

	double speedmax_thr = speedmax * decay * 0.98;
	double accmax = accrate * ServerParam::instance().maxDashPower() * effort;

	while(cycle<full_cyc && speed < speedmax_thr )
	{
		speed += accmax;
		if(speed > speedmax){
			speed = speedmax;
		}
		dis[cycle] = dis[cycle-1] + speed;
		if(dis[cycle] > maxdis || cycle > maxcyc){
			return cycle-1;//��û���ٵ������ܵ���
		}
		++cycle;
		speed*=decay;
	}

	//�������ٽ׶�
	while(cycle<full_cyc){
		dis[cycle] = dis[cycle-1]+speedmax;
		if(dis[cycle]> maxdis || cycle > maxcyc ){
			return cycle-1;//����Ǹ�������
		}
		++cycle;
	}

	//û��(0����)���ٽ׶�
	double acc_tired = player_state.GetStaminaIncMax() * accrate * effort;
	double speed_tired = acc_tired / (1 - decay);
	double speed_tired_thr = speed_tired * decay;
	speed *= decay;
	while(fabs(speed-speed_tired_thr) > 0.004){
		speed += acc_tired;
		dis[cycle] = dis[cycle-1] + speed;
		speed *= decay;
		if(dis[cycle] > maxdis || cycle > maxcyc ){
			return cycle-1;
		}
		++cycle;
	}

	//û��(0����)���ٽ׶�
	do{
		dis[cycle]=dis[cycle-1]+speed_tired;
	}while(dis[cycle++] < maxdis && cycle < maxcyc);

	return cycle-2;
}

//For Debug
void Dasher::DebugCycleNeedToDashForDist(const Vector start, const Vector target, double dist, const int expected_cycle, double speed, const double decay, const double accrate, const double vertical_dist, const double kick_area, double stamina, const double stamina_recovery_thr, const double stacostrate, const double stamina_inc_max)
{
	Assert(vertical_dist > -FLOAT_EPS);

	if (vertical_dist > kick_area) return;

	const double d1 = sqrt( Sqr( kick_area ) - Sqr( vertical_dist ) );
	const int DashMax = (int)ServerParam::instance().maxDashPower();

	Ray negative_run_ray(target, (start - target).Dir());

	int cycle = 0;
	while(cycle < 16){
		++cycle;
		if (cycle > expected_cycle) return;
		double dDash = int(MinMax( stamina_inc_max ,( stamina - stamina_recovery_thr + stamina_inc_max ) / 2, DashMax ) ); //����dash�����ֵ
		double DPower = ( dist - speed - d1 ) / (accrate);
		stamina -= dDash * stacostrate - stamina_inc_max;
		speed += dDash * accrate;
		dist -= speed;
		speed *= decay;

		Logger::instance().LogCircle(negative_run_ray.GetPoint(dist), kick_area, SightLogger::Orange);
		Logger::instance().LogPoint(negative_run_ray.GetPoint(dist), SightLogger::Orange);

		if(DPower <= dDash){//���ܵ���,��ϸ����
			return;
		}
	}
}

/*
* This function is used to correct the target position when near the ball.
* @param player the player to consider.
* @param target the target position to go to.
* @param fix the distance error to fix.
* @return position corrected.
*/
Vector Dasher::CorrectTurnForDash(const PlayerState & player, const Vector & target, double fix)
{
	if (player.GetPosConf() > 0.99 - FLOAT_EPS && player.GetBodyDirConf() > 0.99 - FLOAT_EPS) {
		Ray body_ray(player.GetPos(), player.GetBodyDir());
		Line body_line(body_ray);
		Vector closest_pt = body_line.GetProjectPoint(target);

		double buffer = 0.05 + ServerParam::instance().ballSize();
		if (closest_pt.Dist(player.GetPos()) > player.GetKickableArea() + buffer - fix){
			if (closest_pt.Dist(target)
					< player.GetKickableArea() - buffer + fix){
				return closest_pt;
			}
		}
	}
	return target;
}

/**
* ������ͬһdash_power����ĳ����Ҫ��ʱ��
* Caculate cycles needed to a target position with a certain dash power.
* @param player the player to caculate.
* @param target the target position to go to.
* @param dash_power the power for dash to predict.
* @return an integer to show the cycles caculated.
*/
int Dasher::CyclePredictedToPoint(const PlayerState& player , Vector target , double dash_power)
{
	double corrected_dash_power = dash_power;
	double effective_power;
	double predicted_stamina = player.GetStamina();
	double predicted_effort  = player.GetEffort();
	double predicted_recovery = player.GetRecovery();
	double predicted_capacity = player.GetCapacity();
	double myang = player.GetBodyDir();
	Vector position = player.GetPos();
	Vector velocity;

	if (player.GetVelConf() < FLOAT_EPS)
	{
		velocity = Vector(0,0);
	}
	else
	{
		velocity = player.GetVel();
	}

	Vector last_position = position;
	int max_cyc = (int)(position.Dist(target) / player.GetEffectiveSpeedMax() + 100);
	int last_action = 0; /* 0 -- turn , 1 -- dash*/

	for (int i = 0;i < max_cyc;i++)
	{
		if (position.Dist(target) < PlayerParam::instance().AtPointBuffer())
		{
			return i;
		}

		if (position.Dist(target) > last_position.Dist(target) + FLOAT_EPS && last_action == 1)
		{
			return i;
		}

		last_position = position;

		/*decide if we should turn*/
		double targ_ang;
		if (dash_power > 0)
		{
			targ_ang = (target - position).Dir() - myang;
		}
		else
		{
			targ_ang = (target - position).Dir() - GetNormalizeAngleDeg(myang + 180);
		}

		double max_go_to_point_angle_err = 4; //��08CP_max_go_to_point_angle_err
		if (fabs(GetNormalizeAngleDeg(targ_ang)) > max_go_to_point_angle_err)
		{
			/*turnint*/
			double this_turn = MinMax(-player.GetMaxTurnAngle(), GetNormalizeAngleDeg(targ_ang) , player.GetMaxTurnAngle());

			myang += this_turn;
			corrected_dash_power = 0;
			last_action = 0;
		}
		else
		{
			corrected_dash_power = player.CorrectDashPowerForStamina(dash_power);
			if (fabs(corrected_dash_power) > predicted_stamina)
			{
				effective_power = Sign(corrected_dash_power) * predicted_stamina;
			}
			else
			{
				effective_power = corrected_dash_power;
			}

			effective_power *= predicted_effort;
			effective_power *= player.GetDashPowerRate();
			velocity += Polar2Vector(effective_power , myang);
			last_action = 1;
		}

		if (velocity.Mod() > player.GetEffectiveSpeedMax())
		{
			velocity *= (player.GetEffectiveSpeedMax()/ velocity.Mod());
		}

		position += velocity;
		velocity *= player.GetPlayerDecay();

		//08 ��UpdatePredictStaminaWithDash���� ֱ��д��˺���
		if (dash_power > 0)
		{
			predicted_stamina -= dash_power;
		}
		else
		{
			predicted_stamina -= 2 * dash_power;
		}

		if (predicted_stamina < 0)
		{
			predicted_stamina = 0;
		}

		if (predicted_stamina < ServerParam::instance().recoverDecStamina() && predicted_recovery > ServerParam::instance().recoverMin())
		{
			predicted_recovery -= ServerParam::instance().recoverDec();
		}

		if (predicted_stamina < ServerParam::instance().effortDecStamina()  && predicted_effort > player.GetEffortMin())
		{
			predicted_effort -= ServerParam::instance().effortDec();
		}

		if (predicted_stamina > ServerParam::instance().effortIncStamina() && predicted_effort < player.GetEffortMax())
		{
			predicted_effort += ServerParam::instance().effortDec();
		}

		//����capacity�Ľ�
		double stamina_inc = Min(predicted_recovery * player.GetStaminaIncMax() , predicted_capacity);
		predicted_stamina += stamina_inc;
		if (predicted_stamina > ServerParam::instance().staminaMax())
		{
			predicted_stamina = ServerParam::instance().staminaMax();
		}

		predicted_capacity -= stamina_inc;
		if (predicted_capacity < 0)
		{
			predicted_capacity = 0;
		}
	}

	return max_cyc;
}

/*
 * Fix the route when needed by using the next 3 funcions.
 * @param agent the agent itself.
 * @param origin the origin position to go to.
 * @return new target position fixed from the origin one.
 */
Vector Dasher::FixRoute(const Agent &agent, Vector origin)
{
	const WorldState	& worldstate	= agent.GetWorldState();

	if(worldstate.GetPlayMode() < PM_Our_Mode)
	{
		return origin;
	}

	if ( worldstate.GetPlayMode() == PM_Before_Kick_Off || worldstate.GetPlayMode() == PM_Opp_Kick_Off) {
        origin.SetX(Min(-0.6, origin.X()));
		return origin;
	}

	if(
		worldstate.GetPlayMode() == PM_Opp_Corner_Kick||
		worldstate.GetPlayMode() == PM_Opp_Kick_Off||
		worldstate.GetPlayMode() == PM_Opp_Kick_In||
		worldstate.GetPlayMode() == PM_Opp_Free_Kick ||
		worldstate.GetPlayMode() == PM_Opp_Goalie_Free_Kick ||  /* not a real play mode */
		worldstate.GetPlayMode() == PM_Opp_Offside_Kick ||
		worldstate.GetPlayMode() == PM_Opp_Free_Kick_Fault_Kick||
		worldstate.GetPlayMode() == PM_Opp_Back_Pass_Kick ||
		worldstate.GetPlayMode() == PM_Opp_Indirect_Free_Kick)
	{
		return AvoidCircle(agent, origin);
	}
	else if(worldstate.GetPlayMode() == PM_Opp_Goal_Kick)
	{
	 	return AvoidPenaltyArea(agent, origin);
	}

	return origin;
}

/*
 * ���������Ҫ�Ĺ������ڶԷ�����ʱ���ҷ���Ա����������ΪԲ�ģ��뾶Ϊ9.15m��Բ��Χ�ڣ�
 * ���������Ҫ����㣬�����Ҫͨ�����Բ����Ҫ����·�ߡ������һ���м��,Ȼ���ٵ���
 * ���յ㡣
 * ������Vector Origin;Ҫ��������յ㡣
 * ����ֵ����Ҫ����·�ߺ�Ҫ������м�㡣
 */

/*
 * Avoid the forbidden circle when the opponent team taking a free kick.
 * @param agent the agent itself.
 * @param origin the origin position to go to.
 * @return new target position fixed from the origin one.
 */
Vector Dasher::AvoidCircle(const Agent &agent, Vector origin)
{
	const PlayerState &selfstate = agent.GetSelf();
	const BallState	&ballstate = agent.GetWorldState().GetBall();
	const WorldState	&worldstate	= agent.GetWorldState();
	const Vector & my_pos = selfstate.GetPos();
	const Vector & ball_pos = ballstate.GetPos();
	Vector tmp_fix;
	Ray route(my_pos, (origin-my_pos).Dir());
	Ray mytanget;
	mytanget.SetOrigin(my_pos);
	Ray origintanget;
	origintanget.SetOrigin(origin);
	Line  routeline(my_pos, origin);

	if(worldstate.GetPlayMode() == PM_Opp_Kick_In
	   || worldstate.GetPlayMode() == PM_Opp_Corner_Kick
	   || worldstate.GetPlayMode() == PM_Opp_Free_Kick
	   || worldstate.GetPlayMode() == PM_Opp_Offside_Kick
	   || worldstate.GetPlayMode() == PM_Opp_Goal_Kick
	   || worldstate.GetPlayMode() == PM_Opp_Free_Kick_Fault_Kick
	   || worldstate.GetPlayMode() == PM_Opp_Back_Pass_Kick
	   || worldstate.GetPlayMode() == PM_Opp_Indirect_Free_Kick)
	{
		//����Ա���⴦����д�����ﲻ�ã��ƻ��˳���Ľṹ������
		if((worldstate.GetPlayMode() == PM_Opp_Back_Pass_Kick
			 || worldstate.GetPlayMode() == PM_Opp_Indirect_Free_Kick)
		   && selfstate.GetUnum() == worldstate.GetTeammateGoalieUnum())
		{
			origin = Vector(-52.5, 0.0);
		}

		if(selfstate.GetPos().X() < -52.5
		   && fabs(selfstate.GetPos().Y()) < 7.0)
		{
			//�������ֻ���ڶ���������ǰ���ش���ʱ����
			tmp_fix = origin;
		}
		else
		{
			double radius;
			if(worldstate.GetPlayMode() == PM_Opp_Back_Pass_Kick)
			{
				radius = 7.10;//�Ŵ�һ��ɡ�
			}
			else
			{
				radius = ServerParam::instance().offsideKickMargin() + 0.5;//���зŴ�
			}
			Circle distBall(ball_pos, radius);
			//���Ŀ����ڴ�Բ������,��ôҪ��������
			if(distBall.IsWithin(origin))
			{
				AngleDeg target_dir = (origin - ball_pos).Dir();
				origin.SetX(ball_pos.X() + cos(target_dir * M_PI / 180.0) * radius);
				origin.SetY(ball_pos.Y() + sin(target_dir * M_PI / 180.0) * radius);
			}
			Line  runLine(my_pos,origin);
			Vector projectPoint = runLine.GetProjectPoint(ball_pos);
			if(runLine.IsInBetween(projectPoint, my_pos, origin)
			   && runLine.Dist(ball_pos) < radius)
			{
				//��Բ
				tmp_fix = GoContactLine(agent, radius, projectPoint);
			}
			else
			{
				tmp_fix = origin;
			}
		}
	}
	else if(routeline.IsInBetween(ball_pos, my_pos, origin)
			&&routeline.Dist(ball_pos)< ServerParam::instance().offsideKickMargin() + 0.05
			&&ServerParam::instance().pitchRectanglar().IsWithin(my_pos))
	{
		Vector tag_point = routeline.GetProjectPoint(ball_pos);
		Vector tmp;
		int count = 0;
		Line newroute;
		do{
			Ray Vertical(ball_pos, (tag_point-ball_pos).Dir());
			tmp = Vertical.GetPoint(10.00);
			newroute = Line(my_pos, tmp);
			tag_point = newroute.GetProjectPoint(ball_pos);
			count++;
        }while(newroute.Dist(ball_pos)< ServerParam::instance().offsideKickMargin()
			   &&count<5
			   &&newroute.IsInBetween(tag_point, my_pos, tmp));
		tmp_fix = tmp;
	}
	else if((52.5 - fabs(selfstate.GetPos().X()))< 1.5
			 && (52.5 - fabs(selfstate.GetPos().X())) > 0.0)
	{
		tmp_fix.SetX(-52.5);
		tmp_fix.SetY(selfstate.GetPos().Y());
	}
	else if((fabs(selfstate.GetPos().X()) - 52.5) > FLOAT_EPS)
	{
		tmp_fix.SetX(-52.5);
		tmp_fix.SetY(origin.Y());
	}
	else if((52.5 - fabs(selfstate.GetPos().X())) < 0.0)
	{
		if(selfstate.GetPos().Y() >= origin.Y()
			&& selfstate.GetPos().Y() > 7.02)
		{
			tmp_fix.SetX(ball_pos.X()+(selfstate.GetPos().X() - ball_pos.X()) * cos(10 * M_PI / 180) -(selfstate.GetPos().Y() - ball_pos.Y())*sin(10 * M_PI / 180));
			tmp_fix.SetY(ball_pos.Y()+sin(10 * M_PI / 180) * (selfstate.GetPos().X() - ball_pos.X()) +(selfstate.GetPos().Y() - ball_pos.Y()) * cos(10 * M_PI / 180));
		}
		else if(selfstate.GetPos().Y() < origin.Y()
				&& selfstate.GetPos().Y() < -7.02)
		{
			tmp_fix.SetX(ball_pos.X() +(selfstate.GetPos().X() - ball_pos.X()) * cos(10 * M_PI / 180)+(selfstate.GetPos().Y() - ball_pos.Y())*sin(10 * M_PI / 180));
			tmp_fix.SetY(ball_pos.Y() -sin(10 * M_PI / 180) * (selfstate.GetPos().X() - ball_pos.X()) +(selfstate.GetPos().Y() - ball_pos.Y()) * cos(10 * M_PI / 180));
		}
		else
		{
			tmp_fix.SetX(-52.5);
			tmp_fix.SetY(origin.Y());
		}
	}
	else if(routeline.IsInBetween(ball_pos, my_pos, origin)
			 && routeline.Dist(ball_pos)< 10.0 && selfstate.GetPos().Dist(ballstate.GetPos()) < 10.0)
	{
		if(selfstate.GetPos().Y() <= ball_pos.Y())
		{
			tmp_fix.SetX(ball_pos.X() +(selfstate.GetPos().X() - ball_pos.X()) * cos(10 * M_PI / 180)+(selfstate.GetPos().Y() - ball_pos.Y())*sin(10 * M_PI / 180));
			tmp_fix.SetY(ball_pos.Y() -sin(10 * M_PI / 180) * (selfstate.GetPos().X() - ball_pos.X()) +(selfstate.GetPos().Y() - ball_pos.Y()) * cos(10 * M_PI / 180));
		}
		else
		{
			tmp_fix.SetY(ball_pos.X()+(selfstate.GetPos().X() - ball_pos.X()) * cos(10 * M_PI / 180) -(selfstate.GetPos().Y() - ball_pos.Y())*sin(10 * M_PI / 180));
			tmp_fix.SetY(ball_pos.Y()+sin(10 * M_PI / 180) * (selfstate.GetPos().X() - ball_pos.X()) +(selfstate.GetPos().Y() - ball_pos.Y()) * cos(10 * M_PI / 180));
		}
	}
	else
	{
		tmp_fix = origin;
	}

	if (worldstate.GetPlayMode() == PM_Opp_Offside_Kick) { //�ҷ���Ա���ܳ�����
		double max_x = worldstate.GetBall().GetPos().X() - 0.6;
		if (tmp_fix.X() > max_x) {
			tmp_fix.SetX(max_x);
		}
	}

	return tmp_fix;
}


/*
 * �ڶԷ�������ʱ���ҷ���Ա�ǲ��ܽ�������ģ���Ϊ���������1���Լ������ϡ�2,�Լ�����
 * ���ϡ��Լ�������ʱ����Ϊ�����������1��Ҫ����ĵ��ڽ�������2���Լ�Ҫ����㲻�ڽ�
 * ��������Ҫ����ĵ��·�߾��������������1����ѡ����Ҫ����ĵ�ȽϽ��ĵ���С������2��
 * ��Ҫ�ƿ����������ܵ�����2,��ҪĿ���ǽ����򳡡�
 *
 * ������Vector Origin; ����Ҫ�������λ�㡣
 * ����ֵ��������·�ߺ���Ҫ������м�㣨Ҳ��������Ҫ����ĵ㣩��
 */

/*
 * Avoid the penalty area when the opponent team taking a goal kick.
 * @param agent the agent itself.
 * @param origin the origin position to go to.
 * @return new target position fixed from the origin one.
 */
Vector Dasher::AvoidPenaltyArea(const Agent &agent, Vector origin)
{
	const PlayerState &selfstate = agent.GetSelf();

	if(selfstate.GetPos().X()
		<= ServerParam::instance().PITCH_LENGTH*0.5 - ServerParam::instance().PENALTY_AREA_LENGTH
	   && origin.X() <= ServerParam::instance().PITCH_LENGTH *0.5-ServerParam::instance().PENALTY_AREA_LENGTH)
	{
		return origin;
	}

	const Vector & my_pos = selfstate.GetPos();

	Vector l_front = Vector(ServerParam::instance().PITCH_LENGTH *0.5-ServerParam::instance().PENALTY_AREA_LENGTH,
							- ServerParam::instance().PENALTY_AREA_WIDTH*0.5);
	Vector l_bottom = Vector(ServerParam::instance().PITCH_LENGTH * 0.5,
			                 -ServerParam::instance().PENALTY_AREA_WIDTH*0.5);
	Vector r_front = Vector(ServerParam::instance().PITCH_LENGTH *0.5-ServerParam::instance().PENALTY_AREA_LENGTH,
			                ServerParam::instance().PENALTY_AREA_WIDTH*0.5);
	Vector r_bottom = Vector(ServerParam::instance().PITCH_LENGTH *0.5,
			                 ServerParam::instance().PENALTY_AREA_WIDTH*0.5);


	if(ServerParam::instance().oppPenaltyArea().IsWithin(origin))
	{
		//ѡ���µ�Ŀ���
		if(!ServerParam::instance().pitchRectanglar().IsWithin(selfstate.GetPos()))
		{ //���ڳ��ڣ��Ƚ�ȥ
			Ray routeray(my_pos,(origin-my_pos).Dir());
			Line bottomline(l_bottom, r_bottom);
			if(bottomline.Intersection(routeray, origin))
			{
				origin = selfstate.GetPos().Y() >= 0
				? Vector(ServerParam::instance().PITCH_LENGTH *0.5-0.1, ServerParam::instance().PENALTY_AREA_WIDTH*0.5+0.1)
						: Vector(ServerParam::instance().PITCH_LENGTH *0.5-0.1, -ServerParam::instance().PENALTY_AREA_WIDTH*0.5-0.1);
			}else
			{
				if(selfstate.GetPos().Y() >= 0)
				{
					Line r_line(r_front, r_bottom);
					r_line.Intersection(routeray, origin);
				}else
				{
					Line l_line(l_front, l_bottom);
					l_line.Intersection(routeray, origin);
				}
			}
		}else
		{
			Vector pt1 = Vector(origin.X(), origin.Y()>0?
					ServerParam::instance().PENALTY_AREA_WIDTH*0.5+FLOAT_EPS: -ServerParam::instance().PENALTY_AREA_WIDTH*0.5-FLOAT_EPS);
			Vector pt2 = Vector(ServerParam::instance().PITCH_LENGTH *0.5 -ServerParam::instance().PENALTY_AREA_LENGTH-FLOAT_EPS, origin.Y());

			if (pt1.Dist(origin) <= pt2.Dist(origin)) {
				origin = pt1;
			}
			else {
				origin = pt2;
			}
		}
	}

	//����Ŀ���
	if(selfstate.GetPos().X() <= ServerParam::instance().PITCH_LENGTH*0.5 - ServerParam::instance().PENALTY_AREA_LENGTH
	   && origin.X() <= ServerParam::instance().PITCH_LENGTH *0.5-ServerParam::instance().PENALTY_AREA_LENGTH)
	{
		return origin;
	}

	Vector fix_point;
	Ray routeray(my_pos,(origin-my_pos).Dir());

	//modified by zzz [2008/7/6]
	Vector intersection_point;
	Line frontline(l_front, r_front);
	if(frontline.Intersection(routeray, intersection_point))
	{
		//��Ŀ�������������ǰ���н���
		if(fabs(intersection_point.Y()) >= ServerParam::instance().PENALTY_AREA_WIDTH * 0.5 + 0.5)//���зŴ�
		{
			//����Ҫ�Ƶ���
			fix_point = origin;
		}
		else
		{
			if(intersection_point.Y() > 0)
			{
				//���ߵ��ҽ����������ǰ�ߵĽ��㴦
				fix_point.SetX(ServerParam::instance().PITCH_LENGTH * 0.5 -ServerParam::instance().PENALTY_AREA_LENGTH - 1.0);
				fix_point.SetY(ServerParam::instance().PENALTY_AREA_WIDTH * 0.5 + 1.0);
			}
			else
			{
				//���ߵ�������������ǰ�ߵĽ��㴦
				fix_point.SetX(ServerParam::instance().PITCH_LENGTH * 0.5 -ServerParam::instance().PENALTY_AREA_LENGTH - 1.0);
				fix_point.SetY(- ServerParam::instance().PENALTY_AREA_WIDTH * 0.5 - 1.0);
			}
		}
	}
	else
	{
		//��Ŀ�������������ǰ��û�н��㣬��ʱ��ֱ���߹�ȥ
		fix_point = origin;
	}

    origin = fix_point;
	return origin;
}
/**
 *���ܣ�һ��ģʽ�£�������Բ���ϰ���ʱ��Բ������
 *������Բ�İ뾶�����λ������Ա�˶�ֱ���ϵ�Ͷ���
 *author:zhangzongzhang
 *date: 2008/7/9
**/
/*
 * Caculate a contact line of the forbidden circle to go along when avoiding the circle.
 * @param agent the agent itself.
 * @param radius the radius of the cycle.
 * @param project_point the intend position to go to.
 * @return new target position fixed from the origin one.
 */
Vector Dasher::GoContactLine(const Agent &agent, double radius, Vector project_point)
{
	const PlayerState &selfstate = agent.GetSelf();
	const BallState	&ballstate = agent.GetWorldState().GetBall();
	const WorldState	&worldstate	= agent.GetWorldState();
	Vector target_point;
	const Vector & my_pos = selfstate.GetPos();
	const Vector & last_mypos = worldstate.GetHistory(1)->GetTeammate(selfstate.GetUnum()).GetPos();
	const Vector & ball_pos = ballstate.GetPos();

	//���������ߵĻ��������Ա��ת�����ߵñȽ�����������γ����Ϊ�˿˷����ȱ��
//	if(WS.GetLastPlayMode() == WS.GetPlayMode()
//	   //&& lastTargetPoint.Dist(MyPos) > 1.0��Ҫ��ʷ��Ϣ��
//		&& MyPos.Dist(BallPos) < radius + 2.5
//		&& lastMyPos.Dist(MyPos) >= 0.5)
//	{
//		targetPoint = lastTargetPoint;
//	}
//	else
	//{
		double slope = my_pos.Dist(ball_pos);
		double length;
		//Բ�뾶�����Ŵ��������ɱ����쳣
		if(slope * slope - radius * radius >= 0)
		{
			length = sqrt(slope * slope - radius * radius);
		}
		else
		{
			length = 0.0;
		}
		AngleDeg angle = ASin(radius / slope);
		if(my_pos.Y() < ball_pos.Y())
		{
			//��Ա��������
			AngleDeg ballDir = (ball_pos - my_pos).Dir();
			AngleDeg leftDir = ballDir - angle;
			AngleDeg destDir = (project_point - my_pos).Dir();
			if(destDir >= leftDir && destDir < ballDir)
			{
			angle = - angle;
		}
		}
		else
		{
			//��Ա������ұ�
			AngleDeg ballDir = (ball_pos - my_pos).Dir();
			AngleDeg destDir = (project_point - my_pos).Dir();
			AngleDeg leftDir = ballDir - angle;
			if(destDir > 0)
			{
				destDir -= 360;
			}
			if(destDir >= leftDir && destDir < ballDir)
			{
				angle = - angle;
			}
		}
		angle = (ball_pos - my_pos).Dir() + angle;
		Vector contact_point;//�е�
		contact_point.SetX(my_pos.X() + cos(angle * 3.1415926 / 180.0) * length);
		contact_point.SetY(my_pos.Y() + sin(angle * 3.1415926 / 180.0) * length);
		if(my_pos.Dist(contact_point) >= 1.0)
		{
			target_point = contact_point;
		}
		else
		{
			double buffer_for_avoidcirle = 0.0;
			//bufferForAvoidCirle��Ϊ������ʹ��������������һ�㣬������Ա�Ͳ���嵽Բ��
			//bufferForAvoidCirle��ȴ�Լ���
			//���ߵ�������Ҫһ������ת������һ�����ڲ��ܹ���ָ��λ����
			if(worldstate.GetLastPlayMode() == worldstate.GetPlayMode() && last_mypos.Dist(my_pos) < 0.5)
			{
				if(buffer_for_avoidcirle < 0.0 || buffer_for_avoidcirle > 45.0)
				{
					//����������������Ϊû����ֵ
					buffer_for_avoidcirle = 0.0;
				}
				if((worldstate.CurrentTime().T() + worldstate.CurrentTime().S()) % 2 == 0)
				{
					buffer_for_avoidcirle += 5.0;
					if(buffer_for_avoidcirle > 45.0)
					{
						buffer_for_avoidcirle = 45.0;
					}
				}
			}
			else
			{
				buffer_for_avoidcirle = 0.0;
			}

			if(my_pos.X() > ball_pos.X() && my_pos.Y() > ball_pos.Y())//��Ա�������ǰ��
			{
				if(project_point.Y() < ball_pos.Y()
					|| project_point.X() > my_pos.X())
				{
					contact_point.SetX(my_pos.X()
							+ fabs(my_pos.Y() - ball_pos.Y())
							+ my_pos.Dist(ball_pos) * sin(buffer_for_avoidcirle * 3.1415926 / 180.0));
					contact_point.SetY(my_pos.Y() - fabs(my_pos.X() - ball_pos.X()));
				}
				else
				{
					contact_point.SetX(my_pos.X() - fabs(my_pos.Y() - ball_pos.Y()));
					contact_point.SetY(my_pos.Y() + fabs(my_pos.X() - ball_pos.X())
							+ my_pos.Dist(ball_pos) * sin(buffer_for_avoidcirle * 3.1415926 / 180.0));
				}
			}
			else if(my_pos.X() <= ball_pos.X() && my_pos.Y() > ball_pos.Y())//��Ա������Һ�
			{
				if(project_point.Y() < ball_pos.Y() || project_point.X() < my_pos.X())
				{
					contact_point.SetX(my_pos.X() - fabs(my_pos.Y() - ball_pos.Y())
							- my_pos.Dist(ball_pos) * sin(buffer_for_avoidcirle * 3.1415926 / 180.0));
					contact_point.SetY(my_pos.Y() - fabs(my_pos.X() - ball_pos.X()));
				}
				else
				{
					contact_point.SetX(my_pos.X() + fabs(my_pos.Y() - ball_pos.Y()));
					contact_point.SetY(my_pos.Y() + fabs(my_pos.X() - ball_pos.X())
							+ my_pos.Dist(ball_pos) * sin(buffer_for_avoidcirle * 3.1415926 / 180.0));
				}
			}
			else if(my_pos.X() < ball_pos.X() && my_pos.Y() <= ball_pos.Y())//��Ա��������
			{
				if(project_point.X() < my_pos.X()
					|| project_point.Y() > ball_pos.Y())
				{
					contact_point.SetX(my_pos.X() - fabs(my_pos.Y() - ball_pos.Y())
							- my_pos.Dist(ball_pos) * sin(buffer_for_avoidcirle * 3.1415926 / 180.0));
					contact_point.SetY(my_pos.Y() + fabs(my_pos.X() - ball_pos.X()));
				}
				else
				{
					contact_point.SetX(my_pos.X() + fabs(my_pos.Y() - ball_pos.Y()));
					contact_point.SetY(my_pos.Y() - fabs(my_pos.X() - ball_pos.X())
							- my_pos.Dist(ball_pos) * sin(buffer_for_avoidcirle * 3.1415926 / 180.0));
				}
			}
			else//��Ա�������ǰ��
			{
				if(project_point.X() > my_pos.X() || project_point.Y() > ball_pos.Y())
				{
					contact_point.SetX(my_pos.X() + fabs(my_pos.Y() - ball_pos.Y())
							+ my_pos.Dist(ball_pos) * sin(buffer_for_avoidcirle * 3.1415926 / 180.0));
					contact_point.SetY(my_pos.Y() + fabs(my_pos.X() - ball_pos.X()));
				}
				else
				{
					contact_point.SetX(my_pos.X() - fabs(my_pos.Y() - ball_pos.Y()));
					contact_point.SetY(my_pos.Y() - fabs(my_pos.X() - ball_pos.X())
							- my_pos.Dist(ball_pos) * sin(buffer_for_avoidcirle * 3.1415926 / 180.0));
				}
			}

			target_point = contact_point;
		}
	//}
	//lastTargetPoint = targetPoint;

	return target_point;
}
// end of Dasher.cpp
