/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef COMMUNICATESYSTEM_H_
#define COMMUNICATESYSTEM_H_

#ifdef WIN32
#include <Winsock2.h>
#include <windows.h>
#else
#include <stdint.h>
#endif

#include "Types.h"
#include "Geometry.h"
#include "BehaviorBase.h"
#include "HearMessage.h"

class WorldState;
class BallState;
class Observer;
class Agent;

class CommunicateSystem {

	Observer *mpObserver;
	Agent* mpAgent;

	CommunicateSystem();

public:
	virtual ~CommunicateSystem();

    static CommunicateSystem & instance();

    /*
     * Initial the observer and agent.
     */
    void Initial(Observer *observer , Agent* agent);

	/**
	 * reset some values at the beginning of every cycle and deal with hear message from server
	 */
	void Update();

	/**
	 * send say message to server
	 */
	void Decision();

	/*
	 * Parsing the messages received from teammate.
	 * \param msg pointer to a c style string received this cycle.
	 */
	void ParseReceivedTeammateMsg(char *msg);

	/*
	 * Parsing the messages received from our coach.
	 * \param msg pointer to a c style string received this cycle.
	 */
	void ParseReceivedOurCoachMsg(char *msg);

public:

    /**
     * Point to a certain point.
     * @param target target point��global position��.
     * @return true means success.
     */
    bool Pointto(Vector target);

    /**
     * Cancel the point to command.
     * @return true means success.
     */
    bool PointtoOff();

	/**
	 * Used to save hear message
	 */
	HearMessage mHM;

private:
    Time mLastPointTime;
};

#endif /* COMMUNICATESYSTEM_H_ */
