/************************************************************************************
 * WrightEagle (Soccer Simulation League 2D)                                        *
 * BASE SOURCE CODE RELEASE 2009                                                    *
 * Copyright (C) 1998-2009 WrightEagle 2D Soccer Simulation Team,                   *
 *                         Multi-Agent Systems Lab.,                                *
 *                         School of Computer Science and Technology,               *
 *                         University of Science and Technology of China, China.    *
 *                                                                                  *
 * This program is free software; you can redistribute it and/or                    *
 * modify it under the terms of the GNU General Public License                      *
 * as published by the Free Software Foundation; either version 2                   *
 * of the License, or (at your option) any later version.                           *
 *                                                                                  *
 * This program is distributed in the hope that it will be useful,                  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                    *
 * GNU General Public License for more details.                                     *
 *                                                                                  *
 * You should have received a copy of the GNU General Public License                *
 * along with this program; if not, write to the Free Software                      *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.  *
 ************************************************************************************/

#ifndef __Parser_H__
#define __Parser_H__

#include <set>
#include "Types.h"
#include "Thread.h"
#include "TeamGraphic.h"

class Observer;

class Parser
{
	Observer *mpObserver;

public:
    /**
     * ���캯������������
     */
    Parser(Observer *p_observer);
    ~Parser();

    /**
     * ��ѭ������
     */
    /**
     * The main loop of parser.
     */
    void ParserLoop();

    	/**
	 * Parse the message.
	 * @param msg the message to parse.
	 */
    	void Parse(char *msg);

	/**
	 * Parse the initialize message.
	 * @param msg the message to parse.
	 */
	bool ParseInitializeMsg(char *msg);

private:
	/**
	 * Try to connect to the server.
	 */
	void ConnectToServer();

	/**
	 * Send the initiallize message to the server.
	 */
	void SendInitialLizeMsg();

	/**
	 * Parse the message from server.
	 * @param msg the message received from server.
	 */
	void ParseServerParam(char *msg);

	/**
	 * Parse the player parameters.
	 * @param msg the message received from server.
	 */
	void ParsePlayerParam(char *msg);

	/**
	 * Parse the player type.
	 * @param msg the message received from server.
	 */
	void ParsePlayerType(char *msg);

	/**
	 * Parse the time.
	 * @param msg the message received from server.
	 * @param end_ptr the end pointer of the whole message.
	 * @param is_new_cycle true means the message comes from a new cycle.
	 */
	void ParseTime(char *msg, char **end_ptr, bool is_new_cycle = false);

	/**
	 * Parse the play mode.
	 * @param msg the message received from server.
	 */
	void ParsePlayMode(char *msg);

	/**
	 * Parse sense message.
	 * @param msg the message received from server.
	 */
	void ParseSense(char *msg);

	/**
	 * Parse sight message.
	 * @param msg the message received from server.
	 */
	void ParseSight(char *msg);

	/**
	 * Parse signt message for coach.
	 * @param msg the message received from server.
	 */
	void ParseSight_Coach(char *msg);

	/**
	 * Parse sound.
	 * @param msg the message received from server.
	 */
	void ParseSound(char *msg);

	/**
	 * Parse the change player type message.
	 * @param msg the message received from server.
	 */
	void ParseChangePlayerType(char *msg);

	/**
	 * Parse the ok message.
	 * @param msg the message received from server.
	 */
	void ParseOkMsg(char *msg);

	ServerPlayMode mLastServerPlayMode;

	struct ObjType {
		ObjType(): type(OBJ_None), marker(FLAG_NONE), line(SL_NONE), side('?'), num(0){}
		ObjectType type;
		MarkerType marker;
		SideLineType line;
		char side;
		Unum num;
	};

	struct ObjProperty {
		ObjProperty(): dist(INVALID_VALUE), dir(INVALID_VALUE), dist_chg(INVALID_VALUE),
			dir_chg(INVALID_VALUE), body_dir(INVALID_VALUE), head_dir(INVALID_VALUE),
			pointing(false), point_dir(INVALID_VALUE), tackling(false), kicked(false){}
		double dist;
		double dir;
		double dist_chg;
		double dir_chg;
		AngleDeg body_dir;
		AngleDeg head_dir;
		bool pointing;
		AngleDeg point_dir;
		bool tackling;
		bool kicked;
	};

	struct ObjProperty_Coach {
		ObjProperty_Coach(): x(INVALID_VALUE), y(INVALID_VALUE), vx(INVALID_VALUE), vy(INVALID_VALUE),
		body_dir(INVALID_VALUE), head_dir(INVALID_VALUE), pointing(false), point_dir(INVALID_VALUE), tackling(false){}
		double x;
		double y;
		double vx;
		double vy;
		AngleDeg body_dir;
		AngleDeg head_dir;
		bool pointing;
		AngleDeg point_dir;
		bool tackling;
	};

	/**
	 * Parse the object type.
	 * @param msg the message received from server.
	 */
	ObjType ParseObjType(char *msg);

	/**
	 * Parse the Goal.
	 * @param msg the message received from server.
	 */
	ObjType ParseGoal(char *msg);

	/**
	 * Parse the marker.
	 * @param msg the message received from server.
	 */
	ObjType ParseMarker(char *msg);

	/**
	 * Parse line.
	 * @param msg the message received from server.
	 */
	ObjType ParseLine(char *msg);

	/**
	 * Parse player.
	 * @param msg the message received from server.
	 */
	ObjType ParsePlayer(char *msg);

	/**
	 * Parse the ball.
	 * @param msg the message received from server.
	 */
	ObjType ParseBall(char *msg);

	/**
	 * Parse the property of a certain object.
	 * @param msg the message received from server.
	 */
	ObjProperty ParseObjProperty(char* msg);

	/**
	 * Parse the property of a certain object for coach.
	 * @param msg the message received from server.
	 */
	ObjProperty_Coach ParseObjProperty_Coach(char* msg);

	//the thread for parsing ok msg should be mutex with the decision thread.
	ThreadMutex mOkMutex; //����ok��Ϣ��Ҫ������̻߳���
	int mHalfTime; // ��¼�ǵڼ���half
    bool mConnectServerOk;
	bool mClangOk;
	bool mSynchOk;
	bool mEyeOnOk; //only used when is coach
	bool mChangePlayerTypeOk[TEAMSIZE + 1];
	static char mBuf[MAX_MESSAGE];

public:
	/**
	 * Check if connected to the server.
	 * @return true means connected ok.
	 */
    bool IsConnectServerOk() { bool ret; mOkMutex.Lock(); ret = mConnectServerOk; mOkMutex.UnLock(); return ret; }

    	/**
	 * Check if clang ok.
	 * @return true means clang ok.
	 */
	bool IsClangOk() { bool ret; mOkMutex.Lock(); ret = mClangOk; mOkMutex.UnLock(); return ret; }

	/**
	 * Check if synch see ok.
	 * @return true means synch see ok.
	 */
	bool IsSyncOk() { bool ret; mOkMutex.Lock(); ret = mSynchOk; mOkMutex.UnLock(); return ret; }

	/**
	 * Check if eye on ok.
	 * @return true means eye on ok.
	 */
	bool IsEyeOnOk() { bool ret; mOkMutex.Lock(); ret = mEyeOnOk; mOkMutex.UnLock(); return ret; }

	/**
	 * Check if change player type ok.
	 * @return true means change player type ok.
	 */
	bool IsChangePlayerTypeOk(Unum i) { bool ret; mOkMutex.Lock(); ret = mChangePlayerTypeOk[i]; mOkMutex.UnLock(); return ret; }

	/**
	 * Check if is player types ready.
	 * @return true means they're ready.
	 */
	static bool IsPlayerTypesReady() { return mIsPlayerTypesReady; }

private:
	static bool mIsPlayerTypesReady;
	static const double INVALID_VALUE;

public:
    /*!
      \brief get team_graphic ok flags
      \return const reference to the flag container
    */
    const std::set<TeamGraphic::Index> & GetTeamGraphicOkSet() const
    {
        return mTeamGraphicOkSet;
    }

private:
    //! the flags for team_graphic ok message
    std::set<TeamGraphic::Index> mTeamGraphicOkSet;

    /*!
      \brief analyze ok team_graphic_? message
      \param msg raw server message
    */
    void ParseOkTeamGraphic(const char * msg);
};


#endif
