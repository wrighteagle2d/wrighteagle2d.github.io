#!/bin/bash

sudo mv sources.list /etc/apt/sources.list

sudo apt-get update

sudo apt-get install -y build-essential libboost-all-dev bison flex 

sudo apt-get install -y libqt4-dev libxpm-dev libaudio-dev libxt-dev libpng-dev libglib2.0-dev libfreetype6-dev libxrender-dev libxext-dev libfontconfig-dev libxi-dev

cd rcssserver-15.0.1
./configure
make
sudo make install
cd ..


cd rcsslogplayer-15.0.0
./configure --disable-gl
make
sudo make install
cd ..

cd rcssmonitor-15.0.0
./configure
make
sudo make install
cd ..

sudo ldconfig

